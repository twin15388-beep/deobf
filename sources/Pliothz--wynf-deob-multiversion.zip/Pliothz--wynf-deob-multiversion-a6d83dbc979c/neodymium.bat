@echo off
python "%~dp0neodymium.py" %*
if "%~1"=="" pause
