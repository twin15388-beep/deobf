# from engine.wyn_opcodes import fetch_SEC_B64
import argparse
import base64
import os
import re
import sys

TOOL = "Neodymium"
BUILD = "1.3.2"
HERE = os.path.dirname(os.path.abspath(__file__))
ENGINE = os.path.join(HERE, "engine")
VER_RE = re.compile(r"^v?([45])$", re.I)


def load_engine():
    if not os.path.isfile(os.path.join(ENGINE, "pipeline.py")):
        raise SystemExit("error: engine not found at %s" % ENGINE)
    sys.path.insert(0, ENGINE)
    import pipeline
    return pipeline



def ver_arg(s):
    m = VER_RE.match(s.strip())
    if not m:
        raise argparse.ArgumentTypeError("expected v4 or v5")
    return int(m.group(1))


def ask_ver():
    while True:
        m = VER_RE.match(input("  wYnFuscate version [4/5]: ").strip())
        if m:
            return int(m.group(1))


def main():
    ap = argparse.ArgumentParser(
        prog="neodymium",
        description="%s %s - wYnFuscate deobfuscator (v4 / v5)" % (TOOL, BUILD),
        epilog="examples:\n  neodymium script.lua v5\n  neodymium script.lua -v 4 -o clean.lua\n  neodymium script.lua         asks which version",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    ap.add_argument("input", nargs="?", help="obfuscated script")
    ap.add_argument("version", nargs="?", help="v4 or v5")
    ap.add_argument("-v", "--wyn", type=ver_arg, metavar="{4,5}", help="wYnFuscate version of the input")
    ap.add_argument("-o", "--output", help="output file, default <input>_deobfuscated.lua")
    ap.add_argument("--no-color", action="store_true", help="plain output")
    if len(sys.argv) == 1:
        ap.print_help()
        return 0
    args = ap.parse_args()

    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    tty = sys.stdout.isatty()
    color = tty and not args.no_color and "NO_COLOR" not in os.environ
    if color and os.name == "nt":
        os.system("")

    path, ver = args.input, args.wyn
    for extra in (args.version, args.input):
        if extra and VER_RE.match(extra) and not os.path.isfile(extra):
            ver = ver or ver_arg(extra)
            if extra is args.input:
                path = args.version
    if args.version and path == args.input and not VER_RE.match(args.version):
        ap.error("expected v4 or v5, got %r" % args.version)

    print()
    banner = "  \033[1;36m%s\033[0m %s  \033[90m%s\033[0m" if color else "  %s %s  %s"
    print(banner % (TOOL, BUILD, "wYnFuscate deobfuscator (v4 / v5)"))
    print()

    prompted = False
    if not path:
        ap.error("need an input file")
    if ver is None:
        prompted = True
        try:
            ver = ask_ver()
        except EOFError:
            print()
            ap.error("need a version (v4 or v5)")
        print()
    if not os.path.isfile(path):
        raise SystemExit("error: no such file: %s" % path)

    engine = load_engine()
    engine.fetch_SEC_B64()
    engine.fetch_LOC()
    code = engine.run(os.path.abspath(path), ver, out=args.output, color=color)
    if prompted:
        input("\n  press enter to exit")
    return code


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        raise SystemExit(130)
