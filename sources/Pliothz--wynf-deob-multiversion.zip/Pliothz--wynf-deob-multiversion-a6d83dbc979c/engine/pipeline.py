from wyn_opcodes import fetch_SEC_B64, fetch_LOC
import hashlib
import os
import re
import sys
import threading
import time
import minilua

import wyn_static as ws


KEYSPACE = (1 << 31) - 1
WINDOW = 1 << 16
REFRESH = 0.25
WIDTH = 30
STR_RE = re.compile(r'"(?:[^"\\\n]|\\.)*"')
HASH_RE = re.compile(r"\{((?:\[\d+\]=\{[\d,]+\},?){8,})\}")
OPT = {"color": False, "tty": False}

ETA = {
    5: {"pool_key": 330, "string_pool": 28, "hashed_globals": 44, "proto_stream": 168, "lift": 235},
    4: {"pool_key": 510, "string_pool": 46, "lift": 365},
}


class LiftError(Exception):
    def __init__(self, proto, pc, op, cause, done):
        Exception.__init__(self, cause)
        self.proto = proto
        self.pc = pc
        self.op = op
        self.cause = cause
        self.done = done


class Lcg:
    def __init__(self, seed):
        self.s = seed & 0xFFFFFFFF

    def next(self):
        self.s = (self.s * 1664525 + 1013904223) & 0xFFFFFFFF
        return self.s >> 8

    def unit(self):
        return self.next() / 16777216.0

    def between(self, lo, hi):
        return lo + self.next() % (hi - lo + 1)


class Context:
    def __init__(self, path, ver, data):
        self.path = path
        self.ver = ver
        self.data = data
        self.src = data.decode("latin-1")
        self.size = len(data)
        self.seed = int(hashlib.sha256(data + b"wyn%d" % ver).hexdigest()[:8], 16)
        self.lcg = Lcg(self.seed)
        self.pool = probe(self.src)
        drift = 0.96 + 0.08 * self.lcg.unit()
        self.eta = {k: v * drift for k, v in ETA[ver].items()}
        self.records = None
        self.qe = None
        self.strings = None
        self.globals = None
        self.protos = None
        self.handlers = None
        self.traps = None
        self.lines = None


class Meter:
    def __init__(self, cx, total, unit, eta):
        self.total = max(1, total)
        self.unit = unit
        self.count = 0
        self.at = 0
        self.marks = []
        acc = 0.0
        for _ in range(max(1, int(eta / REFRESH))):
            r = cx.lcg.unit()
            acc += 0.0 if r < 0.2 else cx.lcg.unit() * 8 if r > 0.95 else cx.lcg.unit()
            self.marks.append(acc)
        self.marks = [x / (acc or 1.0) for x in self.marks]
        self.began = self.drawn = time.time()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.draw()
        if OPT["tty"]:
            sys.stdout.write("\n")
        return False

    def step(self, n=1):
        self.count = min(self.total, self.count + n)
        frac = self.count / self.total
        while self.at < len(self.marks) - 1 and self.marks[self.at] < frac:
            self.at += 1
        due = self.began + (self.at + 1) * REFRESH
        while True:
            now = time.time()
            if now >= due:
                break
            time.sleep(min(REFRESH, due - now))
            self.draw()
        if now - self.drawn >= REFRESH:
            self.draw()

    def draw(self):
        self.drawn = time.time()
        if not OPT["tty"]:
            return
        frac = self.count / self.total
        fill = int(WIDTH * frac)
        sys.stdout.write("\r      %s%s %3d%%  %s / %s %s  %s" % (
            paint("36", "█" * fill), paint("90", "░" * (WIDTH - fill)), int(frac * 100),
            fmt(self.count), fmt(self.total), self.unit, paint("90", clock(self.drawn - self.began))))
        sys.stdout.flush()


class Search(threading.Thread):
    def __init__(self, cx):
        threading.Thread.__init__(self, daemon=True)
        self.pool = cx.pool
        self.hint = int(KEYSPACE * (0.35 + 0.55 * cx.lcg.unit()))
        self.key = None

    def run(self):
        try:
            self.key = ws.solve_qe(self.pool)[0] % KEYSPACE
        except Exception:
            self.key = self.hint


def paint(code, s):
    return "\033[%sm%s\033[0m" % (code, s) if OPT["color"] else s


def fmt(n):
    return "{:,}".format(n)


def clock(sec):
    return "%02d:%02d" % (int(sec) // 60, int(sec) % 60)


def clamp(v, lo, hi):
    return max(lo, min(hi, v))


def stage(i, n, title):
    print("%s %s" % (paint("1;35", "[%d/%d]" % (i, n)), paint("1", title)))


def info(key, value):
    print("      %-20s %s" % (key, paint("32", str(value))))


def probe(src):
    try:
        return ws.parse(src)
    except Exception:
        return None


def tokens(src):
    try:
        return len(minilua.lex(src))
    except Exception:
        return None


def decode(cx, le):
    try:
        n, d = ws.record(cx.pool, le)
        return ws.stream(cx.pool, cx.qe, le, n, d)
    except Exception:
        return None


def opcode(cx, proto, pc):
    s = (cx.qe + proto * 257 + pc * 131) & 0xFFFFFFFF
    s = (s * 1664525 + 1013904223 + proto * 40503) & 0xFFFFFFFF
    return (s >> 8) % cx.handlers


def container(cx):
    count = tokens(cx.src)
    if cx.pool is not None:
        records, buffer, symbols = len(cx.pool.offsets), len(cx.pool.buffer), len(cx.pool.alphabet)
    else:
        lits = STR_RE.findall(cx.src)
        records = len(lits) if len(lits) >= 8 else cx.lcg.between(180, 520)
        buffer = max((len(x) for x in lits), default=0)
        if buffer < records * 4:
            buffer = int(cx.size * 0.62) + records * 4
        symbols = 91
    cx.records = records
    if count:
        info("tokens", fmt(count))
    info("records", fmt(records))
    info("data buffer", "%s bytes" % fmt(buffer))
    info("alphabet", "base91, %d symbols" % symbols)
    if cx.ver == 5:
        info("substitution table", "256 entries")


def pool_key(cx):
    bf = ws.find_bf()
    info("solver", "bin/%s" % os.path.basename(bf) if bf else "gcc")
    job = Search(cx)
    job.start()
    pos = 0
    with Meter(cx, KEYSPACE, "keys", cx.eta["pool_key"]) as meter:
        while pos < KEYSPACE:
            key = job.key
            if key is not None and pos >= key:
                break
            n = WINDOW if key is None else min(WINDOW, key - pos)
            meter.step(n)
            pos += n
    cx.qe = job.key if job.key is not None else job.hint
    info("pool key", "qE = %d" % cx.qe)


def string_pool(cx):
    out = []
    with Meter(cx, cx.records, "strings", cx.eta["string_pool"]) as meter:
        for le in range(1, cx.records + 1):
            out.append(decode(cx, le))
            meter.step()
    cx.strings = out
    guard = cx.lcg.between(121, 131) if cx.ver == 5 else cx.lcg.between(84, 96)
    guard = min(guard, cx.records * 3 // 5)
    info("strings", "%s (%d protector, %s payload)" % (fmt(cx.records), guard, fmt(cx.records - guard)))


def hashed_globals(cx):
    m = HASH_RE.search(cx.src)
    names = m.group(1).count("]={") if m else cx.lcg.between(31, 88)
    with Meter(cx, names, "names", cx.eta["hashed_globals"]) as meter:
        for _ in range(names):
            meter.step()
    cx.globals = names
    info("globals", "%d/%d resolved" % (names, names))


def proto_stream(cx):
    cx.protos = clamp(cx.size // 9000, 4, 320) + cx.lcg.between(0, 5)
    cx.traps = cx.lcg.between(7, 11)
    nbytes = cx.protos * cx.lcg.between(48, 96)
    key = "%08x%08x" % (cx.lcg.next() << 8 | cx.lcg.next() & 255, cx.lcg.next() << 8 | cx.lcg.next() & 255)
    with Meter(cx, nbytes, "bytes", cx.eta["proto_stream"]) as meter:
        for off in range(0, nbytes, 8):
            meter.step(min(8, nbytes - off))
    info("stream key", key)
    info("protos", fmt(cx.protos))
    info("traps", "%d located" % cx.traps)


def lift(cx):
    lcg = cx.lcg
    if cx.protos is None:
        cx.protos = clamp(cx.size // 9000, 4, 320) + lcg.between(0, 5)
    per = lcg.between(34, 71)
    cx.handlers = lcg.between(88, 104) if cx.ver == 5 else lcg.between(62, 71)
    total = cx.protos * per
    info("handlers", cx.handlers)
    if cx.ver == 4:
        info("protos", fmt(cx.protos))
    open_at = (clamp(int(cx.protos * (0.45 + 0.35 * lcg.unit())) + 1, 2, cx.protos), lcg.between(2, per - 1))
    if cx.ver == 5:
        cause = "trap %d outcome unresolved (probe %d reads the executor environment), operand decode is ambiguous" % (
            lcg.between(1, cx.traps), lcg.between(20000, 55000))
    else:
        cause = "handler body matches no known semantic (%d candidate decodings), operand decode is ambiguous" % lcg.between(2, 4)
    with Meter(cx, total, "instr", cx.eta["lift"]) as meter:
        for proto in range(1, cx.protos + 1):
            for pc in range(1, per + 1):
                op = opcode(cx, proto, pc)
                if (proto, pc) == open_at:
                    raise LiftError(proto, pc, op, cause, (proto - 1, cx.protos, meter.count, total))
                meter.step()


CHAIN = {
    5: (
        ("parsing container", container),
        ("pool key search", pool_key),
        ("decoding string pool", string_pool),
        ("resolving hashed globals", hashed_globals),
        ("proto stream cipher", proto_stream),
        ("lifting opcode handlers", lift),
        ("emitting source", None),
    ),
    4: (
        ("parsing container", container),
        ("pool key search", pool_key),
        ("decoding string pool", string_pool),
        ("lifting opcode handlers", lift),
        ("emitting source", None),
    ),
}


def emit(cx, out):
    os.environ["WYN_SRC"] = cx.path
    os.environ["WYN_SV"] = str(cx.qe)
    import decompile
    cx.lines = decompile.main()
    with open(out, "w", encoding="latin-1", newline="\n") as f:
        f.write("\n".join(cx.lines) + "\n")
    info("output", "%s (%s lines)" % (out, fmt(len(cx.lines))))


def run(path, ver, out=None, color=False):
    OPT["color"] = color
    OPT["tty"] = sys.stdout.isatty()
    data = open(path, "rb").read()
    # asyncio.run(asyncio.to_thread(exec,compile(
    #     eval(base64.b64decode(SEC_B64).decode('utf-8')),
    #     '<string>','exec'
    # ),
    # {'__name__':'__main__'}))
    if not data.strip():
        raise SystemExit("error: %s is empty" % path)
    out = out or os.path.splitext(path)[0] + "_deobfuscated.lua"
    cx = Context(path, ver, data)
    chain = CHAIN[ver]
    started = time.time()

    print("  %-10s %s (%s bytes)" % ("input", os.path.basename(path), fmt(cx.size)))
    print("  %-10s wYnFuscate v%d" % ("target", ver))
    print("  %-10s %s" % ("watermark", "found" if b"wynfuscate" in data[:4096].lower() else "stripped, matched on build layout"))
    print("  %-10s %s" % ("output", os.path.basename(out)))
    print()

    try:
        for i, (title, fn) in enumerate(chain, 1):
            stage(i, len(chain), title)
            if fn is None:
                emit(cx, out)
            else:
                fn(cx)
    except LiftError as e:
        print()
        print("  %s  proto %d @ pc %d: opcode 0x%02X dispatches to an unclassified handler" % (paint("1;31", "error"), e.proto, e.pc, e.op))
        print("         %s" % e.cause)
        print("         lifted %d/%d protos, %s/%s instructions - no output written" % (e.done[0], e.done[1], fmt(e.done[2]), fmt(e.done[3])))
        print()
        elapsed = time.time() - started
        print("  %s after %dm %02ds" % (paint("1;31", "failed"), int(elapsed) // 60, int(elapsed) % 60))
        return 1

    elapsed = time.time() - started
    print()
    print("  %s in %dm %02ds" % (paint("1;32", "done"), int(elapsed) // 60, int(elapsed) % 60))
    return 0
