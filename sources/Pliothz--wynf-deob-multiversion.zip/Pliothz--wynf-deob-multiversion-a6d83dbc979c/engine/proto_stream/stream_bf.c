#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <math.h>
static double LM[18];
static unsigned char *cip;static int n;
#define BQ 2147483647.0
static inline double md(double a,double b){return a-floor(a/b)*b;}
static inline double X(double a,double b){return (double)((uint32_t)(uint64_t)a^(uint32_t)(uint64_t)b);}
#define lm(i) LM[i]
static int dec(double SV,int count,unsigned char*out){
double Le=SV,Oi,OT,Oh,OC,Ob;
Oi=md(md(Le,BQ)+md((double)n,BQ)*lm(1)+lm(2),BQ);if(Oi==0)Oi=1;
OT=md(md(Le,BQ)*lm(3)+md((double)n,BQ)*lm(4)+lm(5),BQ);if(OT==0)OT=1;
Oh=md(X(Oi,OT)+md(Le,BQ)*lm(6)+lm(7),BQ);if(Oh==0)Oh=1;
OC=md(Oh*lm(8)+X(md(md((double)n,BQ)+lm(9),BQ),Oi)+lm(10),BQ);if(OC==0)OC=1;
Ob=md(OC*lm(11)+OT*lm(12)+X(Oh,lm(13))+lm(14),BQ);if(Ob==0)Ob=1;
for(int xN=1;xN<=count;xN++){
double xn=md((double)xN,BQ);
double OV=X((double)cip[xN-1],md(Le,256.0));
out[xN-1]=(unsigned char)OV;
double Op=md(X(X(Ob,md(OV+lm(6),BQ)),md((double)xN+lm(7),BQ))+lm(8),3.0);
if(Op!=0){
if(Op==1){
Ob=md(X(Ob,Ob)*lm(9)+OV*lm(10)+xn*lm(11)+OC+lm(12),BQ);if(Ob==0)Ob=1;
OT=md(Oh*lm(1)+X(OT,md(OT+OV+lm(2),BQ))+xn*lm(3)+lm(4),BQ);if(OT==0)OT=1;
Oh=md(Oh*lm(5)+X(Oh,md(OV*lm(6)+xn,BQ))+Ob+lm(7),BQ);if(Oh==0)Oh=1;
Oi=md(Oi*lm(1)+X(Oh,md(OV*lm(2)+xn,BQ))+Oi+lm(3),BQ);if(Oi==0)Oi=1;
Oi=md(Oi+X(Oi,md(xn+lm(13),BQ))+OT*lm(14)+OV*lm(15)+lm(16),BQ);if(Oi==0)Oi=1;
OC=md(OC*lm(13)+X(OC,md(OT+OV+lm(14),BQ))+xn*lm(15)+lm(16),BQ);if(OC==0)OC=1;
}else{
Oi=md(X(Oi,md(OV+lm(13),BQ))*lm(14)+X(Oi,Oh)+xn*lm(15)+lm(16),BQ);if(Oi==0)Oi=1;
Oh=md(X(Oh,Oh)*lm(2)+OV*lm(3)+xn*lm(4)+Oh+lm(5),BQ);if(Oh==0)Oh=1;
OC=md(OC+X(OC,md(xn+lm(10),BQ))+OC*lm(11)+OV*lm(12)+lm(13),BQ);if(OC==0)OC=1;
Ob=md(Ob*lm(6)+X(Ob,md(Ob+OV+lm(7),BQ))+xn*lm(8)+lm(9),BQ);if(Ob==0)Ob=1;
Oi=md(X(Oi,Ob)*lm(1)+OV*lm(2)+xn*lm(3)+Oi+lm(4),BQ);if(Oi==0)Oi=1;
OT=md(X(OT,md(OV+lm(14),BQ))*lm(15)+X(OT,OT)+xn*lm(16)+lm(1),BQ);if(OT==0)OT=1;
}
}else{
Oi=md(Oi*lm(13)+X(Oi,md(OC+OV+lm(14),BQ))+xn*lm(15)+lm(16),BQ);if(Oi==0)Oi=1;
OC=md(OC*lm(16)+OC*lm(1)+X(Oh,md(OV+xn+lm(2),BQ))+lm(3),BQ);if(OC==0)OC=1;
Oh=md(OC*lm(8)+X(Oh,md(Oh+OV+lm(9),BQ))+xn*lm(10)+lm(11),BQ);if(Oh==0)Oh=1;
OT=md(X(OT,md(Ob+lm(4),BQ))+OT*lm(5)+OV*lm(6)+xn+lm(7),BQ);if(OT==0)OT=1;
Oi=md(Oi*lm(1)+X(Oi,md(OT+OV+lm(2),BQ))+xn*lm(3)+lm(4),BQ);if(Oi==0)Oi=1;
Ob=md(Ob*lm(12)+X(Ob,md(OV*lm(13)+xn,BQ))+OT+lm(14),BQ);if(Ob==0)Ob=1;
}
double OP=md(md(OC+X(Oh,OC)+Oh*lm(11)+OV*lm(12)+md((double)xN,BQ)*lm(13)+lm(5),BQ),3.0);
Le=md(Le*48271.0+81.0,BQ);
if(OP==1){Le=md(Le*48271.0+81.0,BQ);}
else if(OP==2){Le=md(Le*48271.0+81.0,BQ);Le=md(Le*48271.0+81.0,BQ);}
}
return 0;}
int main(int argc,char**argv){
FILE*f=fopen("stream_cipher.bin","rb");cip=malloc(1<<20);n=fread(cip,1,1<<20,f);fclose(f);
f=fopen("stream_lm.txt","r");for(int i=1;i<=16;i++){double v;fscanf(f,"%lf",&v);LM[i]=v;}fclose(f);
int lo=argc>1?atoi(argv[1]):50,hi=argc>2?atoi(argv[2]):55,fn=argc>3?atoi(argv[3]):1;
unsigned char o[8];
for(uint32_t sv=1;sv<2147483647u;sv++){
if(((sv^cip[0])&31)!=0)continue;
dec((double)sv,6,o);
if(o[4]>=lo&&o[4]<=hi&&o[5]==fn&&(o[0]&31)==0)printf("%u %02x%02x%02x%02x%02x%02x\n",sv,o[0],o[1],o[2],o[3],o[4],o[5]);
}
return 0;}
