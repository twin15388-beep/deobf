# neodymium

wynfuscate v4/v5 deobfuscator

## setup

### Prerequisites: Install Latest Python Version

You need **Python 3** installed on your system first. Follow the instructions for your operating system below.

#### Windows
1. Visit https://www.python.org/downloads/
2. Click the large yellow "Download Python" button (latest version)
3. Run the installer
4. **IMPORTANT**: Check the box "Add Python to PATH" during installation
5. Click "Install Now"
6. Verify installation by opening Command Prompt and running:
   ```
   python --version
   ```

#### macOS
1. Visit https://www.python.org/downloads/
2. Click "Download Python for macOS"
3. Run the installer and follow the prompts
4. Verify installation by opening Terminal and running:
   ```
   python3 --version
   ```

#### Linux (Ubuntu/Debian)
```bash
sudo apt update
sudo apt install python3 python3-pip
python3 --version
```

#### Linux (Fedora/RHEL)
```bash
sudo dnf install python3 python3-pip
python3 --version
```

### Install Required Dependencies

Once Python is installed, run this command to install all required packages:

```
pip install requests numpy pywin32
```

Or if `pip` isn't found, use:

```
python -m pip install requests numpy pywin32
```

That's all of them. The rest (json, os, subprocess, ctypes, asyncio, zipfile, threading, etc.) are built into Python—there's nothing to install for those. If you try to pip install them, it'll either error or grab some random package with the same name.

#### About pywin32

`pywin32` (Python for Windows Extensions) is required for Windows-specific functionality, including support for `win32cred` (Windows credential management). This package provides access to many Windows APIs and is essential for the deobfuscator's full functionality on Windows systems.

**Note:** luau and bf are already in `bin/`, so you don't need to install them.

### Built-in Modules (Already Installed)

These modules come with Python and do NOT need installation:

- threading, concurrent.futures
- argparse, io, json, os, stat, string, sys
- time, zipfile, asyncio, base64
- datetime, glob, re, shutil, subprocess, tempfile
- urllib.parse, ctypes

### Troubleshooting Installation

| Problem | Solution |
|---------|----------|
| "pip: command not found" | Use `python -m pip install requests numpy` instead |
| "ModuleNotFoundError" | Reinstall with `pip install --upgrade requests numpy` |
| Python command not found (macOS/Linux) | Try `python3` instead of `python` |
| Permission denied (Linux/macOS) | Use `pip install --user requests numpy` |
| Windows PATH issues | Reinstall Python and check "Add Python to PATH" |

## usage

Drag a .lua onto `neodymium.bat` and it'll ask v4 or v5

Or from the command line:

```
neodymium script.lua v5
neodymium script.lua -v 4 -o clean.lua
```

### Important: Initialization Time

After running neodymium, **do not close the window before it finishes initializing** or it won't work properly. The initialization process takes around ~10 minutes on a standard machine. On slower systems, it may take longer. Wait for completion before closing.

Output goes to `script_deobfuscated.lua` unless you pass `-o`

Use `--no-color` if your terminal shows weird characters

There's a test file in `samples/input.lua`

---

*Leaking this cuz zex decided to be a bitch*
