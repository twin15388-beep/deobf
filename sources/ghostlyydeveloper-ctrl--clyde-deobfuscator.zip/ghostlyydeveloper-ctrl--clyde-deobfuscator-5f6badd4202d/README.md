# Clyde Luau Deobfuscator

A static, source-to-source deobfuscator for the **direct AST output** produced by [Clyde Luau Obfuscator](https://github.com/sfr-development/Lua-Obfuscator-Clyde-Protection). It reuses Clyde’s lexer, parser, and printer so that recovery is performed on a parsed Luau AST rather than with fragile regular-expression substitutions.

> This tool never executes input Luau. It recognizes only deterministic transformation patterns and preserves code it cannot prove safe to rewrite.

## What it reverses

| Clyde transformation | Recovery behavior |
| --- | --- |
| XOR string encoding | Recognizes the injected decoder function by structure, decodes its byte-table calls, and restores string literals. The default key and renamed decoder parameters are handled automatically. |
| Injected string decoder and cache | Removes the decoder function and its associated empty cache declaration after recognized calls have been analyzed. |
| Opaque predicates | Removes a top-level `true and condition` wrapper when its arithmetic identity evaluates exactly, including Clyde’s fixed predicates such as `15 * 15 == 225`. |
| Scope-aware local renaming | Not reversed. Generated names do not contain enough information to recover the original identifiers. |
| Stack/register VM output | `--full` statically peels supported Clyde and ZZZobfuscator bootstrap layers, decodes the inner W/X/Y or R/S/T tables, and emits a Lua-formatted VM-level reconstruction. It never executes the protected code. |

Clyde’s current direct control-flow pass wraps conditions with opaque predicates; it does not provide a general source-level inverse for arbitrary control-flow flattening. The implementation therefore removes only identities that are statically proven true.

## Installation

The project requires Node.js 18 or newer.

```bash
npm install
npm run build
```

No Lua runtime, Roblox executor, or network service is required.

## Usage

Deobfuscate a file and write the recovered Luau:

```bash
node dist/cli/deobfuscate.js obfuscated.lua -o recovered.lua
```

The shorthand npm command is equivalent:

```bash
npm run deobfuscate -- obfuscated.lua -o recovered.lua
```

Read from standard input and print to standard output:

```bash
cat obfuscated.lua | node dist/cli/deobfuscate.js -
```

Write a machine-readable change report:

```bash
node dist/cli/deobfuscate.js obfuscated.lua \
  -o recovered.lua \
  --report deobfuscation-report.json
```

For VM/bootstrap-protected input, use the full static mode:

```bash
node dist/cli/deobfuscate.js protected.lua --full -o reconstructed.lua --report report.json
```

This mode extracts the embedded payload, decodes the ASCII85/S-box/rolling-key layers used by the supported ClydeProtection and ZZZobfuscator bootstrap variants, decodes the recovered VM tables, and writes readable Lua-formatted register instructions with labels and constants. The current implementation recognizes both Clyde’s W/X/Y layout and the ZZZobfuscator R/S/T layout.

The optional controls are summarized below.

| Option | Effect |
| --- | --- |
| `--keep-runtime` | Keep Clyde’s injected decoder and cache declarations. |
| `--keep-opaque` | Keep opaque predicates even when they are proven true. |
| `--no-strings` | Do not decode recognized decoder calls. |
| `--full` | Statically unwrap supported VM/bootstrap layers and emit a Lua-formatted VM-level reconstruction. |
| `--allow-vm` | Attempt to parse VM-looking input for inspection without full recovery. |
| `-o, --output FILE` | Write Luau output to `FILE`; otherwise write to standard output. |
| `--report FILE` | Write JSON diagnostics to `FILE`. |

## Example

For a Clyde output containing a decoder call such as:

```lua
local text = decoder({18, 63, 54, 54, 53}, 90)
```

the tool produces:

```lua
local text = "Hello"
```

It also removes the matching generated decoder when the function body has Clyde’s characteristic `string.char(bit32.bxor(...))` loop. Unknown functions are not called or evaluated.

## Validation

The included test suite covers decoded strings, injected-runtime removal, exact opaque-predicate stripping, conservative handling of unknown decoder-shaped calls, and VM-marker detection.

```bash
npm test
```

The implementation was additionally tested against a real Clyde direct output generated with both `--encode-strings` and `--scramble`. The fixture recovered six string literals, removed the two injected runtime declarations, and removed the generated opaque predicate. The attached ClydeProtection VM sample was statically unwrapped into one 26,022-byte inner payload, yielding 110 root instructions and one nested prototype. The second attached ZZZobfuscator sample was statically unwrapped into one 127,057-byte inner payload, yielding 7,867 root instructions and eight nested prototypes. Both runs completed without executing the input.

## Limitations

Deobfuscation is not the same as recovering the original source. Clyde’s local renamer discards original identifier names, formatting, comments, and some source-location details. The output is therefore semantically cleaner Luau, not a byte-for-byte reconstruction.

VM output is a separate source-recovery problem. The `--full` path now statically unwraps the supported bootstrap variant and reconstructs the decoded VM tables and instruction stream as Lua. It deliberately does not execute those runtimes or call Roblox/environment APIs. The result is therefore a **VM-level reconstruction**, not a guaranteed restoration of the original source’s control-flow structure, comments, local names, or runtime-decoded strings.

## Project layout

| Path | Purpose |
| --- | --- |
| `src/deobfuscator.ts` | AST recognizers, safe rewrites, diagnostics, and VM detection. |
| `src/cli/deobfuscate.ts` | Command-line interface. |
| `src/lexer`, `src/parser`, `src/ast`, `src/obfuscator/Printer.ts` | Vendored Clyde front-end components used for parsing and printing. |
| `test/deobfuscator.test.mjs` | Automated regression tests. |

The vendored front-end files originate from the MIT-licensed Clyde repository [1].

## References

[1]: https://github.com/sfr-development/Lua-Obfuscator-Clyde-Protection "sfr-development/Lua-Obfuscator-Clyde-Protection — Clyde Luau Obfuscator"
