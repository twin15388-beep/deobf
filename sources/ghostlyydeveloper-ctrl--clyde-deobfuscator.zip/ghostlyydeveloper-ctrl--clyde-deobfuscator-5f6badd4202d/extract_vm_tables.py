from __future__ import annotations

import re
from pathlib import Path

SOURCE = ''

def load_source(path: str):
    global SOURCE
    SOURCE = Path(path).read_text(encoding='utf-8', errors='replace')

class LuaLiteralParser:
    def __init__(self, text: str):
        self.text = text
        self.i = 0

    def skip(self):
        while self.i < len(self.text) and self.text[self.i].isspace(): self.i += 1

    def parse(self):
        self.skip()
        if self.text[self.i] == '{': return self.table()
        if self.text[self.i] in "'\"": return self.string()
        start = self.i
        while self.i < len(self.text) and self.text[self.i] not in ',} \t\r\n': self.i += 1
        token = self.text[start:self.i]
        if token == 'true': return True
        if token == 'false': return False
        if token == 'nil': return None
        if token.lower().startswith('0x'): return int(token, 0)
        return float(token) if any(ch in token for ch in '.eE') else int(token)

    def table(self):
        assert self.text[self.i] == '{'; self.i += 1
        out = []
        while True:
            self.skip()
            if self.text[self.i] == '}': self.i += 1; return out
            out.append(self.parse())
            self.skip()
            if self.text[self.i] == ',': self.i += 1; continue
            if self.text[self.i] == '}': self.i += 1; return out
            raise ValueError(f'expected comma or close at {self.i}: {self.text[self.i:self.i+30]!r}')

    def string(self):
        quote = self.text[self.i]; self.i += 1; out = bytearray()
        while self.i < len(self.text):
            ch = self.text[self.i]; self.i += 1
            if ch == quote: return bytes(out)
            if ch != '\\': out.extend(ch.encode('latin1')); continue
            if self.i >= len(self.text): raise ValueError('unterminated string')
            esc = self.text[self.i]; self.i += 1
            simple = {'n':10,'r':13,'t':9,'b':8,'f':12,'v':11,'a':7,'\\':92,'"':34,"'":39,'0':0}
            if esc in simple: out.append(simple[esc]); continue
            if esc.isdigit():
                digits = esc
                while len(digits) < 3 and self.i < len(self.text) and self.text[self.i].isdigit():
                    digits += self.text[self.i]; self.i += 1
                out.append(int(digits) & 0xff); continue
            if esc == '\n': continue
            out.extend(esc.encode('latin1'))
        raise ValueError('unterminated string')

def find_literal(name: str):
    m = re.search(rf'(?<![A-Za-z0-9_]){re.escape(name)}=\{{', SOURCE)
    if not m: raise ValueError(f'{name} not found')
    start = m.end() - 1; depth = 0; quote = None; escaped = False
    for i in range(start, len(SOURCE)):
        c = SOURCE[i]
        if quote:
            if escaped: escaped = False
            elif c == '\\': escaped = True
            elif c == quote: quote = None
            continue
        if c in "'\"": quote = c; continue
        if c == '{': depth += 1
        elif c == '}':
            depth -= 1
            if depth == 0: return LuaLiteralParser(SOURCE[start:i+1]).parse()
    raise ValueError(f'unclosed {name}')

def as_bytes(value):
    if isinstance(value, bytes): return bytearray(value)
    if isinstance(value, list) and all(isinstance(x, int) and not isinstance(x, bool) for x in value): return bytearray(x & 0xff for x in value)
    return None

def transform_aa(table):
    for oi, value in enumerate(table, 1):
        data = as_bytes(value)
        if data is None: continue
        key = 87 + (oi - 1)
        for j in range(len(data)): data[j] = (data[j] - (key & 0xff)) & 0xff; key += 26
        table[oi-1] = list(data)

def transform_ab(table, aj):
    for oi, value in enumerate(table, 1):
        data = as_bytes(value)
        if data is None: continue
        for j in range(len(data)): data[j] = aj[data[j]] ^ ((oi - 1 + j) & 0xff)
        table[oi-1] = list(data)

def transform_ac(table):
    for oi, value in enumerate(table):
        data = as_bytes(value)
        if data is not None: table[oi] = bytes(data)

def transform_x(table):
    for oi, value in enumerate(table, 1):
        data = as_bytes(value)
        if data is None: continue
        key = 80 + (oi - 1)
        for j in range(len(data)): data[j] ^= key % 251; key += 193
        table[oi-1] = list(data)

def transform_z(table):
    for oi, value in enumerate(table, 1):
        data = as_bytes(value)
        if data is None or not data: continue
        previous = data[0]
        for j in range(1, len(data)):
            key = (previous * 199 + 248 + (oi - 1)) & 0xff
            data[j] ^= key; previous = data[j]
        table[oi-1] = list(data)

def transform_y(table):
    for oi, value in enumerate(table, 1):
        data = as_bytes(value)
        if data is None: continue
        for j in range(len(data)):
            h = j // 2
            key = (216 + (oi - 1) + h * 58) & 0xff if j % 2 == 0 else (237 + (oi - 1) + h * 13) & 0xff
            data[j] ^= key
        table[oi-1] = list(data)

def apply_dispatch(table, aj):
    funcs = {1: transform_aa, 2: lambda x: transform_ab(x, aj), 3: transform_z, 4: transform_x, 5: transform_ac, 6: transform_y}
    for index, fn_id in enumerate([4,6,3,1,2,5], 1):
        if index <= len(table): funcs[fn_id](table)

def bytes_to_text(value):
    if isinstance(value, bytes): return value.decode('utf-8', errors='replace')
    if isinstance(value, list) and all(isinstance(x, int) and not isinstance(x, bool) for x in value): return bytes(x & 0xff for x in value).decode('utf-8', errors='replace')
    return None

def main():
    W = find_literal('W'); X = find_literal('X'); Y = find_literal('Y')
    af, ag, ah, ai = [find_literal(x) for x in ('af','ag','ah','ai')]
    aj = af + ag + ah + ai
    print('counts', len(W), len(X), len(Y), 'aj', len(aj))
    print('W types before', [type(x).__name__ for x in W[:12]])
    # `_W(W)` converts top-level strings to byte arrays.
    for i, value in enumerate(W):
        if isinstance(value, bytes): W[i] = list(value)
    apply_dispatch(W, aj)
    print('W decoded', [(i+1, type(v).__name__, len(v) if isinstance(v,(list,bytes)) else v, bytes_to_text(v)[:80] if bytes_to_text(v) else '') for i,v in enumerate(W[:20])])
    def decode_proto(proto):
        constants = proto[0]
        for i, value in enumerate(constants):
            if isinstance(value, bytes): constants[i] = list(value)
        apply_dispatch(constants, aj)
        for child in proto[2] if len(proto) > 2 and isinstance(proto[2], list) else []: decode_proto(child)
    for proto in Y: decode_proto(proto)
    Path('/home/ubuntu/clyde-deobfuscator/tables-summary.txt').write_text(repr({'W':W,'X':X,'Y':Y}), encoding='utf-8')
    print('Y decoded', repr(Y)[:1000])

if __name__ == '__main__': main()
