import type { Chunk, Expression, Statement, LastStatement } from "./ast/types.js";

export interface DeobfuscateOptions {
  decodeStrings?: boolean;
  stripOpaquePredicates?: boolean;
  stripInjectedDecoder?: boolean;
}

export interface DeobfuscationReport {
  inputKind: "direct" | "vm-or-unknown";
  decoderNames: string[];
  decodedStrings: number;
  removedOpaquePredicates: number;
  removedInjectedStatements: number;
  warnings: string[];
}

type AnyNode = any;

const DEFAULT_OPTIONS: Required<DeobfuscateOptions> = {
  decodeStrings: true,
  stripOpaquePredicates: true,
  stripInjectedDecoder: true,
};

function unwrapParens(exp: AnyNode): AnyNode {
  let current = exp;
  while (current?.type === "ParenExpression") current = current.expression;
  return current;
}

function numericValue(exp: AnyNode): number | undefined {
  const value = unwrapParens(exp);
  if (!value) return undefined;
  if (value.type === "NumberLiteral") {
    const n = Number(value.value);
    return Number.isFinite(n) ? n : undefined;
  }
  if (value.type === "UnaryExpression" && value.operator === "-") {
    const n = numericValue(value.argument);
    return n === undefined ? undefined : -n;
  }
  if (value.type !== "BinaryExpression") return undefined;
  const left = numericValue(value.left);
  const right = numericValue(value.right);
  if (left === undefined || right === undefined) return undefined;
  switch (value.operator) {
    case "+": return left + right;
    case "-": return left - right;
    case "*": return left * right;
    case "/": return right === 0 ? undefined : left / right;
    case "%": return right === 0 ? undefined : left % right;
    case "^": return left ** right;
    default: return undefined;
  }
}

function isTrueOpaquePredicate(exp: AnyNode): boolean {
  const value = unwrapParens(exp);
  if (!value || value.type !== "BinaryExpression" || value.operator !== "==") return false;
  const left = numericValue(value.left);
  const right = numericValue(value.right);
  return left !== undefined && right !== undefined && left === right;
}

function isMember(exp: AnyNode, object: string, property: string): boolean {
  return exp?.type === "MemberExpression" && exp.object?.type === "Identifier" &&
    exp.object.name === object && exp.property === property;
}

function tableNumbers(exp: AnyNode): number[] | undefined {
  if (exp?.type !== "TableConstructor") return undefined;
  const values: number[] = [];
  for (const field of exp.fields ?? []) {
    if (field.kind !== "value" || field.value?.type !== "NumberLiteral") return undefined;
    const n = Number(field.value.value);
    if (!Number.isInteger(n) || n < 0 || n > 0xffffffff) return undefined;
    values.push(n);
  }
  return values;
}

function hasIdentifier(node: AnyNode, name: string): boolean {
  if (!node || typeof node !== "object") return false;
  if (node.type === "Identifier" && node.name === name) return true;
  for (const [key, value] of Object.entries(node)) {
    if (key === "loc" || key === "type") continue;
    if (Array.isArray(value) && value.some((item) => hasIdentifier(item, name))) return true;
    if (value && typeof value === "object" && hasIdentifier(value, name)) return true;
  }
  return false;
}

function looksLikeDecoderFunction(fn: AnyNode): boolean {
  if (fn?.type !== "FunctionExpression" || fn.params?.length !== 2) return false;
  const tableName = fn.params[0]?.name;
  const keyName = fn.params[1]?.name;
  if (!tableName || !keyName || tableName === keyName) return false;
  return (fn.body ?? []).some((stmt: AnyNode) => {
    if (stmt.type !== "ForNumericStatement") return false;
    const loopIndex = stmt.var?.name;
    const loopEnd = unwrapParens(stmt.end);
    if (!loopIndex || loopEnd?.type !== "UnaryExpression" || loopEnd.operator !== "#" ||
        loopEnd.argument?.type !== "Identifier" || loopEnd.argument.name !== tableName) return false;
    return (stmt.body ?? []).some((inner: AnyNode) => {
      if (inner.type !== "AssignmentStatement" || inner.values?.length !== 1) return false;
      const value = inner.values[0];
      if (value?.type !== "CallExpression" || !isMember(value.callee, "string", "char")) return false;
      const xorCall = value.args?.[0];
      if (xorCall?.type !== "CallExpression" || !isMember(xorCall.callee, "bit32", "bxor") || xorCall.args?.length !== 2) return false;
      const indexed = xorCall.args[0];
      return indexed?.type === "IndexExpression" && indexed.object?.type === "Identifier" &&
        indexed.object.name === tableName && indexed.index?.type === "Identifier" && indexed.index.name === loopIndex &&
        xorCall.args[1]?.type === "Identifier" && xorCall.args[1].name === keyName;
    });
  });
}

function findDecoderNames(chunk: AnyNode): Set<string> {
  const names = new Set<string>();
  for (const stmt of chunk.body ?? []) {
    if (stmt.type !== "LocalStatement" || stmt.vars?.length !== 1 || stmt.values?.length !== 1) continue;
    const name = stmt.vars[0]?.name;
    if (!name) continue;
    if (looksLikeDecoderFunction(stmt.values[0])) names.add(name);
  }
  return names;
}

function isEmptyTableDeclaration(stmt: AnyNode): boolean {
  return stmt?.type === "LocalStatement" && stmt.vars?.length === 1 && stmt.values?.length === 1 &&
    stmt.values[0]?.type === "TableConstructor" && stmt.values[0].fields?.length === 0;
}

function isDecoderCall(exp: AnyNode, names: Set<string>): { bytes: number[]; key: number } | undefined {
  if (exp?.type !== "CallExpression" || exp.callee?.type !== "Identifier" || !names.has(exp.callee.name)) return undefined;
  if (exp.args?.length !== 2) return undefined;
  const bytes = tableNumbers(exp.args[0]);
  const key = numericValue(exp.args[1]);
  if (!bytes || key === undefined || !Number.isInteger(key)) return undefined;
  return { bytes, key: key & 0xff };
}

function decodeStringCall(exp: AnyNode, names: Set<string>, report: DeobfuscationReport): AnyNode {
  const call = isDecoderCall(exp, names);
  if (!call) return exp;
  const chars = call.bytes.map((byte) => String.fromCharCode((byte ^ call.key) & 0xff)).join("");
  report.decodedStrings++;
  return { type: "StringLiteral", value: chars, loc: exp.loc };
}

function transformExpression(exp: AnyNode, names: Set<string>, options: Required<DeobfuscateOptions>, report: DeobfuscationReport): AnyNode {
  if (!exp || typeof exp !== "object") return exp;
  if (options.decodeStrings) {
    const decoded = decodeStringCall(exp, names, report);
    if (decoded !== exp) return decoded;
  }
  switch (exp.type) {
    case "BinaryExpression": {
      let left = transformExpression(exp.left, names, options, report);
      let right = transformExpression(exp.right, names, options, report);
      if (options.stripOpaquePredicates && exp.operator === "and" && isTrueOpaquePredicate(left)) {
        report.removedOpaquePredicates++;
        return right;
      }
      return { ...exp, left, right };
    }
    case "UnaryExpression":
      return { ...exp, argument: transformExpression(exp.argument, names, options, report) };
    case "CallExpression":
      return { ...exp, callee: transformExpression(exp.callee, names, options, report), args: (exp.args ?? []).map((a: AnyNode) => transformExpression(a, names, options, report)) };
    case "MethodCallExpression":
      return { ...exp, object: transformExpression(exp.object, names, options, report), args: (exp.args ?? []).map((a: AnyNode) => transformExpression(a, names, options, report)) };
    case "IndexExpression":
      return { ...exp, object: transformExpression(exp.object, names, options, report), index: transformExpression(exp.index, names, options, report) };
    case "MemberExpression":
      return { ...exp, object: transformExpression(exp.object, names, options, report) };
    case "TableConstructor":
      return { ...exp, fields: (exp.fields ?? []).map((field: AnyNode) => field.kind === "index"
        ? { ...field, index: transformExpression(field.index, names, options, report), value: transformExpression(field.value, names, options, report) }
        : { ...field, value: transformExpression(field.value, names, options, report) }) };
    case "FunctionExpression":
      return { ...exp, body: transformBody(exp.body ?? [], names, options, report) };
    case "ParenExpression":
      return { ...exp, expression: transformExpression(exp.expression, names, options, report) };
    case "TypeAssertion":
      return { ...exp, expression: transformExpression(exp.expression, names, options, report) };
    case "IfElseExpression":
      return { ...exp,
        condition: transformExpression(exp.condition, names, options, report),
        thenExp: transformExpression(exp.thenExp, names, options, report),
        elseifClauses: (exp.elseifClauses ?? []).map((c: AnyNode) => ({ ...c,
          condition: transformExpression(c.condition, names, options, report),
          value: transformExpression(c.value, names, options, report),
        })),
        elseExp: transformExpression(exp.elseExp, names, options, report),
      };
    case "StringInterpolation":
      return { ...exp, parts: (exp.parts ?? []).map((part: AnyNode) => typeof part === "string" ? part : transformExpression(part, names, options, report)) };
    default:
      return exp;
  }
}

function transformVar(variable: AnyNode, names: Set<string>, options: Required<DeobfuscateOptions>, report: DeobfuscationReport): AnyNode {
  if (!variable || variable.type === "Identifier") return variable;
  if (variable.type === "IndexExpression") {
    return { ...variable, object: transformExpression(variable.object, names, options, report), index: transformExpression(variable.index, names, options, report) };
  }
  if (variable.type === "MemberExpression") {
    return { ...variable, object: transformExpression(variable.object, names, options, report) };
  }
  return variable;
}

function transformStatement(stmt: AnyNode, names: Set<string>, options: Required<DeobfuscateOptions>, report: DeobfuscationReport): AnyNode {
  switch (stmt.type) {
    case "LocalStatement":
      return { ...stmt, values: stmt.values?.map((e: AnyNode) => transformExpression(e, names, options, report)) };
    case "AssignmentStatement":
      return { ...stmt, vars: stmt.vars.map((v: AnyNode) => transformVar(v, names, options, report)), values: stmt.values.map((e: AnyNode) => transformExpression(e, names, options, report)) };
    case "CompoundAssignmentStatement":
      return { ...stmt, var: transformVar(stmt.var, names, options, report), value: transformExpression(stmt.value, names, options, report) };
    case "FunctionCallStatement":
      return { ...stmt, call: transformExpression(stmt.call, names, options, report) };
    case "ReturnStatement":
      return { ...stmt, values: stmt.values?.map((e: AnyNode) => transformExpression(e, names, options, report)) };
    case "IfStatement":
      return { ...stmt,
        condition: transformExpression(stmt.condition, names, options, report),
        thenBody: transformBody(stmt.thenBody ?? [], names, options, report),
        elseifClauses: (stmt.elseifClauses ?? []).map((c: AnyNode) => ({ ...c,
          condition: transformExpression(c.condition, names, options, report),
          body: transformBody(c.body ?? [], names, options, report),
        })),
        elseBody: stmt.elseBody ? transformBody(stmt.elseBody, names, options, report) : undefined,
      };
    case "WhileStatement":
      return { ...stmt, condition: transformExpression(stmt.condition, names, options, report), body: transformBody(stmt.body ?? [], names, options, report) };
    case "RepeatStatement":
      return { ...stmt, body: transformBody(stmt.body ?? [], names, options, report), condition: transformExpression(stmt.condition, names, options, report) };
    case "ForNumericStatement":
      return { ...stmt,
        start: transformExpression(stmt.start, names, options, report),
        end: transformExpression(stmt.end, names, options, report),
        step: stmt.step ? transformExpression(stmt.step, names, options, report) : undefined,
        body: transformBody(stmt.body ?? [], names, options, report),
      };
    case "ForInStatement":
      return { ...stmt, iter: stmt.iter.map((e: AnyNode) => transformExpression(e, names, options, report)), body: transformBody(stmt.body ?? [], names, options, report) };
    case "DoStatement":
      return { ...stmt, body: transformBody(stmt.body ?? [], names, options, report) };
    case "FunctionStatement":
    case "LocalFunctionStatement":
    case "TypeFunctionStatement":
    case "ExportTypeFunctionStatement":
      return { ...stmt, body: transformBody(stmt.body ?? [], names, options, report) };
    default:
      return stmt;
  }
}

function transformBody(body: AnyNode[], names: Set<string>, options: Required<DeobfuscateOptions>, report: DeobfuscationReport): AnyNode[] {
  return body.map((stmt) => transformStatement(stmt, names, options, report));
}

function removeInjectedStatements(chunk: AnyNode, names: Set<string>, report: DeobfuscationReport): AnyNode {
  if (!names.size) return chunk;
  const remove = new Set<AnyNode>();
  const body = chunk.body ?? [];
  for (let i = 0; i < body.length; i++) {
    const stmt = body[i];
    if (stmt.type !== "LocalStatement" || stmt.vars?.length !== 1 || !names.has(stmt.vars[0]?.name)) continue;
    remove.add(stmt);
    const cacheName = i > 0 && isEmptyTableDeclaration(body[i - 1]) ? body[i - 1].vars[0].name : undefined;
    if (cacheName && hasIdentifier(stmt.values?.[0], cacheName)) remove.add(body[i - 1]);
  }
  report.removedInjectedStatements = remove.size;
  return { ...chunk, body: body.filter((stmt: AnyNode) => !remove.has(stmt)) };
}

export function looksLikeClydeVm(source: string): boolean {
  const explicitMarker = /Clyde Protection v2|vmBlob|base85|LZMA|custom cipher|register VM|stack VM/i.test(source);
  const generatedRuntime = /local\s+function\s+_run\s*\(/.test(source) &&
    /handlers\s*\[\s*\d+\s*\]\s*=\s*function/.test(source);
  const executorBootstrap = /type\s*\(\s*getgenv\s*\)|type\s*\(\s*getfenv\s*\)/.test(source) &&
    /loadstring/.test(source);
  return explicitMarker || generatedRuntime || executorBootstrap;
}

export function deobfuscate(ast: Chunk, options: DeobfuscateOptions = {}): { ast: Chunk; report: DeobfuscationReport } {
  const opts = { ...DEFAULT_OPTIONS, ...options };
  const report: DeobfuscationReport = {
    inputKind: "direct",
    decoderNames: [],
    decodedStrings: 0,
    removedOpaquePredicates: 0,
    removedInjectedStatements: 0,
    warnings: [],
  };
  const names = findDecoderNames(ast);
  report.decoderNames = [...names];
  const withoutRuntime = opts.stripInjectedDecoder ? removeInjectedStatements(ast, names, report) : ast;
  const transformed = {
    ...withoutRuntime,
    body: transformBody(withoutRuntime.body ?? [], names, opts, report),
  } as Chunk;
  return { ast: transformed, report };
}
