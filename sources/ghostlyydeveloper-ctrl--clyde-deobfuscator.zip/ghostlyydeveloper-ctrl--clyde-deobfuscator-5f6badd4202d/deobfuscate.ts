import { mkdtempSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { spawnSync } from "node:child_process";
import { deobfuscate, looksLikeClydeVm } from "../deobfuscator.js";
import { lex } from "../lexer/Lexer.js";
import { parseWithErrors } from "../parser/Parser.js";
import { printChunk } from "../obfuscator/Printer.js";

const args = process.argv.slice(2);
const help = args.includes("-h") || args.includes("--help");

function usage(): void {
  console.log(`Usage: clyde-deobfuscator <input.lua|-> [options]

Options:
  -o, --output <file>       Write recovered Luau to a file
      --report <file>       Write JSON diagnostics to a file
      --keep-runtime        Keep Clyde's injected string decoder
      --keep-opaque         Keep proven-true opaque predicates
      --no-strings          Do not decode recognized string calls
      --full                Statically unwrap VM/bootstrap layers and emit Lua reconstruction
      --allow-vm            Parse VM-looking input instead of stopping early
  -h, --help                Show this help

This is a static source-to-source tool. It never executes input Luau.
Direct Clyde AST output and Clyde VM-level reconstruction are supported.`);
}

if (help) {
  usage();
  process.exit(0);
}

const outputIndex = args.findIndex((arg) => arg === "-o" || arg === "--output");
const reportIndex = args.findIndex((arg) => arg === "--report");
const outputPath = outputIndex >= 0 ? args[outputIndex + 1] : undefined;
const reportPath = reportIndex >= 0 ? args[reportIndex + 1] : undefined;
const inputPath = args.find((arg, index) => {
  if (arg.startsWith("-")) return false;
  if (outputIndex >= 0 && (index === outputIndex || index === outputIndex + 1)) return false;
  if (reportIndex >= 0 && (index === reportIndex || index === reportIndex + 1)) return false;
  return true;
});

if (!inputPath) {
  usage();
  process.exit(2);
}

const source = inputPath === "-" ? readFileSync(0, "utf8") : readFileSync(inputPath, "utf8");
const vmLooking = looksLikeClydeVm(source);
if (vmLooking && args.includes("--full")) {
  const workspace = mkdtempSync(join(tmpdir(), "clyde-full-"));
  const fullOutput = outputPath ?? join(workspace, "full-output.lua");
  const fullReport = reportPath ?? join(workspace, "full-report.json");
  const fullScript = join(dirname(fileURLToPath(import.meta.url)), "../../tools/full_deobfuscate.py");
  const child = spawnSync("python3", [fullScript, inputPath, fullOutput, fullReport], { stdio: "inherit" });
  if (child.status !== 0) process.exit(child.status ?? 1);
  if (!outputPath) process.stdout.write(readFileSync(fullOutput, "utf8"));
  rmSync(workspace, { recursive: true, force: true });
  process.exit(0);
}

if (vmLooking && !args.includes("--allow-vm")) {
  const report = {
    inputKind: "vm-or-unknown",
    decoderNames: [],
    decodedStrings: 0,
    removedOpaquePredicates: 0,
    removedInjectedStatements: 0,
    warnings: ["Clyde VM/bootstrap markers were detected. VM bytecode is not executed or devirtualized by this static tool.", "Use --allow-vm only to attempt parsing the wrapper for inspection; no source recovery is promised."],
  };
  if (reportPath) writeFileSync(reportPath, JSON.stringify(report, null, 2) + "\n", "utf8");
  console.error(report.warnings.join("\n"));
  process.exit(3);
}

const lexed = lex(source);
if (lexed.errors.length) {
  console.error(JSON.stringify({ stage: "lex", errors: lexed.errors }, null, 2));
  process.exit(1);
}

const parsed = parseWithErrors(lexed.tokens);
if (parsed.errors.length) {
  console.error(JSON.stringify({ stage: "parse", errors: parsed.errors }, null, 2));
  process.exit(1);
}

const result = deobfuscate(parsed.ast, {
  decodeStrings: !args.includes("--no-strings"),
  stripOpaquePredicates: !args.includes("--keep-opaque"),
  stripInjectedDecoder: !args.includes("--keep-runtime"),
});
const output = printChunk(result.ast);
if (outputPath) writeFileSync(outputPath, output, "utf8");
else process.stdout.write(output + (output.endsWith("\n") ? "" : "\n"));

if (reportPath) writeFileSync(reportPath, JSON.stringify(result.report, null, 2) + "\n", "utf8");
console.error(`Decoded ${result.report.decodedStrings} string(s), removed ${result.report.removedOpaquePredicates} opaque predicate(s), and removed ${result.report.removedInjectedStatements} injected statement(s).`);
