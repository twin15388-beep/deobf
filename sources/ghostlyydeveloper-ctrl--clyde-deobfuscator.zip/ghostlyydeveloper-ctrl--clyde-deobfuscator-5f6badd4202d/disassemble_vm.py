from __future__ import annotations
import sys
sys.path.insert(0, '/home/ubuntu/clyde-deobfuscator/tools')
from extract_vm_tables import find_literal, apply_dispatch, as_bytes, bytes_to_text

def decode_tables():
    W = find_literal('W'); X = find_literal('X'); Y = find_literal('Y')
    aj = sum((find_literal(n) for n in ('af','ag','ah','ai')), [])
    for i,v in enumerate(W):
        if isinstance(v, bytes): W[i] = list(v)
    apply_dispatch(W, aj)
    def proto(p):
        constants=p[0]
        for i,v in enumerate(constants):
            if isinstance(v,bytes): constants[i]=list(v)
        apply_dispatch(constants,aj)
        if len(p)>2 and isinstance(p[2],list):
            for child in p[2]: proto(child)
    for p in Y: proto(p)
    return W,X,Y

def val(v):
    if isinstance(v,(bytes,bytearray)): return repr(bytes(v).decode('utf8','replace'))
    if isinstance(v,list): return '{' + ','.join(val(x) for x in v[:8]) + ('...' if len(v)>8 else '') + '}'
    return repr(v)

def decode_code(X):
    # The f() loop mutates each first cell once, with K[m] initially zero.
    code=list(X); state={}; out=[]
    for m in range(1,len(code)+1,4):
        q=state.get(m,0)
        r=(193 + m*64 + m*m*138) & 0xff
        p=(code[m-1] ^ r ^ q) & 0xffffffff
        t=code[m] if m < len(code) else 0
        u=code[m+1] if m+1 < len(code) else 0
        v=code[m+2] if m+2 < len(code) else 0
        s=(q*233+p+133)&0xff
        tt=(q^s)&0xffffffff
        code[m-1]=(code[m-1]^tt)&0xffffffff
        state[m]=s
        op=(p^211)&0xffffffff
        out.append((m,op,t,u,v))
    return out

if __name__ == '__main__':
    W,X,Y=decode_tables()
    print('W CONSTANTS')
    for i,v in enumerate(W,1): print(i, val(v), 'text=', bytes_to_text(v) if bytes_to_text(v) else '')
    for pi,p in enumerate(Y,1):
        print(f'PROTO {pi}: constants={len(p[0])} code={len(p[1])} children={len(p[2]) if len(p)>2 else 0} params={p[4] if len(p)>4 else None} regs={p[5] if len(p)>5 else None}')
        for i,v in enumerate(p[0],1): print('  K',i,val(v),'text=',bytes_to_text(v) if bytes_to_text(v) else '')
        print('  INSTRUCTIONS')
        for row in decode_code(p[1]): print(' ',row)
    print('ROOT CODE')
    for row in decode_code(X): print(row)
