from __future__ import annotations

from extract_vm_tables import as_bytes, find_literal, load_source
from full_decode import parse_array


def transform_aa(table):
    for oi, value in enumerate(table, 1):
        data = as_bytes(value)
        if data is None: continue
        key = 196 + (oi - 1)
        for j in range(len(data)):
            data[j] ^= key % 251
            key += 61
        table[oi - 1] = list(data)


def transform_ab(table):
    for oi, value in enumerate(table, 1):
        data = as_bytes(value)
        if data is None: continue
        even, odd = 194 + (oi - 1), 212 + (oi - 1)
        for j in range(len(data)):
            if j % 2 == 0:
                data[j] ^= even & 0xff; even += 17
            else:
                data[j] ^= odd & 0xff; odd += 32
        table[oi - 1] = list(data)


def transform_ac(table):
    for oi, value in enumerate(table, 1):
        data = as_bytes(value)
        if data is None or not data: continue
        previous = data[0]
        for j in range(1, len(data)):
            key = (previous * 53 + 157 + (oi - 1)) & 0xff
            data[j] ^= key; previous = data[j]
        table[oi - 1] = list(data)


def transform_ad(table):
    for oi, value in enumerate(table, 1):
        data = as_bytes(value)
        if data is None: continue
        for j in range(len(data)):
            data[j] = (data[j] - (180 + (oi - 1) + j * 7)) & 0xff
        table[oi - 1] = list(data)


def transform_ae(table, inverse):
    for oi, value in enumerate(table, 1):
        data = as_bytes(value)
        if data is None: continue
        for j in range(len(data)):
            data[j] = inverse[data[j]] ^ ((oi - 1 + j) & 0xff)
        table[oi - 1] = list(data)


def transform_af(table):
    for oi, value in enumerate(table):
        data = as_bytes(value)
        if data is not None: table[oi] = bytes(data)


def apply_secondary(table, inverse):
    transform_aa(table)
    transform_ab(table)
    transform_ac(table)
    transform_ad(table)
    transform_ae(table, inverse)
    transform_af(table)


def decode_secondary_tables(path: str):
    load_source(path)
    constants = find_literal('R')
    code = find_literal('S')
    protos = find_literal('T')
    inverse = parse_array(load_source.__globals__['SOURCE'], '_0inv')
    for i, value in enumerate(constants):
        if isinstance(value, bytes): constants[i] = list(value)
    apply_secondary(constants, inverse)

    def proto(value):
        values = value[0]
        for i, item in enumerate(values):
            if isinstance(item, bytes): values[i] = list(item)
        apply_secondary(values, inverse)
        if len(value) > 2 and isinstance(value[2], list):
            for child in value[2]: proto(child)
    for item in protos: proto(item)
    return constants, code, protos
