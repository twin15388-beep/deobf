#!/usr/bin/env python3
"""Static decoder for the ClydeProtection bootstrap variant in the supplied sample.

This script treats Lua as data. It extracts only literal arrays and the literal
ASCII85 payload, then applies the arithmetic transformations visible in the
bootstrap. It never imports or executes Lua.
"""
from __future__ import annotations

import ast
import re
import struct
import sys
from pathlib import Path


def eval_int(expr: str) -> int:
    tree = ast.parse(expr.strip(), mode="eval")

    def visit(node: ast.AST) -> int:
        if isinstance(node, ast.Constant) and isinstance(node.value, int):
            return int(node.value)
        if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.UAdd, ast.USub)):
            value = visit(node.operand)
            return value if isinstance(node.op, ast.UAdd) else -value
        if isinstance(node, ast.BinOp) and isinstance(node.op, (ast.Add, ast.Sub, ast.Mult, ast.FloorDiv, ast.Mod, ast.Pow)):
            left, right = visit(node.left), visit(node.right)
            if isinstance(node.op, ast.Add): return left + right
            if isinstance(node.op, ast.Sub): return left - right
            if isinstance(node.op, ast.Mult): return left * right
            if isinstance(node.op, ast.FloorDiv): return left // right
            if isinstance(node.op, ast.Mod): return left % right
            return left ** right
        raise ValueError(f"unsupported numeric expression: {expr!r}")

    return visit(tree.body)


def parse_array(source: str, name: str) -> list[int]:
    matches = list(re.finditer(rf"local {re.escape(name)}=\{{([^}}]*)\}}", source))
    if not matches:
        raise ValueError(f"array {name} not found")
    match = max(matches, key=lambda item: len(item.group(1)))
    values = []
    for token in match.group(1).split(","):
        token = token.strip()
        if token:
            values.append(eval_int(token))
    return values


def bxor(*values: int) -> int:
    result = 0
    for value in values:
        result ^= value
    return result & 0xFFFFFFFF


def decode_ascii85(text: str) -> bytes:
    raw = re.sub(r"\s+", "", text).replace("z", "!!!!!")
    out = bytearray()
    for offset in range(0, len(raw), 5):
        group = raw[offset:offset + 5]
        if len(group) < 5:
            group = group + "u" * (5 - len(group))
        value = 0
        for char in group:
            code = ord(char) - 33
            if not 0 <= code <= 84:
                raise ValueError(f"invalid ASCII85 character {char!r}")
            value = value * 85 + code
        out.extend(struct.pack(">I", value))
    return bytes(out)


def transform_xor_index(data: bytes, key_start: int, step: int) -> bytes:
    out = bytearray()
    key = key_start
    for value in data:
        out.append(bxor(value, key & 0xFF) & 0xFF)
        key += step
    return bytes(out)


def transform_reverse_xor(data: bytes, key: int) -> bytes:
    return bytes((bxor(value, key) & 0xFF) for value in reversed(data))


def decode_layer(source: str) -> bytes:
    payload = re.search(r"_2e\s*=\s*_3c\(\[=\[(.*?)\]=\]\)", source, re.S)
    if not payload:
        raise ValueError("Clyde ASCII85 payload was not found")

    data = decode_ascii85(payload.group(1))

    # The attachment’s `_1v` function is the active decryptor. `_1r`, `_1p`,
    # `_3s`, and `_2q` are decoys in this state-machine path.
    sbox_parts = [parse_array(source, name) for name in ("_1f", "_1j", "_0m", "_3p", "_0v")]
    key_parts = [parse_array(source, name) for name in ("_1t", "_1h", "_2t", "_0x")]
    sbox_values = [value ^ (4 * 42 + 1) for value in sum(sbox_parts, [])]
    key_values = [value ^ (6 * 31 - 53) for value in sum(key_parts, [])]
    if len(sbox_values) != 256:
        raise ValueError(f"unexpected S-box length: {len(sbox_values)}")
    if not key_values:
        raise ValueError("empty key schedule")

    decoded = bytearray()
    previous = 0
    for index, encrypted in enumerate(data):
        key = key_values[index % len(key_values)]
        sub = bxor(bxor(encrypted, key), previous) & 0xFF
        decoded.append(sbox_values[sub])
        previous = encrypted
    return bytes(decoded)


def decode_zzz_layer(source: str) -> bytes:
    payload = re.search(r"_3s\s*=\s*_3p\(\[=\[(.*?)\]=\]\)", source, re.S)
    if not payload:
        raise ValueError("ZZZobfuscator ASCII85 payload was not found")
    data = decode_ascii85(payload.group(1))
    # Active path: _3p (ASCII85) -> _3c. The other transforms are retry/decoy paths.
    sbox_parts = [parse_array(source, name) for name in ("_3q", "_4j", "_4n", "_4t", "_1p")]
    key_parts = [parse_array(source, name) for name in ("_0r", "_4g", "_2d")]
    sbox_values = [value ^ (191 - 141) for value in sum(sbox_parts, [])]
    key_values = [value ^ (6 * 34 + 1 - 12) for value in sum(key_parts, [])]
    if len(sbox_values) != 256:
        raise ValueError(f"unexpected ZZZ S-box length: {len(sbox_values)}")
    if not key_values:
        raise ValueError("empty ZZZ key schedule")
    decoded = bytearray()
    previous = 0
    for index, encrypted in enumerate(data):
        key = key_values[index % len(key_values)]
        sub = bxor(bxor(encrypted, key), previous) & 0xff
        decoded.append(sbox_values[sub])
        previous = encrypted
    return bytes(decoded[:127057])


def decode_recursive(source: str, maximum_layers: int = 8) -> list[bytes]:
    layers: list[bytes] = []
    current = source
    for _ in range(maximum_layers):
        decoded = None
        for decoder in (decode_layer, decode_zzz_layer):
            try:
                decoded = decoder(current)
                break
            except ValueError:
                continue
        if decoded is None:
            break
        layers.append(decoded)
        text = decoded.decode("utf-8", errors="replace")
        if not ("[=[" in text and ("_3p" in text or "_3c" in text or "_2e" in text)):
            break
        current = text
    return layers


def main() -> int:
    if len(sys.argv) != 3:
        print(f"usage: {sys.argv[0]} INPUT OUTPUT", file=sys.stderr)
        return 2
    source = Path(sys.argv[1]).read_text(encoding="utf-8")
    layers = decode_recursive(source)
    if not layers:
        print("no supported Clyde bootstrap layer found", file=sys.stderr)
        return 3
    output = layers[-1]
    Path(sys.argv[2]).write_bytes(output)
    print(f"decoded {len(layers)} layer(s), final payload {len(output)} bytes", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
