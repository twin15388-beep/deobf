from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from full_decode import decode_recursive  # noqa: E402
from disassemble_vm import decode_tables, decode_code  # noqa: E402
from extract_vm_tables import bytes_to_text, load_source  # noqa: E402
from secondary_vm import decode_secondary_tables  # noqa: E402

OP_NAMES = {
    192: 'LOADBOOL', 193: 'LOADNIL', 195: 'JMP_IF', 196: 'RETURN', 197: 'SETTABLE',
    201: 'NOP', 208: 'GETTABLE_SELF', 213: 'CLOSURE', 218: 'JMP', 220: 'GETGLOBAL',
    222: 'GETTABLE', 223: 'NOT', 225: 'CONCAT', 226: 'NEWTABLE', 227: 'GETUPVAL',
    240: 'CALL', 241: 'NAMECALL', 243: 'NOP', 245: 'TEST', 246: 'EQ', 247: 'LOADK',
    250: 'MOVE', 253: 'SELF_CALL',
}

def lua_string(value: bytes) -> str:
    out = ['"']
    for byte in value:
        if byte == 34: out.append('\\"')
        elif byte == 92: out.append('\\\\')
        elif byte == 10: out.append('\\n')
        elif 32 <= byte < 127: out.append(chr(byte))
        else: out.append(f'\\{byte:03d}')
    out.append('"')
    return ''.join(out)

def lua_value(value) -> str:
    if isinstance(value, bytes): return lua_string(value)
    if isinstance(value, bool): return 'true' if value else 'false'
    if value is None: return 'nil'
    if isinstance(value, int): return str(value)
    if isinstance(value, list):
        if all(isinstance(x, int) and not isinstance(x, bool) for x in value):
            return '{' + ', '.join(str(x) for x in value) + '}'
        return '{' + ', '.join(lua_value(x) for x in value) + '}'
    return lua_string(str(value).encode())

def k_value(constants, one_based: int) -> str:
    if 1 <= one_based <= len(constants): return lua_value(constants[one_based - 1])
    return f'K[{one_based}]'

def operand(constants, raw: int) -> str:
    if raw >= 256: return k_value(constants, raw - 255)
    return f'R[{raw + 1}]'

def target_pc(pc: int, delta: int) -> int:
    return pc + 4 + delta * 4

def render_instruction(constants, row) -> str:
    pc, op, t, u, v = row
    name = OP_NAMES.get(op, f'OP_{op}')
    if op == 247: return f'R[{v+1}] = {k_value(constants, t+1)}'
    if op == 220: return f'R[{v+1}] = ENV[{k_value(constants, t+1)}]'
    if op == 250: return f'R[{v+1}] = R[{u+1}]'
    if op == 222: return f'R[{u+1}] = R[{v+1}][{operand(constants, t)}]'
    if op == 208: return f'R[{t+1}] = R[{u+1}][{operand(constants, v)}]'
    if op == 227: return f'R[{u+1}] = UPVALUE[{t+1}]'
    if op == 223: return f'R[{t+1}] = not R[{u+1}]'
    if op == 193: return f'for _r = {t+1}, {t+u+1} do R[_r] = nil end'
    if op == 226: return f'R[{t+1}] = {{}}'
    if op == 197: return f'R[{v+1}][{operand(constants, u)}] = {operand(constants, t)}'
    if op == 192:
        line = f'R[{t+1}] = {"true" if u else "false"}'
        return line + (f'; goto pc_{pc+8:04d}' if v != 0 else '')
    if op == 225:
        args = ', '.join(f'R[{i+1}]' for i in range(v, u+1))
        return f'R[{t+1}] = table.concat({{{args}}})'
    if op == 246:
        destination = f'pc_{pc+8:04d}'
        return f'if (({operand(constants, u)} == {operand(constants, t)}) ~= ({v} ~= 0)) then goto {destination} end'
    if op == 245:
        destination = f'pc_{pc+8:04d}'
        return f'if ((not R[{v+1}]) == ({t} ~= 0)) then goto {destination} end'
    if op == 218: return f'goto pc_{target_pc(pc, u):04d}'
    if op == 195: return f'if ((not R[{u+1}]) ~= ({t} ~= 0)) then goto pc_{target_pc(pc, u):04d} end'
    if op == 196: return f'return R[{v+1}]'
    if op == 213: return f'R[{v+1}] = function(...) -- closure proto={u+1}\nend'
    if op == 240: return f'R[{u+1}](...)'
    if op == 253: return f'R[{v+1}][{operand(constants, u)}](...)'
    if op == 241: return f'R[{u+1}] = ENV[{k_value(constants, v+1)}]'
    return f'-- {name} {t}, {u}, {v}'

def render_proto(constants, code, proto_index: int, lines: list[str], indent: str = ''):
    lines.append(f'{indent}-- Prototype {proto_index}: {len(code)//4} instruction(s)')
    lines.append(f'{indent}local R = setmetatable({{}}, {{__index = function(_, k) return nil end}})')
    for row in decode_code(code):
        lines.append(f'{indent}::pc_{row[0]:04d}::')
        lines.append(f'{indent}{render_instruction(constants, row)}')
    lines.append(f'{indent}return R')

def main() -> int:
    if len(sys.argv) not in (3, 4):
        print(f'usage: {sys.argv[0]} INPUT OUTPUT [REPORT]', file=sys.stderr)
        return 2
    source = Path(sys.argv[1]).read_text(encoding='utf-8', errors='replace')
    layers = decode_recursive(source)
    if not layers:
        print('unsupported Clyde bootstrap layout', file=sys.stderr)
        return 3
    inner = layers[-1]
    inner_path = Path(sys.argv[1]).with_suffix('.inner.lua')
    inner_path.write_bytes(inner)
    load_source(str(inner_path))
    try:
        constants, root_code, protos = decode_tables()
        vm_layout = 'W/X/Y'
    except Exception:
        try:
            constants, root_code, protos = decode_secondary_tables(str(inner_path))
            vm_layout = 'R/S/T'
        except Exception as exc:
            print(f'VM table recovery failed: {exc}', file=sys.stderr)
            return 4

    lines = [
        '-- Full static Clyde deobfuscation output',
        '-- The original VM wrapper and payload were decoded without executing Lua.',
        '-- This is a valid Lua-formatted VM-level reconstruction; original comments',
        '-- and discarded local names are not recoverable from compiled bytecode alone.',
        'local ENV = _ENV or _G',
        'local K = {}',
    ]
    for index, value in enumerate(constants, 1): lines.append(f'K[{index}] = {lua_value(value)}')
    lines.append('local R = {}')
    lines.append('-- Root prototype')
    for row in decode_code(root_code):
        lines.append(f'::pc_{row[0]:04d}::')
        lines.append(render_instruction(constants, row))
    for index, proto in enumerate(protos, 1):
        lines.append(f'-- Nested prototype {index}')
        render_proto(proto[0], proto[1], index, lines)
    lines.append('return R')
    output = '\n'.join(lines) + '\n'
    Path(sys.argv[2]).write_text(output, encoding='utf-8')
    report = {
        'inputKind': 'clyde-vm',
        'decodedBootstrapLayers': len(layers),
        'innerPayloadBytes': len(inner),
        'rootInstructionCount': len(root_code)//4,
        'nestedPrototypeCount': len(protos),
        'mode': 'static-vm-level-reconstruction',
        'vmLayout': vm_layout,
        'executedInput': False,
        'warnings': ['This output is VM-level reconstruction, not a guaranteed original-source recovery.'],
    }
    if len(sys.argv) == 4: Path(sys.argv[3]).write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(report), file=sys.stderr)
    return 0

if __name__ == '__main__': raise SystemExit(main())
