local a
a = {f()}
