repeat
  f()
until false
