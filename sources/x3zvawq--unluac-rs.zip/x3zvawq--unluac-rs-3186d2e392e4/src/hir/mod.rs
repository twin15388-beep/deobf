//! 这个模块承载 HIR 层的共享实现。
//!
//! 这一层正式消费 StructureFacts 做恢复决策，把 low-IR 提升到变量世界，并让
//! 后续 AST/Readability 有稳定的语义中间表示可消费。

mod analyze;
mod common;
pub(crate) use common::{HirLuauInliningBody, HirSourceSite, luau_loop_unroll_blocked};
#[cfg(feature = "decompile-debug")]
mod debug;
pub(crate) mod decision;
mod emission;
mod error;
mod expr_safety;
mod promotion;
mod rewrite;
mod simplify;
mod table_layout;
pub(crate) mod traverse;
mod value_facts;
pub use crate::value_semantics::table::TableTemplateKey as HirTableTemplateKey;
pub(crate) mod visit;

pub use crate::parser::{ProtoLineRange, ProtoSignature};
pub(crate) use analyze::analyze_hir;
pub use common::{
    HirAssign, HirBinaryExpr, HirBinaryOpKind, HirBinding, HirBlock, HirCallExpr,
    HirCallRootHandoff, HirCallStmt, HirCapture, HirCaptureInitializer, HirCaptureMode, HirClose,
    HirClosureCreation, HirClosureExpr, HirControlFlowFeature, HirDecisionExpr, HirDecisionNode,
    HirDecisionNodeRef, HirDecisionTarget, HirDecisionTestSource, HirExitRequirement, HirExpr,
    HirGenericFor, HirGenericForDispatchResult, HirGlobalDecl, HirGlobalRef, HirGoto, HirIf,
    HirInitializerMergeTransactionId, HirInlineDisposition, HirInlineDispositions,
    HirInlineRetentionReason, HirLValue, HirLabel, HirLabelId, HirLocalDecl, HirLogicalExpr,
    HirMethodCall, HirMethodRewriteTransactionId, HirMethodSetupProtocolId, HirModule,
    HirNumericFor, HirPackTail, HirProto, HirProtoRef, HirRecordField, HirRepeat, HirRepeatBinding,
    HirRepeatConditionLifetimeFacts, HirReturn, HirStmt, HirTableAccess, HirTableAllocation,
    HirTableConstructor, HirTableField, HirTableSetList, HirTbcDeclaration, HirToBeClosed,
    HirUnaryExpr, HirUnaryOpKind, HirUnresolvedExpr, HirValuePack, HirWhile, LocalId, ParamId,
    TempId, UpvalueId,
};
#[cfg(feature = "decompile-debug")]
pub use debug::dump_hir;
pub use error::HirLowerError;
pub(crate) use expr_safety::{HirInitializerRootProfile, initializer_root_profile};
#[cfg(not(feature = "decompile-debug"))]
mod debug {
    crate::debug::define_unavailable_stage_dump!(dump_hir);
}
#[cfg(not(feature = "decompile-debug"))]
pub use debug::dump_hir;
