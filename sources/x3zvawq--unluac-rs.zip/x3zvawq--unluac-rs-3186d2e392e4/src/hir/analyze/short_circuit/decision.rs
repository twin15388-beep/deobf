//! 将 Structure 冻结的 condition/value-decision DAG 降低为 HIR Decision。
//!
//! 消费节点身份、连边、出口与原操作来源，保留单次求值和终端值身份。

use super::*;
use crate::hir::rewrite::replace_temp_in_expr;

pub(crate) fn build_condition_decision_expr(
    lowering: &ProtoLowering<'_>,
    condition: &ConditionPlan,
) -> Option<HirDecisionExpr> {
    let mut remap = vec![None; condition.nodes.len()];
    let mut values_by_consumer = vec![Vec::new(); condition.nodes.len()];
    let mut next_node = 0usize;
    for node in &condition.nodes {
        if let Some(value) = node.materialized_value {
            values_by_consumer
                .get_mut(value.consumer.index())?
                .push(node.id);
        } else {
            remap[node.id.index()] = Some(HirDecisionNodeRef(next_node));
            next_node += 1;
        }
    }
    let resolved = resolve_condition_nodes(condition, &remap)?;
    let entry = resolved.get(condition.entry.index()).copied().flatten()?;
    let mut subjects = lower_condition_subjects(lowering, condition, &values_by_consumer)?;
    let nodes = condition
        .nodes
        .iter()
        .filter(|node| node.materialized_value.is_none())
        .map(|node| {
            let (test, test_source) = subjects.get_mut(node.id.index())?.take()?;
            Some(HirDecisionNode {
                id: remap[node.id.index()]?,
                test,
                test_source,
                truthy: lower_target(node.semantic_target(true), &resolved)?,
                falsy: lower_target(node.semantic_target(false), &resolved)?,
            })
        })
        .collect::<Option<Vec<_>>>()?;
    (!nodes.is_empty()).then_some(HirDecisionExpr {
        entry,
        nodes,
        emit_as_luau_if: false,
    })
}

pub(crate) fn build_value_decision_expr(
    lowering: &ProtoLowering<'_>,
    decision: &ValueDecisionPlan,
) -> Option<HirDecisionExpr> {
    if !decision.operands.is_empty() {
        return super::operands::build_value_operands(lowering, decision);
    }
    let entry = HirDecisionNodeRef(decision.entry.index());
    let nodes = decision
        .nodes
        .iter()
        .map(|node| {
            let (test, test_source) = if node.id == decision.entry {
                lower_short_circuit_subject(lowering, node.block, node.predicate)
            } else {
                lower_short_circuit_subject_single_eval(lowering, node.block, node.predicate)
            }?;
            let mut lowered = HirDecisionNode {
                id: HirDecisionNodeRef(node.id.index()),
                test,
                test_source,
                truthy: lower_value_target(lowering, decision, node.truthy.target)?,
                falsy: lower_value_target(lowering, decision, node.falsy.target)?,
            };
            if materialized_boolean_comparison(lowering, decision, node, &lowered) {
                lowered.truthy = HirDecisionTarget::CurrentValue;
                lowered.falsy = HirDecisionTarget::CurrentValue;
            }
            Some(lowered)
        })
        .collect::<Option<Vec<_>>>()?;
    (!nodes.is_empty() && entry.index() < nodes.len()).then_some(HirDecisionExpr {
        entry,
        nodes,
        emit_as_luau_if: false,
    })
}

/// 冻结 plan 已验证 terminal edge 到 result_phi 的物理 incoming；再核对原 LOADBOOL
/// 与当前 test/终端，才把显式常量写译为该次比较的返回值，不留下可跨改写复用的许可。
pub(super) fn materialized_boolean_comparison(
    lowering: &ProtoLowering<'_>,
    decision: &ValueDecisionPlan,
    node: &crate::structure::ValueDecisionNodePlan,
    lowered: &HirDecisionNode,
) -> bool {
    let HirExpr::Binary(binary) = &lowered.test else {
        return false;
    };
    if lowering.target != crate::decompile::DecompileDialect::Luajit
        || lowered.test_source != crate::hir::HirDecisionTestSource::Predicate
        || binary.op != crate::hir::HirBinaryOpKind::Eq
        || binary.source_site
            != Some(crate::hir::common::HirSourceSite {
                proto: lowering.id,
                instr: node.predicate,
            })
        || !matches!(
            lowered.truthy,
            HirDecisionTarget::Expr(HirExpr::Boolean(true))
        )
        || !matches!(
            lowered.falsy,
            HirDecisionTarget::Expr(HirExpr::Boolean(false))
        )
    {
        return false;
    }
    [(node.truthy.target, true), (node.falsy.target, false)]
        .into_iter()
        .all(|(target, expected)| {
            let ValueDecisionTarget::Leaf(leaf) = target else {
                return false;
            };
            let crate::structure::SsaValue::Def(def) = decision.leaves[leaf.index()].physical_value else {
                return false;
            };
            matches!(lowering.proto.instrs[lowering.dataflow.def_instr(def).index()],
                LowInstr::LoadBool(load) if load.dst == decision.result_reg && load.value == expected)
        })
}

pub(super) fn lower_value_target(
    lowering: &ProtoLowering<'_>,
    decision: &ValueDecisionPlan,
    target: ValueDecisionTarget,
) -> Option<HirDecisionTarget> {
    match target {
        ValueDecisionTarget::Node(node) => (node.index() < decision.nodes.len())
            .then_some(HirDecisionTarget::Node(HirDecisionNodeRef(node.index()))),
        ValueDecisionTarget::Leaf(leaf) => {
            let leaf = decision.leaves.get(leaf.index())?;
            // 值叶可以直接转交同一 decision 内较早的 LOADBOOL/LOADK，定义不一定
            // 位于叶块。其原块不会发射；继续引用 temp 会把 false 变成未初始化 nil。
            // 这里只展开无独立求值事件的字面量，动态共享 producer 仍保留身份。
            let carried_literal = match leaf.value {
                crate::structure::SsaValue::Def(def)
                    if lowering.dataflow.def_block(def) != decision.header()?
                        && lowering
                            .structure
                            .plan()
                            .region_for_block(lowering.dataflow.def_block(def))
                            == lowering
                                .structure
                                .plan()
                                .region_for_block(decision.header()?) =>
                {
                    expr_for_direct_literal_def(lowering, def)
                }
                _ => None,
            };
            let expr = if let Some(literal) = carried_literal {
                literal
            } else if let crate::structure::SsaValue::Def(def) = leaf.value
                && lowering.dataflow.def_block(def) == decision.header()?
            {
                // 内部操作数可以把入口写入转交到较晚的叶；latest_local_def 只描述
                // 该叶块，不能因此丢掉已经冻结的入口 SSA 身份。
                // Header prefix 正常发射，动态 producer 必须读取原值，不能再次求值。
                expr_for_emitted_header_leaf(lowering, decision.header()?, def)
            } else {
                match leaf.latest_local_def {
                    // ValueDecision 吞掉了 leaf block 的普通指令，必须优先沿完整单次求值
                    // 依赖链展开；普通 def lowering 可能返回引用那些不会再被发射的中间 temp。
                    Some(def) => expr_for_fixed_def_single_eval(lowering, def)
                        .or_else(|| expr_for_fixed_def(lowering, def))?,
                    None => super::super::exprs::expr_for_ssa_value_in_block(
                        lowering, leaf.block, leaf.value,
                    )?,
                }
            };
            Some(HirDecisionTarget::Expr(expr))
        }
        ValueDecisionTarget::CurrentValue(leaf) => decision
            .leaves
            .get(leaf.index())
            .map(|_| HirDecisionTarget::CurrentValue),
    }
}

pub(super) fn expr_for_emitted_header_leaf(
    lowering: &ProtoLowering<'_>,
    header: BlockRef,
    def: crate::structure::DefId,
) -> HirExpr {
    let reg = lowering.dataflow.def_reg(def);
    let fallback = || {
        lowering.bindings.expr_for_reg_value(header, reg, || {
            expr_for_ssa_value(lowering, crate::structure::SsaValue::Def(def))
        })
    };
    let Some(temp) = lowering.bindings.fixed_temps.get(def.index()).copied() else {
        return fallback();
    };

    // Header prefix 仍按原位置发射。这里只把没有源码/捕获身份的稳定字面量交给
    // decision leaf；随后 dead-temp 才能在确认无剩余引用后删除那条机械赋值。
    // 捕获身份由当前 temp/local binding 判断；同槽未来另一版本的 capture 不约束本次字面量。
    if !matches!(
        lowering.bindings.temp_debug_locals.get(temp.index()),
        Some(None)
    ) || lowering.bindings.captured_temp_targets.contains_key(&temp)
        || lowering.bindings.temp_decl_locals.contains_key(&temp)
        || lowering
            .bindings
            .local_for_reg_in_block(header, reg)
            .is_some()
    {
        return fallback();
    }

    // Boolean 预写由完整帧按原结果槽重发；其他入口常量仍可能是分支前已经生效的
    // 初始化。先保留其读取身份，不能把入口写改成仅在未选中另一臂时才执行的字面量。
    match expr_for_direct_literal_def(lowering, def) {
        Some(value @ HirExpr::Boolean(_)) => value,
        _ => fallback(),
    }
}

fn lower_condition_subjects(
    lowering: &ProtoLowering<'_>,
    condition: &ConditionPlan,
    values_by_consumer: &[Vec<crate::structure::ConditionNodeId>],
) -> Option<Vec<Option<(HirExpr, crate::hir::HirDecisionTestSource)>>> {
    let mut subjects = vec![None; condition.nodes.len()];
    let mut state = vec![0u8; condition.nodes.len()];

    for start in 0..condition.nodes.len() {
        if state[start] == 2 {
            continue;
        }
        let mut pending = vec![(crate::structure::ConditionNodeId(start), false)];
        while let Some((node_id, exiting)) = pending.pop() {
            let index = node_id.index();
            if exiting {
                if *state.get(index)? != 1 {
                    return None;
                }
                let node = condition.nodes.get(index)?;
                if !matches!(
                    lowering.proto.instrs.get(node.predicate.index()),
                    Some(LowInstr::Branch(_))
                ) {
                    return None;
                }
                let (mut expr, mut test_source) = if node.id == condition.entry {
                    lower_short_circuit_subject(lowering, node.block, node.predicate)
                } else {
                    lower_short_circuit_subject_single_eval(lowering, node.block, node.predicate)
                }?;
                for producer_id in values_by_consumer.get(index)? {
                    let producer = condition.nodes.get(producer_id.index())?;
                    let value = producer.materialized_value?;
                    let (mut replacement, _) = subjects.get_mut(producer_id.index())?.take()?;
                    // 合流值的极性替换不是原 operand 写回证明，不能给外层表达式签 Value。
                    test_source = crate::hir::HirDecisionTestSource::Predicate;
                    if value.negated {
                        replacement = HirExpr::Unary(Box::new(crate::hir::HirUnaryExpr {
                            source_site: None,
                            op: crate::hir::HirUnaryOpKind::Not,
                            expr: replacement,
                        }));
                    }
                    let read = super::super::exprs::expr_for_ssa_value_in_block(
                        lowering,
                        node.block,
                        crate::structure::SsaValue::Phi(value.phi),
                    )?;
                    let binding = crate::hir::HirBinding::from_expr(&read)?;
                    if crate::hir::rewrite::replace_binding_in_expr(
                        &mut expr,
                        binding,
                        &replacement,
                    ) != 1
                    {
                        return None;
                    }
                    if let Some(def) = value.forwarded_callee {
                        let temp = *lowering.bindings.fixed_temps.get(def.index())?;
                        let replacement = expr_for_fixed_def_single_eval(lowering, def)?;
                        // absorbed-condition 的稠密 owner 会让 single-eval lowering 提前展开
                        // 同一 condition 内的 callee；0 次替换表示它已经被展开。
                        if replace_temp_in_expr(&mut expr, temp, &replacement) > 1 {
                            return None;
                        }
                    }
                }
                state[index] = 2;
                subjects[index] = Some((expr, test_source));
                continue;
            }

            match *state.get(index)? {
                0 => {
                    state[index] = 1;
                    pending.push((node_id, true));
                    for producer in values_by_consumer.get(index)?.iter().rev() {
                        match *state.get(producer.index())? {
                            0 => pending.push((*producer, false)),
                            1 => return None,
                            2 => {}
                            _ => return None,
                        }
                    }
                }
                1 => return None,
                2 => {}
                _ => return None,
            }
        }
    }
    Some(subjects)
}

fn resolve_condition_nodes(
    condition: &ConditionPlan,
    remap: &[Option<HirDecisionNodeRef>],
) -> Option<Vec<Option<HirDecisionNodeRef>>> {
    let mut resolved = vec![None; condition.nodes.len()];
    let mut state = vec![0u8; condition.nodes.len()];
    let mut pending = Vec::new();
    for start in 0..condition.nodes.len() {
        if state[start] == 2 {
            continue;
        }
        pending.clear();
        let mut node = crate::structure::ConditionNodeId(start);
        let target = loop {
            let index = node.index();
            match *state.get(index)? {
                0 => {}
                1 => return None,
                2 => break resolved.get(index).copied().flatten()?,
                _ => return None,
            }
            state[index] = 1;
            pending.push(node);

            let plan = condition.nodes.get(index)?;
            if plan.materialized_value.is_none() {
                break remap.get(index).copied().flatten()?;
            }
            let (ConditionTarget::Node(truthy), ConditionTarget::Node(falsy)) =
                (plan.semantic_target(true), plan.semantic_target(false))
            else {
                return None;
            };
            if truthy != falsy {
                return None;
            }
            node = truthy;
        };
        for node in pending.drain(..).rev() {
            state[node.index()] = 2;
            resolved[node.index()] = Some(target);
        }
    }
    Some(resolved)
}

fn lower_target(
    target: ConditionTarget,
    resolved: &[Option<HirDecisionNodeRef>],
) -> Option<HirDecisionTarget> {
    match target {
        ConditionTarget::Node(node) => Some(HirDecisionTarget::Node(
            resolved.get(node.index()).copied().flatten()?,
        )),
        ConditionTarget::Truthy => Some(HirDecisionTarget::Expr(HirExpr::Boolean(true))),
        ConditionTarget::Falsy => Some(HirDecisionTarget::Expr(HirExpr::Boolean(false))),
    }
}
