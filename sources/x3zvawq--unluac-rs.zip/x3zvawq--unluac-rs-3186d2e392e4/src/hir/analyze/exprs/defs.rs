//! 将唯一来源的 DefId 降低为可复用的 HIR 值。
//!
//! 消费 Dataflow 的定义身份，不为多来源 merge 推测表达式。

use super::*;
use crate::transformer::GetTableKind;

/// 尝试把一个固定定义直接解释成 HIR 表达式。
///
/// 这主要服务 merge 点上的值恢复。我们只在“一个 def 能稳定对应一个值表达式”时
/// 返回 `Some`，否则宁可交回上层继续保守退化，也不在这里伪造来源。
///
/// 这里一旦决定把某个 `call(...)` def 直接恢复成表达式，嵌套的 `callee/args` 也应继续按
/// `single-eval` 语义下钻；否则像 `obj.method(...)` 这种“先读 field 再调用”的值会被
/// 半截留成 temp，最终又把更高层的短路/value-merge 恢复逼回 `if` 壳。
pub(crate) fn expr_for_fixed_def(lowering: &ProtoLowering<'_>, def_id: DefId) -> Option<HirExpr> {
    if let Some(expr) = expr_for_dup_safe_fixed_def(lowering, def_id) {
        return Some(expr);
    }

    let def_instr = lowering.dataflow.def_instr(def_id);
    let def_reg = lowering.dataflow.def_reg(def_id);
    let def_block = lowering.dataflow.def_block(def_id);
    let instr = lowering.proto.instrs.get(def_instr.index())?;

    match instr {
        LowInstr::GetUpvalue(get_upvalue) if get_upvalue.dst == def_reg => {
            Some(lower_upvalue_operand_expr(lowering, get_upvalue.src))
        }
        LowInstr::UnaryOp(unary) if unary.dst == def_reg => {
            Some(HirExpr::Unary(Box::new(HirUnaryExpr {
                source_site: Some(crate::hir::common::HirSourceSite {
                    proto: lowering.id,
                    instr: def_instr,
                }),
                op: lower_unary_op(unary.op),
                expr: expr_for_reg_use(lowering, def_block, def_instr, unary.src),
            })))
        }
        LowInstr::BinaryOp(binary) if binary.dst == def_reg => {
            Some(super::super::helpers::binary_expr(
                crate::hir::common::HirSourceSite {
                    proto: lowering.id,
                    instr: def_instr,
                },
                lower_binary_op(binary.op),
                expr_for_value_operand(lowering, def_block, def_instr, binary.lhs),
                expr_for_value_operand(lowering, def_block, def_instr, binary.rhs),
            ))
        }
        LowInstr::Concat(concat) if concat.dst == def_reg => Some(concat_expr(
            crate::hir::common::HirSourceSite {
                proto: lowering.id,
                instr: def_instr,
            },
            (0..concat.src.len).map(|offset| {
                expr_for_reg_use(
                    lowering,
                    def_block,
                    def_instr,
                    Reg(concat.src.start.index() + offset),
                )
            }),
        )),
        LowInstr::GetTable(get_table) if get_table.dst == def_reg => {
            Some(if get_table.kind == GetTableKind::Raw {
                lower_raw_table_get_expr_inline(
                    lowering,
                    def_block,
                    def_instr,
                    get_table.base,
                    get_table.key,
                )
            } else {
                lower_table_access_expr_inline(
                    lowering,
                    def_block,
                    def_instr,
                    get_table.base,
                    get_table.key,
                )
            })
        }
        LowInstr::NewTable(new_table) if new_table.dst == def_reg => {
            Some(super::expr_for_new_table(
                lowering.proto,
                new_table,
                crate::hir::common::HirSourceSite {
                    proto: lowering.id,
                    instr: def_instr,
                },
            ))
        }
        LowInstr::Call(call) => expr_for_fixed_call(lowering, def_block, def_instr, call, def_reg),
        LowInstr::VarArg(vararg) => expr_for_fixed_vararg(vararg.results, def_reg),
        LowInstr::Closure(closure) if closure.dst == def_reg => {
            Some(lower_closure_expr(lowering, def_block, def_instr, closure))
        }
        LowInstr::GenericForPrep(_) | LowInstr::GenericForCall(_) => None,
        LowInstr::SetUpvalue(_)
        | LowInstr::SetTable(_)
        | LowInstr::SetList(_)
        | LowInstr::TailCall(_)
        | LowInstr::Return(_)
        | LowInstr::Close(_)
        | LowInstr::NumericForInit(_)
        | LowInstr::NumericForLoop(_)
        | LowInstr::GenericForLoop(_)
        | LowInstr::Jump(_)
        | LowInstr::Branch(_) => None,
        _ => None,
    }
}
/// `single-eval` 变体：允许沿着 Move/GetTable 以及纯表达式操作链深度展开，
/// 把 call 等非 dup-safe 的值也直接内联成表达式。
/// 专门服务被吸收的短路分支里 temp 赋值不会出现的场景。
pub(crate) fn expr_for_fixed_def_single_eval(
    lowering: &ProtoLowering<'_>,
    def_id: DefId,
) -> Option<HirExpr> {
    let def_instr = lowering.dataflow.def_instr(def_id);
    let def_reg = lowering.dataflow.def_reg(def_id);
    let def_block = lowering.dataflow.def_block(def_id);
    let instr = lowering.proto.instrs.get(def_instr.index())?;
    let absorbed = block_is_absorbed_decision(lowering, def_block);

    match instr {
        LowInstr::Move(move_instr) if move_instr.dst == def_reg => {
            if !absorbed && lowering.dataflow.reg_is_reference_captured(move_instr.src) {
                return None;
            }
            let expr = expr_for_reg_use_single_eval_with_call_policy(
                lowering,
                def_block,
                def_instr,
                move_instr.src,
                false,
            );
            // closure capture provenance 依赖“同一个子 proto 的闭包表达式”看到稳定的
            // 父作用域来源。Move 链如果把 local function 的 closure 复制进条件表达式，
            // 可能绕过后续 local override，让 capture 从 `local pos` 退回字面量初值。
            // 这种值保留 temp 更安全，也和普通 single-eval 的“只恢复操作数本体”边界一致。
            if matches!(expr, HirExpr::Closure(_)) {
                return Some(expr_for_ssa_value(
                    lowering,
                    lowering.dataflow.use_value(def_instr, move_instr.src),
                ));
            }
            return Some(expr);
        }
        LowInstr::GetTable(get_table) if get_table.dst == def_reg => {
            return Some(if get_table.kind == GetTableKind::Raw {
                lower_raw_table_get_expr_single_eval(
                    lowering,
                    def_block,
                    def_instr,
                    get_table.base,
                    get_table.key,
                )
            } else {
                lower_table_access_expr_single_eval(
                    lowering,
                    def_block,
                    def_instr,
                    get_table.base,
                    get_table.key,
                )
            });
        }
        LowInstr::UnaryOp(unary) if unary.dst == def_reg => {
            if !absorbed && lowering.dataflow.reg_is_reference_captured(unary.src) {
                return None;
            }
            return Some(HirExpr::Unary(Box::new(HirUnaryExpr {
                source_site: Some(crate::hir::common::HirSourceSite {
                    proto: lowering.id,
                    instr: def_instr,
                }),
                op: lower_unary_op(unary.op),
                expr: expr_for_reg_use_single_eval_with_call_policy(
                    lowering, def_block, def_instr, unary.src, true,
                ),
            })));
        }
        LowInstr::BinaryOp(binary) if binary.dst == def_reg => {
            if !absorbed
                && [binary.lhs, binary.rhs]
                    .into_iter()
                    .filter_map(|operand| match operand {
                        ValueOperand::Reg(reg) => Some(reg),
                        ValueOperand::Const(_)
                        | ValueOperand::Integer(_)
                        | ValueOperand::Nil
                        | ValueOperand::Boolean(_) => None,
                    })
                    .any(|reg| lowering.dataflow.reg_is_reference_captured(reg))
            {
                return None;
            }
            return Some(super::super::helpers::binary_expr(
                crate::hir::common::HirSourceSite {
                    proto: lowering.id,
                    instr: def_instr,
                },
                lower_binary_op(binary.op),
                expr_for_value_operand_single_eval_pure_operand(
                    lowering, def_block, def_instr, binary.lhs,
                ),
                expr_for_value_operand_single_eval_pure_operand(
                    lowering, def_block, def_instr, binary.rhs,
                ),
            ));
        }
        LowInstr::Concat(concat) if concat.dst == def_reg => {
            if !absorbed
                && (0..concat.src.len)
                    .map(|offset| Reg(concat.src.start.index() + offset))
                    .any(|reg| lowering.dataflow.reg_is_reference_captured(reg))
            {
                return None;
            }
            let value = concat_expr(
                crate::hir::common::HirSourceSite {
                    proto: lowering.id,
                    instr: def_instr,
                },
                (0..concat.src.len).map(|offset| {
                    expr_for_reg_use_single_eval_with_call_policy(
                        lowering,
                        def_block,
                        def_instr,
                        Reg(concat.src.start.index() + offset),
                        true,
                    )
                }),
            );
            return Some(value);
        }
        _ => {}
    }

    expr_for_fixed_def(lowering, def_id)
}
/// 这类定义可以安全地在表达式里重复展开，不会额外增加副作用，也不会改变
/// `newtable/closure/call` 这类“每次求值都不一样”的语义。
pub(crate) fn expr_for_dup_safe_fixed_def(
    lowering: &ProtoLowering<'_>,
    def_id: DefId,
) -> Option<HirExpr> {
    let def_instr = lowering.dataflow.def_instr(def_id);
    let def_reg = lowering.dataflow.def_reg(def_id);
    let def_block = lowering.dataflow.def_block(def_id);
    let instr = lowering.proto.instrs.get(def_instr.index())?;
    if lowering.dataflow.effect_summaries[def_instr.index()].has_effect_tags() {
        return None;
    }

    match instr {
        LowInstr::Move(move_instr) if move_instr.dst == def_reg => {
            expr_for_reg_use_dup_safe(lowering, def_block, def_instr, move_instr.src)
        }
        LowInstr::LoadNil(load_nil) if reg_in_range(load_nil.dst, def_reg) => Some(HirExpr::Nil),
        LowInstr::LoadBool(load_bool) if load_bool.dst == def_reg => {
            Some(HirExpr::Boolean(load_bool.value))
        }
        LowInstr::LoadConst(load_const) if load_const.dst == def_reg => {
            Some(expr_for_const(lowering.proto, load_const.value))
        }
        LowInstr::LoadInteger(load_integer) if load_integer.dst == def_reg => {
            Some(HirExpr::Integer(load_integer.value))
        }
        LowInstr::LoadNumber(load_number) if load_number.dst == def_reg => {
            Some(HirExpr::Number(load_number.value))
        }
        LowInstr::UnaryOp(unary) if unary.dst == def_reg => {
            Some(HirExpr::Unary(Box::new(HirUnaryExpr {
                source_site: Some(crate::hir::common::HirSourceSite {
                    proto: lowering.id,
                    instr: def_instr,
                }),
                op: lower_unary_op(unary.op),
                expr: expr_for_reg_use_dup_safe(lowering, def_block, def_instr, unary.src)?,
            })))
        }
        LowInstr::GenericForPrep(prep) => prep
            .source_for_target(def_reg)
            .and_then(|source| expr_for_reg_use_dup_safe(lowering, def_block, def_instr, source)),
        LowInstr::GenericForLoop(loop_instr)
            if loop_instr.control_target == def_reg && loop_instr.bindings.len != 0 =>
        {
            expr_for_reg_use_dup_safe(lowering, def_block, def_instr, loop_instr.bindings.start)
        }
        _ => None,
    }
}

/// 只恢复定义指令直接写入的稳定字面量，不沿 Move 或其它表达式来源递归。
pub(crate) fn expr_for_direct_literal_def(
    lowering: &ProtoLowering<'_>,
    def_id: DefId,
) -> Option<HirExpr> {
    let def_instr = lowering.dataflow.def_instr(def_id);
    if !matches!(
        lowering.proto.instrs.get(def_instr.index())?,
        LowInstr::LoadNil(_)
            | LowInstr::LoadBool(_)
            | LowInstr::LoadConst(_)
            | LowInstr::LoadInteger(_)
            | LowInstr::LoadNumber(_)
    ) {
        return None;
    }
    expr_for_dup_safe_fixed_def(lowering, def_id)
}

fn expr_for_fixed_call(
    lowering: &ProtoLowering<'_>,
    block: BlockRef,
    instr_ref: InstrRef,
    call: &crate::transformer::CallInstr,
    reg: Reg,
) -> Option<HirExpr> {
    let ResultPack::Fixed(results) = call.results else {
        return None;
    };
    if results.len != 1 || results.start != reg {
        return None;
    }

    let method_key = lower_method_key(lowering, instr_ref, call.method_name);
    let callee = expr_for_reg_use_single_eval_with_call_policy(
        lowering,
        block,
        instr_ref,
        call.callee,
        false,
    );

    Some(HirExpr::Call(Box::new(HirCallExpr {
        required_luau_inlining: None,
        source_site: Some(crate::hir::common::HirSourceSite {
            proto: lowering.id,
            instr: instr_ref,
        }),
        argument_roots: lowering.promotion_facts.call_argument_roots(instr_ref),
        frame_root_ends: lowering.promotion_facts.call_frame_root_ends(instr_ref),
        callee,
        args: lower_value_pack_single_eval(lowering, block, instr_ref, call.args),
        method: lower_call_method(lowering, instr_ref, call.kind),
        fastcall: match call.kind {
            CallKind::FastCall(args) => Some(args),
            CallKind::Normal | CallKind::Method => None,
        },
        method_key,
        callee_root_handoff: lower_call_root_handoff(lowering, instr_ref),
        method_rewrite_transaction: None,
        plain_method_syntax: false,
        boolean_prewrite_arguments: Vec::new(),
    })))
}

fn expr_for_fixed_vararg(results: ResultPack, reg: Reg) -> Option<HirExpr> {
    let ResultPack::Fixed(range) = results else {
        return None;
    };
    if range.len == 1 && range.start == reg {
        Some(HirExpr::VarArg)
    } else {
        None
    }
}
