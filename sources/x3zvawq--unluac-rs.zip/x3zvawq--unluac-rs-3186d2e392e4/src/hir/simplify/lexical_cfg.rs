//! 发布当前 HIR 区域共享的控制流图与词法查询。
//!
//! 统一解释结构化控制和 label/goto，供消费者查询边及支配关系；仅对当前树快照有效。

use std::{
    cell::OnceCell,
    collections::{BTreeMap, BTreeSet, VecDeque},
};

use crate::hir::common::{
    HirBinding, HirBlock, HirExpr, HirGenericFor, HirLabelId, HirRepeat, HirStmt, LocalId,
};
use crate::hir::expr_safety::HirExprSafety;

use super::expr_facts::expr_truthiness;
use super::mention::{BindingReadCollector, BindingWriteCollector};
use super::stmt_plan::{PathComponent, StmtPath};
use crate::hir::visit::visit_stmt_structure;

mod statement_tree;
pub(super) use statement_tree::{HirStmtId, HirStmtTree};

#[derive(Debug, Clone, Copy, Eq, PartialEq)]
pub(super) enum LexicalCfgFailure {
    AmbiguousLabel,
    ExternalEntry,
}

/// 当前区域的词法入口事实，不裁剪不可达的 label/goto，也不证明出口或支配关系。
pub(super) fn validate_region_entry(
    stmts: &[HirStmt],
    owner_label_refs: &BTreeMap<HirLabelId, usize>,
) -> Result<(), LexicalCfgFailure> {
    let mut labels = BTreeSet::new();
    let mut internal_refs = BTreeMap::<HirLabelId, usize>::new();
    let mut has_duplicate = false;
    for stmt in stmts {
        visit_stmt_structure(stmt, &mut |stmt| match stmt {
            HirStmt::Label(label) => has_duplicate |= !labels.insert(label.id),
            HirStmt::Goto(goto) => *internal_refs.entry(goto.target).or_default() += 1,
            _ => {}
        });
    }
    if has_duplicate {
        return Err(LexicalCfgFailure::AmbiguousLabel);
    }
    if labels.iter().any(|label| {
        owner_label_refs.get(label).copied().unwrap_or_default()
            != internal_refs.get(label).copied().unwrap_or_default()
    }) {
        return Err(LexicalCfgFailure::ExternalEntry);
    }
    Ok(())
}

pub(super) struct LexicalCfg {
    successors: Vec<BTreeSet<usize>>,
    has_external_exit: bool,
}

/// 仅在一次 HIR topology 快照中有效的节点身份。
#[derive(Clone, Copy, Debug, Eq, Ord, PartialEq, PartialOrd)]
pub(super) struct HirFlowNodeId(usize);

impl HirFlowNodeId {
    pub(super) const fn index(self) -> usize {
        self.0
    }
}

/// 仅在一次 HIR topology 快照中关联 generic-for init/dispatch/binding 的身份。
#[derive(Clone, Copy, Debug, Eq, Ord, PartialEq, PartialOrd)]
pub(super) struct HirFlowProtocolId(usize);

/// Structure 已折叠成源码 generic-for 后仍必须保留的运行时协议节点 owner。
#[derive(Clone, Copy)]
pub(super) struct HirGenericForFlow<'a> {
    protocol: HirFlowProtocolId,
    stmt: &'a HirStmt,
    for_stmt: &'a HirGenericFor,
}

impl<'a> HirGenericForFlow<'a> {
    pub(super) const fn protocol(self) -> HirFlowProtocolId {
        self.protocol
    }

    pub(super) const fn stmt(self) -> &'a HirStmt {
        self.stmt
    }

    pub(super) const fn for_stmt(self) -> &'a HirGenericFor {
        self.for_stmt
    }
}

/// 节点上需要由消费者执行的 HIR 语义事件。
///
/// generic-for 的 init/dispatch/binding 共享一个 snapshot-scoped protocol id：init 只
/// 求值一次 iterator pack，dispatch 每轮（包括最终退出前）调用被冻结的 iterator，binding
/// 只在分派选择新一轮后写入。因此退出边不会错误承载一次并未发生的源码 binding 写入。
/// `RepeatCondition` 独立表达 latch，使 lifetime consumer
/// 能在条件观测前检查 body 中仍存活的 binding。函数 owner 还把显式 `return` 与正常落底
/// 汇入 `FunctionExit`，而无法归属的控制转移进入 `UnknownControl`。
#[derive(Clone, Copy)]
pub(super) enum HirFlowNodeKind<'a> {
    Exit,
    FunctionExit,
    UnknownControl,
    Stmt(&'a HirStmt),
    GenericForInit(HirGenericForFlow<'a>),
    RepeatCondition(&'a HirRepeat),
    NumericForDispatch,
    GenericForDispatch(HirGenericForFlow<'a>),
    ForBinding(HirForBindings<'a>),
}

impl<'hir> HirFlowNodeKind<'hir> {
    /// 访问本事件的显式 HIR 求值与赋值子节点，不进入嵌套块。
    ///
    /// for initializer 只访问一次，repeat 条件只在尾端事件访问；隐式 dispatch、
    /// for binding 写入和控制边界仍由 consumer 解释，不能伪造成源码表达式。
    pub(super) fn visit_evaluation(self, visitor: &mut impl crate::hir::visit::HirVisitor<'hir>) {
        use crate::hir::visit::{visit_expr, visit_stmt_header};
        match self {
            Self::Stmt(stmt) => visit_stmt_header(stmt, visitor),
            Self::GenericForInit(flow) => visit_stmt_header(flow.stmt(), visitor),
            Self::RepeatCondition(stmt) => visit_expr(&stmt.cond, visitor),
            Self::Exit
            | Self::FunctionExit
            | Self::UnknownControl
            | Self::NumericForDispatch
            | Self::GenericForDispatch(_)
            | Self::ForBinding(_) => {}
        }
    }
}

/// for 每轮成功分派后由 VM 写入的源码 binding。
#[derive(Clone, Copy)]
pub(super) enum HirForBindings<'a> {
    Numeric(LocalId),
    Generic(HirGenericForFlow<'a>),
}

pub(super) struct HirFlowNode<'a> {
    owner_stmt: Option<&'a HirStmt>,
    kind: HirFlowNodeKind<'a>,
    successors: BTreeMap<HirFlowNodeId, Option<bool>>,
}

impl<'a> HirFlowNode<'a> {
    /// 当前图快照中的原始语句身份；一个循环语句可拥有多个求值/控制事件。
    pub(super) const fn owner_stmt(&self) -> Option<&'a HirStmt> {
        self.owner_stmt
    }

    pub(super) const fn kind(&self) -> HirFlowNodeKind<'a> {
        self.kind
    }

    /// 条件求值事件的原始表达式；for dispatch 不属于表达式 truthiness 分支。
    pub(super) fn condition(&self) -> Option<&'a HirExpr> {
        match self.kind {
            HirFlowNodeKind::Stmt(HirStmt::If(stmt)) => Some(&stmt.cond),
            HirFlowNodeKind::Stmt(HirStmt::While(stmt)) => Some(&stmt.cond),
            HirFlowNodeKind::RepeatCondition(stmt) => Some(&stmt.cond),
            _ => None,
        }
    }

    /// None 是无约束边；同一条件的真假出口相同时也合并为无约束边。
    pub(super) fn successors(&self) -> &BTreeMap<HirFlowNodeId, Option<bool>> {
        &self.successors
    }
}

/// 当前 proto HIR 树的 owner-wide 控制流 topology。
///
/// 图只借用 HIR 节点，必须在对应树发生改写前丢弃。它不附带任何特定 pass 的
/// lattice，避免 root、liveness 和 reaching-def 因为共享 topology 而被耦合在一起。
pub(super) struct HirFlowGraph<'a> {
    nodes: Vec<HirFlowNode<'a>>,
    // 只在前向求解时冻结最终入边的 0/1/多条分类；可达性/SCC 查询不分配此表。
    incoming_multiplicity: OnceCell<Box<[u8]>>,
    entry: HirFlowNodeId,
    exit: HirFlowNodeId,
    goto_edges: Vec<(HirFlowNodeId, OwnerLabelLocation)>,
    unresolved_gotos: Vec<(HirFlowNodeId, HirLabelId)>,
}

impl<'a> HirFlowGraph<'a> {
    pub(super) fn for_block(
        block: &'a HirBlock,
        safety: HirExprSafety,
    ) -> Result<Self, LexicalCfgFailure> {
        Self::for_stmts(&block.stmts, safety)
    }

    /// 为当前 HIR 快照中的连续语句 region 构造完整 topology。
    ///
    /// region 外的 `break` / `continue` 都是终止边；未能在 region 内解析的 goto
    /// 会单独保留来源，消费者可在可达性计算后决定是否拒绝该输入。
    pub(super) fn for_stmts(
        stmts: &'a [HirStmt],
        safety: HirExprSafety,
    ) -> Result<Self, LexicalCfgFailure> {
        Self::for_stmts_with_locations(stmts, safety, |_, _, _, _| {})
    }

    /// 构图时借用当前位置，供 consumer 只保存所需事件的删除或改写坐标。
    ///
    /// 每个有语句 owner 的 typed event 恰好回调一次，包括 repeat 条件及 for 的各个
    /// 分派事件；合成出口不回调。回调顺序是构图顺序，不是执行或源码顺序，位置相对于
    /// 输入 stmts 的根。若构图失败，调用方必须丢弃本次回调产物。
    pub(super) fn for_stmts_with_locations(
        stmts: &'a [HirStmt],
        safety: HirExprSafety,
        observer: impl FnMut(HirFlowNodeId, HirFlowNodeKind<'a>, &LexicalBlockPath, usize),
    ) -> Result<Self, LexicalCfgFailure> {
        HirFlowGraphBuilder::new(safety, HirFlowBoundary::Region, observer).build(stmts)
    }

    /// 为完整函数 owner 构造 topology。
    ///
    /// 与 region 图不同，函数图把 `return` 和正常落底接到同一个函数出口；无法归属的
    /// goto/break/continue 则接到 conservative unknown sink。需要在函数结束观测 TBC、
    /// closure 或其它生命周期事实的 consumer 应使用此入口。
    pub(super) fn for_proto(
        block: &'a HirBlock,
        safety: HirExprSafety,
    ) -> Result<Self, LexicalCfgFailure> {
        Self::for_proto_with_locations(block, safety, |_, _, _, _| {})
    }

    /// 发布函数图的节点位置，同时保留 FunctionExit 与 unknown-control 边界。
    pub(super) fn for_proto_with_locations(
        block: &'a HirBlock,
        safety: HirExprSafety,
        observer: impl FnMut(HirFlowNodeId, HirFlowNodeKind<'a>, &LexicalBlockPath, usize),
    ) -> Result<Self, LexicalCfgFailure> {
        HirFlowGraphBuilder::new(safety, HirFlowBoundary::Function, observer).build(&block.stmts)
    }

    pub(super) const fn exit(&self) -> HirFlowNodeId {
        self.exit
    }

    pub(super) fn nodes(&self) -> &[HirFlowNode<'a>] {
        &self.nodes
    }

    /// 当前图的直接 binding 活跃性，按共享 visitor 读取 RHS、条件、参数与 capture。
    /// for 只在成功的 binding 边写入；例如各自作用域内的 f 调用结束后，后续分支不再
    /// 携带它的直接值需求。间接 ByReference 环境或对象持有需求由具体 consumer 补充。
    pub(super) fn binding_live_out(&self) -> Vec<BTreeSet<HirBinding>> {
        let events = self
            .nodes()
            .iter()
            .map(|node| {
                let mut reads = BTreeSet::new();
                let mut writes = BTreeSet::new();
                node.kind().visit_evaluation(&mut (
                    BindingReadCollector(|binding| {
                        reads.insert(binding);
                    }),
                    BindingWriteCollector(|binding| {
                        writes.insert(binding);
                    }),
                ));
                match node.kind() {
                    HirFlowNodeKind::Stmt(HirStmt::NumericFor(_))
                    | HirFlowNodeKind::GenericForInit(_) => {
                        writes.clear();
                    }
                    HirFlowNodeKind::ForBinding(HirForBindings::Numeric(local)) => {
                        writes.insert(HirBinding::Local(local));
                    }
                    HirFlowNodeKind::ForBinding(HirForBindings::Generic(flow)) => {
                        writes.extend(
                            flow.for_stmt()
                                .bindings
                                .iter()
                                .copied()
                                .map(HirBinding::Local),
                        );
                    }
                    _ => {}
                }
                (reads, writes)
            })
            .collect::<Vec<_>>();
        let mut live_out = vec![BTreeSet::new(); self.nodes().len()];
        self.solve_backward(
            BTreeSet::<HirBinding>::new(),
            |current, incoming| {
                let before = current.len();
                current.extend(incoming.iter().copied());
                current.len() != before
            },
            |id, _, live| {
                live_out[id.index()].clone_from(live);
                let (reads, writes) = &events[id.index()];
                live.retain(|binding| !writes.contains(binding));
                live.extend(reads.iter().copied());
            },
        );
        live_out
    }

    /// 在同一 topology 快照上求前向抽象状态不动点。
    ///
    /// `None` 仅表示不可达，首次到达直接安装状态；之后由 consumer 的 `join` 区分
    /// may-union 与 must-intersection。`transfer` 只解释当前 typed event，不重复建边。
    /// consumer 必须使用有限单调域和单调 transfer，并仅在 join 改变状态时返回 true；观察副产物也
    /// 必须单调合并，因为回边可能使同一节点再次执行。返回值只保存 consumer 从当前
    /// 事件投影出的结果，不强迫它保存整份输入状态再重放 transfer。
    /// 单前驱节点消费并移动状态，只有入口和合流点保存用于不动点比较的输入；每个
    /// 入口可达环必经这类 checkpoint，因此线性链无需按语句复制不断增长的状态。
    pub(super) fn solve_forward<S: Clone, R>(
        &self,
        initial: S,
        join: impl FnMut(&mut S, &S) -> bool,
        transfer: impl FnMut(HirFlowNodeId, HirFlowNodeKind<'a>, &mut S) -> R,
    ) -> Vec<Option<R>> {
        self.solve_forward_with_entries(initial, std::iter::empty(), join, transfer)
    }

    /// 与 solve_forward 共用求解过程，额外入口由 consumer 提供本图节点及其输入事实。
    ///
    /// 例如区域内 label 仍有区域外 goto 时，可从该 label 注入 unknown，而不抹去其它
    /// 路径的已知状态。重复入口先按 join 合流且只入队一次；额外入口即使只有一个图内
    /// 前驱也保留输入 checkpoint，保证注入事实在回边重访时不丢失。空入口列表不分配
    /// 额外的节点表；与普通入口一样，seed 身份必须属于当前图快照。
    pub(super) fn solve_forward_with_entries<S: Clone, R>(
        &self,
        initial: S,
        additional_entries: impl IntoIterator<Item = (HirFlowNodeId, S)>,
        mut join: impl FnMut(&mut S, &S) -> bool,
        mut transfer: impl FnMut(HirFlowNodeId, HirFlowNodeKind<'a>, &mut S) -> R,
    ) -> Vec<Option<R>> {
        let incoming_edges = self.incoming_multiplicity.get_or_init(|| {
            let mut incoming = vec![0u8; self.nodes.len()];
            for node in &self.nodes {
                for successor in node.successors().keys() {
                    let count = &mut incoming[successor.index()];
                    *count = (*count + 1).min(2);
                }
            }
            incoming.into_boxed_slice()
        });
        let mut results = std::iter::repeat_with(|| None)
            .take(self.nodes.len())
            .collect::<Vec<_>>();
        let mut entries = vec![None; self.nodes.len()];
        entries[self.entry.index()] = Some(initial);
        let mut pending = VecDeque::from([self.entry]);
        let mut queued = vec![false; self.nodes.len()];
        queued[self.entry.index()] = true;
        let mut additional_checkpoints = BTreeSet::new();
        for (id, state) in additional_entries {
            additional_checkpoints.insert(id);
            match &mut entries[id.index()] {
                Some(entry) => {
                    join(entry, &state);
                }
                entry @ None => *entry = Some(state),
            }
            if !queued[id.index()] {
                pending.push_back(id);
                queued[id.index()] = true;
            }
        }
        while let Some(id) = pending.pop_front() {
            queued[id.index()] = false;
            let entry = &mut entries[id.index()];
            let mut output = if id == self.entry
                || incoming_edges[id.index()] > 1
                || additional_checkpoints.contains(&id)
            {
                entry.clone()
            } else {
                entry.take()
            }
            .expect("queued HIR flow node must be reachable");
            let node = &self.nodes[id.index()];
            results[id.index()] = Some(transfer(id, node.kind(), &mut output));
            propagate_flow_state(
                output,
                node.successors().keys().copied(),
                &mut entries,
                &mut pending,
                &mut queued,
                &mut join,
            );
        }
        results
    }

    /// 在入口可达子图上求后向抽象状态不动点，由 consumer 投影所需结果。
    ///
    /// 所有可达节点从 lattice 的 bottom 开始执行，包含无法到达函数出口的循环；
    /// 否则无限循环中的读取会被错误视为不可观察。
    /// 此查询与前向分析共用静态 topology。
    /// `transfer` 从输出状态计算输入状态，`join` 将它传播到前驱。
    /// 图负责方向与调度；consumer 只提供有限单调域及当前 typed event 的 gen/kill。
    /// 入口、分支和合流点保留状态用于收敛比较，线性链直接转交状态。每个入口可达环
    /// 必含入口或多前驱节点，因此无出口环也有 checkpoint。观察副产物必须单调合并，
    /// 需要输出快照时在 transfer 改写状态前投影，不能在中间迭代批准删除。
    pub(super) fn solve_backward<S: Clone>(
        &self,
        bottom: S,
        mut join: impl FnMut(&mut S, &S) -> bool,
        mut transfer: impl FnMut(HirFlowNodeId, HirFlowNodeKind<'a>, &mut S),
    ) {
        let reachable = self.reachable();
        let mut predecessors = vec![Vec::new(); self.nodes.len()];
        for (source, node) in self.nodes.iter().enumerate() {
            if reachable[source] {
                for successor in node.successors().keys() {
                    predecessors[successor.index()].push(HirFlowNodeId(source));
                }
            }
        }
        let mut outputs = vec![None; self.nodes.len()];
        let mut pending = reachable
            .iter()
            .enumerate()
            .filter_map(|(index, &is_reachable)| is_reachable.then_some(HirFlowNodeId(index)))
            .collect::<VecDeque<_>>();
        let mut queued = reachable;
        while let Some(id) = pending.pop_front() {
            queued[id.index()] = false;
            let output = &mut outputs[id.index()];
            let mut input = if id == self.entry
                || self.nodes[id.index()].successors().len() > 1
                || predecessors[id.index()].len() > 1
            {
                output.get_or_insert_with(|| bottom.clone()).clone()
            } else {
                output.take().unwrap_or_else(|| bottom.clone())
            };
            transfer(id, self.nodes[id.index()].kind(), &mut input);
            propagate_flow_state(
                input,
                predecessors[id.index()].iter().copied(),
                &mut outputs,
                &mut pending,
                &mut queued,
                &mut join,
            );
        }
    }

    pub(super) fn reachable(&self) -> Vec<bool> {
        let mut reachable = vec![false; self.nodes.len()];
        reachable[self.entry.index()] = true;
        let mut pending = vec![self.entry];
        while let Some(node) = pending.pop() {
            for &successor in self.nodes[node.index()].successors().keys() {
                if !reachable[successor.index()] {
                    reachable[successor.index()] = true;
                    pending.push(successor);
                }
            }
        }
        reachable
    }

    pub(super) fn has_reachable_unresolved_goto(&self) -> bool {
        if self.unresolved_gotos.is_empty() {
            return false;
        }
        let reachable = self.reachable();
        self.unresolved_gotos
            .iter()
            .any(|(source, _)| reachable[source.index()])
    }

    fn reachable_components(&self) -> Vec<Option<usize>> {
        let traversal = crate::graph::depth_first(
            self.nodes.len(),
            self.entry,
            HirFlowNodeId::index,
            |_| true,
            |node| self.nodes[node.index()].successors().keys().copied(),
        );
        let mut predecessors = vec![Vec::new(); self.nodes.len()];
        for &source in &traversal.postorder {
            for successor in self.nodes[source.index()].successors().keys() {
                predecessors[successor.index()].push(source);
            }
        }
        let components = crate::graph::strongly_connected_components(
            self.nodes.len(),
            &traversal.postorder,
            HirFlowNodeId::index,
            |node| predecessors[node.index()].iter().copied(),
        );
        let mut membership = vec![None; self.nodes.len()];
        for (component, members) in components.iter().enumerate() {
            for node in members {
                membership[node.index()] = Some(component);
            }
        }
        membership
    }
}

/// 两个方向共用状态交接：已有输入只借用状态合流，空输入才需要所有权。
/// 最后一条边可直接移动状态，避免在线性链或已建立的循环 checkpoint 上复制集合。
fn propagate_flow_state<S: Clone>(
    state: S,
    edges: impl Iterator<Item = HirFlowNodeId>,
    entries: &mut [Option<S>],
    pending: &mut VecDeque<HirFlowNodeId>,
    queued: &mut [bool],
    join: &mut impl FnMut(&mut S, &S) -> bool,
) {
    let mut state = Some(state);
    let mut edges = edges.peekable();
    while let Some(target) = edges.next() {
        let changed = match &mut entries[target.index()] {
            Some(current) => join(current, state.as_ref().expect("edge has a state")),
            entry @ None => {
                *entry = if edges.peek().is_none() {
                    state.take()
                } else {
                    state.clone()
                };
                true
            }
        };
        if changed && !queued[target.index()] {
            queued[target.index()] = true;
            pending.push_back(target);
        }
    }
}

/// proto owner 内一个词法 block 的稳定路径。
///
/// 路径只在 owner-wide CFG 收集与同一次原地改写之间存活；每一步记录父 block 的语句
/// 索引以及进入的子 block 种类。调用方应先处理子 block、最后再压缩父 block，保证路径
/// 在查询期间不因删除语句而漂移。
#[derive(Clone, Debug, Default, Eq, Ord, PartialEq, PartialOrd)]
pub(super) struct LexicalBlockPath(Vec<LexicalBlockStep>);

impl LexicalBlockPath {
    pub(super) fn root() -> Self {
        Self::default()
    }

    /// 当前事件归属的根层语句；嵌套事件仍投影到最外层 owner，不复制完整路径。
    pub(super) fn root_stmt_index(&self, stmt_index: usize) -> usize {
        self.0.first().map_or(stmt_index, |step| step.stmt_index)
    }

    /// 仅在 consumer 确认需要保存计划时复制路径；末尾索引属于当前 block。
    pub(super) fn to_stmt_path(&self, stmt_index: usize) -> StmtPath {
        let mut path = Vec::with_capacity(self.0.len() * 2 + 1);
        for step in &self.0 {
            path.push(PathComponent::Stmt(step.stmt_index));
            path.push(match step.kind {
                LexicalBlockKind::Then => PathComponent::Then,
                LexicalBlockKind::Else => PathComponent::Else,
                LexicalBlockKind::Body => PathComponent::Body,
            });
        }
        path.push(PathComponent::Stmt(stmt_index));
        path
    }

    /// 临时导航共享路径栈，先恢复父路径再返回，包括未形成子图的 None/Err。
    pub(super) fn with_child<R>(
        &mut self,
        stmt_index: usize,
        kind: LexicalBlockKind,
        visit: impl FnOnce(&mut Self) -> R,
    ) -> R {
        self.0.push(LexicalBlockStep { stmt_index, kind });
        let result = visit(self);
        self.0.pop();
        result
    }
}

#[derive(Clone, Copy, Debug, Eq, Ord, PartialEq, PartialOrd)]
pub(super) enum LexicalBlockKind {
    Then,
    Else,
    Body,
}

#[derive(Clone, Copy, Debug, Eq, Ord, PartialEq, PartialOrd)]
struct LexicalBlockStep {
    stmt_index: usize,
    kind: LexicalBlockKind,
}

/// proto owner 内由真实可达 goto 环形成的词法重入边界。
///
/// block-local `LexicalCfg` 只能看出某个 label 有外部引用，无法区分一次性的前向入口与
/// 从目标可返回源点的回边。这里先建立完整 owner CFG，再只为处于同一可达环的
/// goto/label 对记录目标边界；嵌套 label 同时把包含它的祖先语句记为边界，使只理解
/// block 前缀的 consumer 不会越过一次真实的跨层重入。
#[derive(Clone, Debug, Default)]
pub(super) struct OwnerReentryFacts {
    first_target_by_block: BTreeMap<LexicalBlockPath, usize>,
}

impl OwnerReentryFacts {
    pub(super) fn collect(
        block: &HirBlock,
        safety: HirExprSafety,
    ) -> Result<Self, LexicalCfgFailure> {
        let graph = HirFlowGraph::for_block(block, safety)?;
        let mut facts = Self::default();
        if graph.goto_edges.is_empty() {
            return Ok(facts);
        }
        let components = graph.reachable_components();
        for (source, target) in &graph.goto_edges {
            // source -> target 已是实际 goto 边；同一可达 SCC 恰好证明 target 能回到 source。
            if components[source.index()].is_some()
                && components[source.index()] == components[target.node.index()]
            {
                facts.note_target(target);
            }
        }
        Ok(facts)
    }

    pub(super) fn first_reentry_target(&self, block: &LexicalBlockPath) -> Option<usize> {
        self.first_target_by_block.get(block).copied()
    }

    fn note_target(&mut self, target: &OwnerLabelLocation) {
        let mut ancestor = LexicalBlockPath::root();
        for step in &target.block.0 {
            self.note_block_target(&ancestor, step.stmt_index);
            ancestor.0.push(*step);
        }
        self.note_block_target(&target.block, target.stmt_index);
    }

    fn note_block_target(&mut self, block: &LexicalBlockPath, target: usize) {
        self.first_target_by_block
            .entry(block.clone())
            .and_modify(|first| *first = (*first).min(target))
            .or_insert(target);
    }
}

#[derive(Clone)]
struct OwnerLabelLocation {
    node: HirFlowNodeId,
    block: LexicalBlockPath,
    stmt_index: usize,
}

#[derive(Clone, Copy)]
struct HirLoopTargets {
    break_target: Option<HirFlowNodeId>,
    continue_target: Option<HirFlowNodeId>,
}

#[derive(Clone, Copy, Eq, PartialEq)]
enum HirFlowBoundary {
    Region,
    Function,
}

struct HirFlowGraphBuilder<'a, F> {
    nodes: Vec<HirFlowNode<'a>>,
    labels: BTreeMap<HirLabelId, OwnerLabelLocation>,
    pending_gotos: Vec<(HirFlowNodeId, HirLabelId)>,
    safety: HirExprSafety,
    boundary: HirFlowBoundary,
    function_exit: Option<HirFlowNodeId>,
    unknown_control: Option<HirFlowNodeId>,
    next_protocol: usize,
    observer: F,
}

impl<'a, F> HirFlowGraphBuilder<'a, F>
where
    F: FnMut(HirFlowNodeId, HirFlowNodeKind<'a>, &LexicalBlockPath, usize),
{
    fn new(safety: HirExprSafety, boundary: HirFlowBoundary, observer: F) -> Self {
        Self {
            nodes: Vec::new(),
            labels: BTreeMap::new(),
            pending_gotos: Vec::new(),
            safety,
            boundary,
            function_exit: None,
            unknown_control: None,
            next_protocol: 0,
            observer,
        }
    }

    fn build(mut self, stmts: &'a [HirStmt]) -> Result<HirFlowGraph<'a>, LexicalCfgFailure> {
        let exit = match self.boundary {
            HirFlowBoundary::Region => self.new_node(None, HirFlowNodeKind::Exit, []),
            HirFlowBoundary::Function => {
                let exit = self.new_node(None, HirFlowNodeKind::FunctionExit, []);
                let unknown = self.new_node(None, HirFlowNodeKind::UnknownControl, [exit]);
                self.function_exit = Some(exit);
                self.unknown_control = Some(unknown);
                exit
            }
        };
        let entry = self
            .build_block(
                stmts,
                &mut LexicalBlockPath::root(),
                exit,
                HirLoopTargets {
                    break_target: None,
                    continue_target: None,
                },
            )
            .ok_or(LexicalCfgFailure::AmbiguousLabel)?;

        let mut goto_edges = Vec::with_capacity(self.pending_gotos.len());
        let mut unresolved_gotos = Vec::new();
        for (source, label) in std::mem::take(&mut self.pending_gotos) {
            let Some(location) = self.labels.get(&label).cloned() else {
                unresolved_gotos.push((source, label));
                if let Some(unknown) = self.unknown_control {
                    self.nodes[source.index()].successors.insert(unknown, None);
                }
                continue;
            };
            self.nodes[source.index()]
                .successors
                .insert(location.node, None);
            goto_edges.push((source, location));
        }

        Ok(HirFlowGraph {
            nodes: self.nodes,
            incoming_multiplicity: OnceCell::new(),
            entry,
            exit,
            goto_edges,
            unresolved_gotos,
        })
    }

    fn new_node(
        &mut self,
        owner_stmt: Option<&'a HirStmt>,
        kind: HirFlowNodeKind<'a>,
        successors: impl IntoIterator<Item = HirFlowNodeId>,
    ) -> HirFlowNodeId {
        let id = HirFlowNodeId(self.nodes.len());
        self.nodes.push(HirFlowNode {
            owner_stmt,
            kind,
            successors: successors
                .into_iter()
                .map(|target| (target, None))
                .collect(),
        });
        id
    }

    fn new_owned_node(
        &mut self,
        (stmt, path, stmt_index): (&'a HirStmt, &LexicalBlockPath, usize),
        kind: HirFlowNodeKind<'a>,
        successors: impl IntoIterator<Item = HirFlowNodeId>,
    ) -> HirFlowNodeId {
        let id = self.new_node(Some(stmt), kind, successors);
        (self.observer)(id, kind, path, stmt_index);
        id
    }

    fn set_condition_successors(
        &mut self,
        condition: HirFlowNodeId,
        truthy: HirFlowNodeId,
        falsy: HirFlowNodeId,
    ) {
        let node = &mut self.nodes[condition.index()];
        let known = expr_truthiness(
            node.condition().expect("condition node has an expression"),
            self.safety,
        );
        match known {
            Some(value) => {
                node.successors
                    .insert(if value { truthy } else { falsy }, Some(value));
            }
            None if truthy == falsy => {
                node.successors.insert(truthy, None);
            }
            None => {
                node.successors
                    .extend([(truthy, Some(true)), (falsy, Some(false))]);
            }
        }
    }

    fn build_block(
        &mut self,
        stmts: &'a [HirStmt],
        path: &mut LexicalBlockPath,
        next: HirFlowNodeId,
        loop_targets: HirLoopTargets,
    ) -> Option<HirFlowNodeId> {
        let mut entry = next;
        for (index, stmt) in stmts.iter().enumerate().rev() {
            entry = self.build_stmt(stmt, path, index, entry, loop_targets)?;
        }
        Some(entry)
    }

    fn build_stmt(
        &mut self,
        stmt: &'a HirStmt,
        path: &mut LexicalBlockPath,
        stmt_index: usize,
        next: HirFlowNodeId,
        loop_targets: HirLoopTargets,
    ) -> Option<HirFlowNodeId> {
        match stmt {
            HirStmt::LocalRootRelease(_) => Some(self.new_owned_node(
                (stmt, path, stmt_index),
                HirFlowNodeKind::Stmt(stmt),
                [next],
            )),
            HirStmt::Label(label) => {
                let node = self.new_owned_node(
                    (stmt, path, stmt_index),
                    HirFlowNodeKind::Stmt(stmt),
                    [next],
                );
                let location = OwnerLabelLocation {
                    node,
                    block: path.clone(),
                    stmt_index,
                };
                if self.labels.insert(label.id, location).is_some() {
                    return None;
                }
                Some(node)
            }
            HirStmt::Goto(goto) => {
                let node =
                    self.new_owned_node((stmt, path, stmt_index), HirFlowNodeKind::Stmt(stmt), []);
                self.pending_gotos.push((node, goto.target));
                Some(node)
            }
            HirStmt::Break => {
                let target = loop_targets.break_target.or(self.unknown_control);
                Some(self.new_owned_node(
                    (stmt, path, stmt_index),
                    HirFlowNodeKind::Stmt(stmt),
                    target,
                ))
            }
            HirStmt::Continue => {
                let target = loop_targets.continue_target.or(self.unknown_control);
                Some(self.new_owned_node(
                    (stmt, path, stmt_index),
                    HirFlowNodeKind::Stmt(stmt),
                    target,
                ))
            }
            HirStmt::Return(_) => Some(self.new_owned_node(
                (stmt, path, stmt_index),
                HirFlowNodeKind::Stmt(stmt),
                self.function_exit,
            )),
            HirStmt::Block(block) => path.with_child(stmt_index, LexicalBlockKind::Body, |path| {
                self.build_block(&block.stmts, path, next, loop_targets)
            }),
            HirStmt::If(if_stmt) => {
                let then_entry = path.with_child(stmt_index, LexicalBlockKind::Then, |path| {
                    self.build_block(&if_stmt.then_block.stmts, path, next, loop_targets)
                })?;
                let else_entry = if let Some(block) = &if_stmt.else_block {
                    path.with_child(stmt_index, LexicalBlockKind::Else, |path| {
                        self.build_block(&block.stmts, path, next, loop_targets)
                    })?
                } else {
                    next
                };
                let condition =
                    self.new_owned_node((stmt, path, stmt_index), HirFlowNodeKind::Stmt(stmt), []);
                self.set_condition_successors(condition, then_entry, else_entry);
                Some(condition)
            }
            HirStmt::While(while_stmt) => {
                let condition =
                    self.new_owned_node((stmt, path, stmt_index), HirFlowNodeKind::Stmt(stmt), []);
                let body = path.with_child(stmt_index, LexicalBlockKind::Body, |path| {
                    self.build_block(
                        &while_stmt.body.stmts,
                        path,
                        condition,
                        HirLoopTargets {
                            break_target: Some(next),
                            continue_target: Some(condition),
                        },
                    )
                })?;
                self.set_condition_successors(condition, body, next);
                Some(condition)
            }
            HirStmt::Repeat(repeat_stmt) => {
                let condition = self.new_owned_node(
                    (stmt, path, stmt_index),
                    HirFlowNodeKind::RepeatCondition(repeat_stmt),
                    [],
                );
                let body = path.with_child(stmt_index, LexicalBlockKind::Body, |path| {
                    self.build_block(
                        &repeat_stmt.body.stmts,
                        path,
                        condition,
                        HirLoopTargets {
                            break_target: Some(next),
                            continue_target: Some(condition),
                        },
                    )
                })?;
                self.set_condition_successors(condition, next, body);
                Some(body)
            }
            HirStmt::NumericFor(for_stmt) => {
                let dispatch = self.new_owned_node(
                    (stmt, path, stmt_index),
                    HirFlowNodeKind::NumericForDispatch,
                    [],
                );
                let binding = self.new_owned_node(
                    (stmt, path, stmt_index),
                    HirFlowNodeKind::ForBinding(HirForBindings::Numeric(for_stmt.binding)),
                    [],
                );
                let body = path.with_child(stmt_index, LexicalBlockKind::Body, |path| {
                    self.build_block(
                        &for_stmt.body.stmts,
                        path,
                        dispatch,
                        HirLoopTargets {
                            break_target: Some(next),
                            continue_target: Some(dispatch),
                        },
                    )
                })?;
                self.nodes[binding.index()].successors.insert(body, None);
                self.nodes[dispatch.index()]
                    .successors
                    .extend([(binding, None), (next, None)]);
                Some(self.new_owned_node(
                    (stmt, path, stmt_index),
                    HirFlowNodeKind::Stmt(stmt),
                    [dispatch],
                ))
            }
            HirStmt::GenericFor(for_stmt) => {
                let flow = HirGenericForFlow {
                    protocol: HirFlowProtocolId(self.next_protocol),
                    stmt,
                    for_stmt,
                };
                self.next_protocol += 1;
                let dispatch = self.new_owned_node(
                    (stmt, path, stmt_index),
                    HirFlowNodeKind::GenericForDispatch(flow),
                    [],
                );
                let binding = self.new_owned_node(
                    (stmt, path, stmt_index),
                    HirFlowNodeKind::ForBinding(HirForBindings::Generic(flow)),
                    [],
                );
                let body = path.with_child(stmt_index, LexicalBlockKind::Body, |path| {
                    self.build_block(
                        &for_stmt.body.stmts,
                        path,
                        dispatch,
                        HirLoopTargets {
                            break_target: Some(next),
                            continue_target: Some(dispatch),
                        },
                    )
                })?;
                self.nodes[binding.index()].successors.insert(body, None);
                self.nodes[dispatch.index()]
                    .successors
                    .extend([(binding, None), (next, None)]);
                Some(self.new_owned_node(
                    (stmt, path, stmt_index),
                    HirFlowNodeKind::GenericForInit(flow),
                    [dispatch],
                ))
            }
            HirStmt::LocalDecl(_)
            | HirStmt::GlobalDecl(_)
            | HirStmt::Assign(_)
            | HirStmt::TableSetList(_)
            | HirStmt::ErrNil(_)
            | HirStmt::ToBeClosed(_)
            | HirStmt::Close(_)
            | HirStmt::CallStmt(_) => Some(self.new_owned_node(
                (stmt, path, stmt_index),
                HirFlowNodeKind::Stmt(stmt),
                [next],
            )),
        }
    }
}

impl LexicalCfg {
    pub(super) fn analyze(
        stmts: &[HirStmt],
        owner_label_refs: &BTreeMap<HirLabelId, usize>,
        safety: HirExprSafety,
    ) -> Result<Self, LexicalCfgFailure> {
        validate_region_entry(stmts, owner_label_refs)?;

        let direct_labels = stmts
            .iter()
            .enumerate()
            .filter_map(|(index, stmt)| match stmt {
                HirStmt::Label(label) => Some((label.id, index)),
                _ => None,
            })
            .collect::<BTreeMap<_, _>>();
        let mut successors = vec![BTreeSet::<usize>::new(); stmts.len()];
        let mut has_external_exit = false;
        for (index, stmt) in stmts.iter().enumerate() {
            let graph = HirFlowGraph::for_stmts(std::slice::from_ref(stmt), safety)?;
            let reachable = graph.reachable();
            if index + 1 < stmts.len() && reachable[graph.exit().index()] {
                successors[index].insert(index + 1);
            }
            for (source, target) in &graph.unresolved_gotos {
                if !reachable[source.index()] {
                    continue;
                }
                if let Some(&target_index) = direct_labels.get(target) {
                    successors[index].insert(target_index);
                } else {
                    has_external_exit = true;
                }
            }
        }
        Ok(Self {
            successors,
            has_external_exit,
        })
    }

    pub(super) fn successors(&self) -> &[BTreeSet<usize>] {
        &self.successors
    }

    pub(super) fn has_external_exit(&self) -> bool {
        self.has_external_exit
    }

    /// 按直接语句位置发布“该声明支配所有可达后缀语句”；不可达声明为 false。
    ///
    /// 新 local 的词法作用域延伸到 block 末尾，入口绕过声明会造成非法跳入 scope。
    /// 支配树的子树区间必须包含后缀全部可达节点的 preorder；反向维护其最小/最大值，
    /// 即可一次得到所有声明的结论，无需逐个删除节点重新搜索。结果仅属于当前 CFG 快照。
    pub(super) fn suffix_dominance(&self) -> Vec<bool> {
        let count = self.successors.len();
        let mut predecessors = vec![Vec::new(); count];
        for (source, targets) in self.successors.iter().enumerate() {
            for &target in targets {
                predecessors[target].push(source);
            }
        }
        let traversal = crate::graph::depth_first(
            count,
            0,
            |node| node,
            |_| count != 0,
            |node| self.successors[node].iter().copied(),
        );
        let dominance = crate::graph::dominator_tree(
            &traversal,
            |node| node,
            |node| node,
            |node| predecessors[node].iter().copied(),
        )
        .expect("lexical CFG traversal must define a valid dominance tree");
        let mut result = vec![false; count];
        let mut later: Option<(usize, usize)> = None;
        for index in (0..count).rev() {
            if let Some(start) = dominance.preorder_index[index] {
                let end = dominance.subtree_end[index]
                    .expect("reachable dominator must have a subtree interval");
                result[index] = later.is_none_or(|(min, max)| start <= min && max < end);
                later = Some(later.map_or((start, start), |(min, max)| {
                    (min.min(start), max.max(start))
                }));
            }
        }
        result
    }
}
