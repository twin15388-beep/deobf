//! 将残余 Decision 和短路值表达式降低为普通 HIR 表达式或语句前缀。
//!
//! 消费决策归约证明与物化状态，保留共享求值、写入时点和值根生命周期。

use std::mem;

use crate::hir::common::{
    HirAssign, HirBinaryExpr, HirBlock, HirCallExpr, HirDecisionExpr, HirDecisionNode,
    HirDecisionTarget, HirExpr, HirGenericFor, HirIf, HirLValue, HirLocalDecl, HirLogicalExpr,
    HirNumericFor, HirPackTail, HirRecordField, HirStmt, HirTableAccess, HirTableConstructor,
    HirTableField, HirUnaryExpr, HirValuePack, LocalId,
};
use crate::hir::expr_safety::{HirExprSafety, expr_requires_ordered_snapshot};

use super::eliminate_state::EliminationState;
use crate::hir::visit::any_expr;

pub(super) fn assign_target_supports_direct_materialization(target: &HirLValue) -> bool {
    matches!(
        target,
        HirLValue::Temp(_) | HirLValue::Local(_) | HirLValue::Upvalue(_) | HirLValue::Global(_)
    )
}

pub(super) fn extract_numeric_for(
    mut numeric_for: Box<HirNumericFor>,
    state: &mut EliminationState<'_>,
    safety: HirExprSafety,
) -> (Vec<HirStmt>, Box<HirNumericFor>, bool) {
    let (prefix, mut exprs, exprs_changed) = extract_value_exprs(
        vec![numeric_for.start, numeric_for.limit, numeric_for.step],
        state,
        safety,
    );
    numeric_for.start = exprs.remove(0);
    numeric_for.limit = exprs.remove(0);
    numeric_for.step = exprs.remove(0);
    (prefix, numeric_for, exprs_changed)
}

pub(super) fn extract_generic_for(
    mut generic_for: Box<HirGenericFor>,
    state: &mut EliminationState<'_>,
    safety: HirExprSafety,
) -> (Vec<HirStmt>, Box<HirGenericFor>, bool) {
    let (prefix, iterator_changed) = generic_for.rewrite_iterator(|iterator| {
        let (prefix, rewritten, changed) =
            extract_value_pack(std::mem::take(iterator), state, safety);
        *iterator = rewritten;
        (prefix, changed)
    });
    (prefix, generic_for, iterator_changed)
}

pub(super) fn extract_call_expr(
    call: HirCallExpr,
    state: &mut EliminationState<'_>,
    safety: HirExprSafety,
) -> (Vec<HirStmt>, HirCallExpr, bool) {
    let HirCallExpr {
        required_luau_inlining,
        source_site,
        argument_roots,
        frame_root_ends,
        callee,
        args,
        method,
        fastcall,
        method_key,
        callee_root_handoff,
        method_rewrite_transaction,
        plain_method_syntax,
        boolean_prewrite_arguments,
    } = call;
    let (prefix, mut leading, args, changed) =
        extract_value_pack_with_leading(vec![callee], args, state, safety);
    let callee = leading
        .pop()
        .expect("call extraction should preserve its callee");
    (
        prefix,
        HirCallExpr {
            required_luau_inlining,
            source_site,
            argument_roots,
            frame_root_ends,
            callee,
            args,
            method,
            fastcall,
            method_key,
            callee_root_handoff,
            method_rewrite_transaction,
            plain_method_syntax,
            boolean_prewrite_arguments,
        },
        changed,
    )
}

pub(super) fn extract_value_pack(
    pack: HirValuePack,
    state: &mut EliminationState<'_>,
    safety: HirExprSafety,
) -> (Vec<HirStmt>, HirValuePack, bool) {
    let (prefix, leading, pack, changed) =
        extract_value_pack_with_leading(Vec::new(), pack, state, safety);
    assert!(
        leading.is_empty(),
        "value-pack extraction without leading values must not retain a leading expression"
    );
    (prefix, pack, changed)
}

pub(super) fn extract_value_pack_with_leading(
    mut leading: Vec<HirExpr>,
    pack: HirValuePack,
    state: &mut EliminationState<'_>,
    safety: HirExprSafety,
) -> (Vec<HirStmt>, Vec<HirExpr>, HirValuePack, bool) {
    let leading_len = leading.len();
    leading.extend(pack.fixed);
    let mut extracted = extract_ordered_exprs(leading, state, safety, extract_value_expr);
    let mut tail_prefix = Vec::new();
    let mut tail_changed = false;
    let tail = pack.tail.map(|tail| {
        tail.map_call(|call| {
            let (prefix, call, changed) = extract_call_expr(call, state, safety);
            tail_prefix = prefix;
            tail_changed = changed;
            call
        })
    });
    extracted.append_prefix(tail_prefix, state);
    extracted.changed |= tail_changed;

    let fixed = extracted.exprs.split_off(leading_len);
    (
        extracted.prefix,
        extracted.exprs,
        HirValuePack { fixed, tail },
        extracted.changed,
    )
}

pub(super) fn extract_value_exprs(
    exprs: Vec<HirExpr>,
    state: &mut EliminationState<'_>,
    safety: HirExprSafety,
) -> (Vec<HirStmt>, Vec<HirExpr>, bool) {
    let extracted = extract_ordered_exprs(exprs, state, safety, extract_value_expr);
    (extracted.prefix, extracted.exprs, extracted.changed)
}

fn extract_ordered_exprs(
    exprs: Vec<HirExpr>,
    state: &mut EliminationState<'_>,
    safety: HirExprSafety,
    mut extract: impl FnMut(
        HirExpr,
        &mut EliminationState<'_>,
        HirExprSafety,
    ) -> (Vec<HirStmt>, HirExpr, bool),
) -> OrderedExprExtraction {
    let mut extracted = OrderedExprExtraction::with_capacity(exprs.len());
    for expr in exprs {
        let (prefix, expr, changed) = extract(expr, state, safety);
        let stable = !prefix.is_empty() && matches!(expr, HirExpr::LocalRef(_));
        extracted.push(prefix, expr, changed, stable, true, state);
    }
    extracted
}

/// 暂存最终表达式中的同级值；只有后项确实产生 prefix 时才物化前项，避免平白制造 local。
struct OrderedExprExtraction {
    prefix: Vec<HirStmt>,
    exprs: Vec<HirExpr>,
    pending_snapshots: Vec<usize>,
    changed: bool,
}

impl OrderedExprExtraction {
    fn with_capacity(capacity: usize) -> Self {
        Self {
            prefix: Vec::new(),
            exprs: Vec::with_capacity(capacity),
            pending_snapshots: Vec::new(),
            changed: false,
        }
    }

    fn push(
        &mut self,
        prefix: Vec<HirStmt>,
        expr: HirExpr,
        changed: bool,
        stable: bool,
        snapshot_allowed: bool,
        state: &mut EliminationState<'_>,
    ) {
        self.append_prefix(prefix, state);
        if snapshot_allowed && !stable && expr_requires_ordered_snapshot(&expr) {
            self.pending_snapshots.push(self.exprs.len());
        }
        self.exprs.push(expr);
        self.changed |= changed;
    }

    fn append_prefix(&mut self, mut prefix: Vec<HirStmt>, state: &mut EliminationState<'_>) {
        if prefix.is_empty() {
            return;
        }
        let mut bindings = Vec::with_capacity(self.pending_snapshots.len());
        let mut values = Vec::with_capacity(self.pending_snapshots.len());
        for index in self.pending_snapshots.drain(..) {
            let local = state.alloc_local();
            let value = mem::replace(&mut self.exprs[index], HirExpr::Nil);
            bindings.push(local);
            values.push(value);
            self.exprs[index] = HirExpr::LocalRef(local);
        }
        if !bindings.is_empty() {
            self.prefix.push(HirStmt::LocalDecl(Box::new(HirLocalDecl {
                bindings,
                values: HirValuePack::fixed(values),
                initializer_merge_transaction: None,
            })));
        }
        self.prefix.append(&mut prefix);
    }
}

pub(super) fn extract_assign(
    assign: HirAssign,
    state: &mut EliminationState<'_>,
    safety: HirExprSafety,
) -> (Vec<HirStmt>, HirAssign, bool) {
    if assign.luau_function_declaration {
        // 此合同只容纳 Closure 与全局字段目标，没有待物化的 Decision；
        // 普通赋值的 leading-target 提取会反转其闭包先求值顺序。
        return (Vec::new(), assign, false);
    }
    let luau_compound_global = assign.luau_compound_global;
    let upvalue_write_source = assign.upvalue_write_source;
    let is_phi_transfer = assign.is_phi_transfer;
    let parallel_nil_frame = assign.parallel_nil_frame;
    let initializer_merge_transaction = assign.initializer_merge_transaction;
    let generic_for_initializer_producer = assign.generic_for_initializer_producer;
    let generic_for_dispatch_release = assign.generic_for_dispatch_release;
    let mut leading = Vec::new();
    let mut target_shapes = Vec::with_capacity(assign.targets.len());
    for target in assign.targets {
        match target {
            HirLValue::TableAccess(access) => {
                leading.push(access.base);
                leading.push(access.key);
                target_shapes.push(Err(access.sources));
            }
            target => target_shapes.push(Ok(target)),
        }
    }

    let (prefix, leading, values, changed) =
        extract_value_pack_with_leading(leading, assign.values, state, safety);
    let mut leading = leading.into_iter();
    let targets = target_shapes
        .into_iter()
        .map(|target| {
            target.unwrap_or_else(|sources| {
                HirLValue::TableAccess(Box::new(HirTableAccess {
                    sources,
                    metamethod_free: false,
                    base: leading
                        .next()
                        .expect("table lvalue extraction should preserve its base"),
                    key: leading
                        .next()
                        .expect("table lvalue extraction should preserve its key"),
                    method_setup_protocol: None,
                }))
            })
        })
        .collect();
    assert!(
        leading.next().is_none(),
        "table lvalue extraction must consume every preserved base and key"
    );

    (
        prefix,
        HirAssign {
            luau_function_declaration: false,
            luau_compound_global,
            upvalue_write_source: (!changed).then_some(upvalue_write_source).flatten(),
            is_phi_transfer,
            parallel_nil_frame: (!changed).then_some(parallel_nil_frame).flatten(),
            targets,
            values,
            initializer_merge_transaction: (!changed)
                .then_some(initializer_merge_transaction)
                .flatten(),
            generic_for_initializer_producer: (!changed)
                .then_some(generic_for_initializer_producer)
                .flatten(),
            generic_for_dispatch_release: (!changed)
                .then_some(generic_for_dispatch_release)
                .flatten(),
            method_rewrite_transaction: None,
        },
        changed,
    )
}

pub(super) fn extract_value_expr(
    expr: HirExpr,
    state: &mut EliminationState<'_>,
    safety: HirExprSafety,
) -> (Vec<HirStmt>, HirExpr, bool) {
    if !expr_contains_eliminable_decision(&expr) {
        return (Vec::new(), expr, false);
    }
    if let Some(collapsed) = collapse_expr_to_pure(expr.clone(), safety) {
        return (Vec::new(), collapsed, true);
    }

    let local = state.alloc_local();
    let mut prefix = vec![empty_local_decl(local)];
    prefix.extend(materialize_expr_into_target(
        expr,
        HirLValue::Local(local),
        state,
        safety,
    ));
    (prefix, HirExpr::LocalRef(local), true)
}

pub(super) fn materialize_expr_into_target(
    expr: HirExpr,
    target: HirLValue,
    state: &mut EliminationState<'_>,
    safety: HirExprSafety,
) -> Vec<HirStmt> {
    match expr {
        HirExpr::Decision(decision) if !decision.emit_as_luau_if => {
            materialize_decision_into_target(*decision, target, state, safety)
        }
        HirExpr::LogicalAnd(logical) => {
            materialize_logical_expr_into_target(true, *logical, target, state, safety)
        }
        HirExpr::LogicalOr(logical) => {
            materialize_logical_expr_into_target(false, *logical, target, state, safety)
        }
        expr => {
            let (mut prefix, expr) = prepare_pure_expr(expr, state, safety);
            prefix.push(assign_stmt(target, expr));
            prefix
        }
    }
}

pub(super) fn materialize_expr_for_assignment(
    expr: HirExpr,
    target: HirLValue,
    state: &mut EliminationState<'_>,
    safety: HirExprSafety,
) -> Vec<HirStmt> {
    if matches!(target, HirLValue::Temp(_)) {
        return materialize_expr_into_target(expr, target, state, safety);
    }

    if !expr_contains_eliminable_decision(&expr) {
        return vec![assign_stmt(target, expr)];
    }
    if let HirExpr::Decision(decision) = expr {
        // Decision 的测试不写目标，且每条终端路径只提交一次。不能先折成 logical
        // 再使用其逐步物化通道；后者可能在后续 RHS 事件前覆盖旧 local/upvalue。
        let decision = super::short_circuit::prepare_control_materialization(*decision, safety);
        return materialize_decision_node(&decision, decision.entry.index(), target, state, safety);
    }

    let result = state.alloc_local();
    let mut stmts = vec![empty_local_decl(result)];
    stmts.extend(materialize_expr_into_target(
        expr,
        HirLValue::Local(result),
        state,
        safety,
    ));
    stmts.push(assign_stmt(target, HirExpr::LocalRef(result)));
    stmts
}

fn materialize_logical_expr_into_target(
    is_and: bool,
    logical: HirLogicalExpr,
    target: HirLValue,
    state: &mut EliminationState<'_>,
    safety: HirExprSafety,
) -> Vec<HirStmt> {
    if let Some(lhs_truthy) = super::expr_truthiness(&logical.lhs, safety) {
        let selects_rhs = lhs_truthy == is_and;
        if !selects_rhs || safety.is_discard_safe(&logical.lhs) {
            let selected = if selects_rhs {
                logical.rhs
            } else {
                logical.lhs
            };
            return materialize_expr_into_target(selected, target, state, safety);
        }
    }

    let lhs_local = state.alloc_local();
    let mut stmts = vec![empty_local_decl(lhs_local)];
    stmts.extend(materialize_expr_into_target(
        logical.lhs,
        HirLValue::Local(lhs_local),
        state,
        safety,
    ));
    stmts.push(assign_stmt(target.clone(), HirExpr::LocalRef(lhs_local)));

    let guard = if is_and {
        HirExpr::LocalRef(lhs_local)
    } else {
        HirExpr::LocalRef(lhs_local).negate()
    };
    let then_block = HirBlock {
        stmts: materialize_expr_into_target(logical.rhs, target, state, safety),
    };
    stmts.push(HirStmt::If(Box::new(HirIf {
        preserves_empty_test: false,
        preserves_arm_order: false,
        cond: guard,
        then_block,
        else_block: None,
    })));
    stmts
}

fn materialize_decision_into_target(
    decision: HirDecisionExpr,
    target: HirLValue,
    state: &mut EliminationState<'_>,
    safety: HirExprSafety,
) -> Vec<HirStmt> {
    if let Some(expr) =
        super::collapse_value_decision_expr(&super::analyze_decision(&decision), safety, |_| false)
    {
        return materialize_expr_into_target(expr, target, state, safety);
    }

    let decision = super::short_circuit::prepare_control_materialization(decision, safety);
    materialize_decision_node(&decision, decision.entry.index(), target, state, safety)
}

fn materialize_decision_node(
    decision: &HirDecisionExpr,
    node_index: usize,
    target: HirLValue,
    state: &mut EliminationState<'_>,
    safety: HirExprSafety,
) -> Vec<HirStmt> {
    let node = &decision.nodes[node_index];
    let captures_current = matches!(node.truthy, HirDecisionTarget::CurrentValue)
        || matches!(node.falsy, HirDecisionTarget::CurrentValue);
    let (mut prefix, prepared_test) = prepare_pure_expr(node.test.clone(), state, safety);
    let (cond, current_value) = if captures_current
        && matches!(
            prepared_test,
            HirExpr::LocalRef(_) | HirExpr::TempRef(_) | HirExpr::ParamRef(_)
        ) {
        // CurrentValue 边直接接终端赋值，中间没有其它求值；已有 binding 本身就是
        // 被测试的快照。额外 synthetic local 会占用并不存在的源码槽。
        (prepared_test.clone(), Some(prepared_test))
    } else if captures_current {
        let current_local = state.alloc_local();
        prefix.push(local_decl_with_value(current_local, prepared_test));
        (
            HirExpr::LocalRef(current_local),
            Some(HirExpr::LocalRef(current_local)),
        )
    } else {
        (prepared_test, None)
    };

    let then_block = HirBlock {
        stmts: materialize_decision_target(
            decision,
            node,
            &node.truthy,
            current_value.as_ref(),
            target.clone(),
            state,
            safety,
        ),
    };
    let else_stmts = materialize_decision_target(
        decision,
        node,
        &node.falsy,
        current_value.as_ref(),
        target,
        state,
        safety,
    );
    let cond_discard_safe = safety.is_discard_safe(&cond);

    if cond_discard_safe && then_block.stmts == else_stmts {
        prefix.extend(then_block.stmts);
        return prefix;
    }

    if cond_discard_safe && let Some(cond_truthy) = super::expr_truthiness(&cond, safety) {
        prefix.extend(if cond_truthy {
            then_block.stmts
        } else {
            else_stmts
        });
        return prefix;
    }

    if cond_discard_safe && then_block.stmts.is_empty() && else_stmts.is_empty() {
        return prefix;
    }

    let (cond, then_block, else_block) = if then_block.stmts.is_empty() {
        (cond.negate(), HirBlock { stmts: else_stmts }, None)
    } else if else_stmts.is_empty() {
        (cond, then_block, None)
    } else {
        (cond, then_block, Some(HirBlock { stmts: else_stmts }))
    };

    prefix.push(HirStmt::If(Box::new(HirIf {
        preserves_empty_test: false,
        preserves_arm_order: false,
        cond,
        then_block,
        else_block,
    })));
    prefix
}

fn materialize_decision_target(
    decision: &HirDecisionExpr,
    node: &HirDecisionNode,
    target_branch: &HirDecisionTarget,
    current_value: Option<&HirExpr>,
    target: HirLValue,
    state: &mut EliminationState<'_>,
    safety: HirExprSafety,
) -> Vec<HirStmt> {
    match target_branch {
        HirDecisionTarget::Node(next_ref) => {
            materialize_decision_node(decision, next_ref.index(), target, state, safety)
        }
        HirDecisionTarget::CurrentValue => {
            let value = current_value.cloned().unwrap_or_else(|| node.test.clone());
            if matches!((&target, &value),
                (HirLValue::Local(left), HirExpr::LocalRef(right)) if left == right)
                || matches!((&target, &value),
                    (HirLValue::Temp(left), HirExpr::TempRef(right)) if left == right)
            {
                return Vec::new();
            }
            vec![assign_stmt(target, value)]
        }
        HirDecisionTarget::Expr(expr) => {
            if matches!((&target, expr),
                (HirLValue::Local(left), HirExpr::LocalRef(right)) if left == right)
                || matches!((&target, expr),
                    (HirLValue::Temp(left), HirExpr::TempRef(right)) if left == right)
            {
                // 该终端沿用目标的当前 SSA 值，没有原写入；直接保留空路径，
                // 不先合成自赋值再丢失短路控制关系。全局和上值不领取此许可。
                return Vec::new();
            }
            materialize_expr_for_assignment(expr.clone(), target, state, safety)
        }
    }
}

fn prepare_pure_expr(
    expr: HirExpr,
    state: &mut EliminationState<'_>,
    safety: HirExprSafety,
) -> (Vec<HirStmt>, HirExpr) {
    if expr_contains_eliminable_decision(&expr)
        && let Some(collapsed) = collapse_expr_to_pure(expr.clone(), safety)
    {
        return prepare_pure_expr(collapsed, state, safety);
    }

    match expr {
        HirExpr::Decision(_) | HirExpr::LogicalAnd(_) | HirExpr::LogicalOr(_)
            if expr_contains_eliminable_decision(&expr) =>
        {
            let local = state.alloc_local();
            let mut prefix = vec![empty_local_decl(local)];
            prefix.extend(materialize_expr_into_target(
                expr,
                HirLValue::Local(local),
                state,
                safety,
            ));
            (prefix, HirExpr::LocalRef(local))
        }
        HirExpr::TableAccess(access) => {
            let sources = access.sources;
            let method_setup_protocol = access.method_setup_protocol;
            let metamethod_free = access.metamethod_free;
            let (prefix, exprs) =
                prepare_ordered_exprs(vec![access.base, access.key], state, safety);
            let mut exprs = exprs.into_iter();
            let base = exprs
                .next()
                .expect("table access extraction should preserve its base");
            let key = exprs
                .next()
                .expect("table access extraction should preserve its key");
            (
                prefix,
                HirExpr::TableAccess(Box::new(HirTableAccess {
                    sources,
                    metamethod_free,
                    base,
                    key,
                    method_setup_protocol,
                })),
            )
        }
        HirExpr::Unary(unary) => {
            let (prefix, expr) = prepare_pure_expr(unary.expr, state, safety);
            (
                prefix,
                HirExpr::Unary(Box::new(HirUnaryExpr {
                    source_site: unary.source_site,
                    op: unary.op,
                    expr,
                })),
            )
        }
        HirExpr::Binary(binary) => {
            let (prefix, exprs) =
                prepare_ordered_exprs(vec![binary.lhs, binary.rhs], state, safety);
            let mut exprs = exprs.into_iter();
            let lhs = exprs
                .next()
                .expect("binary extraction should preserve its lhs");
            let rhs = exprs
                .next()
                .expect("binary extraction should preserve its rhs");
            (
                prefix,
                HirExpr::Binary(Box::new(HirBinaryExpr {
                    source_site: binary.source_site,
                    op: binary.op,
                    lhs,
                    rhs,
                })),
            )
        }
        HirExpr::LogicalAnd(logical) => {
            let (prefix, exprs) =
                prepare_ordered_exprs(vec![logical.lhs, logical.rhs], state, safety);
            let mut exprs = exprs.into_iter();
            let lhs = exprs
                .next()
                .expect("logical extraction should preserve its lhs");
            let rhs = exprs
                .next()
                .expect("logical extraction should preserve its rhs");
            (
                prefix,
                HirExpr::LogicalAnd(Box::new(HirLogicalExpr {
                    preserves_boolean_prewrite: false,
                    lhs,
                    rhs,
                })),
            )
        }
        HirExpr::LogicalOr(logical) => {
            let (prefix, exprs) =
                prepare_ordered_exprs(vec![logical.lhs, logical.rhs], state, safety);
            let mut exprs = exprs.into_iter();
            let lhs = exprs
                .next()
                .expect("logical extraction should preserve its lhs");
            let rhs = exprs
                .next()
                .expect("logical extraction should preserve its rhs");
            (
                prefix,
                HirExpr::LogicalOr(Box::new(HirLogicalExpr {
                    preserves_boolean_prewrite: false,
                    lhs,
                    rhs,
                })),
            )
        }
        HirExpr::Call(call) => {
            let (prefix, call, _) = extract_call_expr(*call, state, safety);
            (prefix, HirExpr::Call(Box::new(call)))
        }
        HirExpr::TableConstructor(table) => {
            let (prefix, table) = prepare_table_constructor(*table, state, safety);
            (prefix, HirExpr::TableConstructor(Box::new(table)))
        }
        expr => (Vec::new(), expr),
    }
}

fn prepare_ordered_exprs(
    exprs: Vec<HirExpr>,
    state: &mut EliminationState<'_>,
    safety: HirExprSafety,
) -> (Vec<HirStmt>, Vec<HirExpr>) {
    let extracted = extract_ordered_exprs(exprs, state, safety, |expr, state, safety| {
        let (prefix, expr) = prepare_pure_expr(expr, state, safety);
        let changed = !prefix.is_empty();
        (prefix, expr, changed)
    });
    (extracted.prefix, extracted.exprs)
}

fn collapse_expr_to_pure(expr: HirExpr, safety: HirExprSafety) -> Option<HirExpr> {
    match expr {
        HirExpr::Decision(decision) if decision.emit_as_luau_if => {
            Some(HirExpr::Decision(decision))
        }
        HirExpr::Decision(decision) => {
            super::collapse_value_decision_expr(&super::analyze_decision(&decision), safety, |_| {
                false
            })
        }
        HirExpr::TableAccess(access) => Some(HirExpr::TableAccess(Box::new(HirTableAccess {
            sources: access.sources.clone(),
            metamethod_free: access.metamethod_free,
            base: collapse_expr_to_pure(access.base, safety)?,
            key: collapse_expr_to_pure(access.key, safety)?,
            method_setup_protocol: access.method_setup_protocol,
        }))),
        HirExpr::Unary(unary) => Some(HirExpr::Unary(Box::new(HirUnaryExpr {
            source_site: unary.source_site,
            op: unary.op,
            expr: collapse_expr_to_pure(unary.expr, safety)?,
        }))),
        HirExpr::Binary(binary) => Some(HirExpr::Binary(Box::new(HirBinaryExpr {
            source_site: binary.source_site,
            op: binary.op,
            lhs: collapse_expr_to_pure(binary.lhs, safety)?,
            rhs: collapse_expr_to_pure(binary.rhs, safety)?,
        }))),
        HirExpr::LogicalAnd(logical) => {
            let lhs = collapse_expr_to_pure(logical.lhs, safety)?;
            let rhs = collapse_expr_to_pure(logical.rhs, safety)?;
            let expr = HirExpr::LogicalAnd(Box::new(HirLogicalExpr {
                preserves_boolean_prewrite: false,
                lhs,
                rhs,
            }));
            Some(
                super::super::logical_simplify::simplify_logical_shape_with_safety(&expr, safety)
                    .unwrap_or(expr),
            )
        }
        HirExpr::LogicalOr(logical) => {
            let lhs = collapse_expr_to_pure(logical.lhs, safety)?;
            let rhs = collapse_expr_to_pure(logical.rhs, safety)?;
            let expr = HirExpr::LogicalOr(Box::new(HirLogicalExpr {
                preserves_boolean_prewrite: false,
                lhs,
                rhs,
            }));
            Some(
                super::super::logical_simplify::simplify_logical_shape_with_safety(&expr, safety)
                    .unwrap_or(expr),
            )
        }
        HirExpr::Call(call) => Some(HirExpr::Call(Box::new(collapse_call_to_pure(
            *call, safety,
        )?))),
        HirExpr::TableConstructor(table) => {
            let mut fields = Vec::with_capacity(table.fields.len());
            for field in table.fields {
                match field {
                    HirTableField::Array(expr) => {
                        fields.push(HirTableField::Array(collapse_expr_to_pure(expr, safety)?));
                    }
                    HirTableField::Record(field) => {
                        let key = collapse_expr_to_pure(field.key, safety)?;
                        fields.push(HirTableField::Record(HirRecordField {
                            write_sources: field.write_sources,
                            key,
                            value: collapse_expr_to_pure(field.value, safety)?,
                        }));
                    }
                }
            }
            let trailing_multivalue = match table.trailing_multivalue {
                Some(tail) => Some(tail.try_map_call(|call| collapse_call_to_pure(call, safety))?),
                None => None,
            };
            Some(HirExpr::TableConstructor(Box::new(HirTableConstructor {
                sources: table.sources,
                allocation: table.allocation,
                implicit_template_fields: table.implicit_template_fields,
                fields,
                trailing_multivalue,
            })))
        }
        expr => Some(expr),
    }
}

fn collapse_call_to_pure(call: HirCallExpr, safety: HirExprSafety) -> Option<HirCallExpr> {
    let callee = collapse_expr_to_pure(call.callee, safety)?;
    let fixed = call
        .args
        .fixed
        .into_iter()
        .map(|expr| collapse_expr_to_pure(expr, safety))
        .collect::<Option<Vec<_>>>()?;
    let tail = match call.args.tail {
        Some(tail) => Some(tail.try_map_call(|call| collapse_call_to_pure(call, safety))?),
        None => None,
    };
    Some(HirCallExpr {
        required_luau_inlining: call.required_luau_inlining,
        source_site: call.source_site,
        argument_roots: Vec::new(),
        frame_root_ends: call.frame_root_ends,
        callee,
        args: HirValuePack { fixed, tail },
        method: call.method,
        fastcall: call.fastcall,
        method_key: call.method_key,
        callee_root_handoff: call.callee_root_handoff,
        method_rewrite_transaction: call.method_rewrite_transaction,
        plain_method_syntax: false,
        boolean_prewrite_arguments: call.boolean_prewrite_arguments,
    })
}

fn prepare_table_constructor(
    table: HirTableConstructor,
    state: &mut EliminationState<'_>,
    safety: HirExprSafety,
) -> (Vec<HirStmt>, HirTableConstructor) {
    let mut shapes = Vec::with_capacity(table.fields.len());
    let mut exprs = Vec::new();
    for field in table.fields {
        match field {
            HirTableField::Array(expr) => {
                shapes.push(PreparedTableFieldShape::Array);
                exprs.push(expr);
            }
            HirTableField::Record(HirRecordField {
                write_sources,
                key,
                value,
            }) => {
                shapes.push(PreparedTableFieldShape::Record(write_sources));
                exprs.push(key);
                exprs.push(value);
            }
        }
    }

    let mut extracted = extract_ordered_exprs(exprs, state, safety, |expr, state, safety| {
        let (prefix, expr) = prepare_pure_expr(expr, state, safety);
        let changed = !prefix.is_empty();
        (prefix, expr, changed)
    });

    let (trailing_prefix, trailing_multivalue) = table
        .trailing_multivalue
        .map(|tail| {
            let mut prefix = Vec::new();
            let tail = tail.map_call(|call| {
                let (tail_prefix, call, _) = extract_call_expr(call, state, safety);
                prefix = tail_prefix;
                call
            });
            (prefix, Some(tail))
        })
        .unwrap_or_default();
    extracted.append_prefix(trailing_prefix, state);

    let mut exprs = extracted.exprs.into_iter();
    let fields = shapes
        .into_iter()
        .map(|shape| match shape {
            PreparedTableFieldShape::Array => HirTableField::Array(
                exprs
                    .next()
                    .expect("array field extraction should preserve its value"),
            ),
            PreparedTableFieldShape::Record(write_sources) => {
                HirTableField::Record(HirRecordField {
                    write_sources,
                    key: exprs
                        .next()
                        .expect("record field extraction should preserve its key"),
                    value: exprs
                        .next()
                        .expect("record field extraction should preserve its value"),
                })
            }
        })
        .collect();
    assert!(
        exprs.next().is_none(),
        "table field extraction must consume every prepared expression"
    );

    (
        extracted.prefix,
        HirTableConstructor {
            sources: table.sources,
            allocation: table.allocation,
            implicit_template_fields: table.implicit_template_fields,
            fields,
            trailing_multivalue,
        },
    )
}

enum PreparedTableFieldShape {
    Array,
    Record(crate::hir::common::HirOperationSources),
}

pub(super) fn eliminate_condition_expr(expr: &mut HirExpr, safety: HirExprSafety) -> bool {
    let mut changed = match expr {
        HirExpr::TableAccess(access) => {
            let base_changed = eliminate_condition_expr(&mut access.base, safety);
            let key_changed = eliminate_condition_expr(&mut access.key, safety);
            base_changed || key_changed
        }
        HirExpr::Unary(unary) => eliminate_condition_expr(&mut unary.expr, safety),
        HirExpr::Binary(binary) => {
            let lhs_changed = eliminate_condition_expr(&mut binary.lhs, safety);
            let rhs_changed = eliminate_condition_expr(&mut binary.rhs, safety);
            lhs_changed || rhs_changed
        }
        HirExpr::LogicalAnd(logical) | HirExpr::LogicalOr(logical) => {
            let lhs_changed = eliminate_condition_expr(&mut logical.lhs, safety);
            let rhs_changed = eliminate_condition_expr(&mut logical.rhs, safety);
            lhs_changed || rhs_changed
        }
        HirExpr::Decision(decision) => {
            if !decision.emit_as_luau_if
                && let Some(replacement) = super::collapse_condition_decision_expr(
                    &super::analyze_decision(decision),
                    safety,
                )
            {
                *expr = replacement;
                true
            } else {
                // 候选拒绝[LayerBoundary]：这个递归入口只返回表达式；需要 statement
                // prefix 的非稳定 Decision 由 If/While/Repeat owner 原位物化。
                false
            }
        }
        HirExpr::Call(call) => eliminate_condition_call(call, safety),
        HirExpr::TableConstructor(table) => {
            let mut changed = false;
            for field in &mut table.fields {
                match field {
                    HirTableField::Array(expr) => {
                        changed |= eliminate_condition_expr(expr, safety);
                    }
                    HirTableField::Record(field) => {
                        changed |= eliminate_condition_expr(&mut field.key, safety);
                        changed |= eliminate_condition_expr(&mut field.value, safety);
                    }
                }
            }
            if let Some(call) = table
                .trailing_multivalue
                .as_mut()
                .and_then(HirPackTail::call_mut)
            {
                changed |= eliminate_condition_call(call, safety);
            }
            changed
        }
        HirExpr::Closure(_)
        | HirExpr::Nil
        | HirExpr::Boolean(_)
        | HirExpr::Integer(_)
        | HirExpr::Number(_)
        | HirExpr::String(_)
        | HirExpr::Int64(_)
        | HirExpr::UInt64(_)
        | HirExpr::Vector(_)
        | HirExpr::Complex { .. }
        | HirExpr::ParamRef(_)
        | HirExpr::LocalRef(_)
        | HirExpr::UpvalueRef(_)
        | HirExpr::TempRef(_)
        | HirExpr::GlobalRef(_)
        | HirExpr::CaptureInitializer(_)
        | HirExpr::VarArg
        | HirExpr::Unresolved(_) => false,
    };

    if let Some(replacement) =
        super::super::logical_simplify::simplify_logical_shape_with_safety(expr, safety)
    {
        *expr = replacement;
        changed = true;
    }
    if let Some(replacement) =
        super::super::logical_simplify::simplify_condition_truthiness_shape_with_safety(
            expr, safety,
        )
    {
        *expr = replacement;
        changed = true;
    }

    changed
}

fn eliminate_condition_call(call: &mut HirCallExpr, safety: HirExprSafety) -> bool {
    let mut changed = eliminate_condition_expr(&mut call.callee, safety);
    for arg in &mut call.args.fixed {
        changed |= eliminate_condition_expr(arg, safety);
    }
    if let Some(call) = call.args.tail.as_mut().and_then(HirPackTail::call_mut) {
        changed |= eliminate_condition_call(call, safety);
    }
    changed
}

pub(super) fn expr_contains_eliminable_decision(expr: &HirExpr) -> bool {
    any_expr(
        expr,
        &mut |expr| matches!(expr, HirExpr::Decision(decision) if !decision.emit_as_luau_if),
    )
}

pub(super) fn empty_local_decl(local: LocalId) -> HirStmt {
    HirStmt::LocalDecl(Box::new(HirLocalDecl {
        bindings: vec![local],
        values: HirValuePack::fixed(Vec::new()),
        initializer_merge_transaction: None,
    }))
}

fn local_decl_with_value(local: LocalId, value: HirExpr) -> HirStmt {
    HirStmt::LocalDecl(Box::new(HirLocalDecl {
        bindings: vec![local],
        values: HirValuePack::fixed(vec![value]),
        initializer_merge_transaction: None,
    }))
}

fn assign_stmt(target: HirLValue, value: HirExpr) -> HirStmt {
    HirStmt::Assign(Box::new(HirAssign {
        luau_function_declaration: false,
        luau_compound_global: false,
        upvalue_write_source: None,
        is_phi_transfer: false,
        parallel_nil_frame: None,
        targets: vec![target],
        values: HirValuePack::fixed(vec![value]),
        initializer_merge_transaction: None,
        generic_for_initializer_producer: None,
        generic_for_dispatch_release: None,
        method_rewrite_transaction: None,
    }))
}
