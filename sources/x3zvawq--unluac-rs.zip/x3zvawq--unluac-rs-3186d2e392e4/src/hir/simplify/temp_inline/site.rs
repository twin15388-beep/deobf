//! 分类 temp 在当前 HIR 中的使用站点与求值语境。
//!
//! 消费表达式结构、Decision 和方法协议，供内联 owner 判断搬运边界；不执行替换。

use super::*;
use crate::hir::decision::analyze_decision;
use crate::hir::visit::{HirVisitor, visit_stmts};

pub(super) fn inline_site_in_stmt(stmt: &HirStmt, temp: TempId) -> Option<InlineSite> {
    if let HirStmt::Block(block) = stmt {
        return find_site_in_sequential_block(block, temp);
    }
    match stmt {
        HirStmt::LocalRootRelease(_) => None,
        HirStmt::LocalDecl(local_decl) => {
            find_site_in_exprs(&local_decl.values, temp, InlineSite::Direct)
        }
        HirStmt::GlobalDecl(global_decl) => {
            find_site_in_exprs(&global_decl.values, temp, InlineSite::Direct)
        }
        HirStmt::Assign(assign) => assign
            .targets
            .iter()
            .find_map(|target| find_site_in_lvalue(target, temp, InlineSite::Direct))
            .or_else(|| find_site_in_exprs(&assign.values, temp, InlineSite::Direct)),
        // 候选拒绝[LayerBoundary]：SETLIST base 的 NewTable origin/home 由 table-constructors 消费，temp-inline 只处理 values。
        // SETLIST carries raw table-write semantics and the physical lifetime of its base
        // register.  Keep that base as a direct binding so the table-constructor pass can prove
        // its NewTable origin/home slot; inlining the producer here loses both facts and used to
        // require materializing an unrelated block-local owner afterward.  Values remain normal
        // direct sites.
        HirStmt::TableSetList(set_list) => (!expr_mentions_temp(&set_list.base, temp))
            .then(|| find_site_in_exprs(&set_list.values, temp, InlineSite::Direct))
            .flatten(),
        HirStmt::CallStmt(call_stmt) => {
            find_site_in_call(&call_stmt.call, temp, InlineSite::Direct)
        }
        HirStmt::Return(ret) => direct_fastcall_expr(&ret.values)
            .and_then(|call| find_site_in_call(call, temp, InlineSite::Direct))
            .or_else(|| find_site_in_exprs(&ret.values, temp, InlineSite::ReturnValue)),
        // 候选拒绝[SemanticBarrier:ControlFlow]：`t=f(); if c then use(t) end` 不能把必达的 `f()` 移入零或一次执行的 body；这里只扫描 condition。
        HirStmt::If(if_stmt) => find_site_in_expr(&if_stmt.cond, temp, InlineSite::Condition),
        // 候选拒绝[SemanticBarrier:ControlFlow]：`t=f(); while c do use(t) end` 若移入 body，会把一次求值改成零或多次；repeat/for body 同理，只扫描各自的循环头。
        HirStmt::While(while_stmt) => {
            find_site_in_expr(&while_stmt.cond, temp, InlineSite::LoopCondition)
        }
        HirStmt::Repeat(repeat_stmt) => {
            find_site_in_expr(&repeat_stmt.cond, temp, InlineSite::LoopCondition)
        }
        HirStmt::NumericFor(numeric_for) => {
            find_site_in_expr(&numeric_for.start, temp, InlineSite::LoopHead)
                .or_else(|| find_site_in_expr(&numeric_for.limit, temp, InlineSite::LoopHead))
                .or_else(|| find_site_in_expr(&numeric_for.step, temp, InlineSite::LoopHead))
        }
        HirStmt::GenericFor(generic_for) => {
            find_site_in_exprs(&generic_for.iterator, temp, InlineSite::LoopHead)
        }
        HirStmt::ErrNil(err_nil) => find_site_in_expr(&err_nil.value, temp, InlineSite::Direct),
        // 候选拒绝[LayerBoundary]：close-scopes 需要相邻 definition + TBC binding 来物化
        // `<close>` 词法 owner；它消费协议后会 invalidates TempChain 并重跑 temp-inline，
        // 因而这里先保留独立 resource identity（regress_244）。
        HirStmt::ToBeClosed(_) => None,
        HirStmt::Close(_)
        | HirStmt::Break
        | HirStmt::Continue
        | HirStmt::Goto(_)
        | HirStmt::Label(_) => None,
        HirStmt::Block(_) => unreachable!("blocks are handled before ordinary statement sites"),
    }
}

fn find_site_in_sequential_block(block: &HirBlock, temp: TempId) -> Option<InlineSite> {
    for (index, stmt) in block.stmts.iter().enumerate() {
        if stmt_writes_temp(stmt, temp) {
            return None;
        }
        if !stmt_reads_temp(stmt, temp) {
            continue;
        }
        let site = inline_site_in_stmt(stmt, temp)?;
        return Some(if index == 0 {
            site
        } else {
            InlineSite::PrefixedBlock
        });
    }
    None
}

fn stmt_reads_temp(stmt: &HirStmt, temp: TempId) -> bool {
    struct TempReadProbe {
        temp: TempId,
        found: bool,
    }

    impl HirVisitor<'_> for TempReadProbe {
        fn visit_expr(&mut self, expr: &HirExpr) {
            self.found |= matches!(expr, HirExpr::TempRef(temp) if *temp == self.temp);
        }
    }

    let mut probe = TempReadProbe { temp, found: false };
    visit_stmts(std::slice::from_ref(stmt), &mut probe);
    probe.found
}

pub(super) fn transparent_block_head(mut stmt: &HirStmt) -> Option<&HirStmt> {
    loop {
        let HirStmt::Block(block) = stmt else {
            return Some(stmt);
        };
        // 部分专用 helper 的合同只接受零前缀 block；普通 site classification 另行扫描
        // 顺序 block，并把 later use 降为只接受 proto 稳定常量的 PrefixedBlock site。
        stmt = block.stmts.first()?;
    }
}

pub(super) fn inline_site_in_repeat_condition(cond: &HirExpr, temp: TempId) -> Option<InlineSite> {
    // 调用方已证明 producer 位于本轮 body；移到 until 不增加求值轮次。
    // 短路右臂仍由 conditional 分类拒绝，循环外 producer 继续走 LoopCondition。
    if let HirExpr::Call(call) = cond {
        find_site_in_call(call, temp, InlineSite::Direct)
    } else {
        find_site_in_expr(cond, temp, InlineSite::Condition)
    }
}

/// 判断相邻赋值是否只是在 method 协议前冻结可直接写回源码的 receiver。
///
/// method call 在 HIR 中同时保留 callee base 与隐式首参，因此这里的两个 temp use
/// 最终只对应一次源码 receiver 求值。裸 binding 与以 binding 为根的命名字段链都能
/// 原子收回；普通点调用没有这层协议，不能共享该合同。
pub(super) fn is_method_receiver_snapshot(stmt: &HirStmt, temp: TempId, value: &HirExpr) -> bool {
    if !is_method_receiver_inline_expr(value) {
        return false;
    }
    let call = match stmt {
        HirStmt::CallStmt(call_stmt) => Some(&call_stmt.call),
        HirStmt::LocalDecl(local_decl) => direct_call_expr(&local_decl.values),
        HirStmt::Assign(assign) => direct_call_expr(&assign.values),
        HirStmt::Return(ret) => direct_call_expr(&ret.values),
        _ => None,
    };
    matches!(
        call.and_then(HirCallExpr::method_receiver),
        Some((HirExpr::TempRef(receiver), _)) if *receiver == temp
    )
}

/// 判断 materialization run 中的裸 binding 是否只由某个嵌套 method receiver 对消费。
///
/// 全 proto use-count 由调用方另行限制为两个；这里找到协议匹配的一对引用后，就能排除
/// 普通点调用或第三处消费。字段链不进入这条跨 run 合同，避免重新求 lookup。
pub(super) fn is_bare_method_receiver_snapshot_in_stmt(
    stmt: &HirStmt,
    temp: TempId,
    value: &HirExpr,
) -> bool {
    if !matches!(
        value,
        HirExpr::ParamRef(_) | HirExpr::LocalRef(_) | HirExpr::UpvalueRef(_) | HirExpr::TempRef(_)
    ) {
        return false;
    }

    let mut probe = MethodReceiverTempProbe { temp, found: false };
    visit_stmts(std::slice::from_ref(stmt), &mut probe);
    probe.found
}

struct MethodReceiverTempProbe {
    temp: TempId,
    found: bool,
}

impl HirVisitor<'_> for MethodReceiverTempProbe {
    fn visit_call(&mut self, call: &HirCallExpr) {
        self.found |= call.method_receiver().is_some_and(
            |(receiver, _)| matches!(receiver, HirExpr::TempRef(temp) if *temp == self.temp),
        );
    }
}

fn is_method_receiver_inline_expr(expr: &HirExpr) -> bool {
    match expr {
        HirExpr::ParamRef(_)
        | HirExpr::LocalRef(_)
        | HirExpr::UpvalueRef(_)
        | HirExpr::TempRef(_) => true,
        HirExpr::TableAccess(access) => {
            matches!(&access.key, HirExpr::String(_))
                && is_method_receiver_inline_expr(&access.base)
        }
        _ => false,
    }
}

fn direct_call_expr(values: &crate::hir::common::HirValuePack) -> Option<&HirCallExpr> {
    if values.expr_len() != 1 {
        return None;
    }
    match values.first()? {
        HirExpr::Call(call) => Some(call),
        _ => None,
    }
}

fn direct_fastcall_expr(values: &crate::hir::common::HirValuePack) -> Option<&HirCallExpr> {
    direct_call_expr(values).filter(|call| call.fastcall.is_some())
}

pub(super) fn fastcall_callee_materialization_precedes_temp(stmt: &HirStmt, temp: TempId) -> bool {
    let call = match stmt {
        HirStmt::CallStmt(call_stmt) => &call_stmt.call,
        HirStmt::Return(ret) => {
            let Some(call) = direct_fastcall_expr(&ret.values) else {
                return false;
            };
            call
        }
        _ => return false,
    };
    call.fastcall.is_some() && call.args.iter().any(|arg| expr_mentions_temp(arg, temp))
}

pub(super) fn temp_precedes_observable_eval_in_stmt(
    stmt: &HirStmt,
    temp: TempId,
    moved_value_is_observable: bool,
    reference_captured: &ReferenceCapturedBindings,
) -> bool {
    EvalOrderProbe {
        temp,
        mutable_snapshots_are_barriers: moved_value_is_observable,
        reference_captured,
    }
    .stmt(stmt)
}

pub(super) fn temp_precedes_observable_eval_in_expr(
    expr: &HirExpr,
    temp: TempId,
    moved_value_is_observable: bool,
    reference_captured: &ReferenceCapturedBindings,
) -> bool {
    EvalOrderProbe {
        temp,
        mutable_snapshots_are_barriers: moved_value_is_observable,
        reference_captured,
    }
    .expr(expr)
}

/// 返回 PUC Lua 5.2–5.5 标量 upvalue table 左值的 key。
///
/// 这四种方言会先求 key，再读取最终 table upvalue。Lua 5.1、LuaJIT 与 Luau
/// 会先快照 inherited upvalue，因此不能共享这个合同。
pub(super) fn puc_upvalue_table_key_with_deferred_base_read(
    site: InlineSite,
    stmt: &HirStmt,
    dialect: DecompileDialect,
) -> Option<&HirExpr> {
    if site != InlineSite::Index
        || !matches!(
            dialect,
            DecompileDialect::Lua52
                | DecompileDialect::Lua53
                | DecompileDialect::Lua54
                | DecompileDialect::Lua55
        )
    {
        return None;
    }
    let HirStmt::Assign(assign) = stmt else {
        return None;
    };
    let [HirLValue::TableAccess(access)] = assign.targets.as_slice() else {
        return None;
    };
    if !matches!(&access.base, HirExpr::UpvalueRef(_)) {
        return None;
    }
    Some(&access.key)
}

struct EvalOrderProbe<'a> {
    temp: TempId,
    mutable_snapshots_are_barriers: bool,
    reference_captured: &'a ReferenceCapturedBindings,
}

impl EvalOrderProbe<'_> {
    fn stmt(&self, stmt: &HirStmt) -> bool {
        match stmt {
            HirStmt::LocalRootRelease(_) => false,
            HirStmt::LocalDecl(local_decl) => self.exprs(&local_decl.values),
            HirStmt::GlobalDecl(global_decl) => self.exprs(&global_decl.values),
            HirStmt::Assign(assign) => {
                let (found, prefix_clear) = self.lvalues(&assign.targets);
                found.unwrap_or_else(|| prefix_clear && self.exprs(&assign.values))
            }
            HirStmt::TableSetList(set_list) => {
                self.exprs(std::iter::once(&set_list.base).chain(&set_list.values))
            }
            HirStmt::CallStmt(call_stmt) => self.call(&call_stmt.call),
            HirStmt::Return(ret) => self.exprs(&ret.values),
            HirStmt::If(if_stmt) => self.expr(&if_stmt.cond),
            HirStmt::While(while_stmt) => self.expr(&while_stmt.cond),
            HirStmt::Repeat(repeat_stmt) => self.expr(&repeat_stmt.cond),
            HirStmt::NumericFor(numeric_for) => {
                self.exprs([&numeric_for.start, &numeric_for.limit, &numeric_for.step])
            }
            HirStmt::GenericFor(generic_for) => self.exprs(&generic_for.iterator),
            HirStmt::Block(_) => transparent_block_head(stmt).is_some_and(|stmt| self.stmt(stmt)),
            HirStmt::ErrNil(err_nil) => self.expr(&err_nil.value),
            HirStmt::ToBeClosed(_)
            | HirStmt::Close(_)
            | HirStmt::Break
            | HirStmt::Continue
            | HirStmt::Goto(_)
            | HirStmt::Label(_) => false,
        }
    }

    fn exprs<'a>(&self, exprs: impl IntoIterator<Item = &'a HirExpr>) -> bool {
        self.find_in_exprs(exprs) == Some(true)
    }

    fn find_in_exprs<'a>(&self, exprs: impl IntoIterator<Item = &'a HirExpr>) -> Option<bool> {
        let mut prefix_clear = true;
        for expr in exprs {
            let found = if prefix_clear {
                self.find_in_expr(expr)
            } else {
                expr_mentions_temp(expr, self.temp).then_some(false)
            };
            if found.is_some() {
                return found;
            }
            prefix_clear &= self.prefix_is_clear(expr);
        }
        None
    }

    fn lvalues(&self, lvalues: &[HirLValue]) -> (Option<bool>, bool) {
        let mut prefix_clear = true;
        for lvalue in lvalues {
            if let HirLValue::TableAccess(access) = lvalue {
                for expr in [&access.base, &access.key] {
                    if let Some(found) = self.find_in_expr(expr) {
                        return (Some(prefix_clear && found), prefix_clear);
                    }
                    prefix_clear &= self.prefix_is_clear(expr);
                }
            }
        }
        (None, prefix_clear)
    }

    fn call(&self, call: &HirCallExpr) -> bool {
        self.find_in_call(call) == Some(true)
    }

    fn find_in_call(&self, call: &HirCallExpr) -> Option<bool> {
        if let Some(fastcall) = call.fastcall {
            if let Some(found) = self.find_in_expr(&call.callee) {
                return Some(found);
            }
            for (index, arg) in call.args.fixed.iter().enumerate() {
                let found = if fastcall.fixed_is_direct(index) {
                    self.find_in_expr(arg)
                } else {
                    expr_mentions_temp(arg, self.temp).then_some(false)
                };
                if found.is_some() {
                    return found;
                }
            }
            return call.args.tail.as_ref().and_then(|tail| {
                if fastcall.tail_is_direct() {
                    self.find_in_expr(tail.as_expr())
                } else {
                    expr_mentions_temp(tail.as_expr(), self.temp).then_some(false)
                }
            });
        }
        self.find_in_exprs(std::iter::once(&call.callee).chain(&call.args))
    }

    fn expr(&self, expr: &HirExpr) -> bool {
        self.find_in_expr(expr) == Some(true)
    }

    /// 同一次下降返回“没有引用”或“首次引用是否越过屏障”。若先 contains 再下降，
    /// 长算术链的每层都会重扫其左子树，使一轮逆向内联累计成三次方成本。
    fn find_in_expr(&self, expr: &HirExpr) -> Option<bool> {
        match expr {
            HirExpr::TempRef(other) => (*other == self.temp).then_some(true),
            HirExpr::TableAccess(access) => self.find_in_exprs([&access.base, &access.key]),
            HirExpr::Unary(unary) => self.find_in_expr(&unary.expr),
            HirExpr::Binary(binary) => self.find_in_exprs([&binary.lhs, &binary.rhs]),
            HirExpr::LogicalAnd(logical) | HirExpr::LogicalOr(logical) => self
                .find_in_expr(&logical.lhs)
                .or_else(|| expr_mentions_temp(&logical.rhs, self.temp).then_some(false)),
            HirExpr::Call(call) => self.find_in_call(call),
            // constructor 的分配先于所有字段；closure capture 也不是可移动的消费站点。
            // 仍区分缺少引用与受阻引用，FASTCALL 需要跳过不含该 temp 的参数。
            HirExpr::TableConstructor(_) | HirExpr::Closure(_) => {
                expr_mentions_temp(expr, self.temp).then_some(false)
            }
            HirExpr::Decision(decision) => {
                analyze_decision(decision);
                let entry = &decision.nodes[decision.entry.index()];
                self.find_in_expr(&entry.test)
                    .or_else(|| expr_mentions_temp(expr, self.temp).then_some(false))
            }
            HirExpr::Nil
            | HirExpr::Boolean(_)
            | HirExpr::Integer(_)
            | HirExpr::Number(_)
            | HirExpr::String(_)
            | HirExpr::Int64(_)
            | HirExpr::UInt64(_)
            | HirExpr::Vector(_)
            | HirExpr::Complex { .. }
            | HirExpr::ParamRef(_)
            | HirExpr::LocalRef(_)
            | HirExpr::UpvalueRef(_)
            | HirExpr::GlobalRef(_)
            | HirExpr::CaptureInitializer(_)
            | HirExpr::VarArg
            | HirExpr::Unresolved(_) => None,
        }
    }

    fn prefix_is_clear(&self, expr: &HirExpr) -> bool {
        !(expr_observes_eval_order(expr)
            || self.mutable_snapshots_are_barriers && self.expr_is_mutable_binding_snapshot(expr))
    }

    fn expr_is_mutable_binding_snapshot(&self, expr: &HirExpr) -> bool {
        match expr {
            HirExpr::ParamRef(param) => self.reference_captured.params.contains(param),
            HirExpr::LocalRef(local) => self.reference_captured.locals.contains(local),
            HirExpr::UpvalueRef(_) => true,
            HirExpr::Closure(closure) => closure.captures.iter().any(|capture| {
                capture.mode == crate::hir::common::HirCaptureMode::ByValue
                    && self.expr_is_mutable_binding_snapshot(&capture.binding.expr())
            }),
            _ => false,
        }
    }
}

fn find_site_in_exprs<'a>(
    exprs: impl IntoIterator<Item = &'a HirExpr>,
    temp: TempId,
    site: InlineSite,
) -> Option<InlineSite> {
    exprs
        .into_iter()
        .find_map(|expr| find_site_in_expr(expr, temp, site))
}

fn find_site_in_call(call: &HirCallExpr, temp: TempId, site: InlineSite) -> Option<InlineSite> {
    // method receiver 在 HIR 中出现于 callee base 和隐式首参，但 AST lowering 会依赖
    // method fact 只生成一次 receiver；先识别这对引用，避免把源码级单站点误分类成
    // callee 内部的 Nested use。
    if call
        .method_receiver()
        .is_some_and(|(receiver, _)| matches!(receiver, HirExpr::TempRef(other) if *other == temp))
    {
        return Some(site);
    }
    let callee_site = if site.preserves_execution_region() {
        site.nested()
    } else if matches!(site, InlineSite::Direct) {
        if call.fastcall.is_some() {
            InlineSite::FastCallCallee
        } else {
            InlineSite::CallCallee
        }
    } else if site == InlineSite::CallArg {
        // 参数内的调用仍必达，callee 是其 eager operand；不能降成只允许纯值的
        // Nested，也不能冒充外层 CallCallee，后者会把更早参数误判为跨 callee 移动。
        // 实际前缀事件、捕获与物理根继续由共同 inline guard 证明。
        InlineSite::EagerOperand
    } else {
        site.nested()
    };
    find_site_in_expr(&call.callee, temp, callee_site).or_else(|| {
        if let Some(fastcall) = call.fastcall {
            for (index, arg) in call.args.fixed.iter().enumerate() {
                let arg_site = if fastcall.fixed_is_direct(index) {
                    InlineSite::FastCallArg
                } else {
                    InlineSite::CallArg
                };
                if let Some(found) = if site.preserves_execution_region() {
                    find_site_in_expr(arg, temp, site.nested())
                } else if fastcall.fixed_is_direct(index) {
                    find_site_in_expr_with_fastcall_context(arg, temp, arg_site)
                } else {
                    find_site_in_expr(arg, temp, arg_site)
                } {
                    return Some(found);
                }
            }
            call.args.tail.as_ref().and_then(|tail| {
                if site.preserves_execution_region() {
                    find_site_in_expr(tail.as_expr(), temp, site.nested())
                } else if fastcall.tail_is_direct() {
                    find_site_in_expr_with_fastcall_context(
                        tail.as_expr(),
                        temp,
                        InlineSite::FastCallArg,
                    )
                } else {
                    find_site_in_expr(tail.as_expr(), temp, InlineSite::CallArg)
                }
            })
        } else {
            let arg_site = if site.preserves_execution_region() {
                site.nested()
            } else {
                InlineSite::CallArg
            };
            find_site_in_exprs(&call.args, temp, arg_site)
        }
    })
}

/// 代换后的依赖保留其原消费上下文；FASTCALL direct 参数的纯壳层不能降为普通 nested。
pub(super) fn inline_dependency_site(
    expr: &HirExpr,
    temp: TempId,
    site: InlineSite,
) -> Option<InlineSite> {
    if site == InlineSite::FastCallArg {
        find_site_in_expr_with_fastcall_context(expr, temp, site)
    } else {
        find_site_in_expr(expr, temp, site)
    }
}

fn find_site_in_expr_with_fastcall_context(
    expr: &HirExpr,
    temp: TempId,
    direct_site: InlineSite,
) -> Option<InlineSite> {
    match expr {
        HirExpr::Call(call) => {
            let call_site = if direct_site.preserves_execution_region() {
                direct_site
            } else {
                InlineSite::Direct
            };
            find_site_in_call(call, temp, call_site)
        }
        HirExpr::Unary(unary) => {
            find_site_in_expr_with_fastcall_context(&unary.expr, temp, direct_site)
        }
        HirExpr::Binary(binary) => {
            find_site_in_expr_with_fastcall_context(&binary.lhs, temp, direct_site)
                .or_else(|| find_site_in_expr_with_fastcall_context(&binary.rhs, temp, direct_site))
        }
        HirExpr::LogicalAnd(logical) | HirExpr::LogicalOr(logical) => {
            find_site_in_expr_with_fastcall_context(&logical.lhs, temp, direct_site)
                .or_else(|| find_site_in_expr(&logical.rhs, temp, direct_site.conditional()))
        }
        // 表构造、表访问与 decision arm 会建立独立求值域，只有纯包装节点继承外层 FASTCALL 参数协议。
        _ => find_site_in_expr(expr, temp, direct_site),
    }
}

fn find_site_in_lvalue(lvalue: &HirLValue, temp: TempId, site: InlineSite) -> Option<InlineSite> {
    match lvalue {
        HirLValue::TableAccess(access) => {
            find_site_in_expr(&access.base, temp, site.descend_access_base())
                .or_else(|| find_site_in_expr(&access.key, temp, InlineSite::Index))
        }
        HirLValue::Param(_)
        | HirLValue::Temp(_)
        | HirLValue::Local(_)
        | HirLValue::Upvalue(_)
        | HirLValue::Global(_) => None,
    }
}

fn find_site_in_expr(expr: &HirExpr, temp: TempId, site: InlineSite) -> Option<InlineSite> {
    match expr {
        HirExpr::TempRef(other) if *other == temp => Some(site),
        HirExpr::TempRef(_) => None,
        HirExpr::TableAccess(access) => {
            find_site_in_expr(&access.base, temp, site.descend_access_base())
                .or_else(|| find_site_in_expr(&access.key, temp, InlineSite::Index))
        }
        HirExpr::Unary(unary) => find_site_in_expr(&unary.expr, temp, site.descend_pure_wrapper()),
        HirExpr::Binary(binary) => {
            let child_site = site.descend_pure_wrapper();
            find_site_in_expr(&binary.lhs, temp, child_site)
                .or_else(|| find_site_in_expr(&binary.rhs, temp, child_site))
        }
        HirExpr::LogicalAnd(logical) | HirExpr::LogicalOr(logical) => {
            let child_site = site.descend_pure_wrapper();
            let lhs_site = if site == InlineSite::Direct {
                InlineSite::Condition
            } else {
                child_site
            };
            find_site_in_expr(&logical.lhs, temp, lhs_site)
                .or_else(|| find_site_in_expr(&logical.rhs, temp, child_site.conditional()))
        }
        HirExpr::Decision(decision) => find_site_in_decision(decision, temp, site),
        HirExpr::Call(call) => find_site_in_call(call, temp, site),
        HirExpr::TableConstructor(table) => {
            // 分配发生在首字段之前，即使字段必达也不能把外部求值跨过分配。
            let child_site = site.nested();
            table
                .fields
                .iter()
                .find_map(|field| match field {
                    HirTableField::Array(value) => find_site_in_expr(value, temp, child_site),
                    HirTableField::Record(field) => {
                        find_site_in_table_key(&field.key, temp, child_site)
                            .or_else(|| find_site_in_expr(&field.value, temp, child_site))
                    }
                })
                .or_else(|| {
                    table
                        .trailing_multivalue
                        .as_ref()
                        .and_then(|tail| find_site_in_expr(tail.as_expr(), temp, child_site))
                })
        }
        HirExpr::Closure(_) => {
            // 候选拒绝[SemanticBarrier:Capture]：把 producer 埋入 closure capture 会把定义点快照改成
            // closure 创建/调用时读取，并可能把按引用 cell 改成按值表达式。
            // capture 一旦跨过函数边界，就会直接决定子 proto 的 upvalue provenance。
            // 如果这里把 temp 内联进 capture，后面的 locals / naming 就再也看不到
            // “这是一个单独的局部变量被捕获”这层结构事实了，像
            // `local offset = seed`、`local base = offset + step` 这类源码骨架
            // 会被压扁成参数或裸表达式。这里宁可保留 temp，让后续 locals pass
            // 把它稳定提升成真正的 local。
            None
        }
        HirExpr::Nil
        | HirExpr::Boolean(_)
        | HirExpr::Integer(_)
        | HirExpr::Number(_)
        | HirExpr::String(_)
        | HirExpr::Int64(_)
        | HirExpr::UInt64(_)
        | HirExpr::Vector(_)
        | HirExpr::Complex { .. }
        | HirExpr::ParamRef(_)
        | HirExpr::LocalRef(_)
        | HirExpr::UpvalueRef(_)
        | HirExpr::GlobalRef(_)
        | HirExpr::CaptureInitializer(_)
        | HirExpr::VarArg
        | HirExpr::Unresolved(_) => None,
    }
}

fn find_site_in_decision(
    decision: &crate::hir::common::HirDecisionExpr,
    temp: TempId,
    outer_site: InlineSite,
) -> Option<InlineSite> {
    analyze_decision(decision);
    // 只有入口 test 必达，其余节点与终端值均受条件控制，不能继承无条件使用站点。
    let entry_index = decision.entry.index();
    let entry = &decision.nodes[entry_index];
    let entry_site = match outer_site {
        InlineSite::Direct => InlineSite::Condition,
        InlineSite::ReturnValue
        | InlineSite::Condition
        | InlineSite::LoopCondition
        | InlineSite::LoopHead => outer_site,
        InlineSite::ConditionalNested | InlineSite::RepeatedNested => outer_site,
        InlineSite::Nested
        | InlineSite::EagerOperand
        | InlineSite::EagerAccessBase
        | InlineSite::Index
        | InlineSite::CallArg
        | InlineSite::FastCallArg
        | InlineSite::CallCallee
        | InlineSite::FastCallCallee
        | InlineSite::AccessBase
        | InlineSite::PrefixedBlock => InlineSite::Nested,
    };
    let conditional_site = outer_site.conditional();
    find_site_in_expr(&entry.test, temp, entry_site).or_else(|| {
        decision.nodes.iter().enumerate().find_map(|(index, node)| {
            (index != entry_index)
                .then(|| find_site_in_expr(&node.test, temp, conditional_site))
                .flatten()
                .or_else(|| find_site_in_decision_target(&node.truthy, temp, conditional_site))
                .or_else(|| find_site_in_decision_target(&node.falsy, temp, conditional_site))
        })
    })
}

fn find_site_in_decision_target(
    target: &crate::hir::common::HirDecisionTarget,
    temp: TempId,
    site: InlineSite,
) -> Option<InlineSite> {
    match target {
        crate::hir::common::HirDecisionTarget::Expr(expr) => find_site_in_expr(expr, temp, site),
        crate::hir::common::HirDecisionTarget::Node(_)
        | crate::hir::common::HirDecisionTarget::CurrentValue => None,
    }
}

fn find_site_in_table_key(key: &HirExpr, temp: TempId, site: InlineSite) -> Option<InlineSite> {
    find_site_in_expr(key, temp, site)
}

fn expr_complexity(expr: &HirExpr) -> usize {
    match expr {
        HirExpr::Nil
        | HirExpr::Boolean(_)
        | HirExpr::Integer(_)
        | HirExpr::Number(_)
        | HirExpr::String(_)
        | HirExpr::Int64(_)
        | HirExpr::UInt64(_)
        | HirExpr::Vector(_)
        | HirExpr::Complex { .. }
        | HirExpr::ParamRef(_)
        | HirExpr::LocalRef(_)
        | HirExpr::UpvalueRef(_)
        | HirExpr::TempRef(_)
        | HirExpr::GlobalRef(_)
        | HirExpr::CaptureInitializer(_)
        | HirExpr::VarArg
        | HirExpr::Unresolved(_) => 1,
        HirExpr::Unary(unary) => 1 + expr_complexity(&unary.expr),
        HirExpr::Binary(binary) => 1 + expr_complexity(&binary.lhs) + expr_complexity(&binary.rhs),
        HirExpr::LogicalAnd(logical) | HirExpr::LogicalOr(logical) => {
            1 + expr_complexity(&logical.lhs) + expr_complexity(&logical.rhs)
        }
        HirExpr::TableAccess(access) => {
            1 + expr_complexity(&access.base) + expr_complexity(&access.key)
        }
        HirExpr::Decision(decision) => {
            1 + decision
                .nodes
                .iter()
                .map(decision_node_complexity)
                .sum::<usize>()
        }
        HirExpr::Call(call) => {
            1 + expr_complexity(&call.callee) + call.args.iter().map(expr_complexity).sum::<usize>()
        }
        HirExpr::TableConstructor(table) => {
            1 + table
                .fields
                .iter()
                .map(|field| match field {
                    HirTableField::Array(value) => expr_complexity(value),
                    HirTableField::Record(field) => {
                        table_key_complexity(&field.key) + expr_complexity(&field.value)
                    }
                })
                .sum::<usize>()
                + table
                    .trailing_multivalue
                    .as_ref()
                    .map_or(0, |tail| expr_complexity(tail.as_expr()))
        }
        HirExpr::Closure(closure) => 1 + closure.captures.len(),
    }
}

fn decision_node_complexity(node: &crate::hir::common::HirDecisionNode) -> usize {
    1 + expr_complexity(&node.test)
        + decision_target_complexity(&node.truthy)
        + decision_target_complexity(&node.falsy)
}

fn decision_target_complexity(target: &crate::hir::common::HirDecisionTarget) -> usize {
    match target {
        crate::hir::common::HirDecisionTarget::Expr(expr) => expr_complexity(expr),
        crate::hir::common::HirDecisionTarget::Node(_)
        | crate::hir::common::HirDecisionTarget::CurrentValue => 1,
    }
}

fn table_key_complexity(key: &HirExpr) -> usize {
    expr_complexity(key)
}

#[derive(Clone, Copy, Eq, PartialEq)]
enum EagerInlineRejection {
    ComplexityBudget,
    DeferredDecision,
    DiagnosticResidual,
    NamedClosure,
}

fn eager_inline_rejection(replacement: &HirExpr) -> Option<EagerInlineRejection> {
    if expr_complexity(replacement) > NESTED_INLINE_MAX_COMPLEXITY {
        return Some(EagerInlineRejection::ComplexityBudget);
    }

    match replacement {
        HirExpr::Decision(_) => Some(EagerInlineRejection::DeferredDecision),
        HirExpr::Unresolved(_) => Some(EagerInlineRejection::DiagnosticResidual),
        HirExpr::Closure(_) => Some(EagerInlineRejection::NamedClosure),
        _ => None,
    }
}

#[derive(Clone, Copy, Eq, PartialEq)]
pub(super) enum InlineSite {
    Direct,
    Nested,
    EagerOperand,
    EagerAccessBase,
    ConditionalNested,
    RepeatedNested,
    ReturnValue,
    Index,
    CallArg,
    FastCallArg,
    CallCallee,
    FastCallCallee,
    AccessBase,
    Condition,
    LoopCondition,
    LoopHead,
    PrefixedBlock,
}

impl InlineSite {
    pub(super) fn allows(
        self,
        replacement: &HirExpr,
        options: ReadabilityOptions,
        safety: HirExprSafety,
    ) -> bool {
        match self {
            Self::Direct => true,
            Self::CallCallee | Self::FastCallCallee => true,
            Self::PrefixedBlock => {
                // block prefix 可能写任意 binding/home、触发事件或提前终止；只有不读取
                // identity 且由 proto 持有、无事件的稳定常量能不依赖 prefix 摘要
                // 安全移入 later use。
                is_stable_inline_value(replacement)
            }
            Self::Nested => {
                // 候选拒绝[PolicyBoundary]：普通 nested 只收回无事件小表达式；effectful producer 需要先归入已证明的具体 eager 位置。
                expr_complexity(replacement) <= NESTED_INLINE_MAX_COMPLEXITY
                    && is_small_pure_nested_inline_expr(replacement)
            }
            Self::EagerOperand | Self::EagerAccessBase => {
                match eager_inline_rejection(replacement) {
                    None => true,
                    Some(EagerInlineRejection::ComplexityBudget) => {
                        // 候选拒绝[PolicyBoundary]：已证明必达的 operand/access base 仍受固定
                        // 展示复杂度阈值限制；该阈值不表示表达式不等价。
                        false
                    }
                    Some(EagerInlineRejection::DeferredDecision) => {
                        // 候选拒绝[LayerBoundary]：Decision 由 decision/eliminate owner 消费；
                        // owner invalidates DecisionShape/LogicalExpr/BooleanPattern，均会重审 temp-inline。
                        false
                    }
                    Some(EagerInlineRejection::DiagnosticResidual) => {
                        // 候选拒绝[PolicyBoundary]：Unresolved 是 strict 失败/permissive Error 的
                        // 显式诊断证据，项目选择保留其独立 producer 形状。
                        false
                    }
                    Some(EagerInlineRejection::NamedClosure) => {
                        // 候选拒绝[PolicyBoundary]：closure child body 不计入表达式复杂度，项目
                        // 选择保留命名 producer，避免生成多行 IIFE。
                        false
                    }
                }
            }
            Self::ConditionalNested | Self::RepeatedNested => {
                // 候选拒绝[SemanticBarrier:ControlFlow]：`t=f(); return c and t` 若把 call/lookup producer 移进条件区域，会从 eager 求值变成条件求值；重复区域还可能每轮重算。
                // 候选拒绝[SemanticBarrier:Lifetime]：`t=x; return mutate() and t` 若延后可变 binding 快照，会读取 mutate 后的新值。
                // 候选拒绝[PolicyBoundary]：可跳过且 effect-invariant 的 nested 值仍受固定复杂度阈值限制。
                expr_complexity(replacement) <= NESTED_INLINE_MAX_COMPLEXITY
                    && is_safe_conditional_nested_inline_expr(replacement, safety)
            }
            Self::AccessBase => {
                // 候选拒绝[PolicyBoundary]：access base 只展示原子值或命名字段链，并服从用户配置的复杂度上限。
                self.complexity_limit(options)
                    .is_some_and(|limit| expr_complexity(replacement) <= limit)
                    && is_access_base_inline_expr(replacement)
            }
            // 条件头 / for 头属于源码结构骨架，保留少量低复杂度表达式能明显减少
            // 机械 temp 噪音；但这里仍然用固定的小阈值，避免把整坨复杂逻辑塞回控制头。
            Self::Condition | Self::LoopCondition => {
                // 候选拒绝[PolicyBoundary]：控制头使用固定展示复杂度上限；该限制不表示表达式不等价。
                expr_complexity(replacement) <= CONTROL_HEAD_INLINE_MAX_COMPLEXITY
            }
            // closure 的复杂度无法概括 child proto 函数体；保留独立 producer，避免把普通
            // local function 压成 loop head 里的多行匿名 iterator。
            Self::LoopHead => {
                // 候选拒绝[PolicyBoundary]：closure 保留命名 producer，避免多行 IIFE；其它 loop-head 值仅受展示复杂度限制。
                !matches!(replacement, HirExpr::Closure(_))
                    && expr_complexity(replacement) <= CONTROL_HEAD_INLINE_MAX_COMPLEXITY
            }
            Self::ReturnValue if matches!(replacement, HirExpr::Decision(_)) => {
                // 候选拒绝[LayerBoundary]：残余 Decision 需由 eliminate-decisions 在原
                // producer 上物化，保留结果 home 供 carried-locals 合并；吞入 return
                // 会丢掉该身份并重建 home-free carrier。纯表达式化后仍会重审内联。
                false
            }
            Self::ReturnValue | Self::Index | Self::CallArg | Self::FastCallArg => {
                // 候选拒绝[PolicyBoundary]：return/index/arg 的用户可配置复杂度阈值只控制源码展示密度。
                self.complexity_limit(options)
                    .is_some_and(|limit| expr_complexity(replacement) <= limit)
            }
        }
    }

    fn complexity_limit(self, options: ReadabilityOptions) -> Option<usize> {
        match self {
            Self::Direct
            | Self::Nested
            | Self::EagerOperand
            | Self::EagerAccessBase
            | Self::ConditionalNested
            | Self::RepeatedNested
            | Self::CallCallee
            | Self::FastCallCallee
            | Self::Condition
            | Self::LoopCondition
            | Self::LoopHead
            | Self::PrefixedBlock => None,
            Self::ReturnValue => Some(options.return_inline_max_complexity),
            Self::Index => Some(options.index_inline_max_complexity),
            Self::CallArg => Some(options.args_inline_max_complexity),
            Self::FastCallArg => Some(options.args_inline_max_complexity),
            Self::AccessBase => Some(options.access_base_inline_max_complexity),
        }
    }

    fn descend_access_base(self) -> Self {
        match self {
            Self::Direct => Self::AccessBase,
            Self::LoopCondition | Self::ConditionalNested | Self::RepeatedNested => self.nested(),
            Self::CallCallee | Self::FastCallCallee => Self::EagerAccessBase,
            Self::EagerOperand | Self::EagerAccessBase => self,
            Self::Nested
            | Self::ReturnValue
            | Self::Index
            | Self::CallArg
            | Self::FastCallArg
            | Self::AccessBase
            | Self::Condition
            | Self::LoopHead
            | Self::PrefixedBlock => Self::Nested,
        }
    }

    fn descend_pure_wrapper(self) -> Self {
        match self {
            // 这里只保留 index 语境向下穿透纯壳层，避免像 `t[(x + 1)]` 这种机械中间 temp
            // 在进入 locals 阶段前就失去折叠机会；而 return/call 等站位仍维持保守边界，
            // 防止上下文再次泄漏成“整坨表达式”。
            Self::Index => Self::Index,
            // 条件头 / loop 头本身就是高价值结构位置，允许低复杂度表达式继续穿过
            // 纯 wrapper，能把 `if ((a + b) % 2 == 0)`、`for i = 1, n, 1` 这类源码形状
            // 从机械 temp 链里收回来。
            Self::Condition => Self::Condition,
            Self::LoopCondition => Self::LoopCondition,
            Self::LoopHead => Self::LoopHead,
            Self::ConditionalNested | Self::RepeatedNested => self,
            Self::Direct => Self::EagerOperand,
            Self::Nested
            | Self::EagerOperand
            | Self::EagerAccessBase
            | Self::ReturnValue
            | Self::CallArg
            | Self::FastCallArg
            | Self::CallCallee
            | Self::FastCallCallee
            | Self::AccessBase
            | Self::PrefixedBlock => Self::Nested,
        }
    }

    pub(super) const fn is_call_callee(self) -> bool {
        matches!(self, Self::CallCallee | Self::FastCallCallee)
    }

    fn conditional(self) -> Self {
        match self {
            Self::LoopCondition | Self::RepeatedNested => Self::RepeatedNested,
            Self::ConditionalNested => Self::ConditionalNested,
            _ => Self::ConditionalNested,
        }
    }

    fn nested(self) -> Self {
        match self {
            Self::LoopCondition | Self::RepeatedNested => Self::RepeatedNested,
            Self::ConditionalNested => Self::ConditionalNested,
            _ => Self::Nested,
        }
    }

    const fn preserves_execution_region(self) -> bool {
        matches!(
            self,
            Self::LoopCondition | Self::ConditionalNested | Self::RepeatedNested
        )
    }

    pub(super) const fn is_repeated_region(self) -> bool {
        matches!(self, Self::LoopCondition | Self::RepeatedNested)
    }
}

pub(super) fn is_stable_inline_value(expr: &HirExpr) -> bool {
    matches!(
        expr,
        HirExpr::Nil
            | HirExpr::Boolean(_)
            | HirExpr::Integer(_)
            | HirExpr::Number(_)
            | HirExpr::String(_)
            | HirExpr::Int64(_)
            | HirExpr::UInt64(_)
            | HirExpr::Vector(_)
            | HirExpr::Complex { .. }
    )
}

fn is_atomic_nested_inline_expr(expr: &HirExpr) -> bool {
    matches!(
        expr,
        HirExpr::Nil
            | HirExpr::Boolean(_)
            | HirExpr::Integer(_)
            | HirExpr::Number(_)
            | HirExpr::String(_)
            | HirExpr::Int64(_)
            | HirExpr::UInt64(_)
            | HirExpr::Vector(_)
            | HirExpr::Complex { .. }
            | HirExpr::ParamRef(_)
            | HirExpr::LocalRef(_)
            | HirExpr::UpvalueRef(_)
            | HirExpr::TempRef(_)
            | HirExpr::GlobalRef(_)
            | HirExpr::VarArg
    )
}

fn is_safe_conditional_nested_inline_expr(expr: &HirExpr, safety: HirExprSafety) -> bool {
    safety.is_discard_safe(expr)
        && safety.is_effect_invariant_in_single_value_context(expr)
        && safety.is_repeatable_in_single_value_context(expr)
}

fn is_small_pure_nested_inline_expr(expr: &HirExpr) -> bool {
    match expr {
        HirExpr::Nil
        | HirExpr::Boolean(_)
        | HirExpr::Integer(_)
        | HirExpr::Number(_)
        | HirExpr::String(_)
        | HirExpr::Int64(_)
        | HirExpr::UInt64(_)
        | HirExpr::Vector(_)
        | HirExpr::Complex { .. }
        | HirExpr::ParamRef(_)
        | HirExpr::LocalRef(_)
        | HirExpr::UpvalueRef(_)
        | HirExpr::TempRef(_)
        | HirExpr::GlobalRef(_) => true,
        HirExpr::Unary(unary) => is_small_pure_nested_inline_expr(&unary.expr),
        HirExpr::Binary(binary) => {
            is_small_pure_nested_inline_expr(&binary.lhs)
                && is_small_pure_nested_inline_expr(&binary.rhs)
        }
        HirExpr::LogicalAnd(logical) | HirExpr::LogicalOr(logical) => {
            is_small_pure_nested_inline_expr(&logical.lhs)
                && is_small_pure_nested_inline_expr(&logical.rhs)
        }
        HirExpr::CaptureInitializer(_)
        | HirExpr::VarArg
        | HirExpr::TableAccess(_)
        | HirExpr::Decision(_)
        | HirExpr::Call(_)
        | HirExpr::TableConstructor(_)
        | HirExpr::Closure(_)
        | HirExpr::Unresolved(_) => false,
    }
}

fn is_access_base_inline_expr(expr: &HirExpr) -> bool {
    is_atomic_nested_inline_expr(expr) || is_named_field_chain_expr(expr)
}

fn is_named_field_chain_expr(expr: &HirExpr) -> bool {
    let HirExpr::TableAccess(access) = expr else {
        return false;
    };
    matches!(&access.key, HirExpr::String(_))
        && (is_atomic_nested_inline_expr(&access.base) || is_named_field_chain_expr(&access.base))
}
