//! 将单次消费的 HIR 临时值收回表达式，并组织完整调用准备区内联。
//!
//! 消费使用、来源、capture、根及求值语境事实，保留原值宽度和身份。

mod site;
mod usage;

use std::borrow::Cow;
use std::collections::{BTreeMap, BTreeSet};

use crate::decompile::{DecompileDialect, ReadabilityOptions};
use crate::hir::common::{
    HirBinding, HirBlock, HirCallExpr, HirCaptureMode, HirExpr, HirInlineDispositions,
    HirInlineRetentionReason, HirLValue, HirProto, HirStmt, HirTableField, TempId,
};
use crate::hir::expr_safety::{
    HirEvalEffects, HirExprSafety, expr_observes_eval_order, expr_requires_ordered_snapshot,
};
use crate::hir::promotion::{HomeSlotKey, HomeSlots, ProtoPromotionFacts};

use self::site::{
    InlineSite, fastcall_callee_materialization_precedes_temp, inline_dependency_site,
    inline_site_in_repeat_condition, inline_site_in_stmt, is_bare_method_receiver_snapshot_in_stmt,
    is_method_receiver_snapshot, is_stable_inline_value,
    puc_upvalue_table_key_with_deferred_base_read, temp_precedes_observable_eval_in_expr,
    temp_precedes_observable_eval_in_stmt, transparent_block_head,
};
use self::usage::{
    TempUseScratch, TempUseSummary, collect_expr_temp_uses_summary, collect_stmt_temp_uses,
};
use super::label_refs::{count_label_references, stmt_has_label_or_goto};
use super::mention::{
    BindingReadCollector, CaptureCollector, ReferenceCapturedBindings, ToBeClosedTempCollector,
    binding_home_read_collector, expr_mentions_temp, expr_read_homes, stmt_writes_temp,
};
use super::root_lifetimes::{
    CallRootLifetimeIndices, RootEventBlock, RootEventIndex, RootEventStmt, RootLifetimeFacts,
    ScalarGcRootLifetimeIndices, collect_call_root_lifetimes, collect_scalar_gc_root_lifetimes,
    materialize_generic_for_dispatch_root_releases, scope_end_copy_root_handoffs,
    scope_end_copy_roots_needing_materialization, stmt_has_argument_root_handoff,
};
use crate::hir::rewrite::{replace_temp_in_expr, replace_temp_in_stmt, replace_temps_in_stmt};
use crate::hir::visit::{HirVisitor, visit_expr, visit_stmts};

const NESTED_INLINE_MAX_COMPLEXITY: usize = 5;
const CONTROL_HEAD_INLINE_MAX_COMPLEXITY: usize = 5;

pub(super) struct InlineModuleFacts<'a> {
    pub(super) substantial_closure_bodies: &'a [bool],
    pub(super) inert_call_results: &'a BTreeSet<TempId>,
}

struct TempInlineWorkspace<'a> {
    uses: TempUseScratch,
    order_sensitive_defs: OrderSensitiveDefWorkspace,
    block_depth: usize,
    scope: TempInlineScope,
    dialect: DecompileDialect,
    safety: HirExprSafety,
    readability: ReadabilityOptions,
    module: InlineModuleFacts<'a>,
    physical_root_temps: Vec<bool>,
    new_physical_root_temps: BTreeSet<TempId>,
    inline_dispositions: HirInlineDispositions,
}

enum TempInlineScope {
    All,
    BranchValueSinks(Vec<bool>),
}

impl TempInlineScope {
    fn allows_open_return(&self) -> bool {
        matches!(self, Self::All)
    }

    fn allows_adjacent(
        &self,
        temp: TempId,
        site: InlineSite,
        next_stmt: &HirStmt,
        is_block_terminal: bool,
    ) -> bool {
        let Self::BranchValueSinks(exposed) = self else {
            return true;
        };
        exposed.get(temp.index()).copied().unwrap_or(false)
            && site == InlineSite::ReturnValue
            && is_block_terminal
            && matches!(
                next_stmt,
                HirStmt::Return(ret)
                    if ret.values.tail.is_none()
                        && matches!(ret.values.fixed.as_slice(),
                            [HirExpr::TempRef(result)] if *result == temp)
            )
    }

    fn allows_call(
        &self,
        call_stmt: &crate::hir::common::HirCallStmt,
        callee_value: &HirExpr,
        terminal_candidate: Option<TempId>,
        sink: &HirStmt,
    ) -> bool {
        let Self::BranchValueSinks(exposed) = self else {
            return true;
        };
        !call_stmt.call.is_method()
            && call_stmt.call.method_key.is_none()
            && matches!(callee_value, HirExpr::GlobalRef(_))
            && terminal_candidate.is_some_and(|temp| {
                exposed.get(temp.index()).copied().unwrap_or(false)
                    && inline_site_in_stmt(sink, temp).is_some()
            })
    }
}

impl<'a> TempInlineWorkspace<'a> {
    fn new(
        proto: &HirProto,
        scope: TempInlineScope,
        dialect: DecompileDialect,
        readability: ReadabilityOptions,
        module: InlineModuleFacts<'a>,
        inline_dispositions: HirInlineDispositions,
        safety: HirExprSafety,
    ) -> Self {
        let temp_count = proto.temp_count;
        let mut physical_root_temps = vec![false; temp_count];
        for temp in &proto.physical_root_temps {
            if let Some(protected) = physical_root_temps.get_mut(temp.index()) {
                *protected = true;
            }
        }
        Self {
            uses: TempUseScratch::new(proto),
            order_sensitive_defs: OrderSensitiveDefWorkspace::new(temp_count),
            block_depth: 0,
            scope,
            dialect,
            safety,
            readability,
            module,
            physical_root_temps,
            new_physical_root_temps: BTreeSet::new(),
            inline_dispositions,
        }
    }
}

pub(super) fn inline_temps_in_proto_with_facts(
    proto: &mut HirProto,
    readability: ReadabilityOptions,
    facts: &ProtoPromotionFacts,
    dialect: DecompileDialect,
    module: InlineModuleFacts<'_>,
    safety: HirExprSafety,
) -> bool {
    inline_temps_in_proto_with_scope(
        proto,
        readability,
        facts,
        TempInlineScope::All,
        dialect,
        module,
        safety,
    )
}

pub(super) fn inline_exposed_branch_value_sinks_in_proto_with_facts(
    proto: &mut HirProto,
    exposed_temps: &[TempId],
    readability: ReadabilityOptions,
    facts: &ProtoPromotionFacts,
    dialect: DecompileDialect,
    safety: HirExprSafety,
) {
    if exposed_temps.is_empty() {
        return;
    }
    let exposed_len = exposed_temps
        .iter()
        .map(|temp| temp.index())
        .max()
        .expect("non-empty exposed temp set must have a maximum")
        + 1;
    let mut exposed = vec![false; exposed_len];
    for temp in exposed_temps {
        exposed[temp.index()] = true;
    }
    inline_temps_in_proto_with_scope(
        proto,
        readability,
        facts,
        TempInlineScope::BranchValueSinks(exposed),
        dialect,
        InlineModuleFacts {
            substantial_closure_bodies: &[],
            inert_call_results: &BTreeSet::new(),
        },
        safety,
    );
}

fn inline_temps_in_proto_with_scope(
    proto: &mut HirProto,
    readability: ReadabilityOptions,
    facts: &ProtoPromotionFacts,
    scope: TempInlineScope,
    dialect: DecompileDialect,
    module: InlineModuleFacts<'_>,
    safety: HirExprSafety,
) -> bool {
    let mut identities = (
        CaptureCollector::new(HirCaptureMode::ByReference),
        (
            CaptureCollector::new(HirCaptureMode::ByValue),
            ToBeClosedTempCollector::default(),
        ),
    );
    visit_stmts(&proto.body.stmts, &mut identities);
    let (reference, (value, closed)) = identities;
    let reference_captured = reference.bindings;
    let mut identity_sensitive_temps = reference_captured.temps.clone();
    identity_sensitive_temps.extend(value.bindings.temps);
    identity_sensitive_temps.extend(closed.temps);
    let temp_debug_locals = &proto.temp_debug_locals;
    let mut release_temp_is_eligible = |temp: TempId| {
        !identity_sensitive_temps.contains(&temp)
            && temp_debug_locals
                .get(temp.index())
                .is_none_or(Option::is_none)
    };
    let mut changed = matches!(&scope, TempInlineScope::All)
        && materialize_generic_for_dispatch_root_releases(
            &mut proto.body,
            facts,
            safety,
            &mut release_temp_is_eligible,
        );
    let scope_roots = scope_end_copy_roots_needing_materialization(&proto.body.stmts, facts);
    let original_root_count = proto.physical_root_temps.len();
    proto.physical_root_temps.extend(scope_roots);
    changed |= proto.physical_root_temps.len() != original_root_count;
    let inline_dispositions = std::mem::take(&mut proto.inline_dispositions);
    let mut workspace = TempInlineWorkspace::new(
        proto,
        scope,
        dialect,
        readability,
        module,
        inline_dispositions,
        safety,
    );
    for temp in workspace.uses.boolean_value_predicates() {
        changed |= workspace
            .inline_dispositions
            .preserve_temp(temp, HirInlineRetentionReason::BooleanValueContext);
        workspace.physical_root_temps[temp.index()] = true;
        workspace.new_physical_root_temps.insert(temp);
    }
    let mut live_use_counts = collect_block_temp_use_totals(&proto.body.stmts, &mut workspace.uses);
    // 前面的 dispatch root-release 只插入 Temp=nil，保留原 capture/TBC；引用捕获集合仍有效。
    let captures = TempInlineCaptureFacts::new(&reference_captured, facts);
    let event_index = RootEventIndex::new(&proto.body.stmts, facts, safety);
    changed |= inline_temps_in_block(
        &mut proto.body,
        &mut workspace,
        &mut live_use_counts,
        &captures,
        readability,
        facts,
        &BTreeSet::new(),
        event_index.root(),
    );
    let physical_root_count = proto.physical_root_temps.len();
    proto
        .physical_root_temps
        .extend(workspace.new_physical_root_temps.iter().copied());
    changed |= proto.physical_root_temps.len() != physical_root_count;
    proto.inline_dispositions = workspace.inline_dispositions;
    changed
}

impl TempInlineWorkspace<'_> {
    fn collect_temp_root_lifetimes(
        &mut self,
        stmts: &[HirStmt],
        facts: &ProtoPromotionFacts,
        event_block: Option<RootEventBlock<'_>>,
    ) -> (
        CallRootLifetimeIndices,
        ScalarGcRootLifetimeIndices,
        Vec<bool>,
    ) {
        // 分析停用[LayerBoundary]：普通潜在事件由后续 locals 以
        // `collect_call_root_lifetimes(..., true, ...)` 配对并物化 owner；locals 的 TempChain
        // invalidation 会让 temp-inline 针对已物化 owner 重跑。本轮只消费 lookup 的显式 GC/
        // return 后缀证明与已完成 overwrite pair，避免把尚未配对的普通观察扩成全局 barrier。
        let snapshot = RootLifetimeFacts::with_events(stmts, facts, self.safety, event_block);
        let call_roots = collect_call_root_lifetimes(
            &snapshot,
            facts,
            self.safety,
            false,
            |temp| !self.module.inert_call_results.contains(&temp),
            |_| super::root_lifetimes::RootOverwritePolicy::Reuse,
        );
        let mut marked = call_roots.marked_stmts(stmts.len());
        let lookup_roots =
            collect_scalar_gc_root_lifetimes(&snapshot, facts, self.safety, |_| true);
        lookup_roots.mark_stmts(&mut marked);
        let mut dispatch_operands = BTreeSet::new();
        for (index, stmt) in stmts.iter().enumerate() {
            // locals 会原子物化普通多返回组；其任一结果的确切覆盖都必须留在原 home，
            // 即使该槽自身没有触发保活。否则 nil forwarding 会让物化后的 sibling 无终点
            // （regress_509）。generic initializer 仍由专属 owner 消费整包。
            marked[index] |= call_roots.owner_overwrites(index).any(|owner| {
                matches!(&stmts[owner.root_index()], HirStmt::Assign(assign)
                    if assign.targets.len() > 1 && assign.generic_for_initializer_producer.is_none())
                    // 未读的固定单结果同样由 locals 物化；保留其原槽覆盖，避免 COPY
                    // 内联后只剩高槽 scratch，丢失后续赋值沿用该 binding 的事实。
                    || stmts[owner.root_index()].scalar_temp_assignment().is_some_and(|(temp, value)| {
                        matches!(value, HirExpr::Call(call)
                            if !snapshot.has_read_after(temp, owner.root_index())
                                && facts.fixed_call_result(call, 0) == Some(temp)
                                && facts.native_call_frame(call).is_some_and(|frame|
                                    frame.home == owner.home()
                                        && matches!(frame.results, Some(crate::transformer::ResultPack::Fixed(pack))
                                            if pack.len == 1 && pack.start.index() == frame.home.slot())))
                    })
            });
            if call_roots.call_dispatch_releases(index).next().is_some()
                || lookup_roots.call_dispatch_releases(index).next().is_some()
            {
                collect_stmt_temp_uses(stmt, &mut self.uses).for_each(|temp, _| {
                    dispatch_operands.insert(temp);
                });
            }
        }
        if self.block_depth == 1 {
            // handoff 与覆盖配对来自同一改写前快照；先保护接收 home，再递归内联子块。
            self.publish_lookup_handoffs(&lookup_roots);
        }
        for (index, stmt) in stmts.iter().enumerate() {
            if !marked[index]
                && stmt.scalar_temp_assignment().is_some_and(|(temp, _)| {
                    // 候选拒绝[SemanticBarrier:Lifetime]：regress_509 的 lookup 必须先于
                    // dispatch root release；locals 安装释放位置前不能收回操作数求值点。
                    dispatch_operands.contains(&temp)
                        || facts.is_copy_root_endpoint(temp, |producer| {
                            self.uses.has_definition(producer)
                                || facts.promoted_local_for_temp(producer).is_some()
                        })
                        || self
                            .physical_root_temps
                            .get(temp.index())
                            .copied()
                            .unwrap_or(false)
                })
            {
                // Raw CFG facts can pair a producer in the parent block with exact overwrites in
                // multiple terminal children. The block-local collector above cannot represent that
                // relation. Same-block pairs stay owned by the precise collector (including its
                // effectful-RHS fusion); only an otherwise unrepresented endpoint is protected here.
                // A scope-end copy root is protected here only when a direct if test controls a later
                // observing arm, or when a generic-for producer consumes it before a loop-body
                // observation. Direct return/protocol result slots already transfer the same value
                // into VM-owned homes and remain eligible for their dedicated inline owners.
                marked[index] = true;
            }
        }
        (call_roots, lookup_roots, marked)
    }

    fn publish_lookup_handoffs(&mut self, roots: &ScalarGcRootLifetimeIndices) {
        for temp in roots.handoff_roots() {
            self.physical_root_temps[temp.index()] = true;
            self.new_physical_root_temps.insert(temp);
        }
    }
}

#[allow(clippy::too_many_arguments)]
fn inline_temps_in_block(
    block: &mut HirBlock,
    workspace: &mut TempInlineWorkspace<'_>,
    live_use_counts: &mut [usize],
    captures: &TempInlineCaptureFacts<'_>,
    readability: ReadabilityOptions,
    facts: &ProtoPromotionFacts,
    inherited_captured_slots: &BTreeSet<HomeSlotKey>,
    event_scope: RootEventBlock<'_>,
) -> bool {
    let reference_captured = captures.bindings;
    let is_proto_root = workspace.block_depth == 0;
    workspace.block_depth += 1;
    let mut changed = false;
    let (mut call_root_indices, mut scalar_root_indices, mut physical_root_lifetimes) =
        workspace.collect_temp_root_lifetimes(&block.stmts, facts, Some(event_scope));
    let mut captured_slots_before_stmt =
        CapturedSlotSnapshots::new(block.stmts.len(), inherited_captured_slots);
    let mut active_captured_slots = inherited_captured_slots.clone();

    for index in 0..block.stmts.len() {
        captured_slots_before_stmt.push(&active_captured_slots);
        if matches!(workspace.scope, TempInlineScope::All) {
            let mut nested_captured_slots = active_captured_slots.clone();
            facts.collect_prefix_captured_home_slots_in_stmt(
                &block.stmts[index],
                &mut nested_captured_slots,
            );
            changed |= inline_temps_in_nested_blocks(
                &mut block.stmts[index],
                workspace,
                live_use_counts,
                captures,
                readability,
                facts,
                &nested_captured_slots,
                event_scope.stmt(index),
            );
        }
        let stmt = &block.stmts[index];
        facts.collect_captured_home_slots_in_stmt(stmt, &mut active_captured_slots);
    }

    if is_proto_root
        && inline_root_open_return_nil_pack(
            block,
            &workspace.uses,
            live_use_counts,
            facts,
            &captured_slots_before_stmt,
            &physical_root_lifetimes,
        )
    {
        changed = true;
        captured_slots_before_stmt =
            captured_slots_before_stmts(block, facts, inherited_captured_slots);
        (
            call_root_indices,
            scalar_root_indices,
            physical_root_lifetimes,
        ) = workspace.collect_temp_root_lifetimes(&block.stmts, facts, None);
    }

    if matches!(workspace.scope, TempInlineScope::All)
        && inline_covered_root_copies(
            block,
            &mut workspace.uses,
            live_use_counts,
            facts,
            &captured_slots_before_stmt,
            captures,
            &call_root_indices,
            &mut workspace.physical_root_temps,
            &mut workspace.new_physical_root_temps,
            &workspace.inline_dispositions,
            workspace.safety,
            (!changed).then_some(event_scope),
        )
    {
        changed = true;
        captured_slots_before_stmt =
            captured_slots_before_stmts(block, facts, inherited_captured_slots);
        (
            call_root_indices,
            scalar_root_indices,
            physical_root_lifetimes,
        ) = workspace.collect_temp_root_lifetimes(&block.stmts, facts, None);
    }

    if inline_terminal_nil_return_pack(
        block,
        &workspace.uses,
        live_use_counts,
        facts,
        &captured_slots_before_stmt,
        &physical_root_lifetimes,
    ) {
        changed = true;
        captured_slots_before_stmt =
            captured_slots_before_stmts(block, facts, inherited_captured_slots);
        (
            call_root_indices,
            scalar_root_indices,
            physical_root_lifetimes,
        ) = workspace.collect_temp_root_lifetimes(&block.stmts, facts, None);
    }

    if inline_materialization_runs(
        block,
        workspace,
        live_use_counts,
        facts,
        &captured_slots_before_stmt,
        captures,
        &physical_root_lifetimes,
    ) {
        changed = true;
        captured_slots_before_stmt =
            captured_slots_before_stmts(block, facts, inherited_captured_slots);
        (
            call_root_indices,
            scalar_root_indices,
            physical_root_lifetimes,
        ) = workspace.collect_temp_root_lifetimes(&block.stmts, facts, None);
    }

    if matches!(workspace.scope, TempInlineScope::All)
        && inline_adjacent_root_expression_overwrites(
            &adjacent_root_overwrites(&block.stmts, &workspace.uses, live_use_counts, facts),
            block,
            live_use_counts,
            facts,
            &captured_slots_before_stmt,
            &call_root_indices,
            &scalar_root_indices,
        )
    {
        changed = true;
        captured_slots_before_stmt =
            captured_slots_before_stmts(block, facts, inherited_captured_slots);
        (_, _, physical_root_lifetimes) =
            workspace.collect_temp_root_lifetimes(&block.stmts, facts, None);
    }

    // proto 级 live use count 会随成功内联同步减少；当前 block 只需保留下一条
    // 语句和 callee 物化位置。这既保留相邻内联边界，也避免每个 nested block
    // 重新遍历整棵子树。fallback 回边上任何额外读取都会使 live count 大于 1，
    // 因此不会被当成可删的 forwarding temp。
    let mut kept_rev = Vec::with_capacity(block.stmts.len());
    let mut callee_materialized_at = None;
    let mut adjacent_changed = false;

    // 反向内联可能先吞掉 COPY；在改写前保存低槽 GETTABLE 的写回义务。
    // 这次写入由 carried-local/索引帧恢复，不能随 callee COPY 迁到高槽。
    for pair in block.stmts.windows(2) {
        if let Some((temp, HirExpr::TableAccess(_))) = pair[0].scalar_temp_assignment()
            && let Some((target, HirExpr::TempRef(source))) = pair[1].scalar_temp_assignment()
            && *source == temp
            && facts
                .trusted_temp_home_slot(temp)
                .zip(facts.trusted_temp_home_slot(target))
                .is_some_and(|(source, destination)| source.slot() < destination.slot())
        {
            changed |= workspace
                .inline_dispositions
                .preserve_temp(temp, HirInlineRetentionReason::PhysicalFramePrefix);
            workspace.physical_root_temps[temp.index()] = true;
            workspace.new_physical_root_temps.insert(temp);
        }
    }

    let mut earlier = std::mem::take(&mut block.stmts)
        .into_iter()
        .enumerate()
        .rev()
        .peekable();
    while let Some((index, stmt)) = earlier.next() {
        let preserves_table_initialization =
            stmt.scalar_temp_assignment().is_some_and(|(temp, value)| {
                kept_rev.last().is_some_and(|sink| {
                    crate::hir::table_layout::inline_changes_table_initialization(sink, temp, value)
                })
            });
        if preserves_table_initialization {
            let (temp, _) = stmt
                .scalar_temp_assignment()
                .expect("checked table operand producer");
            changed |= workspace
                .inline_dispositions
                .preserve_temp(temp, HirInlineRetentionReason::TableInitialization);
        }
        if let Some((temp, _)) = stmt.scalar_temp_assignment()
            && temp_rebinds_captured_slot(
                temp,
                facts,
                captured_slots_before_stmt
                    .get(index)
                    .expect("forward scan should record every statement"),
            )
        {
            // 该写入的物理 home 已按引用捕获；即使其它 guard 先拒绝候选，也必须把
            // “不能删除这次 binding 写入”的结论交给后续身份提升与 AST。
            changed |= workspace
                .inline_dispositions
                .preserve_temp(temp, HirInlineRetentionReason::CapturedValueEpoch);
        }
        if let Some((temp, value)) = stmt.scalar_temp_assignment()
            && kept_rev
                .last()
                .is_some_and(|next| occupies_branch_call_prefix(temp, value, next, facts))
        {
            // 后续 locals/inline-exprs 也必须消费同一前缀义务；单轮拒绝内联不足以保留身份。
            changed |= workspace
                .inline_dispositions
                .preserve_temp(temp, HirInlineRetentionReason::PhysicalFramePrefix);
            workspace.physical_root_temps[temp.index()] = true;
            workspace.new_physical_root_temps.insert(temp);
        }
        if let Some((temp, value)) = stmt.scalar_temp_assignment()
            // 候选拒绝[SemanticBarrier:TableShape]：regress_471 的常量字段会触发模板裁尾，改变 #table。
            && !preserves_table_initialization
            // LayerBoundary：GETTABLE 的结果覆盖属于原 SETLIST 缓冲帧；
            // 独立内联会丢失这次写回，固定批次 owner 也无法再原位降低。
            && !kept_rev.last().is_some_and(|next| set_list_needs_lookup_frame(next, temp, value))
            // 候选拒绝[SemanticBarrier:Lifetime]：被 physical-root lifetime 标记的 call/lookup 结果仍承担 VM root；提前删除会改变对象存活期（regress_356）。
            && !physical_root_lifetimes[index]
            && !workspace
                .physical_root_temps
                .get(temp.index())
                .copied()
                .unwrap_or(false)
            // 候选拒绝[SemanticBarrier:Lifetime]：`t=f(); box.x=t` 中 t 是写入完成前的唯一 VM root，删除可能改变 GC/析构可观察时机。
            // A call result stored in a table can outlive the immediate write. Removing the
            // temp would remove the only lexical/VM root before a later rawset or table clear;
            // keep that producer unless a separate lifetime proof exists.
            && !(matches!(value, HirExpr::Call(_))
                && kept_rev.last().is_some_and(|next_stmt| {
                    stmt_stores_temp_in_table(next_stmt, temp)
                        && !call_result_can_enter_set_list(temp, next_stmt, &workspace.uses, facts)
                }))
            // 候选拒绝[PolicyBoundary]：DebugScope 标注该 temp 是显式源码 binding，保留其独立声明身份。
            && !workspace.uses.has_debug_local_hint(temp)
            // 候选拒绝[LayerBoundary]：原低槽分配/初始化、FASTCALL 参数源与 CALL 写回由完整帧共同消费。
            && !facts.temp_requires_call_frame(temp)
            // 候选拒绝[SemanticBarrier:Capture]：若 closure 已按引用捕获该 home，删除写入会让 closure 观察旧值；见 regress_310。
            && !temp_rebinds_captured_slot(
                temp,
                facts,
                captured_slots_before_stmt
                    .get(index)
                    .expect("forward scan should record every statement"),
            )
            // `t = t + step` 这类自更新赋值表面上只在后缀里被用了一次，
            // 但它本质上承载的是跨语句/跨迭代的状态推进。
            // 一旦把它内联进下一条 `yield/return/call`，当前赋值本身就会消失，
            // 后续再也没有地方记录“状态已经更新过”。
            // 因此这里只允许折叠真正的 forwarding temp，不折叠自引用状态槽位。
            // 候选拒绝[SemanticBarrier:Lifetime]：`t=t+1; return t` 若删 producer，状态槽不再完成本次更新。
            && !expr_mentions_temp(value, temp)
            && let Some(next_stmt) = kept_rev.last()
            // 候选拒绝[LayerBoundary]：多目标 Phi 只有合流关系，不能把低槽的
            // 逐次计算改成高槽并行 RHS；carried-local owner 负责恢复目标身份。
            && !(matches!(value, HirExpr::Binary(_) | HirExpr::Unary(_))
                && phi_value_writes_target_slot(temp, next_stmt, facts))
            // 候选拒绝[LayerBoundary]：callee 下方的 producer 属于原声明前缀。
            // 即使值是常量，也不能局部删除后让完整 CALL/作用域事务失去其原槽占位。
            && !occupies_scalar_call_prefix(temp, value, next_stmt, facts)
            && !occupies_closure_call_prefix(temp, value, next_stmt, facts)
            // 候选拒绝[LayerBoundary]：一元操作在更高槽写结果时，原 CALL 结果
            // 是它下方仍存活的输入声明；保留两槽事实供源码帧 owner 同批恢复。
            && !occupies_unary_input_prefix(temp, value, next_stmt, facts)
            // 候选拒绝[LayerBoundary]：参数 COPY 的来源 CALL 保留独立结果槽，交完整帧消费。
            // GETTABLE 的低槽写回和 CLOSURE 的原分配槽不能改挂到异槽 COPY；
            // 索引帧需先恢复原目标身份，再消费调用准备。否则 locals 会把声明
            // 提升到调用 scratch，后续帧无法证明原声明前缀和两槽生命周期。
            // 候选拒绝[SemanticBarrier:Lifetime]：前层签发的 copy root 也不能改挂到异槽定义。
            // 647 的副本被用作 callee 后覆写，源槽仍跨 GC 存活；同值不代表同生命周期。
            && !next_stmt.scalar_temp_assignment().is_some_and(|(target, copied)| {
                    matches!(copied, HirExpr::TempRef(source) if *source == temp)
                        && facts.trusted_temp_home_slot(temp) != facts.trusted_temp_home_slot(target)
                        && (facts.is_scope_end_copy_root_temp(temp)
                            || matches!(value, HirExpr::Closure(_))
                            || (matches!(value, HirExpr::TableAccess(_))
                                && facts.trusted_temp_home_slot(temp).zip(facts.trusted_temp_home_slot(target))
                                    .is_some_and(|(source, destination)| source.slot() < destination.slot()))
                            // 值决策预写仍占据原结果槽；移到高槽 COPY 会遗留低槽
                            // 预写，且让后续 CALL 的声明前缀永久缺一格。
                            || (workspace.dialect == DecompileDialect::Luau
                                && (facts.boolean_value_prewrite(temp).is_some()
                                || facts.copy_value_prewrite(temp).is_some()
                                || matches!(value, HirExpr::Binary(binary)
                                    if facts.comparison_result_temp(binary) == Some(temp)))
                                && facts.trusted_temp_home_slot(temp).zip(facts.trusted_temp_home_slot(target))
                                    .is_some_and(|(source, destination)| source.slot() < destination.slot()))
                            || (matches!(value, HirExpr::Call(_))
                                && facts.temp_is_transferred_call_argument(target)))
                })
            && let use_count = total_use_count(temp, live_use_counts)
            // 候选拒绝[SemanticBarrier:Lifetime]：两个以上消费不能随 producer 一并替换；零消费属于 dead-temps owner。
            // 候选拒绝[LayerBoundary]：零消费 producer 的 effect-preserving 删除由 dead-temps pass 负责。
            && (use_count == 1
                || (use_count == 2
                    && is_method_receiver_snapshot(next_stmt, temp, value)))
            // 下一条语句没有受支持的直接消费站点时，不形成相邻候选；proto 内更晚的
            // 唯一 use 属于非紧邻形状，具体站点边界由 `inline_site_in_stmt` 标记。
            && let Some(site) = inline_site_in_stmt(next_stmt, temp)
            // 候选拒绝[SemanticBarrier:ValueFlow]：regress_387 的 repeat body 会重新定义
            // 同一 carrier；把循环前的 nil 内联到 until 会抹掉这些 reaching writes。
            && !(site.is_repeated_region() && stmt_writes_temp(next_stmt, temp))
            && prefixed_block_candidate_is_safe(
                site,
                temp,
                value,
                reference_captured,
                workspace.safety,
            )
            // 候选拒绝[LayerBoundary]：branch-value 定向入口只消费 terminal return，完整相邻内联由正常 temp-inline 轮次负责。
            && workspace
                .scope
                .allows_adjacent(temp, site, next_stmt, kept_rev.len() == 1)
            // 候选拒绝[SemanticBarrier:EvalOrder]：`callee=f; arg=g(); callee(arg)` 不能只把 arg 移到 callee 物化之前。
            && !call_arg_inline_crosses_materialized_callee(
                site,
                value,
                index,
                callee_materialized_at,
            )
            // 候选拒绝[SemanticBarrier:EvalOrder]：sink 中 temp 之前的 call/lookup/可变快照会观察 producer 移动；见 regress_172、regress_211。
            && !inline_crosses_evaluation_boundary(
                site,
                value,
                next_stmt,
                temp,
                reference_captured,
                workspace.dialect,
                workspace.safety,
            )
            // 候选拒绝[PolicyBoundary]：复杂 child closure 保留命名 binding，避免生成多行 IIFE。
            && !substantial_result_closure_prefers_binding(
                site,
                value,
                next_stmt,
                workspace.module.substantial_closure_bodies,
            )
            && (site.allows(value, readability, workspace.safety)
                || (site == InlineSite::CallArg
                    && workspace.uses.has_unique_definition(temp)
                    && facts.temp_is_transferred_call_argument(temp)
                    && stmt_has_argument_root_handoff(next_stmt, temp)))
            && inline_expansion_budget(next_stmt, value).is_some()
        {
            let next_stmt = kept_rev
                .last_mut()
                .expect("next stmt metadata must track the last kept stmt");
            let batched = use_count == 1
                && matches!(workspace.scope, TempInlineScope::All)
                && inline_pure_dependency_chain(
                    next_stmt,
                    (index, &stmt, site),
                    &mut earlier,
                    &mut PureInlineContext {
                        scratch: &mut workspace.uses,
                        live_use_counts,
                        facts,
                        captured_slots_before_stmt: &captured_slots_before_stmt,
                        readability,
                        safety: workspace.safety,
                    },
                    &physical_root_lifetimes,
                    &workspace.physical_root_temps,
                    reference_captured,
                    &mut callee_materialized_at,
                );
            if !batched {
                replace_temp_in_stmt(next_stmt, temp, value);
                if site.is_call_callee() {
                    callee_materialized_at = Some(index);
                }
                remove_live_use(live_use_counts, temp);
                if use_count == 2 {
                    // method receiver 会把 replacement 同时写入 callee base 与隐式首参；
                    // 删除原赋值只抵消其中一份，因此需把新增的语法 use 记回本轮计数。
                    collect_expr_temp_uses_summary(value, &mut workspace.uses)
                        .add_to_totals(live_use_counts);
                    remove_live_use(live_use_counts, temp);
                }
            }
            changed = true;
            adjacent_changed = true;
            continue;
        }

        // FASTCALL fallback callee 在参数后物化，收回 callee 后仍可按协议折叠相邻末参数；普通调用保留原顺序屏障。
        callee_materialized_at = kept_rev
            .last()
            .and_then(HirStmt::scalar_temp_assignment)
            .and_then(|(next_temp, _)| {
                fastcall_callee_materialization_precedes_temp(&stmt, next_temp).then_some(index)
            });
        kept_rev.push(stmt);
    }

    kept_rev.reverse();
    block.stmts = kept_rev;

    // 相邻逆向扫描可能刚把 `rhs_temp = g()` 收进 same-home overwrite，形成
    // `root = f(); overwrite = root + g()`。若等下一轮，locals 会先把这对 temp 固化为
    // source binding；因此在同一坐标压缩完成后重算 root/capture 事实，并交回同一个
    // root owner 原子消费；同槽 lookup 链也在 locals 冻结身份之前交接。
    if adjacent_changed && matches!(workspace.scope, TempInlineScope::All) {
        let candidates =
            adjacent_root_overwrites(&block.stmts, &workspace.uses, live_use_counts, facts);
        if is_proto_root || !candidates.is_empty() {
            let snapshot = RootLifetimeFacts::new(&block.stmts, facts, workspace.safety);
            // 根层 lookup handoff 仍会发布 PhysicalRoot，即使没有相邻 call 覆盖候选。
            // 深层的保护标记已消费完毕，不能为丢弃的投影重扫每层完整子树。
            let lookup_roots =
                collect_scalar_gc_root_lifetimes(&snapshot, facts, workspace.safety, |_| true);
            if is_proto_root {
                workspace.publish_lookup_handoffs(&lookup_roots);
            }
            if !candidates.is_empty() {
                let call_roots = collect_call_root_lifetimes(
                    &snapshot,
                    facts,
                    workspace.safety,
                    false,
                    |_| true,
                    |_| super::root_lifetimes::RootOverwritePolicy::Reuse,
                );
                let captured_slots =
                    captured_slots_before_stmts(block, facts, inherited_captured_slots);
                changed |= inline_adjacent_root_expression_overwrites(
                    &candidates,
                    block,
                    live_use_counts,
                    facts,
                    &captured_slots,
                    &call_roots,
                    &lookup_roots,
                );
            }
        }
    }

    workspace.block_depth -= 1;
    changed
}

fn substantial_result_closure_prefers_binding(
    site: InlineSite,
    value: &HirExpr,
    sink: &HirStmt,
    substantial_closure_bodies: &[bool],
) -> bool {
    let Some(sink) = transparent_block_head(sink) else {
        return false;
    };
    let HirExpr::Closure(closure) = value else {
        return false;
    };
    site.is_call_callee()
        && matches!(
            sink,
            HirStmt::Assign(_) | HirStmt::LocalDecl(_) | HirStmt::Return(_)
        )
        && substantial_closure_bodies
            .get(closure.proto.index())
            .copied()
            .unwrap_or(true)
}

pub(super) fn proto_body_prefers_named_callee(body: &HirBlock) -> bool {
    let stmts = match body.stmts.last() {
        Some(HirStmt::Return(ret)) if ret.values.fixed.is_empty() && ret.values.tail.is_none() => {
            &body.stmts[..body.stmts.len() - 1]
        }
        _ => body.stmts.as_slice(),
    };
    stmts.len() > 1
        || matches!(
            stmts.first(),
            Some(
                HirStmt::If(_)
                    | HirStmt::While(_)
                    | HirStmt::Repeat(_)
                    | HirStmt::NumericFor(_)
                    | HirStmt::GenericFor(_)
                    | HirStmt::Block(_)
            )
        )
}

fn inline_crosses_evaluation_boundary(
    site: InlineSite,
    value: &HirExpr,
    next_stmt: &HirStmt,
    temp: TempId,
    reference_captured: &ReferenceCapturedBindings,
    dialect: DecompileDialect,
    safety: HirExprSafety,
) -> bool {
    // 候选拒绝[SemanticBarrier:ControlFlow]：循环外 `t=f()` 不能内联进 while 条件而改成每轮调用；见 regress_172#1/#2。
    // 候选拒绝[SemanticBarrier:EvalOrder]：无 capture closure 仍会分配新 identity；`a=f(); t=function() end; g(a,t)` 不能把分配移到 `f()` 之后。
    let producer_requires_order =
        expr_requires_ordered_snapshot(value) || !safety.is_discard_safe(value);
    let producer_has_observable_eval =
        expr_observes_eval_order(value) || !safety.is_discard_safe(value);
    (site.is_repeated_region() && !is_stable_inline_value(value))
        || (producer_requires_order
            && !puc_upvalue_table_key_with_deferred_base_read(site, next_stmt, dialect)
                .is_some_and(|key| {
                    temp_precedes_observable_eval_in_expr(
                        key,
                        temp,
                        producer_has_observable_eval,
                        reference_captured,
                    )
                })
            && !temp_precedes_observable_eval_in_stmt(
                next_stmt,
                temp,
                producer_has_observable_eval,
                reference_captured,
            ))
}

fn prefixed_block_candidate_is_safe(
    site: InlineSite,
    temp: TempId,
    value: &HirExpr,
    reference_captured: &ReferenceCapturedBindings,
    safety: HirExprSafety,
) -> bool {
    // 候选拒绝[SemanticBarrier:Capture]：`t = 1; closure = function() return t end;
    // return t` 中删除 producer 会让按引用捕获的 closure 失去其 cell，即使 replacement
    // 本身没有 GC lifetime。其它 PrefixedBlock 候选由 site 限制为 proto 常量持有的
    // stable value；它们的结果不依赖 target physical home 是否继续作为 root。
    site != InlineSite::PrefixedBlock
        || (!reference_captured.temps.contains(&temp) && safety.result_is_gc_inert(value))
}

fn captured_slots_before_stmts(
    block: &HirBlock,
    facts: &ProtoPromotionFacts,
    inherited_captured_slots: &BTreeSet<HomeSlotKey>,
) -> CapturedSlotSnapshots {
    let mut snapshots = CapturedSlotSnapshots::new(block.stmts.len(), inherited_captured_slots);
    let mut active_captured_slots = inherited_captured_slots.clone();
    for stmt in &block.stmts {
        snapshots.push(&active_captured_slots);
        facts.collect_captured_home_slots_in_stmt(stmt, &mut active_captured_slots);
    }
    snapshots
}

struct CapturedSlotSnapshots {
    snapshots: Vec<BTreeSet<HomeSlotKey>>,
    before_stmt: Vec<usize>,
}

impl CapturedSlotSnapshots {
    fn new(stmt_count: usize, inherited: &BTreeSet<HomeSlotKey>) -> Self {
        Self {
            snapshots: vec![inherited.clone()],
            before_stmt: Vec::with_capacity(stmt_count),
        }
    }

    fn push(&mut self, active: &BTreeSet<HomeSlotKey>) {
        if self.snapshots.last().is_none_or(|last| last != active) {
            self.snapshots.push(active.clone());
        }
        self.before_stmt.push(self.snapshots.len() - 1);
    }

    fn get(&self, stmt_index: usize) -> Option<&BTreeSet<HomeSlotKey>> {
        self.before_stmt
            .get(stmt_index)
            .and_then(|snapshot_index| self.snapshots.get(*snapshot_index))
    }
}

fn set_list_needs_lookup_frame(stmt: &HirStmt, temp: TempId, value: &HirExpr) -> bool {
    let HirStmt::TableSetList(batch) = stmt else {
        return false;
    };
    matches!(value, HirExpr::TableAccess(_)) && batch.values.fixed.contains(&HirExpr::TempRef(temp))
}

/// 物理 root 终点只证明源程序的后缀；目标还需要 constructor 的强引用载体。
/// 任意已有表可能是弱表，删除显式释放再重编译会让隐藏调用结果槽存活更久（regress_396）。
fn call_result_can_enter_set_list(
    temp: TempId,
    stmt: &HirStmt,
    uses: &TempUseScratch,
    facts: &ProtoPromotionFacts,
) -> bool {
    let HirStmt::TableSetList(set_list) = stmt else {
        return false;
    };
    let HirExpr::TempRef(seed) = set_list.base else {
        return false;
    };
    uses.has_unique_definition(temp)
        && facts.call_result_root_ends_after_value_use(temp)
        && facts.is_direct_table_seed_temp(seed)
        && facts.trusted_temp_home_slot(seed).is_some()
}

/// 连续低槽 Phi 按原 home 定位成员，再核对真实两端；不逐 producer 重扫整个结果组。
fn phi_value_writes_target_slot(temp: TempId, stmt: &HirStmt, facts: &ProtoPromotionFacts) -> bool {
    let HirStmt::Assign(assign) = stmt else {
        return false;
    };
    let Some(HirLValue::Temp(first)) = assign.targets.first() else {
        return false;
    };
    if !assign.is_phi_transfer || assign.targets.len() < 2 {
        return false;
    }
    let Some(home) = facts.trusted_temp_home_slot(temp) else {
        return false;
    };
    let Some(first) = facts.trusted_temp_home_slot(*first) else {
        return false;
    };
    let Some(offset) = home.slot().checked_sub(first.slot()) else {
        return false;
    };
    matches!((assign.targets.get(offset), assign.values.fixed.get(offset)),
        (Some(HirLValue::Temp(target)), Some(HirExpr::TempRef(source)))
            if *source == temp && facts.trusted_temp_home_slot(*target) == Some(home))
}

fn stmt_stores_temp_in_table(stmt: &HirStmt, temp: TempId) -> bool {
    let Some(stmt) = transparent_block_head(stmt) else {
        return false;
    };
    match stmt {
        HirStmt::Assign(assign) => {
            let table_lvalue = assign.targets.iter().any(|target| {
                matches!(
                    target,
                    HirLValue::TableAccess(access)
                        if expr_mentions_temp(&access.base, temp)
                            || expr_mentions_temp(&access.key, temp)
                )
            });
            let table_constructor_value = assign.values.iter().any(|value| {
                matches!(value, HirExpr::TableConstructor(_)) && expr_mentions_temp(value, temp)
            });
            table_lvalue
                || table_constructor_value
                || (assign
                    .targets
                    .iter()
                    .any(|target| matches!(target, HirLValue::TableAccess(_)))
                    && assign
                        .values
                        .iter()
                        .any(|value| expr_mentions_temp(value, temp)))
        }
        HirStmt::GlobalDecl(global_decl) => global_decl.values.fixed.iter().any(|value| {
            matches!(value, HirExpr::TempRef(value_temp) if *value_temp == temp)
                || (matches!(value, HirExpr::TableConstructor(_))
                    && expr_mentions_temp(value, temp))
        }),
        HirStmt::TableSetList(set_list) => {
            expr_mentions_temp(&set_list.base, temp)
                || set_list
                    .values
                    .iter()
                    .any(|value| expr_mentions_temp(value, temp))
        }
        HirStmt::LocalDecl(local_decl) => local_decl.values.iter().any(|value| {
            matches!(value, HirExpr::TableConstructor(_)) && expr_mentions_temp(value, temp)
        }),
        _ => false,
    }
}

/// 当前坐标下的重写候选；只筛选语法与删除资格，不能代替整个 block 的 home 配对证明。
struct AdjacentRootOverwrite {
    overwrite_index: usize,
    root: TempId,
}

fn adjacent_root_overwrites(
    stmts: &[HirStmt],
    scratch: &TempUseScratch,
    live_use_counts: &[usize],
    facts: &ProtoPromotionFacts,
) -> Vec<AdjacentRootOverwrite> {
    let mut candidates = Vec::new();
    for overwrite_index in 1..stmts.len() {
        let Some((root, value)) = stmts[overwrite_index - 1].scalar_temp_assignment() else {
            continue;
        };
        let Some((target, overwrite)) = stmts[overwrite_index].scalar_temp_assignment() else {
            continue;
        };
        if root == target {
            continue;
        }
        // 候选拒绝[SemanticBarrier:Lifetime]：覆盖后仍读 root，或同一 temp 有多个定义时，不能删除原结果 epoch。
        if total_use_count(root, live_use_counts) != 1 || !scratch.has_unique_definition(root) {
            continue;
        }
        // 只删除 source root；Boolean 值覆盖融合仍保留 target 的原声明与 debug 身份。
        // 其它运算继续保持既有 debug 边界。
        if scratch.has_debug_local_hint(root)
            || (scratch.has_debug_local_hint(target)
                && !matches!(overwrite, HirExpr::Unary(unary)
                    if unary.op == crate::hir::HirUnaryOpKind::Not))
        {
            continue;
        }
        let supported = match value {
            HirExpr::Call(_) => call_root_overwrite_is_inlineable(overwrite, root, target, facts),
            HirExpr::TableAccess(_) => lookup_root_overwrite_is_inlineable(overwrite, root, facts),
            _ => false,
        };
        if !supported {
            continue;
        }
        candidates.push(AdjacentRootOverwrite {
            overwrite_index,
            root,
        });
    }
    candidates
}

fn inline_adjacent_root_expression_overwrites(
    candidates: &[AdjacentRootOverwrite],
    block: &mut HirBlock,
    live_use_counts: &mut [usize],
    facts: &ProtoPromotionFacts,
    captured_slots_before_stmt: &CapturedSlotSnapshots,
    call_roots: &CallRootLifetimeIndices,
    scalar_roots: &ScalarGcRootLifetimeIndices,
) -> bool {
    if candidates.is_empty() {
        return false;
    }
    let mut removed = vec![false; block.stmts.len()];
    let mut replacements = BTreeMap::new();
    let mut sinks = BTreeSet::new();
    for &AdjacentRootOverwrite {
        overwrite_index,
        root,
    } in candidates
    {
        let root_index = overwrite_index - 1;
        let Some(pair) = call_roots
            // 精确终点独立于是否选择额外保活；融合消费原覆盖事实，不要求先物化 root。
            .owner_overwrites(overwrite_index)
            .chain(scalar_roots.owner_overwrites(overwrite_index))
            .find(|pair| pair.root_index() == root_index)
        else {
            continue;
        };
        let Some((target, _)) = block.stmts[overwrite_index].scalar_temp_assignment() else {
            unreachable!("adjacent overwrite must retain its scalar target");
        };
        // 只消费同一 home 的原值覆盖。CALL 后的异槽 MOVE 属于独立交接事务，不能
        // 将其目标 home 的结束证书解释成 CALL 自己的结果槽被覆盖。
        if facts.trusted_temp_home_slot(root) != Some(pair.home())
            || facts.trusted_temp_home_slot(target) != Some(pair.home())
        {
            continue;
        }
        let mut captured_slots = captured_slots_before_stmt
            .get(overwrite_index)
            .expect("capture snapshots must cover the adjacent root overwrite")
            .clone();
        facts.collect_captured_home_slots_in_stmt(
            &block.stmts[overwrite_index],
            &mut captured_slots,
        );
        // 候选拒绝[SemanticBarrier:Capture]：已有 capture 或 overwrite RHS 新建的 closure
        // 若引用 root home，删除 producer 会让它观察 overwrite 前的旧 cell。
        if captured_slots.contains(&pair.home()) {
            continue;
        }

        let (_, value) = block.stmts[root_index]
            .scalar_temp_assignment()
            .expect("adjacent root candidate retains its producer until compaction");
        replacements.insert(root, value.clone());
        sinks.insert(overwrite_index);
        removed[root_index] = true;
        remove_live_use(live_use_counts, root);
    }
    let changed = removed.contains(&true);
    if changed {
        // 唯一定义、单 use 和前向相邻边保证无环；只展开最终 sink 一次，不为长字段
        // 链的每个中间节点反复复制增长中的表达式。共享 rewrite owner 消费该替换 DAG。
        for index in sinks.into_iter().filter(|index| !removed[*index]) {
            replace_temps_in_stmt(&mut block.stmts[index], &replacements);
        }
        block.stmts = std::mem::take(&mut block.stmts)
            .into_iter()
            .enumerate()
            .filter_map(|(index, stmt)| (!removed[index]).then_some(stmt))
            .collect();
    }
    changed
}

fn lookup_root_overwrite_is_inlineable(
    mut expr: &HirExpr,
    root: TempId,
    facts: &ProtoPromotionFacts,
) -> bool {
    if matches!(comparison_operand(expr), Some(HirExpr::TempRef(temp)) if *temp == root) {
        // 只描述候选的单次读取；原 lookup→Boolean 的同槽覆盖仍由事务上方的
        // owner_overwrites/可信 home 证明。赋值保留值语境，不把 Boolean 改成 if 极性。
        return true;
    }
    let original = expr;
    while let HirExpr::Unary(unary) = expr
        && unary.op == crate::hir::HirUnaryOpKind::Not
    {
        expr = &unary.expr;
    }
    if let HirExpr::Binary(binary) = expr
        && matches!(
            binary.op,
            crate::hir::HirBinaryOpKind::Eq
                | crate::hir::HirBinaryOpKind::Lt
                | crate::hir::HirBinaryOpKind::Le
        )
        && matches!(binary.lhs, HirExpr::TempRef(temp) if temp == root)
        && let Some(home) = facts.trusted_temp_home_slot(root)
    {
        // 低槽直接读取没有额外参数准备写；lookup 结果保留到比较完成，再由原
        // 同 home Boolean 覆盖退休。不能把需另行求值的 RHS 当作此处的寄存器读。
        let rhs_home = match binary.rhs {
            HirExpr::TempRef(temp) => facts.trusted_temp_home_slot(temp),
            HirExpr::LocalRef(local) => facts.trusted_local_home_slot(local),
            HirExpr::ParamRef(param) => facts.trusted_param_home_slot(param),
            _ => None,
        };
        return rhs_home.is_some_and(|rhs| rhs.slot() < home.slot());
    }
    // 只消费一层 GETTABLE 的直接 base 与常量 key。嵌套 access 已没有每个中间
    // home 的独立身份，最终覆盖不能证明它们曾在同槽写回；长链必须逐条签证再合并。
    matches!(original, HirExpr::TableAccess(access)
        if matches!(access.base, HirExpr::TempRef(temp) if temp == root)
            && matches!(access.key,
                HirExpr::Nil
                    | HirExpr::Boolean(_)
                    | HirExpr::Integer(_)
                    | HirExpr::Number(_)
                    | HirExpr::String(_)))
}

/// 由 root_lifetimes 冻结的同值覆盖计划；use_sites 只描述此次替换的 HIR 位置。
struct CoveredRootCopy {
    target: TempId,
    source: TempId,
    copy_index: usize,
    target_home: HomeSlotKey,
    source_home: HomeSlotKey,
    use_sites: Vec<usize>,
}

/// 统一提交 scope-end 死复制与 SELF receiver 的根交接。
/// 生命周期/协议来自 root_lifetimes，本层检查 debug、capture、TBC 与当前读取并保留
/// source 的 PhysicalRoot。例：t=u; u=nil; dead=t; callback() 删除 dead，保留 t 的求值点。
#[allow(clippy::too_many_arguments)]
fn inline_covered_root_copies(
    block: &mut HirBlock,
    scratch: &mut TempUseScratch,
    live_use_counts: &mut [usize],
    facts: &ProtoPromotionFacts,
    captured_slots_before_stmt: &CapturedSlotSnapshots,
    captures: &TempInlineCaptureFacts<'_>,
    call_roots: &CallRootLifetimeIndices,
    physical_root_temps: &mut [bool],
    new_physical_root_temps: &mut BTreeSet<TempId>,
    inline_dispositions: &HirInlineDispositions,
    safety: HirExprSafety,
    event_scope: Option<RootEventBlock<'_>>,
) -> bool {
    let reference_captured = captures.bindings;
    let captured_homes = &captures.homes;
    let mut identities = (
        CaptureCollector::new(HirCaptureMode::ByValue),
        ToBeClosedTempCollector::default(),
    );
    visit_stmts(&block.stmts, &mut identities);
    let (value, closed) = identities;
    let mut identity_sensitive = value.bindings.temps;
    identity_sensitive.extend(closed.temps);
    // 子块改写会使入口快照失效；只有候选实际请求覆盖证明时才建立当前快照。
    let current_events = std::cell::OnceCell::new();
    let mut preserves_home = |range, home| {
        let scope = event_scope.unwrap_or_else(|| {
            current_events
                .get_or_init(|| RootEventIndex::new(&block.stmts, facts, safety))
                .root()
        });
        scope.slice(range).preserves_home(home)
    };
    let dead_copies = scope_end_copy_root_handoffs(&block.stmts, facts, &mut preserves_home)
        .into_iter()
        // 仍有源码读取的 source 已有自己的 use owner；不额外冻结它而阻止普通 copy 消解。
        .filter(|handoff| total_use_count(handoff.source, live_use_counts) == 1)
        .map(|handoff| CoveredRootCopy {
            target: handoff.target,
            source: handoff.source,
            copy_index: handoff.copy_index,
            target_home: handoff.target_home,
            source_home: handoff.source_home,
            use_sites: Vec::new(),
        });
    let method_copies = call_roots
        .method_receiver_handoffs(&block.stmts, facts, &mut preserves_home)
        .into_iter()
        .map(|handoff| {
            debug_assert!(handoff.sink_index() < handoff.overwrite_index());
            CoveredRootCopy {
                target: handoff.target(),
                source: handoff.source(),
                copy_index: handoff.producer_index(),
                target_home: handoff.target_home(),
                source_home: handoff.source_home(),
                use_sites: vec![handoff.lookup_index(), handoff.sink_index()],
            }
        });
    let plan = dead_copies.chain(method_copies).find(|handoff| {
        total_use_count(handoff.target, live_use_counts) == handoff.use_sites.len()
            && !scratch.has_debug_local_hint(handoff.target)
            && !inline_dispositions.temp(handoff.target).must_preserve()
            && !identity_sensitive.contains(&handoff.target)
            && !identity_sensitive.contains(&handoff.source)
            && !captured_homes.contains(&handoff.target_home)
            && !captured_homes.contains(&handoff.source_home)
            && !reference_captured.temps.contains(&handoff.target)
            && !reference_captured.temps.contains(&handoff.source)
            && materialization_run_candidate_is_safe(
                handoff.target,
                &HirExpr::TempRef(handoff.source),
                handoff.copy_index,
                scratch,
                facts,
                captured_slots_before_stmt,
            )
    });
    let Some(plan) = plan else {
        return false;
    };
    let replacement = HirExpr::TempRef(plan.source);
    for index in plan.use_sites {
        replace_temp_in_stmt(&mut block.stmts[index], plan.target, &replacement);
        remove_live_use(live_use_counts, plan.target);
        collect_expr_temp_uses_summary(&replacement, scratch).add_to_totals(live_use_counts);
    }
    block.stmts.remove(plan.copy_index);
    remove_live_use(live_use_counts, plan.source);
    physical_root_temps[plan.source.index()] = true;
    new_physical_root_temps.insert(plan.source);
    true
}

fn call_root_overwrite_is_inlineable(
    expr: &HirExpr,
    root: TempId,
    target: TempId,
    facts: &ProtoPromotionFacts,
) -> bool {
    match expr {
        HirExpr::Unary(unary) if unary.op == crate::hir::HirUnaryOpKind::Not => {
            let mut operand = &unary.expr;
            while let HirExpr::Unary(nested) = operand
                && nested.op == crate::hir::HirUnaryOpKind::Not
            {
                operand = &nested.expr;
            }
            // 同 home 覆盖由原配对证明；NOT 链仍在赋值的值语境中，不能转为 if 极性。
            matches!(operand, HirExpr::TempRef(source) if *source == root)
        }
        HirExpr::Binary(binary) => {
            matches!(&binary.lhs, HirExpr::TempRef(source) if *source == root)
        }
        HirExpr::LogicalOr(logical) => {
            root_is_inert_on_branch(&logical.lhs, root, false)
                || comparison_continuation_overwrites_root(logical, root, target, facts)
        }
        HirExpr::LogicalAnd(logical) => {
            root_is_inert_on_branch(&logical.lhs, root, true)
                || comparison_continuation_overwrites_root(logical, root, target, facts)
        }
        _ => false,
    }
}

/// 比较不写回旧操作数；条件路径上的一元操作完成后才退休旧 root。
/// `f()==false and #owner==0` 必须保留 LEN 的原身份，不能只看最终 Boolean 的 home。
/// 前者 LEN 与 CALL 同槽时可原子树化；命名 item 的 LEN 在另一个槽时继续保留 item。
fn comparison_continuation_overwrites_root(
    logical: &crate::hir::HirLogicalExpr,
    root: TempId,
    target: TempId,
    facts: &ProtoPromotionFacts,
) -> bool {
    if !matches!(comparison_operand(&logical.lhs), Some(HirExpr::TempRef(temp)) if *temp == root) {
        return false;
    }
    let Some(HirExpr::Unary(unary)) = comparison_operand(&logical.rhs) else {
        return false;
    };
    let Some(home) = facts.trusted_temp_home_slot(root) else {
        return false;
    };
    if facts.trusted_temp_home_slot(target) != Some(home)
        || facts.unary_result_home(unary) != Some(home)
    {
        return false;
    }
    // 原低槽 binding 直接作为 unary operand；不把 GGET/GETUPVAL 等额外准备写
    // 藏进 operand 后猜测它们会在何时覆盖旧 root。
    let operand_home = match unary.expr {
        HirExpr::TempRef(temp) => facts.trusted_temp_home_slot(temp),
        HirExpr::LocalRef(local) => facts.trusted_local_home_slot(local),
        HirExpr::ParamRef(param) => facts.trusted_param_home_slot(param),
        _ => None,
    };
    operand_home.is_some_and(|operand| operand.slot() < home.slot())
}

fn comparison_operand(mut expr: &HirExpr) -> Option<&HirExpr> {
    while let HirExpr::Unary(unary) = expr
        && unary.op == crate::hir::HirUnaryOpKind::Not
    {
        expr = &unary.expr;
    }
    let HirExpr::Binary(binary) = expr else {
        return None;
    };
    (matches!(
        binary.op,
        crate::hir::HirBinaryOpKind::Eq
            | crate::hir::HirBinaryOpKind::Lt
            | crate::hir::HirBinaryOpKind::Le
    ) && matches!(
        binary.rhs,
        HirExpr::Nil
            | HirExpr::Boolean(_)
            | HirExpr::Integer(_)
            | HirExpr::Number(_)
            | HirExpr::String(_)
    ))
    .then_some(&binary.lhs)
}

/// 短路继续求值时，旧 CALL 结果必须已被左侧测试限制为无 GC 身份的值。
/// 例如 `not result and observe()` 进入右侧时 result 必为 nil/false；
/// `result and observe()` 则可能仍需保活对象，不能套用这一许可。也不能用
/// `result == false` 作相同推断：LuaJIT cdata 的 __eq 可以对 primitive 返回 true。
/// 这只补充候选形状；相邻覆盖、同 home、唯一读取与捕获仍由共同事务验证。
fn root_is_inert_on_branch(expr: &HirExpr, root: TempId, truthy: bool) -> bool {
    match expr {
        HirExpr::TempRef(source) => *source == root && !truthy,
        HirExpr::Unary(unary) if unary.op == crate::hir::HirUnaryOpKind::Not => {
            root_is_inert_on_branch(&unary.expr, root, !truthy)
        }
        _ => false,
    }
}

/// 调用 materialization 与相邻依赖链共享纯 producer 验证和一次 DAG 提交。
/// 依赖方向、连续性和消费站点由各自入口证明；repeatable 排除调用、查找和分配，
/// 但不表示来源 binding 不可变。capture 与求值前缀证明仍负责快照读取时点。
struct PureInlineContext<'a> {
    scratch: &'a mut TempUseScratch,
    live_use_counts: &'a mut [usize],
    facts: &'a ProtoPromotionFacts,
    captured_slots_before_stmt: &'a CapturedSlotSnapshots,
    readability: ReadabilityOptions,
    safety: HirExprSafety,
}

impl PureInlineContext<'_> {
    fn candidate_is_safe(&self, temp: TempId, value: &HirExpr, index: usize) -> bool {
        // 候选拒绝[SemanticBarrier:Lifetime]：额外 use 仍需原 producer 的值。
        // 候选拒绝[SemanticBarrier:EvalOrder]：批量路径只合并 repeatable 值。
        // 候选拒绝[PolicyBoundary]：原 producer 继续服从固定 nested 复杂度上限。
        // capture、debug 与自更新身份由同一 materialization guard 判定。
        total_use_count(temp, self.live_use_counts) == 1
            && self.safety.is_repeatable(value)
            && InlineSite::Nested.allows(value, self.readability, self.safety)
            && materialization_run_candidate_is_safe(
                temp,
                value,
                index,
                self.scratch,
                self.facts,
                self.captured_slots_before_stmt,
            )
    }

    fn commit(&mut self, sink: &mut HirStmt, replacements: &BTreeMap<TempId, HirExpr>) {
        assert_ne!(
            replace_temps_in_stmt(sink, replacements),
            0,
            "proven pure materialization must reach its sink"
        );
        let mut remaining = false;
        collect_stmt_temp_uses(sink, self.scratch).for_each(|temp, _| {
            remaining |= replacements.contains_key(&temp);
        });
        assert!(
            !remaining,
            "acyclic materialization substitution must consume every run temp"
        );
        for &temp in replacements.keys() {
            remove_live_use(self.live_use_counts, temp);
        }
    }
}

fn occupies_branch_call_prefix(
    temp: TempId,
    value: &HirExpr,
    sink: &HirStmt,
    facts: &ProtoPromotionFacts,
) -> bool {
    let (HirExpr::Call(call), HirStmt::If(branch)) = (value, sink) else {
        return false;
    };
    fn reads_predicate_input(condition: &HirExpr, temp: TempId) -> bool {
        match condition {
            HirExpr::LogicalAnd(logical) | HirExpr::LogicalOr(logical) => {
                reads_predicate_input(&logical.lhs, temp)
                    || reads_predicate_input(&logical.rhs, temp)
            }
            HirExpr::Unary(unary) if unary.op == crate::hir::HirUnaryOpKind::Not => {
                reads_predicate_input(&unary.expr, temp)
            }
            _ => matches!(comparison_operand(condition).unwrap_or(condition),
                HirExpr::TempRef(input) if *input == temp),
        }
    }
    // 已先求值的结果也可能位于短路树的后继测试；树化条件不结束其原前缀身份。
    if !reads_predicate_input(&branch.cond, temp) || facts.fixed_call_result(call, 0) != Some(temp)
    {
        return false;
    }
    let Some(home) = facts.trusted_temp_home_slot(temp) else {
        return false;
    };
    super::source_frames::branch_entry_requires_prefix(branch, home, facts)
}

fn occupies_unary_input_prefix(
    temp: TempId,
    value: &HirExpr,
    sink: &HirStmt,
    facts: &ProtoPromotionFacts,
) -> bool {
    let HirExpr::Call(call) = value else {
        return false;
    };
    let Some((_, HirExpr::Unary(unary))) = sink.scalar_temp_assignment() else {
        return false;
    };
    matches!(unary.expr, HirExpr::TempRef(input) if input == temp)
        && facts
            .unary_operand_home(unary)
            .zip(facts.unary_result_home(unary))
            .is_some_and(|(input, output)| {
                input.slot() < output.slot()
                    && facts.trusted_temp_home_slot(temp) == Some(input)
                    && call
                        .source_site
                        .and_then(|source| facts.operation_result_home(source))
                        == Some(input)
            })
}

/// callee/参数 COPY 可先被逆向扫描收回；调用槽下方的原闭包仍属于声明前缀。
fn occupies_closure_call_prefix(
    temp: TempId,
    value: &HirExpr,
    sink: &HirStmt,
    facts: &ProtoPromotionFacts,
) -> bool {
    if !matches!(value, HirExpr::Closure(_)) {
        return false;
    }
    let call = match sink {
        HirStmt::CallStmt(stmt) => Some(&stmt.call),
        stmt => {
            let values = match stmt {
                HirStmt::Assign(assign) => &assign.values,
                HirStmt::LocalDecl(decl) => &decl.values,
                HirStmt::Return(ret) => &ret.values,
                _ => return false,
            };
            match (values.fixed.as_slice(), &values.tail) {
                ([HirExpr::Call(call)], None) => Some(call.as_ref()),
                ([], Some(tail)) => match tail.as_expr() {
                    HirExpr::Call(call) => Some(call.as_ref()),
                    _ => None,
                },
                _ => None,
            }
        }
    };
    call.is_some_and(|call| {
        facts
            .trusted_temp_home_slot(temp)
            .zip(facts.native_call_layout(call))
            .is_some_and(|(home, frame)| home.slot() < frame.home.slot())
    })
}

fn occupies_scalar_call_prefix(
    temp: TempId,
    value: &HirExpr,
    sink: &HirStmt,
    facts: &ProtoPromotionFacts,
) -> bool {
    if !matches!(
        value,
        HirExpr::Nil | HirExpr::Boolean(_) | HirExpr::Integer(_) | HirExpr::Number(_)
    ) {
        // 可收集值与带求值事件的 producer 仍消费已有 root/求值顺序证明；
        // 此处只延期此前因值稳定而直接删除的标量声明前缀。
        return false;
    }
    let HirStmt::CallStmt(stmt) = sink else {
        return false;
    };
    facts
        .trusted_temp_home_slot(temp)
        .zip(facts.native_call_layout(&stmt.call))
        .is_some_and(|(home, frame)| home.slot() < frame.home.slot())
}

/// 一个读取叶与常量组成的纯表达式没有需再次物化的 sibling 快照；返回继续追溯的 Temp。
/// 多读取分支需要展开后的前缀事实，仍交给原逐站点路径，不能用 repeatable 猜测。
fn single_pure_dependency(value: &HirExpr) -> Option<Option<TempId>> {
    let mut binding = None;
    let multiple = crate::hir::visit::any_expr(value, &mut |expr| {
        let Some(current) = HirBinding::from_expr(expr) else {
            return false;
        };
        binding.replace(current).is_some()
    });
    (!multiple).then_some(match binding {
        Some(HirBinding::Temp(temp)) => Some(temp),
        _ => None,
    })
}

#[expect(
    clippy::too_many_arguments,
    reason = "候选、原坐标根快照和可变 callee 顺序分别由相邻 owner 持有"
)]
// t0=not p; t1=not t0; box.x=t1 可沿唯一读取叶一次展开为 box.x=not not p。
// 保留原站点和 callee 物化位置传播证明，避免每展开一层就重扫增长中的 sink。
fn inline_pure_dependency_chain(
    sink: &mut HirStmt,
    first: (usize, &HirStmt, InlineSite),
    earlier: &mut std::iter::Peekable<impl Iterator<Item = (usize, HirStmt)>>,
    context: &mut PureInlineContext<'_>,
    physical_root_lifetimes: &[bool],
    physical_root_temps: &[bool],
    reference_captured: &ReferenceCapturedBindings,
    callee_materialized_at: &mut Option<usize>,
) -> bool {
    let (first_index, first_stmt, mut site) = first;
    let (mut expected, first_value) = first_stmt
        .scalar_temp_assignment()
        .expect("adjacent scalar producer");
    let mut first = Some((first_index, first_stmt));
    let mut replacements = BTreeMap::new();
    let mut callee = *callee_materialized_at;
    let mut budget = matches!(first_value, HirExpr::Unary(_)).then(|| inline_syntax_budget(sink));
    loop {
        let from_iterator = first.is_none();
        let Some((index, stmt)) =
            first.or_else(|| earlier.peek().map(|(index, stmt)| (*index, stmt)))
        else {
            break;
        };
        let Some((temp, value)) = stmt.scalar_temp_assignment() else {
            break;
        };
        if temp != expected
            || replacements.contains_key(&temp)
            || physical_root_lifetimes[index]
            || physical_root_temps
                .get(temp.index())
                .copied()
                .unwrap_or(false)
            || matches!(
                site,
                InlineSite::ConditionalNested
                    | InlineSite::RepeatedNested
                    | InlineSite::LoopCondition
                    | InlineSite::LoopHead
                    | InlineSite::PrefixedBlock
            )
            || !context.candidate_is_safe(temp, value, index)
            || occupies_scalar_call_prefix(temp, value, sink, context.facts)
            || occupies_closure_call_prefix(temp, value, sink, context.facts)
            || !site.allows(value, context.readability, context.safety)
            || call_arg_inline_crosses_materialized_callee(site, value, index, callee)
        {
            // 候选拒绝[LayerBoundary]：连续批处理在原根、身份、执行区域或求值顺序边界停止。
            break;
        }
        let Some(dependency) = single_pure_dependency(value) else {
            // 候选拒绝[ProofIncomplete]：多读取分支需要展开后的 sibling 前缀，仍由逐站点路径证明。
            break;
        };
        // 先核对原 producer 的小表达式，再扫描可能很大的 sink。非 repeatable 的
        // 算术链不会进入批量路径，不能每折叠一层又为必然拒绝的候选重扫整条链。
        if first.is_some()
            && !temp_precedes_observable_eval_in_stmt(sink, expected, true, reference_captured)
        {
            // 候选拒绝[SemanticBarrier:EvalOrder]：来源快照不能越过 sink 的事件或先前可变读取。
            return false;
        }
        if let Some(remaining) = budget {
            let Some(remaining) = spend_inline_syntax_budget(value, remaining) else {
                // 候选拒绝[TargetConstraint:SyntaxDepth]：每个一元 producer 单独很小，
                // 但展开总和仍可能超过解析嵌套上限；保留边界赋值，不删除原运算。
                break;
            };
            budget = Some(remaining);
        }
        if dependency.is_some_and(|temp| replacements.contains_key(&temp)) {
            // 候选拒绝[SemanticBarrier:ValueFlow]：向后依赖已选 producer 会形成不同 epoch 或环。
            break;
        }
        let next = dependency.and_then(|dependency| {
            temp_precedes_observable_eval_in_expr(value, dependency, true, reference_captured)
                .then(|| {
                    inline_dependency_site(value, dependency, site).map(|site| (dependency, site))
                })
                .flatten()
        });
        replacements.insert(temp, value.clone());
        if site.is_call_callee() {
            callee = Some(index);
        }
        if from_iterator {
            earlier.next();
        } else {
            first = None;
        }
        let Some((dependency, next_site)) = next else {
            break;
        };
        expected = dependency;
        site = next_site;
    }
    if replacements.len() < 2 {
        return false;
    }
    context.commit(sink, &replacements);
    *callee_materialized_at = callee;
    true
}

// PUC 的语法递归上限约为 200；为外围调用、控制结构和源码投影留出余量。
// 只约束一元链的拼接；左结合算术的长度不等于解析递归深度。
// 节点预算保守覆盖一元嵌套，每次查询最多访问固定数量节点。
const INLINE_SYNTAX_NODE_BUDGET: usize = 128;

struct InlineSyntaxBudget(usize);

impl HirVisitor<'_> for InlineSyntaxBudget {
    fn is_complete(&self) -> bool {
        self.0 == 0
    }

    fn visit_expr(&mut self, _expr: &HirExpr) {
        self.0 -= 1;
    }
}

fn inline_syntax_budget(sink: &HirStmt) -> usize {
    let mut budget = InlineSyntaxBudget(INLINE_SYNTAX_NODE_BUDGET);
    crate::hir::visit::visit_stmt_header(sink, &mut budget);
    budget.0
}

fn spend_inline_syntax_budget(value: &HirExpr, remaining: usize) -> Option<usize> {
    // 代换移除一个 TempRef 叶子；至少留一格，区分刚好到界与提前终止遍历。
    let mut budget = InlineSyntaxBudget(remaining + 1);
    visit_expr(value, &mut budget);
    (budget.0 != 0).then_some(budget.0)
}

fn inline_expansion_budget(sink: &HirStmt, value: &HirExpr) -> Option<usize> {
    if matches!(value, HirExpr::Unary(_)) {
        spend_inline_syntax_budget(value, inline_syntax_budget(sink))
    } else {
        Some(INLINE_SYNTAX_NODE_BUDGET)
    }
}

#[derive(Clone, Copy)]
enum EagerConditionCallCallee {
    Temp(TempId),
    Other,
}

fn first_eager_condition_call_callee(expr: &HirExpr) -> Option<EagerConditionCallCallee> {
    match expr {
        HirExpr::Call(call) => Some(match &call.callee {
            HirExpr::TempRef(temp) => EagerConditionCallCallee::Temp(*temp),
            _ => EagerConditionCallCallee::Other,
        }),
        HirExpr::Unary(unary) => first_eager_condition_call_callee(&unary.expr),
        HirExpr::Binary(binary) => first_eager_condition_call_callee(&binary.lhs)
            .or_else(|| first_eager_condition_call_callee(&binary.rhs)),
        HirExpr::LogicalAnd(logical) | HirExpr::LogicalOr(logical) => {
            // The RHS is conditional. A producer evaluated before the If cannot move there.
            first_eager_condition_call_callee(&logical.lhs)
        }
        HirExpr::TableAccess(access) => first_eager_condition_call_callee(&access.base)
            .or_else(|| first_eager_condition_call_callee(&access.key)),
        HirExpr::Nil
        | HirExpr::Boolean(_)
        | HirExpr::Integer(_)
        | HirExpr::Number(_)
        | HirExpr::String(_)
        | HirExpr::Int64(_)
        | HirExpr::UInt64(_)
        | HirExpr::Vector(_)
        | HirExpr::Complex { .. }
        | HirExpr::ParamRef(_)
        | HirExpr::TempRef(_)
        | HirExpr::LocalRef(_)
        | HirExpr::UpvalueRef(_)
        | HirExpr::GlobalRef(_)
        | HirExpr::CaptureInitializer(_)
        | HirExpr::VarArg
        | HirExpr::Decision(_)
        | HirExpr::TableConstructor(_)
        | HirExpr::Closure(_)
        | HirExpr::Unresolved(_) => None,
    }
}

fn condition_materialization_value_is_supported(expr: &HirExpr) -> bool {
    match expr {
        HirExpr::Nil
        | HirExpr::Boolean(_)
        | HirExpr::Integer(_)
        | HirExpr::Number(_)
        | HirExpr::String(_)
        | HirExpr::Int64(_)
        | HirExpr::UInt64(_)
        | HirExpr::Vector(_)
        | HirExpr::Complex { .. }
        | HirExpr::ParamRef(_)
        | HirExpr::TempRef(_)
        | HirExpr::LocalRef(_)
        | HirExpr::UpvalueRef(_)
        | HirExpr::GlobalRef(_) => true,
        HirExpr::TableAccess(access) => {
            condition_materialization_value_is_supported(&access.base)
                && condition_materialization_value_is_supported(&access.key)
        }
        HirExpr::Unary(unary) => condition_materialization_value_is_supported(&unary.expr),
        HirExpr::Binary(binary) => {
            condition_materialization_value_is_supported(&binary.lhs)
                && condition_materialization_value_is_supported(&binary.rhs)
        }
        HirExpr::LogicalAnd(_)
        | HirExpr::LogicalOr(_)
        | HirExpr::Call(_)
        | HirExpr::Decision(_)
        | HirExpr::TableConstructor(_)
        | HirExpr::Closure(_)
        | HirExpr::CaptureInitializer(_)
        | HirExpr::VarArg
        | HirExpr::Unresolved(_) => false,
    }
}

struct EagerConditionMaterializationProof<'a> {
    scratch: &'a mut TempUseScratch,
    live_use_counts: &'a mut [usize],
    facts: &'a ProtoPromotionFacts,
    captured_slots_before_stmt: &'a CapturedSlotSnapshots,
    order_sensitive_defs: &'a OrderSensitiveDefWorkspace,
    reference_captured: &'a ReferenceCapturedBindings,
    dialect: DecompileDialect,
    safety: HirExprSafety,
}

// If 只吸收首个必达 call 的完整 eager 依赖闭包；短路 RHS 未必执行，
// 不能把原先无条件求值的 producer 移入其中。
fn inline_eager_condition_materialization_run(
    block: &mut HirBlock,
    run_start: usize,
    run_end: usize,
    physical_root_lifetimes: &[bool],
    proof: &mut EagerConditionMaterializationProof<'_>,
    removed_stmts: &mut [bool],
) -> bool {
    let Some(HirStmt::If(if_stmt)) = block.stmts.get(run_end) else {
        return false;
    };
    let Some(EagerConditionCallCallee::Temp(callee_temp)) =
        first_eager_condition_call_callee(&if_stmt.cond)
    else {
        return false;
    };
    if physical_root_lifetimes[run_start..run_end]
        .iter()
        .any(|preserve| *preserve)
    {
        // A real VM root cannot be consumed merely because the same value reaches a condition.
        return false;
    }

    let mut positions = BTreeMap::new();
    for index in run_start..run_end {
        let Some((temp, value)) = block.stmts[index].scalar_temp_assignment() else {
            return false;
        };
        if !condition_materialization_value_is_supported(value)
            || positions.insert(temp, index).is_some()
        {
            return false;
        }
    }
    if !positions.contains_key(&callee_temp) {
        return false;
    }

    for (&temp, &position) in &positions {
        let (_, value) = block.stmts[position]
            .scalar_temp_assignment()
            .expect("condition materialization position must retain its scalar definition");
        let mut dependencies_precede = true;
        collect_expr_temp_uses_summary(value, proof.scratch).for_each(|dependency, _| {
            if positions
                .get(&dependency)
                .is_some_and(|dependency_position| *dependency_position >= position)
            {
                dependencies_precede = false;
            }
        });
        if !dependencies_precede || total_use_count(temp, proof.live_use_counts) != 1 {
            return false;
        }
    }

    let mut rewritten_sink = block.stmts[run_end].clone();
    let mut removed_temps = Vec::with_capacity(run_end - run_start);
    for index in (run_start..run_end).rev() {
        let (temp, value) = block.stmts[index]
            .scalar_temp_assignment()
            .expect("condition materialization run must retain scalar definitions");
        if collect_stmt_temp_uses(&rewritten_sink, proof.scratch).count(temp) != 1 {
            // Every producer must belong to the dependency closure of the eager call. This also
            // rejects unrelated dead assignments instead of absorbing dead-temps responsibility.
            return false;
        }
        let Some(site) = inline_site_in_stmt(&rewritten_sink, temp) else {
            return false;
        };
        if matches!(
            site,
            InlineSite::ConditionalNested
                | InlineSite::RepeatedNested
                | InlineSite::LoopCondition
                | InlineSite::LoopHead
                | InlineSite::PrefixedBlock
        ) || !materialization_run_candidate_is_safe(
            temp,
            value,
            index,
            proof.scratch,
            proof.facts,
            proof.captured_slots_before_stmt,
        ) || !prefixed_block_candidate_is_safe(
            site,
            temp,
            value,
            proof.reference_captured,
            proof.safety,
        ) || arg_value_forwards_prior_order_sensitive_expr(
            value,
            run_start,
            proof.order_sensitive_defs,
        ) || inline_crosses_evaluation_boundary(
            site,
            value,
            &rewritten_sink,
            temp,
            proof.reference_captured,
            proof.dialect,
            proof.safety,
        ) {
            return false;
        }
        replace_temp_in_stmt(&mut rewritten_sink, temp, value);
        removed_temps.push(temp);
    }

    block.stmts[run_end] = rewritten_sink;
    removed_stmts[run_start..run_end].fill(true);
    for temp in removed_temps {
        remove_live_use(proof.live_use_counts, temp);
    }
    true
}

fn inline_pure_materialization_run(
    block: &mut HirBlock,
    run_start: usize,
    run_end: usize,
    callee_index: usize,
    callee_temp: TempId,
    context: &mut PureInlineContext<'_>,
    order_sensitive_defs: &OrderSensitiveDefWorkspace,
) -> bool {
    if callee_index != run_start || run_end <= run_start {
        return false;
    }

    let mut replacements = BTreeMap::new();
    let mut positions = BTreeMap::new();
    for index in run_start..run_end {
        let Some((temp, value)) = block.stmts[index].scalar_temp_assignment() else {
            return false;
        };
        if !context.candidate_is_safe(temp, value, index)
            || arg_value_forwards_prior_order_sensitive_expr(value, run_start, order_sensitive_defs)
        {
            return false;
        }
        // Pure substitution 以 temp 为 DAG 节点；同一 canonical temp 的多个 def 属于
        // 不同 epoch，不能让 map insertion 静默覆盖，留给后面的逐项路径处理。
        if positions.insert(temp, index).is_some() {
            return false;
        }
        replacements.insert(temp, value.clone());
    }

    // Every candidate must be on the dependency path that reaches the sink.  This
    // avoids deleting a dead assignment merely because its value happens to be pure.
    let mut needed = BTreeSet::new();
    collect_stmt_temp_uses(&block.stmts[run_end], context.scratch).for_each(|temp, _| {
        needed.insert(temp);
    });
    let mut pending = needed.iter().copied().collect::<Vec<_>>();
    while let Some(temp) = pending.pop() {
        let Some(value) = replacements.get(&temp) else {
            continue;
        };
        collect_expr_temp_uses_summary(value, context.scratch).for_each(|dependency, _| {
            if needed.insert(dependency) {
                pending.push(dependency);
            }
        });
    }
    if positions.keys().any(|temp| !needed.contains(temp)) {
        // 候选拒绝[LayerBoundary]：不在 sink 依赖闭包内的是 dead assignment，由 dead-temps owner 处理。
        return false;
    }

    // A candidate may only depend on an earlier assignment.  Reject forward edges
    // explicitly so the map cannot contain a cycle or change source evaluation order.
    for (&temp, value) in &replacements {
        let Some(&position) = positions.get(&temp) else {
            continue;
        };
        let mut valid = true;
        collect_expr_temp_uses_summary(value, context.scratch).for_each(|dependency, _| {
            if positions
                .get(&dependency)
                .is_some_and(|dependency_position| *dependency_position >= position)
            {
                valid = false;
            }
        });
        if !valid {
            // 候选拒绝[SemanticBarrier:EvalOrder]：forward edge/cycle 会把依赖移动到其定义之前或改变求值拓扑。
            return false;
        }
    }

    assert!(
        replacements.contains_key(&callee_temp),
        "pure materialization map must contain its validated callee"
    );
    context.commit(&mut block.stmts[run_end], &replacements);
    true
}

fn inline_materialization_runs(
    block: &mut HirBlock,
    workspace: &mut TempInlineWorkspace<'_>,
    live_use_counts: &mut [usize],
    facts: &ProtoPromotionFacts,
    captured_slots_before_stmt: &CapturedSlotSnapshots,
    captures: &TempInlineCaptureFacts<'_>,
    physical_root_lifetimes: &[bool],
) -> bool {
    let reference_captured = captures.bindings;
    // child block 已全部处理完才会到这里，因此同一个 proto 级 workspace 不会覆盖
    // 仍在活跃递归 frame 中的 parent 索引。
    let TempInlineWorkspace {
        uses,
        order_sensitive_defs,
        scope,
        dialect,
        safety,
        readability,
        ..
    } = workspace;
    order_sensitive_defs.rebuild(&block.stmts);
    let reference_captured_home_slots = &captures.homes;
    let mut removed_stmts = vec![false; block.stmts.len()];
    let mut changed = false;
    let mut index = 0;

    while index < block.stmts.len() {
        if block.stmts[index].scalar_temp_assignment().is_none() {
            index += 1;
            continue;
        }
        let run_start = index;
        let mut run_end = run_start + 1;
        while run_end < block.stmts.len() && block.stmts[run_end].scalar_temp_assignment().is_some()
        {
            run_end += 1;
        }
        if matches!(scope, TempInlineScope::All)
            && inline_eager_condition_materialization_run(
                block,
                run_start,
                run_end,
                physical_root_lifetimes,
                &mut EagerConditionMaterializationProof {
                    scratch: uses,
                    live_use_counts,
                    facts,
                    captured_slots_before_stmt,
                    order_sensitive_defs,
                    reference_captured,
                    dialect: *dialect,
                    safety: *safety,
                },
                &mut removed_stmts,
            )
        {
            changed = true;
            index = run_end + 1;
            continue;
        }
        if physical_root_lifetimes[run_start..run_end]
            .iter()
            .any(|preserve| *preserve)
        {
            // 候选拒绝[SemanticBarrier:Lifetime]：run 内仍有 call/lookup result 充当显式 GC 或后续写前的 VM root，不能整段删除（regress_356）。
            index = run_end;
            continue;
        }
        if scope.allows_open_return()
            && inline_open_return_fixed_alias_run(
                block,
                run_start..run_end,
                live_use_counts,
                OpenReturnFixedAliasProof {
                    scratch: uses,
                    facts,
                    captured_slots_before_stmt,
                    reference_captured_home_slots,
                },
                &mut removed_stmts,
            )
        {
            changed = true;
            index = run_end + 1;
            continue;
        }
        if inline_numeric_for_stable_header_aliases(
            block,
            run_start..run_end,
            live_use_counts,
            NumericForHeaderProof {
                scratch: uses,
                facts,
                safety: *safety,
                reference_captured,
                captured_slots_before_stmt,
                reference_captured_home_slots,
            },
            &mut removed_stmts,
        ) {
            changed = true;
            index = run_end + 1;
            continue;
        }
        let Some(HirStmt::CallStmt(call_stmt)) = block.stmts.get(run_end) else {
            index = run_end;
            continue;
        };
        let HirExpr::TempRef(callee_temp) = call_stmt.call.callee else {
            index = run_end + 1;
            continue;
        };
        // 同一 canonical temp 可能由 loop-state coalescing 产生多个 def；直接调用读取的
        // 是 run 内最后一次写入，较早 producer 不属于本次融合事务。
        let Some(callee_index) = (run_start..run_end).rfind(|candidate_index| {
            block.stmts[*candidate_index]
                .scalar_temp_assignment()
                .is_some_and(|(candidate, _)| candidate == callee_temp)
        }) else {
            index = run_end + 1;
            continue;
        };
        let Some((_, callee_value)) = block.stmts[callee_index].scalar_temp_assignment() else {
            index = run_end + 1;
            continue;
        };
        let callee_value = callee_value.clone();
        let terminal_candidate = block.stmts[..run_end]
            .last()
            .and_then(HirStmt::scalar_temp_assignment)
            .map(|(temp, _)| temp);
        if !scope.allows_call(
            call_stmt,
            &callee_value,
            terminal_candidate,
            &block.stmts[run_end],
        ) {
            // 候选拒绝[LayerBoundary]：branch-value 定向轮次仅接管 root global call + terminal exposed sink，其余留给完整 temp-inline。
            index = run_end + 1;
            continue;
        }
        if !materialization_run_candidate_is_safe(
            callee_temp,
            &callee_value,
            callee_index,
            uses,
            facts,
            captured_slots_before_stmt,
        ) || total_use_count(callee_temp, live_use_counts) != 1
        {
            // 候选拒绝[SemanticBarrier:Capture]：callee home 被引用捕获或 producer 自引用时，删写会改变 closure/状态所见值。
            // 候选拒绝[PolicyBoundary]：DebugScope 标注的 callee 保留独立源码 binding 身份。
            // 候选拒绝[SemanticBarrier:Lifetime]：callee 存在额外消费时不能随本 call 一并删除。
            index = run_end + 1;
            continue;
        }

        // A long forwarding run can be represented as a substitution DAG.  Validate
        // the complete pure alias chain once, then rewrite the sink in one traversal;
        // this keeps generated source readable without imposing an arbitrary run-size
        // cutoff.  Runs containing observable expressions continue through the precise
        // per-site proof below.
        let mut pure_context = PureInlineContext {
            scratch: uses,
            live_use_counts,
            facts,
            captured_slots_before_stmt,
            readability: *readability,
            safety: *safety,
        };
        if inline_pure_materialization_run(
            block,
            run_start,
            run_end,
            callee_index,
            callee_temp,
            &mut pure_context,
            order_sensitive_defs,
        ) {
            removed_stmts[run_start..run_end].fill(true);
            changed = true;
            index = run_end + 1;
            continue;
        }

        let mut rewritten_sink = block.stmts[run_end].clone();
        let mut removed_temps = Vec::with_capacity(run_end - callee_index);
        let mut discarded_uses = Vec::new();
        let mut duplicated_uses = Vec::new();
        let trailing = &block.stmts[run_end + 1..];
        let sink_is_terminal = trailing.is_empty()
            || matches!(trailing, [HirStmt::Return(ret)]
                if ret.values.fixed.is_empty() && ret.values.tail.is_none());
        let materialization_run = &block.stmts[callee_index..run_end];
        let mut method_receiver_pair_seen = false;
        let mut complete_run = true;
        for candidate_index in ((callee_index + 1)..run_end).rev() {
            let Some((temp, value)) = block.stmts[candidate_index].scalar_temp_assignment() else {
                complete_run = false;
                break;
            };
            let use_count = total_use_count(temp, live_use_counts);
            let forwarded_owner_survives = sink_is_terminal
                && materialization_run_preserves_forwarded_temp_owner(
                    materialization_run,
                    candidate_index - callee_index,
                    value,
                    facts,
                );
            let method_receiver_pair = use_count == 2
                && sink_is_terminal
                && (!matches!(value, HirExpr::TempRef(_)) || forwarded_owner_survives)
                && is_bare_method_receiver_snapshot_in_stmt(&rewritten_sink, temp, value);
            let stable_method_run_alias =
                forwarded_owner_survives && (method_receiver_pair || method_receiver_pair_seen);
            // 候选拒绝[SemanticBarrier:Lifetime]：除 method 协议的同次 receiver 求值外，多 use 仍需原 temp 值。
            if use_count > 1 && !method_receiver_pair {
                complete_run = false;
                break;
            }
            let candidate_is_safe = materialization_run_candidate_is_safe(
                temp,
                value,
                candidate_index,
                uses,
                facts,
                captured_slots_before_stmt,
            );
            if set_list_needs_lookup_frame(&rewritten_sink, temp, value) {
                // LayerBoundary：整批构造器尚未接管前，保留 GETTABLE 的原结果写。
                complete_run = false;
                break;
            }
            if matches!(value, HirExpr::Call(_))
                && stmt_stores_temp_in_table(&rewritten_sink, temp)
                && !call_result_can_enter_set_list(temp, &rewritten_sink, uses, facts)
            {
                // 候选拒绝[SemanticBarrier:Lifetime]：call result 写表前由 temp 保持存活，删除会改变 VM root 生命周期。
                complete_run = false;
                break;
            }
            // 无读的 copy 仍可持有独立 VM root。Promotion 已证明其终点时，完整
            // 保活/覆盖事务属于 dead-temps；Normal run 不能在该 owner 执行前删掉
            // producer（regress_419），经随后将删除的依赖间接变成零 use 也相同。
            let candidate_can_be_discarded = candidate_is_safe
                && safety.is_discard_safe(value)
                && (safety.result_is_gc_inert(value)
                    || (!facts.is_scope_end_copy_root_temp(temp)
                        && facts.copy_root_overwrites(temp).is_none()));
            if use_count == 0 {
                if candidate_can_be_discarded {
                    discarded_uses.push(collect_expr_temp_uses_summary(value, uses));
                    continue;
                }
                // 候选拒绝[SemanticBarrier:EvalOrder]：零 use 但不可安全丢弃的 call/lookup/allocation 仍是原序列中的可观察事件。
                // 候选拒绝[SemanticBarrier:Capture]：被捕获/self-rebinding 的零 use 写也不能由 run 删除。
                // 候选拒绝[PolicyBoundary]：DebugScope 标注的零 use temp 仍保留源码 binding 身份。
                complete_run = false;
                break;
            }
            let Some(site) = inline_site_in_stmt(&rewritten_sink, temp) else {
                if collect_stmt_temp_uses(&rewritten_sink, uses).count(temp) == 0 {
                    let planned_discard_use_count = discarded_uses
                        .iter()
                        .map(|discarded: &TempUseSummary| discarded.count(temp))
                        .sum::<usize>();
                    if planned_discard_use_count == use_count && candidate_can_be_discarded {
                        // 逆序扫描已经证明该 temp 的全部 use 都位于随后将删除的纯表达式中；
                        // 把当前 value 的依赖继续并入 discard delta，整段提交时统一扣除。
                        discarded_uses.push(collect_expr_temp_uses_summary(value, uses));
                        continue;
                    }
                    // 候选拒绝[SemanticBarrier:Lifetime]：至少一份 live use 位于本次 sink/计划删除集之外，
                    // 删除 producer 会让该 use 失去原值。
                    // 候选拒绝[SemanticBarrier:EvalOrder]：即使唯一 use 位于计划删除集，带事件的 value 也不能随之丢弃。
                    // 候选拒绝[SemanticBarrier:Capture]：被捕获/self-rebinding 的 producer 不能作为纯依赖删除。
                    // 候选拒绝[PolicyBoundary]：DebugScope 标注的 temp 保留源码 binding 身份。
                    complete_run = false;
                    break;
                }
                // sink 内 use 的 Closure capture 等明确边界由 site classifier 标记。
                complete_run = false;
                break;
            };
            if !candidate_is_safe
                || !prefixed_block_candidate_is_safe(site, temp, value, reference_captured, *safety)
                || (!stable_method_run_alias
                    && arg_value_forwards_prior_order_sensitive_expr(
                        value,
                        callee_index,
                        order_sensitive_defs,
                    ))
                || (!stable_method_run_alias
                    && inline_crosses_evaluation_boundary(
                        site,
                        value,
                        &rewritten_sink,
                        temp,
                        reference_captured,
                        *dialect,
                        *safety,
                    ))
            {
                // 候选拒绝[SemanticBarrier:Capture]：candidate home capture/self-rebind 会改变 closure 或状态所见值。
                // 候选拒绝[PolicyBoundary]：DebugScope 标注的 candidate 保留源码 binding 身份。
                // 候选拒绝[SemanticBarrier:EvalOrder]：参数转发更早的 order-sensitive def，或 sink 前缀含 observable eval，移动会重排事件。
                complete_run = false;
                break;
            }
            replace_temp_in_stmt(&mut rewritten_sink, temp, value);
            removed_temps.push(temp);
            if method_receiver_pair {
                // 原赋值已经持有 replacement 的一份 use；method lowering 把两处 HIR
                // 引用收成一次源码求值，因此替换后只新增一份活跃依赖。
                duplicated_uses.push(collect_expr_temp_uses_summary(value, uses));
                removed_temps.push(temp);
                method_receiver_pair_seen = true;
            }
        }
        if !complete_run {
            index = run_end + 1;
            continue;
        }
        let callee_site = inline_site_in_stmt(&rewritten_sink, callee_temp)
            .expect("non-callee substitutions must preserve the direct call callee");
        assert!(
            callee_site.is_call_callee(),
            "materialization run callee must remain in the direct call position"
        );
        if inline_crosses_evaluation_boundary(
            callee_site,
            &callee_value,
            &rewritten_sink,
            callee_temp,
            reference_captured,
            *dialect,
            *safety,
        ) {
            // 候选拒绝[SemanticBarrier:EvalOrder]：callee 前有可观察事件时，内联会把其求值延后。
            index = run_end + 1;
            continue;
        }
        replace_temp_in_stmt(&mut rewritten_sink, callee_temp, &callee_value);
        removed_temps.push(callee_temp);

        block.stmts[run_end] = rewritten_sink;
        removed_stmts[callee_index..run_end].fill(true);
        remove_live_use(live_use_counts, callee_temp);
        for temp in removed_temps
            .into_iter()
            .filter(|temp| *temp != callee_temp)
        {
            remove_live_use(live_use_counts, temp);
        }
        for uses in discarded_uses {
            uses.subtract_from_totals(live_use_counts);
        }
        for uses in duplicated_uses {
            uses.add_to_totals(live_use_counts);
        }
        changed = true;
        // 语句仍保留原索引，后续 run 可以继续复用进入本函数前冻结的 capture 与
        // order-sensitive def 快照；压缩只能在整次扫描结束后统一发生。
        index = run_end + 1;
    }

    if changed {
        let mut index = 0;
        block.stmts.retain(|_| {
            let keep = !removed_stmts[index];
            index += 1;
            keep
        });
    }
    changed
}

fn materialization_run_preserves_forwarded_temp_owner(
    run: &[HirStmt],
    candidate_offset: usize,
    value: &HirExpr,
    facts: &ProtoPromotionFacts,
) -> bool {
    let HirExpr::TempRef(owner) = value else {
        return false;
    };
    let Some(owner_home) = facts.trusted_temp_home_slot(*owner) else {
        return false;
    };

    run.iter().enumerate().all(|(offset, stmt)| {
        if offset == candidate_offset {
            return true;
        }
        let Some((target, _)) = stmt.scalar_temp_assignment() else {
            return false;
        };
        facts
            .trusted_temp_home_slot(target)
            .is_some_and(|home| home != owner_home)
            && facts
                .trusted_immediate_move_write_homes(target)
                .is_some_and(|homes| !homes.contains(&owner_home))
    })
}

struct RootOpenReturnNilPackPlan {
    assignment_index: usize,
    fixed_start: usize,
    targets: Vec<TempId>,
}

fn inline_root_open_return_nil_pack(
    block: &mut HirBlock,
    scratch: &TempUseScratch,
    live_use_counts: &mut [usize],
    facts: &ProtoPromotionFacts,
    captured_slots_before_stmt: &CapturedSlotSnapshots,
    physical_root_lifetimes: &[bool],
) -> bool {
    let Some(plan) = root_open_return_nil_pack_plan(
        block,
        scratch,
        live_use_counts,
        facts,
        captured_slots_before_stmt,
        physical_root_lifetimes,
    ) else {
        return false;
    };

    let return_index = block.stmts.len() - 1;
    let HirStmt::Return(ret) = &mut block.stmts[return_index] else {
        unreachable!("validated terminal nil-pack sink must remain a return")
    };
    ret.values.fixed[plan.fixed_start..plan.fixed_start + plan.targets.len()].fill(HirExpr::Nil);
    for target in plan.targets {
        remove_live_use(live_use_counts, target);
    }
    block.stmts.remove(plan.assignment_index);
    true
}

fn root_open_return_nil_pack_plan(
    block: &HirBlock,
    scratch: &TempUseScratch,
    live_use_counts: &[usize],
    facts: &ProtoPromotionFacts,
    captured_slots_before_stmt: &CapturedSlotSnapshots,
    physical_root_lifetimes: &[bool],
) -> Option<RootOpenReturnNilPackPlan> {
    let return_index = block.stmts.len().checked_sub(1)?;
    let HirStmt::Return(ret) = &block.stmts[return_index] else {
        return None;
    };
    let tail = ret.values.tail.as_ref()?;
    if tail.exact_width().is_some() || !matches!(tail.as_expr(), HirExpr::Call(_)) {
        return None;
    }
    let captured_slots = captured_slots_before_stmt
        .get(return_index)
        .expect("capture snapshots must cover the root return");

    for assignment_index in (0..return_index).rev() {
        let HirStmt::Assign(assign) = &block.stmts[assignment_index] else {
            continue;
        };
        if assign.targets.len() < 2
            || assign.values.tail.is_some()
            || assign.values.fixed.len() != assign.targets.len()
            || !assign
                .values
                .fixed
                .iter()
                .all(|value| matches!(value, HirExpr::Nil))
        {
            continue;
        }
        if *physical_root_lifetimes
            .get(assignment_index)
            .expect("physical-root snapshots must cover the open-return nil-pack assignment")
        {
            // 候选拒绝[SemanticBarrier:Lifetime]：nil producer 终止了仍可被 tail call 的 GC 观察到的物理 root（regress_360）。
            continue;
        }
        let Some(targets) = assign
            .targets
            .iter()
            .map(|target| match target {
                HirLValue::Temp(temp) => Some(*temp),
                HirLValue::Param(_)
                | HirLValue::Local(_)
                | HirLValue::Upvalue(_)
                | HirLValue::Global(_)
                | HirLValue::TableAccess(_) => None,
            })
            .collect::<Option<Vec<_>>>()
        else {
            continue;
        };
        let fixed_start = ret.values.fixed.windows(targets.len()).position(|window| {
            window
                .iter()
                .zip(&targets)
                .all(|(value, target)| matches!(value, HirExpr::TempRef(temp) if temp == target))
        });
        let Some(fixed_start) = fixed_start else {
            continue;
        };

        let mut target_slots = BTreeSet::new();
        let mut non_entry_physical_read_protected_slots = BTreeSet::new();
        let mut targets_are_safe = true;
        let mut has_non_entry_physical_target = false;
        let mut all_physical_targets_have_exact_homes = true;
        for target in &targets {
            // 候选拒绝[SemanticBarrier:Lifetime]：额外 use 会继续观察原 nil 写入后的 temp。
            if total_use_count(*target, live_use_counts) != 1
                // 候选拒绝[PolicyBoundary]：DebugScope 标注的 temp 保留独立源码 binding 身份。
                || scratch.has_debug_local_hint(*target)
            {
                targets_are_safe = false;
                break;
            }
            let possible_homes = facts.complete_temp_home_slots(*target);
            // 候选拒绝[SemanticBarrier:Capture]：任一可能 target home 已被引用捕获时，
            // 删除 nil 写会让 closure 继续观察旧值。
            if possible_homes
                .iter()
                .any(|slot| captured_slots.contains(slot))
            {
                targets_are_safe = false;
                break;
            }
            let is_non_entry_physical =
                !facts.overwrites_entry_nil(*target) && !possible_homes.is_empty();
            has_non_entry_physical_target |= is_non_entry_physical;
            if is_non_entry_physical {
                non_entry_physical_read_protected_slots.extend(possible_homes.iter().copied());
            }
            all_physical_targets_have_exact_homes &=
                possible_homes.is_empty() || facts.trusted_temp_home_slot(*target).is_some();
            target_slots.extend(possible_homes.iter().copied());
        }
        if has_non_entry_physical_target && !all_physical_targets_have_exact_homes {
            // 候选拒绝[SemanticBarrier:Lifetime]：merged physical target 可沿不同路径落入
            // 不同 raw home；删除 nil 写会让实际 home 的旧资源继续跨 tail call/GC 存活，
            // 而单个静态 target 无法指认应结束的 root epoch。明确 home-free target 不参与。
            targets_are_safe = false;
        }
        if targets_are_safe {
            match root_open_return_remaining_read_relation(
                ret,
                fixed_start,
                targets.len(),
                &non_entry_physical_read_protected_slots,
                facts,
            ) {
                RootNilPackGapReadRelation::Disjoint => {}
                RootNilPackGapReadRelation::Overlap => {
                    // 候选拒绝[SemanticBarrier:ValueFlow]：return 的其它 fixed/tail 表达式若通过
                    // alias binding 读取 target home，删除 nil 写会让它读到此前 value。
                    targets_are_safe = false;
                }
            }
        }
        let protected_temps = targets.iter().copied().collect::<BTreeSet<_>>();
        let referenced_labels = count_label_references(&block.stmts)
            .into_keys()
            .collect::<BTreeSet<_>>();
        if !targets_are_safe
            || !block.stmts[assignment_index + 1..return_index]
                .iter()
                .all(|stmt| {
                    root_nil_pack_gap_preserves_slots_with_context(
                        stmt,
                        &protected_temps,
                        &target_slots,
                        &non_entry_physical_read_protected_slots,
                        &referenced_labels,
                        facts,
                    )
                })
        {
            continue;
        }

        return Some(RootOpenReturnNilPackPlan {
            assignment_index,
            fixed_start,
            targets,
        });
    }
    None
}

/// 收回紧邻终态 fixed return 前的并行 nil 写入。
///
/// 这条路径与 open-tail 的 root handoff 分开：return 本身仍在原 statement 位置产生
/// 同样宽度的 nil pack，因而没有把 nil 跨过 call/lookup 或其它求值事件。只有临时槽、
/// 未失效的 home、无 debug/capture 且每个目标只有唯一 return 读取时才成立；带 tail 的
/// return、局部/参数目标和任何不可信 home 继续保留原始并行写。
fn inline_terminal_nil_return_pack(
    block: &mut HirBlock,
    scratch: &TempUseScratch,
    live_use_counts: &mut [usize],
    facts: &ProtoPromotionFacts,
    captured_slots_before_stmt: &CapturedSlotSnapshots,
    physical_root_lifetimes: &[bool],
) -> bool {
    let Some(return_index) = block.stmts.len().checked_sub(1) else {
        return false;
    };
    let Some(assign_index) = return_index.checked_sub(1) else {
        return false;
    };
    if *physical_root_lifetimes
        .get(assign_index)
        .expect("physical-root snapshots must cover the terminal nil-pack assignment")
    {
        // 候选拒绝[SemanticBarrier:Lifetime]：nil producer 仍是 physical-root lifetime owner，删除会提前释放其先前值（regress_356）。
        return false;
    }
    let (HirStmt::Assign(assign), HirStmt::Return(ret)) =
        (&block.stmts[assign_index], &block.stmts[return_index])
    else {
        return false;
    };
    if assign.targets.len() < 2
        || assign.values.tail.is_some()
        || assign.values.fixed.len() != assign.targets.len()
        || !assign
            .values
            .fixed
            .iter()
            .all(|value| matches!(value, HirExpr::Nil))
        || ret.values.tail.is_some()
        || ret.values.fixed.len() != assign.targets.len()
    {
        return false;
    }

    let Some(targets) = assign
        .targets
        .iter()
        .map(|target| match target {
            HirLValue::Temp(temp) => Some(*temp),
            HirLValue::Param(_)
            | HirLValue::Local(_)
            | HirLValue::Upvalue(_)
            | HirLValue::Global(_)
            | HirLValue::TableAccess(_) => None,
        })
        .collect::<Option<Vec<_>>>()
    else {
        return false;
    };
    if !ret
        .values
        .fixed
        .iter()
        .zip(&targets)
        .all(|(value, target)| matches!(value, HirExpr::TempRef(temp) if temp == target))
    {
        return false;
    }

    let captured_slots = captured_slots_before_stmt
        .get(assign_index)
        .expect("capture snapshots must cover the terminal nil-pack assignment");
    for target in &targets {
        let possible_homes = facts.complete_temp_home_slots(*target);
        // 候选拒绝[SemanticBarrier:Capture]：closure 已引用捕获任一可能 target home 时，
        // 删除 nil 写会让其继续观察旧值。
        if possible_homes
            .iter()
            .any(|slot| captured_slots.contains(slot))
        {
            return false;
        }
        // 候选拒绝[PolicyBoundary]：DebugScope 标注的 temp 保留独立源码 binding 身份。
        if scratch.has_debug_local_hint(*target) {
            return false;
        }
        // 候选拒绝[SemanticBarrier:Lifetime]：额外 use 会继续观察被删除的 nil 写或 temp identity。
        if total_use_count(*target, live_use_counts) != 1 {
            return false;
        }
    }

    let HirStmt::Return(ret) = &mut block.stmts[return_index] else {
        unreachable!("validated terminal nil-pack sink must remain a return")
    };
    ret.values.fixed.fill(HirExpr::Nil);
    for target in targets {
        remove_live_use(live_use_counts, target);
    }
    block.stmts.remove(assign_index);
    true
}

fn root_nil_pack_gap_preserves_slots_with_context(
    stmt: &HirStmt,
    protected_temps: &BTreeSet<TempId>,
    protected_slots: &BTreeSet<HomeSlotKey>,
    read_protected_slots: &BTreeSet<HomeSlotKey>,
    referenced_labels: &BTreeSet<crate::hir::common::HirLabelId>,
    facts: &ProtoPromotionFacts,
) -> bool {
    match root_nil_pack_gap_read_relation(stmt, read_protected_slots, facts) {
        RootNilPackGapReadRelation::Disjoint => {}
        RootNilPackGapReadRelation::Overlap => {
            // 候选拒绝[SemanticBarrier:ValueFlow]：gap 通过另一个 binding 读取同一 home 时，
            // 原程序看到 nil overwrite，删除后却会看到此前 value；target 的唯一 use 不能覆盖 alias read。
            return false;
        }
    }
    match stmt {
        HirStmt::LocalRootRelease(_) => true,
        HirStmt::Assign(assign) => {
            // 候选拒绝[SemanticBarrier:EvalOrder]：`t=nil; t=x; return t` 若跨过同槽写，会错误恢复成 `return nil`。
            assign.targets.iter().all(|target| {
                if matches!(target, HirLValue::Temp(temp) if protected_temps.contains(temp)) {
                    return false;
                }
                if protected_slots.is_empty() {
                    return true;
                }
                direct_lvalue_possible_home_slots(target, facts).is_disjoint(protected_slots)
            })
        }
        HirStmt::LocalDecl(local_decl) => {
            // 候选拒绝[SemanticBarrier:EvalOrder]：gap local 写复用 protected home 会覆盖 return 应读取的 nil temp。
            if protected_slots.is_empty() {
                return true;
            }
            local_decl.bindings.iter().all(|local| {
                facts
                    .complete_local_home_slots(*local)
                    .is_disjoint(protected_slots)
            })
        }
        HirStmt::GlobalDecl(_)
        | HirStmt::TableSetList(_)
        | HirStmt::ErrNil(_)
        | HirStmt::CallStmt(_) => true,
        HirStmt::ToBeClosed(to_be_closed) => protected_slots
            .iter()
            .all(|home| home.slot() != to_be_closed.reg_index),
        HirStmt::Close(close) => {
            // 候选拒绝[SemanticBarrier:Lifetime]：关闭范围若包含 nil target 的物理槽，
            // 删除 overwrite 会让 cleanup 看到此前 value，而不是 nil（regress_433 覆盖无关槽可通过）。
            protected_slots
                .iter()
                .all(|home| home.slot() < close.from_reg)
        }
        HirStmt::If(if_stmt) => {
            root_nil_pack_gap_block_preserves_slots(
                &if_stmt.then_block,
                protected_temps,
                protected_slots,
                read_protected_slots,
                referenced_labels,
                facts,
            ) && if_stmt.else_block.as_ref().is_none_or(|else_block| {
                root_nil_pack_gap_block_preserves_slots(
                    else_block,
                    protected_temps,
                    protected_slots,
                    read_protected_slots,
                    referenced_labels,
                    facts,
                )
            })
        }
        HirStmt::While(while_stmt) => root_nil_pack_gap_block_preserves_slots(
            &while_stmt.body,
            protected_temps,
            protected_slots,
            read_protected_slots,
            referenced_labels,
            facts,
        ),
        HirStmt::Repeat(repeat_stmt) => root_nil_pack_gap_block_preserves_slots(
            &repeat_stmt.body,
            protected_temps,
            protected_slots,
            read_protected_slots,
            referenced_labels,
            facts,
        ),
        HirStmt::NumericFor(numeric_for) => {
            facts
                .complete_local_home_slots(numeric_for.binding)
                .is_disjoint(protected_slots)
                && root_nil_pack_gap_block_preserves_slots(
                    &numeric_for.body,
                    protected_temps,
                    protected_slots,
                    read_protected_slots,
                    referenced_labels,
                    facts,
                )
        }
        HirStmt::GenericFor(generic_for) => {
            generic_for.bindings.iter().all(|binding| {
                facts
                    .complete_local_home_slots(*binding)
                    .is_disjoint(protected_slots)
            }) && root_nil_pack_gap_block_preserves_slots(
                &generic_for.body,
                protected_temps,
                protected_slots,
                read_protected_slots,
                referenced_labels,
                facts,
            )
        }
        HirStmt::Block(block) => root_nil_pack_gap_block_preserves_slots(
            block,
            protected_temps,
            protected_slots,
            read_protected_slots,
            referenced_labels,
            facts,
        ),
        // Return/loop exits cannot reach the rewritten terminal sink on this path. Its expressions,
        // direct roots and cleanup effects were already checked above and by the assignment snapshot.
        HirStmt::Return(_) | HirStmt::Break | HirStmt::Continue => true,
        // 候选拒绝[SemanticBarrier:ControlFlow]：`goto L; t=nil; ::L::; return t, tail()`
        // 可从外部跳过 nil 写；把终态读取改成 literal nil 会错误覆盖该路径的旧 epoch。
        HirStmt::Goto(_) => false,
        HirStmt::Label(label) => {
            // 无引用 label 不改变路径；有引用 label 可能是上述外部跳入点，缺 CFG dominance 时保留。
            !referenced_labels.contains(&label.id)
        }
    }
}

#[derive(Clone, Copy, Eq, PartialEq)]
enum RootNilPackGapReadRelation {
    Disjoint,
    Overlap,
}

fn root_nil_pack_gap_read_relation(
    stmt: &HirStmt,
    protected_slots: &BTreeSet<HomeSlotKey>,
    facts: &ProtoPromotionFacts,
) -> RootNilPackGapReadRelation {
    if protected_slots.is_empty() {
        return RootNilPackGapReadRelation::Disjoint;
    }
    if direct_binding_read_homes_in_stmt(stmt, facts).is_disjoint(protected_slots) {
        RootNilPackGapReadRelation::Disjoint
    } else {
        RootNilPackGapReadRelation::Overlap
    }
}

fn root_open_return_remaining_read_relation(
    ret: &crate::hir::common::HirReturn,
    fixed_start: usize,
    target_count: usize,
    protected_slots: &BTreeSet<HomeSlotKey>,
    facts: &ProtoPromotionFacts,
) -> RootNilPackGapReadRelation {
    if protected_slots.is_empty() {
        return RootNilPackGapReadRelation::Disjoint;
    }
    let mut homes = BTreeSet::new();
    {
        let mut collector = binding_home_read_collector(facts, &mut homes);
        for (index, value) in ret.values.fixed.iter().enumerate() {
            if index < fixed_start || index >= fixed_start + target_count {
                visit_expr(value, &mut collector);
            }
        }
        if let Some(tail) = &ret.values.tail {
            visit_expr(tail.as_expr(), &mut collector);
        }
    }
    if homes.is_disjoint(protected_slots) {
        RootNilPackGapReadRelation::Disjoint
    } else {
        RootNilPackGapReadRelation::Overlap
    }
}

fn direct_binding_read_homes_in_stmt(
    stmt: &HirStmt,
    facts: &ProtoPromotionFacts,
) -> BTreeSet<HomeSlotKey> {
    let mut homes = BTreeSet::new();
    visit_stmts(
        std::slice::from_ref(stmt),
        &mut binding_home_read_collector(facts, &mut homes),
    );
    homes
}

fn root_nil_pack_gap_block_preserves_slots(
    block: &HirBlock,
    protected_temps: &BTreeSet<TempId>,
    protected_slots: &BTreeSet<HomeSlotKey>,
    read_protected_slots: &BTreeSet<HomeSlotKey>,
    referenced_labels: &BTreeSet<crate::hir::common::HirLabelId>,
    facts: &ProtoPromotionFacts,
) -> bool {
    block.stmts.iter().all(|stmt| {
        root_nil_pack_gap_preserves_slots_with_context(
            stmt,
            protected_temps,
            protected_slots,
            read_protected_slots,
            referenced_labels,
            facts,
        )
    })
}

fn direct_lvalue_possible_home_slots<'a>(
    target: &HirLValue,
    facts: &'a ProtoPromotionFacts,
) -> HomeSlots<'a> {
    match target {
        HirLValue::Param(param) => facts.complete_param_home_slots(*param),
        HirLValue::Temp(temp) => facts.complete_temp_home_slots(*temp),
        HirLValue::Local(local) => facts.complete_local_home_slots(*local),
        HirLValue::Upvalue(_) | HirLValue::Global(_) | HirLValue::TableAccess(_) => {
            Cow::Owned(BTreeSet::new())
        }
    }
}

// t0=source; t1=setup(); t2=t0; for i=t2,3 只有在 setup 不能改写 source 时
// 才可把头部改为 for i=source,3；稳定 binding 读取不等于任意可跨事件的快照。
fn inline_numeric_for_stable_header_aliases(
    block: &mut HirBlock,
    run: std::ops::Range<usize>,
    live_use_counts: &mut [usize],
    proof: NumericForHeaderProof<'_>,
    removed_stmts: &mut [bool],
) -> bool {
    let (run_start, run_end) = (run.start, run.end);
    if !matches!(block.stmts.get(run_end), Some(HirStmt::NumericFor(_))) {
        return false;
    }

    let mut rewritten_sink = block.stmts[run_end].clone();
    let mut last_def_indices = vec![None; proof.scratch.temp_count()];
    for candidate_index in run_start..run_end {
        let (temp, _) = block.stmts[candidate_index]
            .scalar_temp_assignment()
            .expect("numeric-for materialization run must contain only scalar temp definitions");
        last_def_indices[temp.index()] = Some(candidate_index);
    }
    let mut changed = false;
    for candidate_index in run_start..run_end {
        if removed_stmts[candidate_index] {
            continue;
        }
        let Some((temp, value)) = block.stmts[candidate_index].scalar_temp_assignment() else {
            continue;
        };
        if last_def_indices[temp.index()] != Some(candidate_index) {
            // 候选拒绝[SemanticBarrier:Lifetime]：同一 canonical temp 的较早定义不是 loop-head reaching def；删除它并替换 sink 会切到旧 value epoch。
            continue;
        }
        let site = inline_site_in_stmt(&rewritten_sink, temp);
        let dependencies_are_stable = materialization_run_preserves_value_reads(
            block,
            candidate_index + 1..run_end,
            value,
            proof.facts,
        );
        if proof.safety.is_repeatable_in_single_value_context(value)
            && proof
                .safety
                .is_effect_invariant_in_single_value_context(value)
            && dependencies_are_stable
        {
            // 候选拒绝[SemanticBarrier:Lifetime]：额外 use、capture 或 self-rebind 仍要求 producer 存在。
            // 候选拒绝[PolicyBoundary]：DebugScope 标注的 temp 保留独立源码 binding 身份。
            if total_use_count(temp, live_use_counts) != 1
                || !materialization_run_candidate_is_safe(
                    temp,
                    value,
                    candidate_index,
                    proof.scratch,
                    proof.facts,
                    proof.captured_slots_before_stmt,
                )
                || site != Some(InlineSite::LoopHead)
            {
                continue;
            }
            replace_temp_in_stmt(&mut rewritten_sink, temp, value);
            assert!(
                inline_site_in_stmt(&rewritten_sink, temp).is_none(),
                "validated numeric-for literal alias must consume its only loop-head use"
            );
            removed_stmts[candidate_index] = true;
            remove_live_use(live_use_counts, temp);
            changed = true;
            continue;
        }
        if expr_observes_eval_order(value) {
            // 候选拒绝[SemanticBarrier:EvalOrder]：lookup/call/元方法运算移入 numeric-for
            // header 会跨过其它状态准备求值，改变 lookup/call/metamethod 的先后（regress_144）。
            continue;
        }
        // 候选拒绝[SemanticBarrier:Lifetime]：额外 use、capture 或 self-rebind 仍要求 producer 存在。
        // 候选拒绝[PolicyBoundary]：DebugScope 标注的 temp 保留独立源码 binding 身份。
        if site != Some(InlineSite::LoopHead) {
            continue;
        }
        let Some(plan) = numeric_for_binding_header_alias_plan(
            block,
            run_start..run_end,
            candidate_index,
            live_use_counts,
            &proof,
        ) else {
            continue;
        };
        replace_temp_in_stmt(&mut rewritten_sink, temp, &plan.replacement);
        assert!(
            inline_site_in_stmt(&rewritten_sink, temp).is_none(),
            "validated numeric-for binding alias must consume its only loop-head use"
        );
        for (chain_index, chain_temp) in plan.chain {
            assert!(
                !removed_stmts[chain_index],
                "numeric-for binding alias chains must be disjoint"
            );
            removed_stmts[chain_index] = true;
            remove_live_use(live_use_counts, chain_temp);
        }
        changed = true;
    }
    if changed {
        block.stmts[run_end] = rewritten_sink;
    }
    changed
}

fn materialization_run_preserves_value_reads(
    block: &HirBlock,
    later_run: std::ops::Range<usize>,
    value: &HirExpr,
    facts: &ProtoPromotionFacts,
) -> bool {
    let read_homes = expr_read_homes(value, facts);
    if read_homes.is_empty() {
        return true;
    }
    block.stmts[later_run].iter().all(|stmt| {
        let (target, _) = stmt
            .scalar_temp_assignment()
            .expect("numeric-for materialization run must contain only scalar temp definitions");
        if expr_mentions_temp(value, target) {
            return false;
        }
        let target_write_homes = complete_materialization_write_homes(target, facts);
        if !target_write_homes.is_disjoint(&read_homes) {
            // 候选拒绝[SemanticBarrier:ValueFlow]：后续 run target 覆盖 expression source home 时，
            // producer 保存的是旧快照，移入 loop header 会改读新 epoch。
            return false;
        }
        true
    })
}

struct NumericForBindingHeaderAliasPlan {
    replacement: HirExpr,
    chain: Vec<(usize, TempId)>,
}

struct NumericForHeaderProof<'a> {
    scratch: &'a TempUseScratch,
    facts: &'a ProtoPromotionFacts,
    safety: HirExprSafety,
    reference_captured: &'a ReferenceCapturedBindings,
    captured_slots_before_stmt: &'a CapturedSlotSnapshots,
    reference_captured_home_slots: &'a BTreeSet<HomeSlotKey>,
}

/// 本轮 temp-inline 的引用捕获身份及其完整 home 投影。
/// 身份在进入递归改写前冻结，promotion 在整轮只读；块和 repeat 候选共享同一份
/// may-alias 全集，例如不同 local 同属一个 captured slot 时仍必须阻止延后读取。
struct TempInlineCaptureFacts<'a> {
    bindings: &'a ReferenceCapturedBindings,
    homes: BTreeSet<HomeSlotKey>,
}

impl<'a> TempInlineCaptureFacts<'a> {
    fn new(bindings: &'a ReferenceCapturedBindings, facts: &ProtoPromotionFacts) -> Self {
        Self {
            bindings,
            homes: bindings.complete_home_slots(facts),
        }
    }
}

fn complete_materialization_write_homes(
    temp: TempId,
    facts: &ProtoPromotionFacts,
) -> HomeSlots<'_> {
    let mut homes = facts.complete_temp_home_slots(temp);
    if homes.is_empty() {
        return homes;
    }
    let moves = facts.complete_immediate_move_write_homes(temp);
    if !moves.is_empty() {
        homes.to_mut().extend(moves.iter().copied());
    }
    homes
}

fn numeric_for_binding_header_alias_plan(
    block: &HirBlock,
    run: std::ops::Range<usize>,
    sink_temp_index: usize,
    live_use_counts: &[usize],
    proof: &NumericForHeaderProof<'_>,
) -> Option<NumericForBindingHeaderAliasPlan> {
    let (sink_temp, _) = block.stmts[sink_temp_index].scalar_temp_assignment()?;
    let sink_captured_slots = proof
        .captured_slots_before_stmt
        .get(run.end)
        .expect("capture snapshots must cover the numeric-for sink");
    let mut chain = Vec::new();
    let mut current_index = sink_temp_index;
    let (replacement, source_homes, source_temp, source_requires_event_free_gap, source_index) = loop {
        let (temp, value) = block.stmts[current_index].scalar_temp_assignment()?;
        if total_use_count(temp, live_use_counts) != 1 || expr_mentions_temp(value, temp) {
            // 候选拒绝[SemanticBarrier:Lifetime]：链节点有额外 use 或自写时，删除整条快照链会丢失仍可观察的值或状态更新。
            return None;
        }
        if proof.scratch.has_debug_local_hint(temp) {
            // 候选拒绝[PolicyBoundary]：DebugScope 标注的 temp 保留独立源码 binding 身份。
            return None;
        }
        let chain_write_homes = complete_materialization_write_homes(temp, proof.facts);
        if !chain_write_homes.is_disjoint(sink_captured_slots) {
            // 候选拒绝[SemanticBarrier:Capture]：chain primary/hidden-MOVE 写入了 sink 前已捕获的 home；删除 producer 会让 closure 继续观察旧 cell 值。
            return None;
        }
        if !chain_write_homes.is_empty()
            && !chain_write_homes.is_disjoint(proof.reference_captured_home_slots)
        {
            // 候选拒绝[SemanticBarrier:Capture]：删除写入 captured home 的 chain producer
            // 会让现有或随后创建的 closure 观察此前 cell value（regress_310）。
            return None;
        }
        chain.push((current_index, temp));
        match value {
            HirExpr::ParamRef(param) => {
                let homes = proof.facts.complete_param_home_slots(*param);
                break (value.clone(), homes, None, false, current_index);
            }
            HirExpr::LocalRef(local) => {
                let homes = proof.facts.complete_local_home_slots(*local);
                break (value.clone(), homes, None, false, current_index);
            }
            HirExpr::TempRef(source) => {
                if let Some(source_index) = (run.start..current_index).rfind(|index| {
                    block.stmts[*index]
                        .scalar_temp_assignment()
                        .is_some_and(|(candidate, _)| candidate == *source)
                }) {
                    current_index = source_index;
                } else {
                    let homes = proof.facts.complete_temp_home_slots(*source);
                    break (value.clone(), homes, Some(*source), false, current_index);
                }
            }
            HirExpr::UpvalueRef(_) => {
                // Upvalue 没有当前 proto 的 physical home；只要跨越区间无 lookup/call/元方法事件，
                // 读取位置从 producer 延到 header 不会获得外部改写机会。
                break (
                    value.clone(),
                    Cow::Owned(BTreeSet::new()),
                    None,
                    true,
                    current_index,
                );
            }
            _ => {
                // 候选拒绝[SemanticBarrier:EvalOrder]：lookup/call/元方法运算若作为 chain root，
                // 延到 numeric-for header 会跨过状态准备求值并改变事件顺序（regress_144）。
                return None;
            }
        }
    };

    let source_is_reference_captured = if source_homes.is_empty() {
        false
    } else {
        !source_homes.is_disjoint(proof.reference_captured_home_slots)
    };

    let chain_indices = chain
        .iter()
        .map(|(index, _)| *index)
        .collect::<BTreeSet<_>>();
    for stmt_index in (source_index + 1)..run.end {
        if chain_indices.contains(&stmt_index) {
            continue;
        }
        let (target, value) = block.stmts[stmt_index]
            .scalar_temp_assignment()
            .expect("numeric-for materialization run must contain only scalar temp definitions");
        if source_temp == Some(target) {
            // 候选拒绝[SemanticBarrier:ValueFlow]：链外状态准备按同一 HIR identity
            // 重写 source 时，原 producer 保留旧快照，延后读取会切到新 value epoch。
            return None;
        }
        let target_write_homes = complete_materialization_write_homes(target, proof.facts);
        if !target_write_homes.is_disjoint(&source_homes) {
            // 候选拒绝[SemanticBarrier:ValueFlow]：链外状态准备写覆盖 source possible-home 时，
            // 原 temp 冻结旧值；延后读取会切到新 epoch。
            return None;
        }
        if (source_is_reference_captured || source_requires_event_free_gap)
            && expr_observes_eval_order(value)
        {
            // 候选拒绝[SemanticBarrier:ValueFlow]：区间 call/lookup/元方法可经引用 closure
            // 改写 captured source（或 upvalue）；延后读取会破坏定义点快照（regress_145）。
            return None;
        }
    }

    if (source_is_reference_captured || source_requires_event_free_gap)
        && !temp_precedes_observable_eval_in_stmt(
            &block.stmts[run.end],
            sink_temp,
            true,
            proof.reference_captured,
        )
    {
        // 候选拒绝[SemanticBarrier:ValueFlow]：numeric-for 的 start/limit/step 或其表达式
        // 前缀若先执行 call/lookup/元方法，可在 replacement 读取前改写 captured source/upvalue；
        // 原 producer 已冻结旧值，延后到 header 会切到新 epoch（regress_145）。
        return None;
    }

    Some(NumericForBindingHeaderAliasPlan { replacement, chain })
}

struct OpenReturnFixedAliasProof<'a> {
    scratch: &'a TempUseScratch,
    facts: &'a ProtoPromotionFacts,
    captured_slots_before_stmt: &'a CapturedSlotSnapshots,
    reference_captured_home_slots: &'a BTreeSet<HomeSlotKey>,
}

fn inline_open_return_fixed_alias_run(
    block: &mut HirBlock,
    run: std::ops::Range<usize>,
    live_use_counts: &mut [usize],
    proof: OpenReturnFixedAliasProof<'_>,
    removed_stmts: &mut [bool],
) -> bool {
    let (run_start, run_end) = (run.start, run.end);
    let Some(HirStmt::Return(ret)) = block.stmts.get(run_end) else {
        return false;
    };
    let Some(tail) = ret.values.tail.as_ref() else {
        return false;
    };
    if tail.exact_width().is_some() || !matches!(tail.as_expr(), HirExpr::Call(_)) {
        return false;
    }
    let alias_count = ret.values.fixed.len();
    if alias_count == 0 || alias_count >= run_end - run_start {
        return false;
    }

    let captured_slots = proof
        .captured_slots_before_stmt
        .get(run_end)
        .expect("capture snapshots must cover the planned open-return sink");
    let mut target_temps = BTreeSet::new();
    let mut source_temps = BTreeSet::new();
    let mut target_slots = BTreeSet::new();
    let mut source_slots = BTreeSet::new();
    for (stmt, fixed) in block.stmts[run_start..(run_start + alias_count)]
        .iter()
        .zip(&ret.values.fixed)
    {
        let Some((target, HirExpr::TempRef(source))) = stmt.scalar_temp_assignment() else {
            return false;
        };
        if !matches!(fixed, HirExpr::TempRef(temp) if *temp == target)
            || total_use_count(target, live_use_counts) != 1
            || proof.scratch.has_debug_local_hint(target)
        {
            // 候选拒绝[SemanticBarrier:Lifetime]：fixed prefix 非对应唯一 target use 时，删除 alias 会改变其它消费者所见值。
            // 候选拒绝[PolicyBoundary]：DebugScope 标注的 alias 保留独立源码 binding 身份。
            return false;
        }
        let target_homes = proof.facts.complete_temp_home_slots(target);
        let source_homes = proof.facts.complete_temp_home_slots(*source);
        let touches_captured_home = target_homes
            .iter()
            .chain(source_homes.iter())
            .any(|home| captured_slots.contains(home));
        if touches_captured_home {
            // 候选拒绝[SemanticBarrier:Capture]：source/target 的任一可能 home 已捕获，
            // 当前 HIR 事务不能证明移动读取安全；这不是“任何后续源码改写都非法”的
            // 绝对结论，因此不能把本次证明不足升级成跨层 Preserve。
            return false;
        }
        if !target_temps.insert(target) || !target_slots.is_disjoint(&target_homes) {
            // 候选拒绝[SemanticBarrier:Capture]：多个 target 可能共享 HIR/物理槽时，
            // 移动读取会改变 closure/slot 生命周期。per-definition certificate 尚未覆盖
            // 此关系，本阶段不把它错误聚合成整个 TempId 的 retention。
            return false;
        }
        source_temps.insert(*source);
        target_slots.extend(target_homes.iter().copied());
        source_slots.extend(source_homes.iter().copied());
    }
    if !(target_slots.is_empty() && source_slots.is_empty())
        && (!target_slots.is_disjoint(proof.reference_captured_home_slots)
            || !source_slots.is_disjoint(proof.reference_captured_home_slots))
    {
        // 候选拒绝[SemanticBarrier:Capture]：删除 captured target 写或把 captured source
        // 读取延到 open tail setup 之后超出当前 HIR 证明；AST 仍可针对 Lua 源码的
        // left-to-right return 求值规则证明另一种合法改写，所以这里只拒绝本事务。
        return false;
    }
    if !target_temps.is_disjoint(&source_temps) || !target_slots.is_disjoint(&source_slots) {
        // 候选拒绝[SemanticBarrier:EvalOrder]：source/target 同槽会让 fixed return 读到 tail setup 后的新值；见 regress_310。
        return false;
    }

    for stmt in &block.stmts[(run_start + alias_count)..run_end] {
        let Some((target, _)) = stmt.scalar_temp_assignment() else {
            return false;
        };
        if target_temps.contains(&target) || source_temps.contains(&target) {
            // 候选拒绝[SemanticBarrier:EvalOrder]：tail setup 直接重写 fixed alias 的 source/target
            // HIR binding 时，延后读取会切到 setup 后的新值。
            return false;
        }
        let protected_slots_are_empty = target_slots.is_empty() && source_slots.is_empty();
        let possible_homes = proof.facts.complete_temp_home_slots(target);
        if !protected_slots_are_empty
            && (!possible_homes.is_disjoint(&target_slots)
                || !possible_homes.is_disjoint(&source_slots))
        {
            // 候选拒绝[SemanticBarrier:EvalOrder]：tail setup 覆盖 fixed alias 槽时，内联会把读取延后到覆盖之后。
            return false;
        }
    }

    let (run, sink) = block.stmts.split_at_mut(run_end);
    let HirStmt::Return(ret) = &mut sink[0] else {
        unreachable!("validated open-return sink must remain a return")
    };
    for (offset, (stmt, fixed)) in run[run_start..(run_start + alias_count)]
        .iter()
        .zip(&mut ret.values.fixed)
        .enumerate()
    {
        let Some((target, HirExpr::TempRef(source))) = stmt.scalar_temp_assignment() else {
            unreachable!("validated fixed-prefix alias must remain scalar")
        };
        *fixed = HirExpr::TempRef(*source);
        removed_stmts[run_start + offset] = true;
        remove_live_use(live_use_counts, target);
    }
    true
}

fn call_arg_inline_crosses_materialized_callee(
    site: InlineSite,
    value: &HirExpr,
    stmt_index: usize,
    callee_materialized_at: Option<usize>,
) -> bool {
    site == InlineSite::CallArg
        && expr_observes_eval_order(value)
        && callee_materialized_at.is_some_and(|callee_index| stmt_index < callee_index)
}

// 每个 block 只重置上次实际写过的槽，避免块数与 proto temp 数相乘的稠密初始化。
struct OrderSensitiveDefWorkspace {
    defs: Vec<Option<usize>>,
    touched: Vec<TempId>,
}

impl OrderSensitiveDefWorkspace {
    fn new(temp_count: usize) -> Self {
        Self {
            defs: vec![None; temp_count],
            touched: Vec::new(),
        }
    }

    fn rebuild(&mut self, stmts: &[HirStmt]) {
        for temp in self.touched.drain(..) {
            self.defs[temp.index()] = None;
        }
        for (index, stmt) in stmts.iter().enumerate() {
            let Some((temp, value)) = stmt.scalar_temp_assignment() else {
                continue;
            };
            if !expr_observes_eval_order(value) {
                continue;
            }
            let slot = &mut self.defs[temp.index()];
            if slot.is_none() {
                self.touched.push(temp);
            }
            *slot = Some(index);
        }
    }

    fn get(&self, temp: TempId) -> Option<usize> {
        self.defs[temp.index()]
    }
}

fn arg_value_forwards_prior_order_sensitive_expr(
    arg_value: &HirExpr,
    callee_def_index: usize,
    prior_order_sensitive_defs: &OrderSensitiveDefWorkspace,
) -> bool {
    let HirExpr::TempRef(temp) = arg_value else {
        return false;
    };
    prior_order_sensitive_defs
        .get(*temp)
        .is_some_and(|arg_def_index| arg_def_index < callee_def_index)
}

fn materialization_run_candidate_is_safe(
    temp: TempId,
    value: &HirExpr,
    stmt_index: usize,
    scratch: &TempUseScratch,
    facts: &ProtoPromotionFacts,
    captured_slots_before_stmt: &CapturedSlotSnapshots,
) -> bool {
    // 候选拒绝[PolicyBoundary]：DebugScope 标注的 temp 保留独立源码 binding 身份。
    !scratch.has_debug_local_hint(temp)
        && !facts.temp_requires_call_frame(temp)
        // 候选拒绝[SemanticBarrier:Capture]：引用捕获该 home 的 closure 必须观察 producer 写入后的值；见 regress_310。
        && !temp_rebinds_captured_slot(
            temp,
            facts,
            captured_slots_before_stmt
                .get(stmt_index)
                .expect("captured slot scan should cover every statement"),
        )
        // 候选拒绝[SemanticBarrier:Lifetime]：`t=t+1; sink(t)` 的 producer 是状态更新而非 forwarding temp；见 regress_263#2。
        && !expr_mentions_temp(value, temp)
}

fn total_use_count(temp: TempId, total_use_totals: &[usize]) -> usize {
    total_use_totals
        .get(temp.index())
        .copied()
        .unwrap_or_default()
}

fn remove_live_use(live_use_counts: &mut [usize], temp: TempId) {
    let count = live_use_counts
        .get_mut(temp.index())
        .expect("live use counts should cover every referenced temp");
    *count = count
        .checked_sub(1)
        .expect("successful inline should remove one live use");
}

fn collect_block_temp_use_totals(stmts: &[HirStmt], scratch: &mut TempUseScratch) -> Vec<usize> {
    let mut totals = vec![0; scratch.temp_count()];
    for stmt in stmts {
        collect_stmt_temp_uses(stmt, scratch).add_to_totals(&mut totals);
    }
    totals
}

#[allow(clippy::too_many_arguments)]
fn inline_temps_in_nested_blocks(
    stmt: &mut HirStmt,
    workspace: &mut TempInlineWorkspace<'_>,
    live_use_counts: &mut [usize],
    captures: &TempInlineCaptureFacts<'_>,
    readability: ReadabilityOptions,
    facts: &ProtoPromotionFacts,
    inherited_captured_slots: &BTreeSet<HomeSlotKey>,
    event_scope: RootEventStmt<'_>,
) -> bool {
    match stmt {
        HirStmt::LocalRootRelease(_) => false,
        HirStmt::If(if_stmt) => {
            let mut changed = inline_temps_in_block(
                &mut if_stmt.then_block,
                workspace,
                live_use_counts,
                captures,
                readability,
                facts,
                inherited_captured_slots,
                event_scope.child(0),
            );
            if let Some(else_block) = &mut if_stmt.else_block {
                changed |= inline_temps_in_block(
                    else_block,
                    workspace,
                    live_use_counts,
                    captures,
                    readability,
                    facts,
                    inherited_captured_slots,
                    event_scope.child(1),
                );
            }
            changed
        }
        HirStmt::While(while_stmt) => inline_temps_in_block(
            &mut while_stmt.body,
            workspace,
            live_use_counts,
            captures,
            readability,
            facts,
            inherited_captured_slots,
            event_scope.child(0),
        ),
        HirStmt::Repeat(repeat_stmt) => {
            let policy = RepeatInlinePolicy {
                readability,
                safety: workspace.safety,
            };
            let mut changed = inline_temps_in_block(
                &mut repeat_stmt.body,
                workspace,
                live_use_counts,
                captures,
                readability,
                facts,
                inherited_captured_slots,
                event_scope.child(0),
            );
            changed |= inline_repeat_head_scalar_temp(
                repeat_stmt,
                &mut workspace.uses,
                live_use_counts,
                captures,
                policy,
                facts,
                inherited_captured_slots,
            );
            changed |= inline_repeat_tail_temp(
                repeat_stmt,
                &mut workspace.uses,
                live_use_counts,
                captures.bindings,
                policy,
                facts,
                inherited_captured_slots,
            );
            changed
        }
        HirStmt::NumericFor(numeric_for) => inline_temps_in_block(
            &mut numeric_for.body,
            workspace,
            live_use_counts,
            captures,
            readability,
            facts,
            inherited_captured_slots,
            event_scope.child(0),
        ),
        HirStmt::GenericFor(generic_for) => inline_temps_in_block(
            &mut generic_for.body,
            workspace,
            live_use_counts,
            captures,
            readability,
            facts,
            inherited_captured_slots,
            event_scope.child(0),
        ),
        HirStmt::Block(block) => inline_temps_in_block(
            block,
            workspace,
            live_use_counts,
            captures,
            readability,
            facts,
            inherited_captured_slots,
            event_scope.child(0),
        ),
        HirStmt::LocalDecl(_)
        | HirStmt::GlobalDecl(_)
        | HirStmt::Assign(_)
        | HirStmt::TableSetList(_)
        | HirStmt::ErrNil(_)
        | HirStmt::ToBeClosed(_)
        | HirStmt::Close(_)
        | HirStmt::CallStmt(_)
        | HirStmt::Return(_)
        | HirStmt::Break
        | HirStmt::Continue
        | HirStmt::Goto(_)
        | HirStmt::Label(_) => false,
    }
}

#[derive(Clone, Copy)]
struct RepeatInlinePolicy {
    readability: ReadabilityOptions,
    safety: HirExprSafety,
}

fn inline_repeat_head_scalar_temp(
    repeat_stmt: &mut crate::hir::common::HirRepeat,
    scratch: &mut TempUseScratch,
    live_use_counts: &mut [usize],
    captures: &TempInlineCaptureFacts<'_>,
    policy: RepeatInlinePolicy,
    facts: &ProtoPromotionFacts,
    inherited_captured_slots: &BTreeSet<HomeSlotKey>,
) -> bool {
    let Some((temp, _)) = repeat_stmt
        .body
        .stmts
        .first()
        .and_then(HirStmt::scalar_temp_assignment)
    else {
        return false;
    };
    // 这里的 producer 已由 structure fact 证明是 continue 重定位出的 latch prefix；
    // 删除它会把 RHS 从每轮 body 前移动到 body 后的 until 求值点。
    if !facts.is_repeat_condition_prefix_temp(temp) {
        // 普通 body 首句不形成 repeat-prefix 候选；只有 structure 已标注的 before-body
        // condition prefix 才属于本事务。
        return false;
    }
    inline_repeat_head_scalar_temp_with_proven_prefix(
        repeat_stmt,
        scratch,
        live_use_counts,
        captures,
        policy,
        facts,
        inherited_captured_slots,
    )
}

fn inline_repeat_head_scalar_temp_with_proven_prefix(
    repeat_stmt: &mut crate::hir::common::HirRepeat,
    scratch: &mut TempUseScratch,
    live_use_counts: &mut [usize],
    captures: &TempInlineCaptureFacts<'_>,
    policy: RepeatInlinePolicy,
    facts: &ProtoPromotionFacts,
    inherited_captured_slots: &BTreeSet<HomeSlotKey>,
) -> bool {
    let Some((temp, value)) = repeat_stmt
        .body
        .stmts
        .first()
        .and_then(HirStmt::scalar_temp_assignment)
    else {
        return false;
    };
    // 候选拒绝[PolicyBoundary]：DebugScope 标注的 temp 保留独立源码 binding 身份。
    // 候选拒绝[SemanticBarrier:Lifetime]：非唯一 condition use 仍需要原 temp。
    if scratch.has_debug_local_hint(temp)
        || total_use_count(temp, live_use_counts) != 1
        || collect_expr_temp_uses_summary(&repeat_stmt.cond, scratch).count(temp) != 1
    {
        return false;
    }
    let Some(site) = inline_site_in_repeat_condition(&repeat_stmt.cond, temp) else {
        // 候选拒绝[SemanticBarrier:Capture]：唯一 use 位于 closure capture 时，内联会把定义点快照
        // 改成 closure 的按引用 cell/value capture。
        return false;
    };
    if !site.allows(value, policy.readability, policy.safety) {
        // 候选拒绝[PolicyBoundary]：repeat condition 服从控制头复杂度展示阈值。
        return false;
    }

    let mut captured_slots = inherited_captured_slots.clone();
    for stmt in &repeat_stmt.body.stmts[1..] {
        if collect_stmt_temp_uses(stmt, scratch).count(temp) != 0
            || stmt_writes_temp(stmt, temp)
            || stmt_has_label_or_goto(stmt)
        {
            // 候选拒绝[SemanticBarrier:ControlFlow]：中间 use/write 或 break/return/goto 会让 producer 与 condition 不再位于每轮同一路径；见 regress_263#2。
            return false;
        }
        facts.collect_captured_home_slots_in_stmt(stmt, &mut captured_slots);
    }
    if temp_rebinds_captured_slot(temp, facts, &captured_slots) {
        // 候选拒绝[SemanticBarrier:Capture]：closure 已引用捕获该 home，删除首句写入会让其观察上一轮值。
        return false;
    }
    if !repeat_head_dependencies_are_stable(
        value,
        temp,
        &repeat_stmt.body.stmts[1..],
        &repeat_stmt.cond,
        &RepeatHeadDependencyProof {
            captures,
            safety: policy.safety,
            facts,
            captured_slots: &captured_slots,
        },
    ) {
        return false;
    }

    let value = value.clone();
    assert_eq!(
        replace_temp_in_expr(&mut repeat_stmt.cond, temp, &value),
        1,
        "validated repeat-head candidate must have exactly one rewrite site"
    );
    repeat_stmt.body.stmts.remove(0);
    remove_live_use(live_use_counts, temp);
    true
}

fn is_repeat_header_rootless_scalar(expr: &HirExpr) -> bool {
    matches!(
        expr,
        HirExpr::Nil
            | HirExpr::Boolean(_)
            | HirExpr::Integer(_)
            | HirExpr::Number(_)
            | HirExpr::Int64(_)
            | HirExpr::UInt64(_)
    )
}

struct RepeatHeadDependencyProof<'a> {
    captures: &'a TempInlineCaptureFacts<'a>,
    safety: HirExprSafety,
    facts: &'a ProtoPromotionFacts,
    captured_slots: &'a BTreeSet<HomeSlotKey>,
}

fn repeat_head_dependencies_are_stable(
    value: &HirExpr,
    temp: TempId,
    body_suffix: &[HirStmt],
    condition: &HirExpr,
    proof: &RepeatHeadDependencyProof<'_>,
) -> bool {
    if !is_repeat_header_rootless_scalar(value) {
        if !proof.safety.is_repeatable_in_single_value_context(value) {
            // 不能证明动态值可重复求值时，保留 producer 的求值时点和快照。
            return false;
        }

        let mut read_homes = BTreeSet::new();
        let mut read_identities = BTreeSet::new();
        visit_expr(
            value,
            &mut BindingReadCollector(|binding| {
                read_identities.insert(binding);
                read_homes.extend(
                    proof
                        .facts
                        .complete_binding_home_slots(binding)
                        .iter()
                        .copied(),
                );
            }),
        );
        let source_is_captured = read_identities.iter().any(|&binding| {
            matches!(binding, HirBinding::Upvalue(_)) || proof.captures.bindings.contains(binding)
        }) || !read_homes.is_disjoint(&proof.captures.homes);
        let body_writes = direct_binding_writes_in_stmts(
            body_suffix,
            proof.facts,
            proof.safety,
            source_is_captured,
        );
        if !read_identities.is_disjoint(&body_writes.identities)
            || !read_homes.is_disjoint(&body_writes.homes)
        {
            // 候选拒绝[SemanticBarrier:ValueFlow]：body 重写 source identity 或任一 possible-home 时，
            // body 前 producer 保存旧 epoch；移进 until 会读取 body 后的新 epoch。
            return false;
        }
        // Close 阈值只按 slot 比较；最小阈值覆盖的尾区间包含其它 Close 的全部槽。
        if body_writes
            .first_close_reg
            .zip(read_homes.last())
            .is_some_and(|(from, home)| home.slot() >= from)
        {
            // 候选拒绝[SemanticBarrier:Lifetime]：body Close 若结束 source home，producer 是
            // cleanup 前的快照/root；移到 until 会在生命周期结束后读取。
            return false;
        }

        if source_is_captured
            && (body_writes.observes_eval
                || !temp_precedes_observable_eval_in_expr(
                    condition,
                    temp,
                    true,
                    proof.captures.bindings,
                ))
        {
            // body 或 until 前缀的用户事件可改写 captured identity/home；producer 保存旧快照。
            return false;
        }
    }

    let target_write_homes = complete_materialization_write_homes(temp, proof.facts);
    if proof.captures.bindings.temps.contains(&temp)
        || !target_write_homes.is_disjoint(proof.captured_slots)
    {
        // 候选拒绝[SemanticBarrier:Capture]：删除写入 captured temp identity/home 的 prefix
        // producer 会让 closure 观察上一轮 cell value。
        return false;
    }
    if !target_write_homes.is_disjoint(&proof.captures.homes) {
        // 候选拒绝[SemanticBarrier:Capture]：prefix target 的 primary/hidden write 命中
        // captured home 时，删除 producer 会改变 closure 观察值。
        return false;
    }
    true
}

#[derive(Default)]
struct DirectBindingWriteSummary {
    identities: BTreeSet<HirBinding>,
    homes: BTreeSet<HomeSlotKey>,
    first_close_reg: Option<usize>,
    observes_eval: bool,
}

fn direct_binding_writes_in_stmts(
    stmts: &[HirStmt],
    facts: &ProtoPromotionFacts,
    safety: HirExprSafety,
    observe: bool,
) -> DirectBindingWriteSummary {
    let mut collector = DirectBindingWriteCollector {
        facts,
        summary: Default::default(),
    };
    if observe {
        let mut pair = (
            collector,
            HirEvalEffects::new(safety, |stmt| {
                matches!(stmt, HirStmt::TableSetList(_) | HirStmt::ErrNil(_))
            }),
        );
        visit_stmts(stmts, &mut pair);
        collector = pair.0;
        collector.summary.observes_eval = pair.1.found();
    } else {
        visit_stmts(stmts, &mut collector);
    }
    collector.summary
}

struct DirectBindingWriteCollector<'a> {
    facts: &'a ProtoPromotionFacts,
    summary: DirectBindingWriteSummary,
}

impl DirectBindingWriteCollector<'_> {
    fn note_binding(&mut self, binding: HirBinding) {
        self.summary.identities.insert(binding);
        let homes = match binding {
            HirBinding::Temp(temp) => complete_materialization_write_homes(temp, self.facts),
            _ => self.facts.complete_binding_home_slots(binding),
        };
        self.summary.homes.extend(homes.iter().copied());
    }
}

impl HirVisitor<'_> for DirectBindingWriteCollector<'_> {
    fn visit_local_root_release(&mut self, local: crate::hir::common::LocalId) {
        self.summary.identities.insert(HirBinding::Local(local));
    }

    fn visit_stmt(&mut self, stmt: &HirStmt) {
        match stmt {
            HirStmt::LocalDecl(decl) => {
                for &local in &decl.bindings {
                    self.note_binding(HirBinding::Local(local));
                }
            }
            HirStmt::NumericFor(for_stmt) => self.note_binding(HirBinding::Local(for_stmt.binding)),
            HirStmt::GenericFor(for_stmt) => {
                for &local in &for_stmt.bindings {
                    self.note_binding(HirBinding::Local(local));
                }
            }
            HirStmt::Close(close) => {
                let from = self.summary.first_close_reg.get_or_insert(close.from_reg);
                *from = (*from).min(close.from_reg);
            }
            _ => {}
        }
    }

    fn visit_lvalue(&mut self, lvalue: &HirLValue) {
        let binding = match lvalue {
            HirLValue::Param(param) => HirBinding::Param(*param),
            HirLValue::Local(local) => HirBinding::Local(*local),
            HirLValue::Temp(temp) => HirBinding::Temp(*temp),
            HirLValue::Upvalue(upvalue) => HirBinding::Upvalue(*upvalue),
            HirLValue::Global(_) | HirLValue::TableAccess(_) => return,
        };
        self.note_binding(binding);
    }
}

fn inline_repeat_tail_temp(
    repeat_stmt: &mut crate::hir::common::HirRepeat,
    scratch: &mut TempUseScratch,
    live_use_counts: &mut [usize],
    reference_captured: &ReferenceCapturedBindings,
    policy: RepeatInlinePolicy,
    facts: &ProtoPromotionFacts,
    inherited_captured_slots: &BTreeSet<HomeSlotKey>,
) -> bool {
    let Some(tail_index) = repeat_stmt.body.stmts.len().checked_sub(1) else {
        return false;
    };
    let Some((temp, value)) = repeat_stmt.body.stmts[tail_index].scalar_temp_assignment() else {
        return false;
    };
    // 候选拒绝[PolicyBoundary]：DebugScope 标注的 temp 保留独立源码 binding 身份。
    // 候选拒绝[SemanticBarrier:Lifetime]：self-reference 或额外 use 需要保留状态写入/temp 值。
    if scratch.has_debug_local_hint(temp)
        || expr_mentions_temp(value, temp)
        || total_use_count(temp, live_use_counts) != 1
        || collect_expr_temp_uses_summary(&repeat_stmt.cond, scratch).count(temp) != 1
    {
        return false;
    }
    let Some(site) = inline_site_in_repeat_condition(&repeat_stmt.cond, temp) else {
        // 候选拒绝[SemanticBarrier:Capture]：唯一 use 位于 closure capture 时，内联会把定义点快照
        // 改成 closure 的按引用 cell/value capture。
        return false;
    };
    if !site.allows(value, policy.readability, policy.safety)
        || expr_requires_ordered_snapshot(value)
            && !temp_precedes_observable_eval_in_expr(
                &repeat_stmt.cond,
                temp,
                expr_observes_eval_order(value),
                reference_captured,
            )
    {
        // 候选拒绝[PolicyBoundary]：repeat condition 服从控制头复杂度展示阈值。
        // 候选拒绝[SemanticBarrier:EvalOrder]：condition 中 temp 前的 observable eval 会在内联后先于 producer value 执行。
        return false;
    }

    let mut captured_slots = inherited_captured_slots.clone();
    for stmt in &repeat_stmt.body.stmts[..tail_index] {
        if collect_stmt_temp_uses(stmt, scratch).count(temp) != 0
            || stmt_writes_temp(stmt, temp)
            || stmt_has_label_or_goto(stmt)
        {
            // 候选拒绝[SemanticBarrier:ControlFlow]：中间 use/write 或非局部控制转移破坏同轮路径证明；见 regress_263#2。
            return false;
        }
        facts.collect_captured_home_slots_in_stmt(stmt, &mut captured_slots);
    }
    if temp_rebinds_captured_slot(temp, facts, &captured_slots) {
        // 候选拒绝[SemanticBarrier:Capture]：closure 引用捕获该 home 时，删除尾写会改变闭包观察值。
        return false;
    }

    let value = value.clone();
    assert_eq!(
        replace_temp_in_expr(&mut repeat_stmt.cond, temp, &value),
        1,
        "validated repeat-tail candidate must have exactly one rewrite site"
    );
    repeat_stmt.body.stmts.pop();
    remove_live_use(live_use_counts, temp);
    true
}

fn temp_rebinds_captured_slot(
    temp: TempId,
    facts: &ProtoPromotionFacts,
    captured_slots: &BTreeSet<HomeSlotKey>,
) -> bool {
    // HIR 子树的 capture 并集可能来自已经返回的分支；原 fixed 写入的 CFG 事实
    // 可以排除该次写入仍有开放 cell。已合并或失去 home 身份的 temp 不借用此证明，
    // 实际捕获当前 binding 的 use 仍由各内联站点保护。
    !facts.temp_definition_reference_unaliased(temp)
        && !facts
            .complete_temp_home_slots(temp)
            .is_disjoint(captured_slots)
}
