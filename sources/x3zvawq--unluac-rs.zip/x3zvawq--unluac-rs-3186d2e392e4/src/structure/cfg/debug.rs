//! 这个文件承载 Structure 层内部 CFG / 图事实 / 数据流的调试片段。
//!
//! CFG/GraphFacts/Dataflow 都是跨 dialect 共享的底层事实，所以观察视图也放在这里；
//! 对外只暴露统一的 Structure dump，由 `src/structure/debug.rs` 负责把这些片段拼起来。

use std::fmt::Write as _;

use crate::debug::{
    DebugColorMode, DebugDetail, DebugFilters, FocusPlan, ProtoSummaryRow, ProtoTreeEntry,
    build_proto_nodes, collect_proto_tree, colorize_debug_text, compute_focus_plan,
    format_breadcrumb, format_display_set, format_proto_summary_row, plan_proto_focus,
};
use crate::transformer::{LowInstr, LoweredChunk, LoweredProto};

use super::common::{
    BlockRef, CfgGraph, DataflowFacts, EffectTag, GraphFacts, OpenUseSources, SideEffectSummary,
    SsaRegMap, SsaValue,
};

#[derive(Debug, Clone, Copy)]
struct DataflowProtoEntry<'a> {
    id: usize,
    parent: Option<usize>,
    depth: usize,
    proto: &'a LoweredProto,
    cfg: &'a CfgGraph,
    facts: &'a DataflowFacts,
}

/// 输出 CFG 的人类可读摘要。
pub(in crate::structure) fn dump_cfg_graph(
    graph: &CfgGraph,
    detail: DebugDetail,
    filters: &DebugFilters,
    color: DebugColorMode,
) -> String {
    let mut output = String::new();
    let entries = collect_proto_tree(graph, |node| node.children.iter());
    let plan = plan_proto_focus(&entries, filters);

    let _ = writeln!(output, "===== Dump CFG =====");
    let _ = writeln!(output, "cfg detail={} protos={}", detail, entries.len());
    write_focus_header(&mut output, filters, &plan);
    let _ = writeln!(output);

    if plan.focus.is_none() {
        let _ = writeln!(output, "  <no proto matched filters>");
        return colorize_debug_text(&output, color);
    }

    for entry in &entries {
        if plan.is_elided(entry.id) {
            let indent = "  ".repeat(entry.depth);
            let _ = writeln!(
                output,
                "{indent}{}",
                format_proto_summary_row(&build_cfg_summary_row(entry)),
            );
            continue;
        }
        if !plan.is_visible(entry.id) {
            continue;
        }

        let cfg = &entry.value.cfg;
        let indent = "  ".repeat(entry.depth);
        let _ = writeln!(
            output,
            "{indent}proto#{} blocks={} edges={} entry=#{} exit=#{} reachable={}",
            entry.id,
            cfg.block_order.len(),
            cfg.edges.len(),
            cfg.entry_block.index(),
            cfg.exit_block.index(),
            format_display_set(&cfg.reachable_blocks),
        );

        if matches!(detail, DebugDetail::Summary) {
            continue;
        }

        let _ = writeln!(output, "{indent}  block listing");
        for block_ref in &cfg.block_order {
            let block = cfg.blocks[block_ref.index()];
            let _ = writeln!(
                output,
                "{indent}    block #{} instrs=[@{}..@{}) preds={} succs={}",
                block_ref.index(),
                block.instrs.start.index(),
                block.instrs.end(),
                format_edge_refs(&cfg.preds[block_ref.index()]),
                format_edge_refs(&cfg.succs[block_ref.index()]),
            );
        }
        let _ = writeln!(
            output,
            "{indent}    block #{} <synthetic-exit> preds={} succs={}",
            cfg.exit_block.index(),
            format_edge_refs(&cfg.preds[cfg.exit_block.index()]),
            format_edge_refs(&cfg.succs[cfg.exit_block.index()]),
        );

        let _ = writeln!(output, "{indent}  edge listing");
        for (edge_index, edge) in cfg.edges.iter().enumerate() {
            let _ = writeln!(
                output,
                "{indent}    edge #{} #{} -> #{} kind={}",
                edge_index,
                edge.from.index(),
                edge.to.index(),
                format_edge_kind(edge.kind),
            );
        }
    }

    colorize_debug_text(&output, color)
}

/// 输出 GraphFacts 的人类可读摘要。
pub(in crate::structure) fn dump_graph_facts_tree(
    graph_facts: &GraphFacts,
    detail: DebugDetail,
    filters: &DebugFilters,
    color: DebugColorMode,
) -> String {
    let mut output = String::new();
    let entries = collect_proto_tree(graph_facts, |node| node.children.iter());
    let plan = plan_proto_focus(&entries, filters);

    let _ = writeln!(output, "===== Dump GraphFacts =====");
    let _ = writeln!(
        output,
        "graph-facts detail={} protos={}",
        detail,
        entries.len()
    );
    write_focus_header(&mut output, filters, &plan);
    let _ = writeln!(output);

    if plan.focus.is_none() {
        let _ = writeln!(output, "  <no proto matched filters>");
        return colorize_debug_text(&output, color);
    }

    for entry in &entries {
        if plan.is_elided(entry.id) {
            let indent = "  ".repeat(entry.depth);
            let _ = writeln!(
                output,
                "{indent}{}",
                format_proto_summary_row(&build_graph_facts_summary_row(entry)),
            );
            continue;
        }
        if !plan.is_visible(entry.id) {
            continue;
        }

        let facts = entry.value;
        let indent = "  ".repeat(entry.depth);
        let _ = writeln!(
            output,
            "{indent}proto#{} rpo={} backedges={} loop_headers={}",
            entry.id,
            format_display_set(&facts.rpo),
            format_edge_refs(&facts.backedges),
            format_display_set(
                facts
                    .natural_loops
                    .iter()
                    .map(|natural_loop| natural_loop.header)
            ),
        );

        if matches!(detail, DebugDetail::Summary) {
            continue;
        }

        let _ = writeln!(output, "{indent}  dominator tree");
        for (block_index, parent) in facts.dominator_tree.parent.iter().enumerate() {
            let _ = writeln!(
                output,
                "{indent}    block #{} parent={}",
                block_index,
                parent
                    .map(|block| format!("#{}", block.index()))
                    .unwrap_or_else(|| "-".to_owned()),
            );
        }

        let _ = writeln!(output, "{indent}  post-dominator tree");
        for (block_index, parent) in facts.post_dominator_tree.parent.iter().enumerate() {
            let _ = writeln!(
                output,
                "{indent}    block #{} parent={}",
                block_index,
                parent
                    .map(|block| format!("#{}", block.index()))
                    .unwrap_or_else(|| "-".to_owned()),
            );
        }

        let _ = writeln!(output, "{indent}  dominance frontier");
        for block_index in 0..facts.dominance_frontier.len() {
            let block = BlockRef(block_index);
            if facts.dominance_frontier_is_empty(block) && matches!(detail, DebugDetail::Normal) {
                continue;
            }
            let _ = writeln!(
                output,
                "{indent}    block #{} frontier={}",
                block_index,
                format_display_set(facts.dominance_frontier_blocks(block)),
            );
        }

        let _ = writeln!(output, "{indent}  natural loops");
        if facts.natural_loops.is_empty() {
            let _ = writeln!(output, "{indent}    <none>");
        } else {
            for natural_loop in &facts.natural_loops {
                let _ = writeln!(
                    output,
                    "{indent}    header=#{} backedges={} blocks={}",
                    natural_loop.header.index(),
                    format_edge_refs(&natural_loop.backedges),
                    format_display_set(&natural_loop.blocks),
                );
            }
        }
    }

    colorize_debug_text(&output, color)
}

/// 输出数据流层的人类可读摘要。
pub(in crate::structure) fn dump_dataflow_facts(
    chunk: &LoweredChunk,
    cfg: &CfgGraph,
    dataflow: &DataflowFacts,
    detail: DebugDetail,
    filters: &DebugFilters,
    color: DebugColorMode,
) -> String {
    let mut output = String::new();
    let entries = collect_dataflow_entries(&chunk.main, cfg, dataflow);
    let plan = plan_focus_dataflow(&entries, filters);

    let _ = writeln!(output, "===== Dump Dataflow =====");
    let _ = writeln!(
        output,
        "dataflow detail={} protos={}",
        detail,
        entries.len()
    );
    write_focus_header(&mut output, filters, &plan);
    let _ = writeln!(output);

    if plan.focus.is_none() {
        let _ = writeln!(output, "  <no proto matched filters>");
        return colorize_debug_text(&output, color);
    }

    for entry in &entries {
        if plan.is_elided(entry.id) {
            let indent = "  ".repeat(entry.depth);
            let _ = writeln!(
                output,
                "{indent}{}",
                format_proto_summary_row(&build_dataflow_summary_row(entry)),
            );
            continue;
        }
        if !plan.is_visible(entry.id) {
            continue;
        }

        let indent = "  ".repeat(entry.depth);
        let _ = writeln!(
            output,
            "{indent}proto#{} defs={} open_defs={} phis={}",
            entry.id,
            entry.facts.defs.len(),
            entry.facts.open_defs.len(),
            entry.facts.phi_candidates.len(),
        );

        if matches!(detail, DebugDetail::Summary) {
            continue;
        }

        let _ = writeln!(output, "{indent}  instr effects");
        for (instr_index, instr) in entry.proto.instrs.iter().enumerate() {
            let effect = &entry.facts.instr_effects[instr_index];
            let summary = &entry.facts.effect_summaries[instr_index];
            let block = entry.cfg.cfg.instr_to_block[instr_index];
            let _ = writeln!(
                output,
                "{indent}    @{instr_index:03} block=#{} {:<18} reads={} writes={} open-use={} open-def={} effects={} roots={:?}",
                block.index(),
                format_low_instr_head(instr),
                format_display_set(effect.fixed_uses()),
                format_display_set(effect.fixed_must_defs()),
                effect
                    .open_use
                    .map(|r| r.to_string())
                    .unwrap_or_else(|| "-".to_owned()),
                effect
                    .open_must_def
                    .map(|r| r.to_string())
                    .unwrap_or_else(|| "-".to_owned()),
                format_effect_tags(summary),
                summary.root_observation,
            );
        }

        let _ = writeln!(output, "{indent}  liveness");
        for block in &entry.cfg.cfg.block_order {
            let _ = writeln!(
                output,
                "{indent}    block #{} live_in={} live_out={} open_in={} open_out={}",
                block.index(),
                format_display_set(entry.facts.live_in_regs(*block)),
                format_display_set(entry.facts.live_out_regs(*block)),
                entry.facts.block_open_live_in(*block),
                entry.facts.block_open_live_out(*block),
            );
        }

        let _ = writeln!(output, "{indent}  phi candidates");
        if entry.facts.phi_candidates.is_empty() {
            let _ = writeln!(output, "{indent}    <none>");
        } else {
            for candidate in &entry.facts.phi_candidates {
                let _ = writeln!(
                    output,
                    "{indent}    block #{} reg={} incoming={}",
                    candidate.block.index(),
                    candidate.reg,
                    format_phi_incoming(&candidate.incoming),
                );
            }
        }

        if matches!(detail, DebugDetail::Verbose) {
            let _ = writeln!(output, "{indent}  block SSA values");
            for block in entry.cfg.cfg.block_order.iter().copied() {
                let _ = writeln!(
                    output,
                    "{indent}    block #{} in={} out={}",
                    block.index(),
                    format_ssa_map(&entry.facts.block_entry_values[block.index()]),
                    format_ssa_map(&entry.facts.block_exit_values[block.index()]),
                );
            }

            let _ = writeln!(output, "{indent}  instruction uses");
            for instr_index in 0..entry.proto.instrs.len() {
                let _ = writeln!(
                    output,
                    "{indent}    @{instr_index:03} fixed={} open={}",
                    format_ssa_map(
                        entry
                            .facts
                            .use_values_at(crate::transformer::InstrRef(instr_index))
                    ),
                    format_open_sources(
                        entry
                            .facts
                            .open_use_sources_at(crate::transformer::InstrRef(instr_index))
                    ),
                );
            }
        }
    }

    colorize_debug_text(&output, color)
}

fn collect_dataflow_entries<'a>(
    proto: &'a LoweredProto,
    cfg: &'a CfgGraph,
    dataflow: &'a DataflowFacts,
) -> Vec<DataflowProtoEntry<'a>> {
    let mut entries = Vec::new();
    struct Frame<'a> {
        proto: &'a LoweredProto,
        cfg: &'a CfgGraph,
        dataflow: &'a DataflowFacts,
        parent: Option<usize>,
        depth: usize,
    }
    let mut pending = vec![Frame {
        proto,
        cfg,
        dataflow,
        parent: None,
        depth: 0,
    }];
    while let Some(frame) = pending.pop() {
        let id = entries.len();
        entries.push(DataflowProtoEntry {
            id,
            parent: frame.parent,
            depth: frame.depth,
            proto: frame.proto,
            cfg: frame.cfg,
            facts: frame.dataflow,
        });
        let child_count = frame
            .proto
            .children
            .len()
            .min(frame.cfg.children.len())
            .min(frame.dataflow.children.len());
        for index in (0..child_count).rev() {
            pending.push(Frame {
                proto: &frame.proto.children[index],
                cfg: &frame.cfg.children[index],
                dataflow: &frame.dataflow.children[index],
                parent: Some(id),
                depth: frame.depth + 1,
            });
        }
    }
    entries
}

fn plan_focus_dataflow(entries: &[DataflowProtoEntry<'_>], filters: &DebugFilters) -> FocusPlan {
    let parents: Vec<Option<usize>> = entries.iter().map(|e| e.parent).collect();
    let nodes = build_proto_nodes(&parents);
    compute_focus_plan(&nodes, &filters.as_focus_request())
}

fn write_focus_header(output: &mut String, filters: &DebugFilters, plan: &FocusPlan) {
    if let Some(proto_id) = filters.proto {
        let _ = writeln!(output, "filters proto=proto#{proto_id}");
    }
    let _ = writeln!(output, "filters proto_depth={}", filters.proto_depth);
    if let Some(breadcrumb) = format_breadcrumb(plan) {
        let _ = writeln!(output, "focus {breadcrumb}");
    }
}

fn build_cfg_summary_row(entry: &ProtoTreeEntry<&CfgGraph>) -> ProtoSummaryRow {
    ProtoSummaryRow {
        id: entry.id,
        name: None,
        first: None,
        lines: None,
        instrs: None,
        children: Some(entry.value.children.len()),
    }
}

fn build_graph_facts_summary_row(entry: &ProtoTreeEntry<&GraphFacts>) -> ProtoSummaryRow {
    ProtoSummaryRow {
        id: entry.id,
        name: None,
        first: None,
        lines: None,
        instrs: None,
        children: Some(entry.value.children.len()),
    }
}

fn build_dataflow_summary_row(entry: &DataflowProtoEntry<'_>) -> ProtoSummaryRow {
    ProtoSummaryRow {
        id: entry.id,
        name: None,
        first: None,
        lines: None,
        instrs: Some(entry.proto.instrs.len()),
        children: Some(entry.proto.children.len()),
    }
}

fn format_edge_refs(edge_refs: &[super::common::EdgeRef]) -> String {
    if edge_refs.is_empty() {
        "-".to_string()
    } else {
        edge_refs
            .iter()
            .map(|edge| edge.to_string())
            .collect::<Vec<_>>()
            .join(", ")
    }
}

fn format_ssa_map(values: &SsaRegMap) -> String {
    if values.iter().next().is_none() {
        "[-]".to_string()
    } else {
        values
            .iter()
            .map(|(reg, value)| format!("{reg}<-{}", format_ssa_value(value)))
            .collect::<Vec<_>>()
            .join(" ")
    }
}

fn format_ssa_value(value: SsaValue) -> String {
    match value {
        SsaValue::Entry(reg) => format!("entry({reg})"),
        SsaValue::Def(def) => def.to_string(),
        SsaValue::Phi(phi) => phi.to_string(),
    }
}

fn format_open_sources(sources: &OpenUseSources) -> String {
    if !sources.has_entry() && sources.defs().is_empty() {
        "[-]".to_string()
    } else {
        let mut values = Vec::new();
        if sources.has_entry() {
            values.push("entry".to_string());
        }
        values.extend(
            sources
                .defs()
                .iter()
                .map(|def| format!("open{}", def.index())),
        );
        format!("[{}]", values.join(", "))
    }
}

fn format_effect_tags(summary: &SideEffectSummary) -> String {
    if !summary.has_effect_tags() {
        "[-]".to_string()
    } else {
        let tags = [
            (EffectTag::Alloc, "alloc"),
            (EffectTag::ReadTable, "read-table"),
            (EffectTag::WriteTable, "write-table"),
            (EffectTag::ReadEnv, "read-env"),
            (EffectTag::WriteEnv, "write-env"),
            (EffectTag::ReadUpvalue, "read-upvalue"),
            (EffectTag::WriteUpvalue, "write-upvalue"),
            (EffectTag::Call, "call"),
            (EffectTag::Metamethod, "metamethod"),
            (EffectTag::MayThrow, "may-throw"),
            (EffectTag::Close, "close"),
            (EffectTag::RegisterClose, "register-close"),
        ];
        format!(
            "[{}]",
            tags.into_iter()
                .filter_map(|(tag, label)| summary.has_effect_tag(tag).then_some(label))
                .collect::<Vec<_>>()
                .join(", ")
        )
    }
}

fn format_phi_incoming(incoming: &[super::common::PhiIncoming]) -> String {
    incoming
        .iter()
        .map(|incoming| {
            let pred = incoming
                .pred
                .map(|pred| pred.to_string())
                .unwrap_or_else(|| "entry".to_string());
            format!("{}:{}", pred, format_ssa_value(incoming.value))
        })
        .collect::<Vec<_>>()
        .join(", ")
}

fn format_low_instr_head(instr: &LowInstr) -> &'static str {
    match instr {
        LowInstr::Move(_instr) => "move",
        LowInstr::LoadNil(_instr) => "load-nil",
        LowInstr::LoadBool(_instr) => "load-bool",
        LowInstr::LoadConst(_instr) => "load-const",
        LowInstr::LoadInteger(_instr) => "load-int",
        LowInstr::LoadNumber(_instr) => "load-num",
        LowInstr::UnaryOp(_instr) => "unary-op",
        LowInstr::BinaryOp(_instr) => "binary-op",
        LowInstr::Concat(_instr) => "concat",
        LowInstr::GetUpvalue(_instr) => "get-upvalue",
        LowInstr::SetUpvalue(_instr) => "set-upvalue",
        LowInstr::GetTable(_instr) => "get-table",
        LowInstr::SetTable(_instr) => "set-table",
        LowInstr::ErrNil(_instr) => "err-nnil",
        LowInstr::TypeGuard(_instr) => "type-guard",
        LowInstr::NewTable(_instr) => "new-table",
        LowInstr::SetList(_instr) => "set-list",
        LowInstr::Call(_instr) => "call",
        LowInstr::TailCall(_instr) => "tail-call",
        LowInstr::VarArg(_instr) => "vararg",
        LowInstr::Return(_instr) => "return",
        LowInstr::Closure(_instr) => "closure",
        LowInstr::Close(_instr) => "close",
        LowInstr::Tbc(_instr) => "tbc",
        LowInstr::NumericForInit(_instr) => "numeric-for-init",
        LowInstr::NumericForLoop(_instr) => "numeric-for-loop",
        LowInstr::GenericForPrep(_instr) => "generic-for-prep",
        LowInstr::GenericForCall(_instr) => "generic-for-call",
        LowInstr::GenericForLoop(_instr) => "generic-for-loop",
        LowInstr::Jump(_instr) => "jump",
        LowInstr::Branch(_instr) => "branch",
    }
}

fn format_edge_kind(kind: super::common::EdgeKind) -> &'static str {
    match kind {
        super::common::EdgeKind::Fallthrough => "fallthrough",
        super::common::EdgeKind::Jump => "jump",
        super::common::EdgeKind::BranchTrue => "branch-true",
        super::common::EdgeKind::BranchFalse => "branch-false",
        super::common::EdgeKind::LoopBody => "loop-body",
        super::common::EdgeKind::LoopExit => "loop-exit",
        super::common::EdgeKind::Return => "return",
        super::common::EdgeKind::TailCall => "tail-call",
    }
}
