//! 冻结结构候选尚不能吸收的跳转证据。
//!
//! 消费 loop、branch 和不可规约区域关系，向最终计划提供 residual transfer 约束；
//! 具体 goto/label 语法由后层表达。

use std::collections::BTreeSet;

use crate::structure::{Cfg, EdgeKind, EdgeRef};
use crate::transformer::LoweredProto;

use super::common::IrreducibleRegion;
use super::common::{
    BranchCandidate, GotoReason, LoopCandidate, LoopKindHint, ResidualTransferEvidence,
};
use super::helpers::block_has_non_control_prefix;
use super::loops::transparent_loop_exit_target;

pub(super) fn analyze_residual_transfers(
    proto: &LoweredProto,
    cfg: &Cfg,
    loop_candidates: &[LoopCandidate],
    branch_candidates: &[BranchCandidate],
    irreducible_regions: &[IrreducibleRegion],
) -> Vec<ResidualTransferEvidence> {
    let mut residuals = BTreeSet::new();
    let membership = LoopMembershipIndex::new(cfg, loop_candidates);

    for (candidate_index, loop_candidate) in loop_candidates.iter().enumerate() {
        for &edge_ref in &membership.entry_edges_by_candidate[candidate_index] {
            let edge = cfg.edges[edge_ref.index()];
            if edge.to != loop_candidate.header {
                residuals.insert(ResidualTransferEvidence {
                    edge: edge_ref,
                    reason: GotoReason::MultiEntryRegion,
                });
            }
        }

        for edge_ref in &loop_candidate.backedges {
            if backedge_crosses_nested_loop(
                proto,
                cfg,
                loop_candidates,
                &membership.body_scope_owners_by_block,
                &membership.body_scope_exit_targets_by_candidate,
                loop_candidate,
                *edge_ref,
            ) {
                residuals.insert(ResidualTransferEvidence {
                    edge: *edge_ref,
                    reason: GotoReason::CrossLoopContinueLike,
                });
            }
        }

        if let Some(continue_target) = loop_candidate.continue_target {
            // numeric-for 和 repeat-until 的 continue target block 可能在 terminator
            // 前面挂着属于 loop body tail 的普通语句（如 state carry 或 body 尾部
            // 计算）。这些前缀不是循环控制，跳到 block 开头只是让 branch merge 回
            // body tail 的自然路径，语义上不是 continue。
            //
            // generic-for 的 continue target 是 header（GenericForCall +
            // GenericForLoop）。这里的前缀 GenericForCall 是循环控制的一部分（调用
            // 迭代器），跳到 header 等价于"重新迭代"，所以仍应视为 continue。
            let tail_carries_body = matches!(
                loop_candidate.kind_hint,
                LoopKindHint::NumericForLike
                    | LoopKindHint::RepeatLike
                    | LoopKindHint::WhileTrueLike
            ) && block_has_non_control_prefix(proto, cfg, continue_target);
            for block in &loop_candidate.blocks {
                for edge_ref in &cfg.succs[block.index()] {
                    let edge = cfg.edges[edge_ref.index()];

                    if edge.to == continue_target
                        && !tail_carries_body
                        && !loop_candidate.backedges.contains(edge_ref)
                        && !loop_candidate.continue_edges.contains(edge_ref)
                        && edge.kind != EdgeKind::Fallthrough
                        && cfg.reachable_blocks.contains(&edge.from)
                        // 如果 edge.from 是某个 branch candidate 的 header，
                        // 且 continue_target 是它的一个分支臂或 merge，
                        // 那么这条边会被结构化 branch lowering 自然吸收
                        // （表现为 `if cond then body end` 的自然落回），
                        // 不应标记为 unstructured continue。
                        && !is_branch_arm_to_target(
                            branch_candidates,
                            edge.from,
                            continue_target,
                        )
                        && !is_same_header_nested_loop_exit(
                            loop_candidates,
                            &membership.exit_owners_by_block,
                            loop_candidate,
                            edge.from,
                        )
                        && !is_degenerate_branch_to_target(cfg, edge.from, continue_target)
                    {
                        residuals.insert(ResidualTransferEvidence {
                            edge: *edge_ref,
                            reason: GotoReason::UnstructuredContinueLike,
                        });
                    }
                }
            }
        }
    }

    for irreducible in irreducible_regions {
        for edge_ref in &irreducible.entry_edges {
            residuals.insert(ResidualTransferEvidence {
                edge: *edge_ref,
                reason: GotoReason::IrreducibleFlow,
            });
        }
    }

    residuals.into_iter().collect()
}

/// loop 候选 membership 的单次稠密投影。
///
/// candidate identity 仍由切片下标精确区分；same-header 与退化候选不会被按 header
/// 合并。入口边直接从 CFG edge 扫描投影到 owner，body scope 的真实出口也在同轮缓存，
/// 避免每条 backedge 再扫描完整候选区域。
struct LoopMembershipIndex {
    body_scope_owners_by_block: Vec<Vec<usize>>,
    body_scope_exit_targets_by_candidate: Vec<Vec<crate::structure::BlockRef>>,
    exit_owners_by_block: Vec<Vec<usize>>,
    entry_edges_by_candidate: Vec<Vec<EdgeRef>>,
}

impl LoopMembershipIndex {
    fn new(cfg: &Cfg, candidates: &[LoopCandidate]) -> Self {
        let mut core_owners_by_block = vec![Vec::new(); cfg.blocks.len()];
        let mut body_scope_owners_by_block = vec![Vec::new(); cfg.blocks.len()];
        let mut body_scope_exit_targets_by_candidate = vec![Vec::new(); candidates.len()];
        let mut exit_owners_by_block = vec![Vec::new(); cfg.blocks.len()];
        for (candidate_index, candidate) in candidates.iter().enumerate() {
            for block in &candidate.blocks {
                core_owners_by_block[block.index()].push(candidate_index);
            }
            for block in &candidate.body_scope_blocks {
                body_scope_owners_by_block[block.index()].push(candidate_index);
                if cfg.reachable_blocks.contains(block) {
                    body_scope_exit_targets_by_candidate[candidate_index].extend(
                        cfg.succs[block.index()]
                            .iter()
                            .map(|edge_ref| cfg.edges[edge_ref.index()].to)
                            .filter(|target| !candidate.body_scope_blocks.contains(target)),
                    );
                }
            }
            for block in &candidate.exits {
                exit_owners_by_block[block.index()].push(candidate_index);
            }
        }

        let mut entry_edges_by_candidate = vec![Vec::new(); candidates.len()];
        for (edge_index, edge) in cfg.edges.iter().enumerate() {
            if !cfg.reachable_blocks.contains(&edge.from) {
                continue;
            }
            let source_owners = &core_owners_by_block[edge.from.index()];
            for &candidate_index in &core_owners_by_block[edge.to.index()] {
                if source_owners.binary_search(&candidate_index).is_err() {
                    entry_edges_by_candidate[candidate_index].push(EdgeRef(edge_index));
                }
            }
        }

        Self {
            body_scope_owners_by_block,
            body_scope_exit_targets_by_candidate,
            exit_owners_by_block,
            entry_edges_by_candidate,
        }
    }
}

fn backedge_crosses_nested_loop(
    proto: &LoweredProto,
    cfg: &Cfg,
    candidates: &[LoopCandidate],
    body_scope_owners_by_block: &[Vec<usize>],
    body_scope_exit_targets_by_candidate: &[Vec<crate::structure::BlockRef>],
    outer: &LoopCandidate,
    edge_ref: EdgeRef,
) -> bool {
    let edge = cfg.edges[edge_ref.index()];
    edge.to == outer.header
        && body_scope_owners_by_block[edge.from.index()]
            .iter()
            .any(|index| {
                let inner = &candidates[*index];
                inner.header != outer.header
                    && inner.blocks.len() < outer.blocks.len()
                    && inner.blocks.is_subset(&outer.body_scope_blocks)
                    && !nested_loop_body_scope_exits_to_outer_header(
                        proto,
                        cfg,
                        &body_scope_exit_targets_by_candidate[*index],
                        outer.header,
                    )
            })
}

fn nested_loop_body_scope_exits_to_outer_header(
    proto: &LoweredProto,
    cfg: &Cfg,
    exit_targets: &[crate::structure::BlockRef],
    outer_header: crate::structure::BlockRef,
) -> bool {
    !exit_targets.is_empty()
        && exit_targets.iter().all(|target| {
            *target == outer_header
                || transparent_loop_exit_target(proto, cfg, *target) == Some(outer_header)
        })
}

fn is_same_header_nested_loop_exit(
    candidates: &[LoopCandidate],
    exit_owners_by_block: &[Vec<usize>],
    outer: &LoopCandidate,
    from: crate::structure::BlockRef,
) -> bool {
    // 内层 exit block 属于外层区域却不属于内层 core；它汇入外层条件是正常的
    // 嵌套控制流，不能因为目标恰是外层 continue target 就要求 goto。
    exit_owners_by_block[from.index()]
        .iter()
        .copied()
        .map(|index| &candidates[index])
        .any(|inner| {
            inner.header == outer.header
                && inner.blocks.len() < outer.blocks.len()
                && inner.blocks.is_subset(&outer.blocks)
        })
}

fn is_degenerate_branch_to_target(
    cfg: &Cfg,
    from: crate::structure::BlockRef,
    target: crate::structure::BlockRef,
) -> bool {
    cfg.branch_edges(from)
        .is_some_and(|(then_edge, else_edge)| {
            cfg.edges[then_edge.index()].to == target && cfg.edges[else_edge.index()].to == target
        })
}

/// 判断 `from` 是否是某个 branch candidate 的 header，且该 branch 的某个分支臂
/// 直接指向 `target`。这种边会被结构化 branch lowering 自然吸收为
/// `if cond then ... end` 的隐式 fallthrough，不需要标记为 unstructured continue。
fn is_branch_arm_to_target(
    branch_candidates: &[BranchCandidate],
    from: crate::structure::BlockRef,
    target: crate::structure::BlockRef,
) -> bool {
    branch_candidates.iter().any(|candidate| {
        candidate.header == from
            && (candidate.then_entry == target
                || candidate.else_entry == Some(target)
                || candidate.merge == Some(target))
    })
}
