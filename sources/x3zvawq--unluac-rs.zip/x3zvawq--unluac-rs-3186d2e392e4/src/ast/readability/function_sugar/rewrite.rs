//! 协调 function-sugar 的局部规则并在当前 block 上收敛。
//!
//! 消费合法 AST 与各规则的证明结果，保持 HIR 发布的 capture 和声明身份。

use super::super::ReadabilityContext;
use super::super::binding_flow::{
    BindingUseIndex, BindingWriteIndex, MutableSnapshotNames, mutable_snapshot_names_in_block,
};
use super::chain::try_chain_local_method_call_stmt;
use super::constructor::{
    ConstructorRunFacts, try_inline_terminal_constructor_call,
    try_inline_terminal_constructor_fields,
};
use super::direct::{lower_declared_function, lower_direct_function_stmt};
use super::forwarded::try_lower_forwarded_function_stmt;
use super::method_alias::{
    MethodRewriteTransactionIndex, recover_proven_direct_method_calls,
    try_recover_certified_method_setup, try_recover_method_alias_stmt,
};
use crate::ast::common::{
    AstBlock, AstCallKind, AstExpr, AstFunctionExpr, AstLValue, AstModule, AstStmt, AstTableField,
    AstTableKey, AstTargetDialect,
};

pub(in crate::ast::readability) fn apply(
    module: &mut AstModule,
    context: ReadabilityContext,
) -> bool {
    let mutable_snapshots = mutable_snapshot_names_in_block(&module.body);
    let direct_method_changed = recover_proven_direct_method_calls(module);
    let method_transactions =
        MethodRewriteTransactionIndex::for_function_body(module.entry_function, &module.body);
    direct_method_changed
        | rewrite_block(
            &mut module.body,
            context.target,
            &mutable_snapshots,
            None,
            &method_transactions,
        )
        | super::method_decl::apply(module)
}

fn rewrite_block(
    block: &mut AstBlock,
    target: AstTargetDialect,
    mutable_snapshots: &MutableSnapshotNames,
    trailing_expr: Option<&AstExpr>,
    method_transactions: &MethodRewriteTransactionIndex,
) -> bool {
    let mut changed = false;
    for stmt in &mut block.stmts {
        changed |= rewrite_nested(stmt, target, mutable_snapshots, method_transactions);
    }

    let old_stmts = std::mem::take(&mut block.stmts);
    // LocalId/SyntheticLocalId are numbered per function. Current-function counting still
    // records explicit capture provenance, while descending into child bodies would conflate
    // unrelated bindings that happen to reuse the same numeric id.
    let use_index = BindingUseIndex::for_stmts_with_trailing_expr(&old_stmts, trailing_expr);
    let write_index = BindingWriteIndex::for_stmts(&old_stmts);
    let constructor_runs = ConstructorRunFacts::for_stmts(&old_stmts);

    let mut new_stmts = Vec::with_capacity(old_stmts.len());
    let mut old_stmts = old_stmts.into_iter();
    let mut index = 0;
    while let Some(first) = old_stmts.as_slice().first() {
        let remaining = old_stmts.as_slice();
        let rewritten = try_recover_certified_method_setup(remaining, method_transactions)
            .or_else(|| lower_declared_function(remaining))
            .or_else(|| try_inline_terminal_constructor_fields(remaining))
            .or_else(|| {
                try_inline_terminal_constructor_call(
                    remaining,
                    &use_index,
                    &constructor_runs,
                    index,
                    mutable_snapshots,
                )
            })
            .or_else(|| {
                try_recover_method_alias_stmt(
                    remaining,
                    &use_index,
                    &write_index,
                    index,
                    mutable_snapshots,
                )
            })
            .or_else(|| try_chain_local_method_call_stmt(remaining, &use_index, index))
            .or_else(|| {
                try_lower_forwarded_function_stmt(
                    remaining,
                    &use_index,
                    index,
                    target,
                    mutable_snapshots,
                )
            })
            .or_else(|| {
                lower_direct_function_stmt(first, target, mutable_snapshots).map(|stmt| (stmt, 1))
            });

        if let Some((stmt, consumed)) = rewritten {
            new_stmts.push(stmt);
            changed = true;
            old_stmts.by_ref().take(consumed).for_each(drop);
            index += consumed;
        } else {
            // 索引保留原始坐标，未命中的语句直接移交；父块不再复制已改写的子树。
            new_stmts.push(old_stmts.next().expect("remaining statement checked above"));
            index += 1;
        }
    }

    block.stmts = new_stmts;
    changed
}

fn rewrite_nested(
    stmt: &mut AstStmt,
    target: AstTargetDialect,
    mutable_snapshots: &MutableSnapshotNames,
    method_transactions: &MethodRewriteTransactionIndex,
) -> bool {
    match stmt {
        AstStmt::If(if_stmt) => {
            let mut changed = rewrite_block(
                &mut if_stmt.then_block,
                target,
                mutable_snapshots,
                None,
                method_transactions,
            );
            if let Some(else_block) = &mut if_stmt.else_block {
                changed |= rewrite_block(
                    else_block,
                    target,
                    mutable_snapshots,
                    None,
                    method_transactions,
                );
            }
            changed |= rewrite_function_exprs_in_expr(&mut if_stmt.cond, target);
            changed
        }
        AstStmt::While(while_stmt) => {
            rewrite_function_exprs_in_expr(&mut while_stmt.cond, target)
                | rewrite_block(
                    &mut while_stmt.body,
                    target,
                    mutable_snapshots,
                    None,
                    method_transactions,
                )
        }
        AstStmt::Repeat(repeat_stmt) => {
            // `until` 与 repeat body 共用词法作用域；条件 use 必须参与正文候选的删除证明。
            let body_changed = rewrite_block(
                &mut repeat_stmt.body,
                target,
                mutable_snapshots,
                Some(&repeat_stmt.cond),
                method_transactions,
            );
            body_changed | rewrite_function_exprs_in_expr(&mut repeat_stmt.cond, target)
        }
        AstStmt::NumericFor(numeric_for) => {
            let mut changed = rewrite_function_exprs_in_expr(&mut numeric_for.start, target);
            changed |= rewrite_function_exprs_in_expr(&mut numeric_for.limit, target);
            changed |= rewrite_function_exprs_in_expr(&mut numeric_for.step, target);
            changed |= rewrite_block(
                &mut numeric_for.body,
                target,
                mutable_snapshots,
                None,
                method_transactions,
            );
            changed
        }
        AstStmt::GenericFor(generic_for) => {
            let mut changed = false;
            for expr in &mut generic_for.iterator {
                changed |= rewrite_function_exprs_in_expr(expr, target);
            }
            changed |= rewrite_block(
                &mut generic_for.body,
                target,
                mutable_snapshots,
                None,
                method_transactions,
            );
            changed
        }
        AstStmt::DoBlock(block) => {
            rewrite_block(block, target, mutable_snapshots, None, method_transactions)
        }
        AstStmt::FunctionDecl(function_decl) => {
            rewrite_function_expr(&mut function_decl.func, target)
        }
        AstStmt::LocalFunctionDecl(local_function_decl) => {
            rewrite_function_expr(&mut local_function_decl.func, target)
        }
        AstStmt::LocalDecl(local_decl) => {
            let mut changed = false;
            for value in &mut local_decl.values {
                changed |= rewrite_function_exprs_in_expr(value, target);
            }
            changed
        }
        AstStmt::GlobalDecl(global_decl) => {
            let mut changed = false;
            for value in &mut global_decl.values {
                changed |= rewrite_function_exprs_in_expr(value, target);
            }
            changed
        }
        AstStmt::Assign(assign) => {
            let mut changed = false;
            for target_lvalue in &mut assign.targets {
                changed |= rewrite_function_exprs_in_lvalue(target_lvalue, target);
            }
            for value in &mut assign.values {
                changed |= rewrite_function_exprs_in_expr(value, target);
            }
            changed
        }
        AstStmt::CallStmt(call_stmt) => rewrite_function_exprs_in_call(&mut call_stmt.call, target),
        AstStmt::Return(ret) => {
            let mut changed = false;
            for value in &mut ret.values {
                changed |= rewrite_function_exprs_in_expr(value, target);
            }
            changed
        }
        AstStmt::Break
        | AstStmt::Continue
        | AstStmt::Goto(_)
        | AstStmt::Label(_)
        | AstStmt::Error(_) => false,
    }
}

fn rewrite_function_expr(function: &mut AstFunctionExpr, target: AstTargetDialect) -> bool {
    let mutable_snapshots = mutable_snapshot_names_in_block(&function.body);
    let method_transactions =
        MethodRewriteTransactionIndex::for_function_body(function.function, &function.body);
    rewrite_block(
        &mut function.body,
        target,
        &mutable_snapshots,
        None,
        &method_transactions,
    )
}

fn rewrite_function_exprs_in_call(call: &mut AstCallKind, target: AstTargetDialect) -> bool {
    match call {
        AstCallKind::Call(call) => {
            let mut changed = rewrite_function_exprs_in_expr(&mut call.callee, target);
            for arg in &mut call.args {
                changed |= rewrite_function_exprs_in_expr(arg, target);
            }
            changed
        }
        AstCallKind::MethodCall(call) => {
            let mut changed = rewrite_function_exprs_in_expr(&mut call.receiver, target);
            for arg in &mut call.args {
                changed |= rewrite_function_exprs_in_expr(arg, target);
            }
            changed
        }
    }
}

fn rewrite_function_exprs_in_lvalue(
    target_lvalue: &mut AstLValue,
    target: AstTargetDialect,
) -> bool {
    match target_lvalue {
        AstLValue::Name(_) => false,
        AstLValue::FieldAccess(access) => rewrite_function_exprs_in_expr(&mut access.base, target),
        AstLValue::IndexAccess(access) => {
            rewrite_function_exprs_in_expr(&mut access.base, target)
                | rewrite_function_exprs_in_expr(&mut access.index, target)
        }
    }
}

fn rewrite_function_exprs_in_expr(expr: &mut AstExpr, target: AstTargetDialect) -> bool {
    match expr {
        AstExpr::IfExpr(branch) => {
            rewrite_function_exprs_in_expr(&mut branch.cond, target)
                | rewrite_function_exprs_in_expr(&mut branch.then_expr, target)
                | rewrite_function_exprs_in_expr(&mut branch.else_expr, target)
        }
        AstExpr::FieldAccess(access) => rewrite_function_exprs_in_expr(&mut access.base, target),
        AstExpr::IndexAccess(access) => {
            rewrite_function_exprs_in_expr(&mut access.base, target)
                | rewrite_function_exprs_in_expr(&mut access.index, target)
        }
        AstExpr::Unary(unary) => rewrite_function_exprs_in_expr(&mut unary.expr, target),
        AstExpr::Binary(binary) => {
            rewrite_function_exprs_in_expr(&mut binary.lhs, target)
                | rewrite_function_exprs_in_expr(&mut binary.rhs, target)
        }
        AstExpr::LogicalAnd(logical) | AstExpr::LogicalOr(logical) => {
            rewrite_function_exprs_in_expr(&mut logical.lhs, target)
                | rewrite_function_exprs_in_expr(&mut logical.rhs, target)
        }
        AstExpr::Call(call) => {
            let mut changed = rewrite_function_exprs_in_expr(&mut call.callee, target);
            for arg in &mut call.args {
                changed |= rewrite_function_exprs_in_expr(arg, target);
            }
            changed
        }
        AstExpr::MethodCall(call) => {
            let mut changed = rewrite_function_exprs_in_expr(&mut call.receiver, target);
            for arg in &mut call.args {
                changed |= rewrite_function_exprs_in_expr(arg, target);
            }
            changed
        }
        AstExpr::SingleValue(expr) => rewrite_function_exprs_in_expr(expr, target),
        AstExpr::TableConstructor(table) => {
            let mut changed = false;
            for field in &mut table.fields {
                match field {
                    AstTableField::Array(value) => {
                        changed |= rewrite_function_exprs_in_expr(value, target);
                    }
                    AstTableField::Record(record) => {
                        if let AstTableKey::Expr(key) = &mut record.key {
                            changed |= rewrite_function_exprs_in_expr(key, target);
                        }
                        changed |= rewrite_function_exprs_in_expr(&mut record.value, target);
                    }
                }
            }
            changed
        }
        AstExpr::FunctionExpr(function) => rewrite_function_expr(function, target),
        AstExpr::Nil
        | AstExpr::Boolean(_)
        | AstExpr::Integer(_)
        | AstExpr::Number(_)
        | AstExpr::String(_)
        | AstExpr::Int64(_)
        | AstExpr::UInt64(_)
        | AstExpr::Vector(_)
        | AstExpr::Complex { .. }
        | AstExpr::Var(_)
        | AstExpr::CaptureInitializer(_)
        | AstExpr::VarArg
        | AstExpr::Error(_) => false,
    }
}
