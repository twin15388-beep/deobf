unit LuaSSA;

{
  LuaSSA.pas - Control Flow Graph construction, SSA lifting, Phi-insertion,
               and renaming pass for Lua 5.1 bytecode.

  Pipeline:
    1. BuildCFG        – partition instructions into basic blocks, add edges.
    2. ComputeDominators – iterative dataflow (Cooper/Harvey/Kennedy).
    3. ComputeDF         – dominance frontier sets.
    4. InsertPhiFunctions – standard liveness-based Phi placement.
    5. RenamePass        – walk dominator tree, rename defs/uses.

  IR node kinds cover every Lua 5.x opcode.  Phi-nodes are represented as
  SSA_PHI with a variable-length Operands array.

  Memory: call FreeSSAFunction to release all allocations.
}

{$mode objfpc}{$H+}

interface

uses
  SysUtils, LuaChunk, LuaOpcodes;

{ ======================================================================
  SSA value reference
  ====================================================================== }
type
  { Every SSA value is identified by (Register, Version).
    Register -1 = "no value" / undefined.
    Register -2 = constant slot (used for RK constants embedded in IR). }
  TSSARef = record
    Reg     : Integer;   { Lua register index, or -1/−2 }
    Version : Integer;   { SSA rename count             }
    ConstIdx: Integer;   { valid when Reg = -2          }
  end;

const
  SSA_NO_REF    : TSSARef = (Reg: -1; Version: 0; ConstIdx: 0);
  SSA_CONST_REG = -2;

function MakeRef(Reg, Ver: Integer): TSSARef;
function MakeConstRef(Idx: Integer): TSSARef;
function RefEqual(const A, B: TSSARef): Boolean;
function RefToStr(const R: TSSARef): AnsiString;

{ ======================================================================
  SSA node kinds
  ====================================================================== }
type
  TSSAKind = (
    SSA_NOP,
    SSA_PHI,
    SSA_MOVE,
    SSA_LOADK,
    SSA_LOADBOOL,
    SSA_LOADNIL,
    SSA_GETUPVAL,
    SSA_GETGLOBAL,
    SSA_GETTABLE,
    SSA_SETGLOBAL,
    SSA_SETUPVAL,
    SSA_SETTABLE,
    SSA_NEWTABLE,
    SSA_SELF,
    SSA_BINOP,      { ADD SUB MUL DIV MOD POW }
    SSA_UNOP,       { UNM NOT LEN }
    SSA_CONCAT,
    SSA_JUMP,
    SSA_BRANCH,     { EQ LT LE TEST TESTSET }
    SSA_CALL,
    SSA_TAILCALL,
    SSA_RETURN,
    SSA_FORPREP,
    SSA_FORLOOP,
    SSA_TFORLOOP,
    SSA_SETLIST,
    SSA_CLOSE,
    SSA_CLOSURE,
    SSA_VARARG
  );

  TBinOp = (bopAdd, bopSub, bopMul, bopDiv, bopMod, bopPow,
             bopIDiv, bopBAnd, bopBOr, bopBXor, bopSHL, bopSHR);
  TUnOp  = (uopNeg, uopNot, uopLen, uopBNot);
  TRelOp = (ropEQ, ropLT, ropLE, ropTest, ropTestSet);

  { ------------------------------------------------------------------ }
  {  Single SSA instruction                                             }
  { ------------------------------------------------------------------ }
  PSSANode = ^TSSANode;
  TSSANode = record
    Kind      : TSSAKind;
    PC        : Integer;       { source instruction index (0-based) }
    Line      : Integer;       { source line number, -1 if unknown  }
    Dest      : TSSARef;       { output value (may be SSA_NO_REF)   }

    { generic operand slots }
    OpA       : TSSARef;
    OpB       : TSSARef;
    OpC       : TSSARef;

    { Phi-node: list of incoming (value, predecessor-block-index) pairs }
    Operands  : array of TSSARef;   { for SSA_PHI: one per predecessor }
    PhiBlocks : array of Integer;   { predecessor block indices }

    { operator selectors }
    BinOp : TBinOp;
    UnOp  : TUnOp;
    RelOp : TRelOp;
    Invert: Boolean;  { for EQ/LT/LE: result is inverted if A=1 }

    { jump targets (block indices) }
    TargetTrue  : Integer;   { -1 = fall-through / not used }
    TargetFalse : Integer;

    { raw integer immediates }
    ImmA, ImmB, ImmC: Integer;

    { pointer into proto's constant / sub-proto table }
    ConstIdx  : Integer;   { LOADK, GETGLOBAL, SETGLOBAL, CLOSURE }
    UpvalIdx  : Integer;   { GETUPVAL, SETUPVAL }

    { SSA-versioned argument references for CALL/TAILCALL/RETURN }
    ArgRefs   : array of TSSARef;

    { LocVar binding: index into Proto^.LocVars[], -1 = no LocVar (temp) }
    LocVarIdx : Integer;
    { True for LOADNIL pseudo-def nodes (per-register) - metadata only, not emitted }
    IsMetaOnly: Boolean;
  end;

  { ------------------------------------------------------------------ }
  {  Basic block                                                        }
  { ------------------------------------------------------------------ }
  PBasicBlock = ^TBasicBlock;
  TBasicBlock = record
    Index      : Integer;
    StartPC    : Integer;     { first instruction PC (inclusive) }
    EndPC      : Integer;     { last  instruction PC (inclusive) }
    Nodes      : array of PSSANode;
    Succs      : array of Integer;   { successor block indices }
    Preds      : array of Integer;   { predecessor block indices }
    { dominator tree }
    IDom       : Integer;    { immediate dominator index, -1 for entry }
    DomChildren: array of Integer;
    { dominance frontier }
    DF         : array of Integer;
  end;

  { ------------------------------------------------------------------ }
  {  Implicit def record: tracks (Reg,Version) --> parent node for      }
  {  extra registers defined by TFORLOOP/CALL(C>=3)/SELF that have    }
  {  no SSA node with matching Dest in AllNodes.                      }
  { ------------------------------------------------------------------ }
  TImplicitDef = record
    Reg: Integer;
    Version: Integer;
    ParentNode: PSSANode;
  end;

  { ------------------------------------------------------------------ }
  {  Complete SSA function (one per TProto)                            }
  { ------------------------------------------------------------------ }
  TSSAFunction = record
    Proto   : PProto;      { source proto (not owned)    }
    Blocks  : array of TBasicBlock;
    AllNodes: array of PSSANode;  { flat list for easy freeing }
    NumRegs : Integer;     { = Proto^.MaxStack            }
    LuaVersion : Byte;     { $51, $52, $53, $54, $55 - for version-specific logic }
    ImplicitDefs: array of TImplicitDef;
  end;
  PSSAFunction = ^TSSAFunction;

{ ======================================================================
  Public API
  ====================================================================== }

{ Build SSA function from a parsed proto (Lua 5.1 only, existing path) }
function BuildSSAFunction(Proto: PProto): PSSAFunction; overload;

{ Build SSA function using a version-aware opcode table.
  When OT is nil, falls back to the existing 5.1 path. }
function BuildSSAFunction(Proto: PProto; const OT: POpcodeTable): PSSAFunction; overload;

{ Add a synthetic integer constant to Proto^.K[], return its index }
function AddSyntheticConst(Proto: PProto; IVal: Int64): Integer;

{ Add a synthetic float constant to Proto^.K[], return its index }
function AddSyntheticFloatConst(Proto: PProto; FVal: Double): Integer;

{ Dump SSA IR to stdout for debugging }
procedure DumpSSA(const F: PSSAFunction);

{ Free all SSA structures }
procedure FreeSSAFunction(F: PSSAFunction);

implementation

{ ======================================================================
  TSSARef helpers
  ====================================================================== }

function MakeRef(Reg, Ver: Integer): TSSARef;
begin
  Result.Reg      := Reg;
  Result.Version  := Ver;
  Result.ConstIdx := 0;
end;

function MakeConstRef(Idx: Integer): TSSARef;
begin
  Result.Reg      := SSA_CONST_REG;
  Result.Version  := 0;
  Result.ConstIdx := Idx;
end;

function RefEqual(const A, B: TSSARef): Boolean;
begin
  Result := (A.Reg = B.Reg) and (A.Version = B.Version) and
            (A.ConstIdx = B.ConstIdx);
end;

function RefToStr(const R: TSSARef): AnsiString;
begin
  if R.Reg = -1 then
    Result := '_'
  else if R.Reg = SSA_CONST_REG then
    Result := 'K' + IntToStr(R.ConstIdx)
  else
    Result := 'R' + IntToStr(R.Reg) + '_' + IntToStr(R.Version);
end;

{ ======================================================================
  Helper: new SSANode
  ====================================================================== }

function NewNode(Kind: TSSAKind; PC, Line: Integer): PSSANode;
begin
  New(Result);
  Result^ := Default(TSSANode);
  Result^.Kind        := Kind;
  Result^.PC          := PC;
  Result^.Line        := Line;
  Result^.Dest        := SSA_NO_REF;
  Result^.OpA         := SSA_NO_REF;
  Result^.OpB         := SSA_NO_REF;
  Result^.OpC         := SSA_NO_REF;
  Result^.TargetTrue  := -1;
  Result^.TargetFalse := -1;
  Result^.ConstIdx    := -1;
  Result^.UpvalIdx    := -1;
  Result^.LocVarIdx   := -1;
  Result^.IsMetaOnly  := False;
end;

{ ======================================================================
  Step 1 – Build CFG
  ====================================================================== }

{ Returns true if opcode causes a block boundary (is a leader or ends a block) }
function IsJump(Op: TOpCode): Boolean;
begin
  Result := Op in [OP_JMP, OP_EQ, OP_LT, OP_LE, OP_TEST, OP_TESTSET,
                   OP_FORLOOP, OP_FORPREP, OP_TFORLOOP,
                   OP_RETURN, OP_TAILCALL];
end;

procedure ComputeLeaders(const Proto: PProto; var Leaders: array of Boolean);
var
  I, N, Target: Integer;
  Inst: TInstruction;
  Op: TOpCode;
begin
  N := Length(Proto^.Code);
  { PC 0 is always a leader }
  Leaders[0] := True;
  I := 0;
  while I < N do begin
    Inst := Proto^.Code[I];
    Op   := GET_OPCODE(Inst);
    case Op of
      OP_JMP: begin
        Target := I + 1 + GETARG_sBx(Inst);
        if (Target >= 0) and (Target < N) then Leaders[Target] := True;
        if I + 1 < N then Leaders[I + 1] := True;
      end;
      OP_EQ, OP_LT, OP_LE, OP_TEST, OP_TESTSET: begin
        { These skip the next instruction if condition is false;
          the instruction AFTER the skip target is also a leader }
        if I + 1 < N then Leaders[I + 1] := True;
        if I + 2 < N then Leaders[I + 2] := True;
        { the JMP that follows often gives the actual branch target }
      end;
      OP_FORLOOP: begin
        Target := I + 1 + GETARG_sBx(Inst);
        if (Target >= 0) and (Target < N) then Leaders[Target] := True;
        if I + 1 < N then Leaders[I + 1] := True;
      end;
      OP_FORPREP: begin
        Target := I + 1 + GETARG_sBx(Inst);
        if (Target >= 0) and (Target < N) then Leaders[Target] := True;
        if I + 1 < N then Leaders[I + 1] := True;
      end;
      OP_TFORLOOP: begin
        { followed by a JMP; the instruction after the JMP is also a leader }
        if I + 1 < N then Leaders[I + 1] := True;
        if I + 2 < N then Leaders[I + 2] := True;
      end;
      OP_LOADBOOL: begin
        { LOADBOOL with C=1 skips the next instruction }
        if GETARG_C(Inst) <> 0 then begin
          if I + 1 < N then Leaders[I + 1] := True;
          if I + 2 < N then Leaders[I + 2] := True;
        end;
      end;
      OP_RETURN, OP_TAILCALL: begin
        if I + 1 < N then Leaders[I + 1] := True;
      end;
    end;
    Inc(I);
  end;
end;

{ Map from PC to block index }
function PCToBlock(const PCMap: array of Integer; PC: Integer): Integer;
begin
  if (PC >= 0) and (PC < Length(PCMap)) then
    Result := PCMap[PC]
  else
    Result := -1;
end;

procedure BuildCFG(SF: PSSAFunction);
var
  Proto : PProto;
  N     : Integer;
  Leaders  : array of Boolean;
  PCMap    : array of Integer;   { PC -> block index }
  I, BIdx  : Integer;
  Inst     : TInstruction;
  Op       : TOpCode;
  Target   : Integer;
  NBB      : Integer;
  Blk      : PBasicBlock;

  procedure AddSucc(Src, Dst: Integer);
  var J: Integer;
  begin
    if Dst < 0 then Exit;
    for J := 0 to High(SF^.Blocks[Src].Succs) do
      if SF^.Blocks[Src].Succs[J] = Dst then Exit; { no duplicate }
    SetLength(SF^.Blocks[Src].Succs, Length(SF^.Blocks[Src].Succs) + 1);
    SF^.Blocks[Src].Succs[High(SF^.Blocks[Src].Succs)] := Dst;
    SetLength(SF^.Blocks[Dst].Preds, Length(SF^.Blocks[Dst].Preds) + 1);
    SF^.Blocks[Dst].Preds[High(SF^.Blocks[Dst].Preds)] := Src;
  end;

begin
  Proto := SF^.Proto;
  N     := Length(Proto^.Code);
  if N = 0 then Exit;

  SetLength(Leaders, N);
  SetLength(PCMap, N);
  for I := 0 to N - 1 do begin Leaders[I] := False; PCMap[I] := -1; end;

  ComputeLeaders(Proto, Leaders);

  { Count blocks and assign block indices }
  NBB := 0;
  for I := 0 to N - 1 do
    if Leaders[I] then begin
      PCMap[I] := NBB;
      Inc(NBB);
    end;

  { Fill non-leader PCs with their block index }
  BIdx := -1;
  for I := 0 to N - 1 do begin
    if Leaders[I] then BIdx := PCMap[I];
    PCMap[I] := BIdx;
  end;

  SetLength(SF^.Blocks, NBB);
  for I := 0 to NBB - 1 do begin
    SF^.Blocks[I] := Default(TBasicBlock);
    SF^.Blocks[I].Index   := I;
    SF^.Blocks[I].StartPC := -1;
    SF^.Blocks[I].EndPC   := -1;
    SF^.Blocks[I].IDom    := -1;
  end;

  { Set StartPC / EndPC for each block }
  BIdx := -1;
  for I := 0 to N - 1 do begin
    if Leaders[I] then begin
      BIdx := PCMap[I];
      SF^.Blocks[BIdx].StartPC := I;
    end;
    SF^.Blocks[BIdx].EndPC := I;
  end;

  { Add edges by examining the terminator of each block }
  for BIdx := 0 to NBB - 1 do begin
    Blk  := @SF^.Blocks[BIdx];
    I    := Blk^.EndPC;
    Inst := Proto^.Code[I];
    Op   := GET_OPCODE(Inst);
    case Op of
      OP_JMP: begin
        Target := I + 1 + GETARG_sBx(Inst);
        AddSucc(BIdx, PCToBlock(PCMap, Target));
      end;
      OP_EQ, OP_LT, OP_LE, OP_TEST, OP_TESTSET: begin
        { Next instruction is always JMP in well-formed Lua bytecode;
          we add the JMP target AND fall-through. }
        AddSucc(BIdx, PCToBlock(PCMap, I + 1));  { the JMP block }
        AddSucc(BIdx, PCToBlock(PCMap, I + 2));  { skip target    }
      end;
      OP_FORLOOP: begin
        Target := I + 1 + GETARG_sBx(Inst);     { loop back }
        AddSucc(BIdx, PCToBlock(PCMap, Target));
        AddSucc(BIdx, PCToBlock(PCMap, I + 1));  { exit }
      end;
      OP_FORPREP: begin
        Target := I + 1 + GETARG_sBx(Inst);
        AddSucc(BIdx, PCToBlock(PCMap, Target));
      end;
      OP_TFORLOOP: begin
        AddSucc(BIdx, PCToBlock(PCMap, I + 1));  { JMP or next }
        AddSucc(BIdx, PCToBlock(PCMap, I + 2));
      end;
      OP_LOADBOOL: begin
        { LOADBOOL with C=1 skips the next instruction }
        if GETARG_C(Inst) <> 0 then
          AddSucc(BIdx, PCToBlock(PCMap, I + 2))
        else if I + 1 < N then
          AddSucc(BIdx, PCToBlock(PCMap, I + 1));
      end;
      OP_RETURN, OP_TAILCALL: { no successors } ;
    else
      { fall-through }
      if I + 1 < N then
        AddSucc(BIdx, PCToBlock(PCMap, I + 1));
    end;
  end;
end;

{ ======================================================================
  Step 2 – Compute Dominators (Cooper/Harvey/Kennedy iterative)
  ====================================================================== }

{ Returns the nearest common dominator of blocks A and B using idom array }
function Intersect(const IDom: array of Integer; A, B: Integer): Integer;
begin
  while A <> B do begin
    while A > B do A := IDom[A];
    while B > A do B := IDom[B];
  end;
  Result := A;
end;

procedure ComputeDominators(SF: PSSAFunction);
var
  N    : Integer;
  IDom : array of Integer;
  Changed: Boolean;
  I, J, P, New_IDom: Integer;
begin
  N := Length(SF^.Blocks);
  if N = 0 then Exit;
  SetLength(IDom, N);
  for I := 0 to N - 1 do IDom[I] := -1;
  IDom[0] := 0;

  Changed := True;
  while Changed do begin
    Changed := False;
    { Post-order traversal approximation: iterate in reverse }
    for I := 1 to N - 1 do begin
      New_IDom := -1;
      for J := 0 to High(SF^.Blocks[I].Preds) do begin
        P := SF^.Blocks[I].Preds[J];
        if IDom[P] <> -1 then begin
          if New_IDom = -1 then
            New_IDom := P
          else
            New_IDom := Intersect(IDom, P, New_IDom);
        end;
      end;
      if New_IDom = -1 then New_IDom := 0;  { unreachable -> entry }
      if IDom[I] <> New_IDom then begin
        IDom[I]  := New_IDom;
        Changed  := True;
      end;
    end;
  end;

  for I := 0 to N - 1 do
    SF^.Blocks[I].IDom := IDom[I];

  { Build dominator tree children lists }
  for I := 1 to N - 1 do begin
    J := IDom[I];
    if J >= 0 then begin
      SetLength(SF^.Blocks[J].DomChildren,
                Length(SF^.Blocks[J].DomChildren) + 1);
      SF^.Blocks[J].DomChildren[High(SF^.Blocks[J].DomChildren)] := I;
    end;
  end;
end;

{ ======================================================================
  Step 3 – Dominance Frontier
  ====================================================================== }

procedure AddToDF(SF: PSSAFunction; B, Runner: Integer);
var
  I: Integer;
begin
  for I := 0 to High(SF^.Blocks[B].DF) do
    if SF^.Blocks[B].DF[I] = Runner then Exit;
  SetLength(SF^.Blocks[B].DF, Length(SF^.Blocks[B].DF) + 1);
  SF^.Blocks[B].DF[High(SF^.Blocks[B].DF)] := Runner;
end;

procedure ComputeDominanceFrontier(SF: PSSAFunction);
var
  I, J, Runner: Integer;
begin
  for I := 0 to High(SF^.Blocks) do begin
    if Length(SF^.Blocks[I].Preds) >= 2 then begin
      for J := 0 to High(SF^.Blocks[I].Preds) do begin
        Runner := SF^.Blocks[I].Preds[J];
        while Runner <> SF^.Blocks[I].IDom do begin
          AddToDF(SF, Runner, I);
          if Runner = 0 then Break;
          Runner := SF^.Blocks[Runner].IDom;
        end;
      end;
    end;
  end;
end;

{ ======================================================================
  Step 4 – Lift instructions to un-versioned SSA nodes
  ====================================================================== }

{ Map raw RK argument to TSSARef (unversioned, version=0) }
function RKRef(X: Integer): TSSARef;
begin
  if ISK(X) then
    Result := MakeConstRef(INDEXRK(X))
  else
    Result := MakeRef(X, 0);
end;

{ ======================================================================
  Synthetic constant helpers
  ====================================================================== }

function AddSyntheticConst(Proto: PProto; IVal: Int64): Integer;
var
  I, N: Integer;
  C: TLuaConst;
begin
  { Check if this constant already exists to avoid duplicates }
  N := Length(Proto^.K);
  for I := 0 to N - 1 do begin
    if (Proto^.K[I].Kind = lckInteger) and (Proto^.K[I].IValue = IVal) then begin
      Result := I;
      Exit;
    end;
    if (Proto^.K[I].Kind = lckNumber) and (Proto^.K[I].NValue = IVal) and
       (Frac(Proto^.K[I].NValue) = 0) then begin
      Result := I;
      Exit;
    end;
  end;
  { Append new constant }
  SetLength(Proto^.K, N + 1);
  C := Default(TLuaConst);
  C.Kind   := lckInteger;
  C.IValue := IVal;
  C.NValue := IVal;
  Proto^.K[N] := C;
  Result := N;
end;

function AddSyntheticFloatConst(Proto: PProto; FVal: Double): Integer;
var
  I, N: Integer;
  C: TLuaConst;
begin
  { Check if this constant already exists }
  N := Length(Proto^.K);
  for I := 0 to N - 1 do begin
    if (Proto^.K[I].Kind in [lckFloat, lckNumber]) and
       (Proto^.K[I].NValue = FVal) then begin
      Result := I;
      Exit;
    end;
  end;
  { Append new constant }
  SetLength(Proto^.K, N + 1);
  C := Default(TLuaConst);
  C.Kind   := lckFloat;
  C.NValue := FVal;
  Proto^.K[N] := C;
  Result := N;
end;

{ ======================================================================
  Version-aware RK resolution for 5.2-5.3
  ====================================================================== }

function RKRefV(const OT: TOpcodeTable; X: Integer): TSSARef;
begin
  if IsRK(OT, X) then
    Result := MakeConstRef(RKIndex(OT, X))
  else
    Result := MakeRef(X, 0);
end;

procedure LiftBlock(SF: PSSAFunction; BIdx: Integer);
var
  Proto : PProto;
  Blk   : PBasicBlock;
  I, PC : Integer;
  Inst  : TInstruction;
  Op    : TOpCode;
  A, B, C, Bx, sBx: Integer;
  Node  : PSSANode;
  Line  : Integer;
  J, ArgCount, TopSetReg: Integer;

  procedure Add(N: PSSANode);
  begin
    SetLength(Blk^.Nodes, Length(Blk^.Nodes) + 1);
    Blk^.Nodes[High(Blk^.Nodes)] := N;
    SetLength(SF^.AllNodes, Length(SF^.AllNodes) + 1);
    SF^.AllNodes[High(SF^.AllNodes)] := N;
  end;

begin
  Proto := SF^.Proto;
  Blk   := @SF^.Blocks[BIdx];
  PC := Blk^.StartPC;
  while PC <= Blk^.EndPC do begin
    Inst := Proto^.Code[PC];
    Op   := GET_OPCODE(Inst);
    A    := GETARG_A(Inst);
    B    := GETARG_B(Inst);
    C    := GETARG_C(Inst);
    Bx   := GETARG_Bx(Inst);
    sBx  := GETARG_sBx(Inst);
    if PC < Length(Proto^.LineInfo) then Line := Proto^.LineInfo[PC]
    else Line := -1;

    case Op of
      OP_MOVE: begin
        Node := NewNode(SSA_MOVE, PC, Line);
        Node^.Dest := MakeRef(A, 0);
        Node^.OpA  := MakeRef(B, 0);
        Add(Node);
      end;
      OP_LOADK: begin
        Node := NewNode(SSA_LOADK, PC, Line);
        Node^.Dest     := MakeRef(A, 0);
        Node^.ConstIdx := Bx;
        Add(Node);
      end;
      OP_LOADBOOL: begin
        Node := NewNode(SSA_LOADBOOL, PC, Line);
        Node^.Dest := MakeRef(A, 0);
        Node^.ImmA := B;  { 0 or 1 }
        Node^.ImmB := C;  { skip flag }
        Add(Node);
      end;
      OP_LOADNIL: begin
        Node := NewNode(SSA_LOADNIL, PC, Line);
        Node^.ImmA := A;  { first reg }
        Node^.ImmB := B;  { last reg  }
        { LOADNIL defines registers A..B; dest is the range start }
        Node^.Dest := MakeRef(A, 0);
        Add(Node);
      end;
      OP_GETUPVAL: begin
        Node := NewNode(SSA_GETUPVAL, PC, Line);
        Node^.Dest     := MakeRef(A, 0);
        Node^.UpvalIdx := B;
        Add(Node);
      end;
      OP_GETGLOBAL: begin
        Node := NewNode(SSA_GETGLOBAL, PC, Line);
        Node^.Dest     := MakeRef(A, 0);
        Node^.ConstIdx := Bx;
        Add(Node);
      end;
      OP_GETTABLE: begin
        Node := NewNode(SSA_GETTABLE, PC, Line);
        Node^.Dest := MakeRef(A, 0);
        Node^.OpA  := MakeRef(B, 0);
        Node^.OpB  := RKRef(C);
        Add(Node);
      end;
      OP_SETGLOBAL: begin
        Node := NewNode(SSA_SETGLOBAL, PC, Line);
        Node^.OpA      := MakeRef(A, 0);
        Node^.ConstIdx := Bx;
        Add(Node);
      end;
      OP_SETUPVAL: begin
        Node := NewNode(SSA_SETUPVAL, PC, Line);
        Node^.OpA      := MakeRef(A, 0);
        Node^.UpvalIdx := B;
        Add(Node);
      end;
      OP_SETTABLE: begin
        Node := NewNode(SSA_SETTABLE, PC, Line);
        Node^.OpA := MakeRef(A, 0);
        Node^.OpB := RKRef(B);
        Node^.OpC := RKRef(C);
        Add(Node);
      end;
      OP_NEWTABLE: begin
        Node := NewNode(SSA_NEWTABLE, PC, Line);
        Node^.Dest := MakeRef(A, 0);
        Node^.ImmA := B;  { array size hint }
        Node^.ImmB := C;  { hash size hint  }
        Add(Node);
      end;
      OP_SELF: begin
        Node := NewNode(SSA_SELF, PC, Line);
        Node^.Dest := MakeRef(A, 0);   { method }
        Node^.OpA  := MakeRef(B, 0);   { table  }
        Node^.OpB  := RKRef(C);        { key    }
        Node^.ImmA := A + 1;           { self slot }
        Add(Node);
      end;
      OP_ADD, OP_SUB, OP_MUL, OP_DIV, OP_MOD, OP_POW: begin
        Node := NewNode(SSA_BINOP, PC, Line);
        Node^.Dest := MakeRef(A, 0);
        Node^.OpA  := RKRef(B);
        Node^.OpB  := RKRef(C);
        case Op of
          OP_ADD: Node^.BinOp := bopAdd;
          OP_SUB: Node^.BinOp := bopSub;
          OP_MUL: Node^.BinOp := bopMul;
          OP_DIV: Node^.BinOp := bopDiv;
          OP_MOD: Node^.BinOp := bopMod;
          OP_POW: Node^.BinOp := bopPow;
        end;
        Add(Node);
      end;
      OP_UNM, OP_NOT, OP_LEN: begin
        Node := NewNode(SSA_UNOP, PC, Line);
        Node^.Dest := MakeRef(A, 0);
        Node^.OpA  := MakeRef(B, 0);
        case Op of
          OP_UNM: Node^.UnOp := uopNeg;
          OP_NOT: Node^.UnOp := uopNot;
          OP_LEN: Node^.UnOp := uopLen;
        end;
        Add(Node);
      end;
      OP_CONCAT: begin
        Node := NewNode(SSA_CONCAT, PC, Line);
        Node^.Dest := MakeRef(A, 0);
        Node^.ImmA := B;  { first register }
        Node^.ImmB := C;  { last register  }
        Add(Node);
      end;
      OP_JMP: begin
        Node := NewNode(SSA_JUMP, PC, Line);
        Node^.TargetTrue := PC + 1 + sBx;
        Add(Node);
      end;
      OP_EQ: begin
        Node := NewNode(SSA_BRANCH, PC, Line);
        Node^.RelOp  := ropEQ;
        Node^.Invert := A <> 0;
        Node^.OpA    := RKRef(B);
        Node^.OpB    := RKRef(C);
        Add(Node);
      end;
      OP_LT: begin
        Node := NewNode(SSA_BRANCH, PC, Line);
        Node^.RelOp  := ropLT;
        Node^.Invert := A <> 0;
        Node^.OpA    := RKRef(B);
        Node^.OpB    := RKRef(C);
        Add(Node);
      end;
      OP_LE: begin
        Node := NewNode(SSA_BRANCH, PC, Line);
        Node^.RelOp  := ropLE;
        Node^.Invert := A <> 0;
        Node^.OpA    := RKRef(B);
        Node^.OpB    := RKRef(C);
        Add(Node);
      end;
      OP_TEST: begin
        Node := NewNode(SSA_BRANCH, PC, Line);
        Node^.RelOp  := ropTest;
        Node^.OpA    := MakeRef(A, 0);
        Node^.Invert := C <> 0;
        Add(Node);
      end;
      OP_TESTSET: begin
        Node := NewNode(SSA_BRANCH, PC, Line);
        Node^.RelOp  := ropTestSet;
        Node^.Dest   := MakeRef(A, 0);
        Node^.OpA    := MakeRef(B, 0);
        Node^.Invert := C <> 0;
        Add(Node);
      end;
      OP_CALL: begin
        Node := NewNode(SSA_CALL, PC, Line);
        Node^.Dest := MakeRef(A, 0);   { base of result registers }
        Node^.OpA  := MakeRef(A, 0);   { function register (SSA use) }
        Node^.ImmA := A;
        Node^.ImmB := B;  { arg count + 1 }
        Node^.ImmC := C;  { ret count + 1 }
        if B > 1 then begin
          SetLength(Node^.ArgRefs, B - 1);
          for J := 0 to B - 2 do
            Node^.ArgRefs[J] := MakeRef(A + 1 + J, 0);
        end else if B = 0 then begin
          { Variable args: R(A+1) to stack top.
            Scan backward for the stack-top-setting instruction. }
          TopSetReg := -1;
          for J := High(Blk^.Nodes) downto 0 do begin
            if (Blk^.Nodes[J]^.Kind = SSA_CALL) and (Blk^.Nodes[J]^.ImmC = 0) then begin
              TopSetReg := Blk^.Nodes[J]^.ImmA;
              Break;
            end;
            if (Blk^.Nodes[J]^.Kind = SSA_VARARG) and
               (Blk^.Nodes[J]^.ImmB = 0) then begin
              TopSetReg := Blk^.Nodes[J]^.Dest.Reg;
              Break;
            end;
          end;
          if TopSetReg > A then begin
            ArgCount := TopSetReg - A;
            SetLength(Node^.ArgRefs, ArgCount);
            for J := 0 to ArgCount - 1 do
              Node^.ArgRefs[J] := MakeRef(A + 1 + J, 0);
          end;
        end;
        Add(Node);
      end;
      OP_TAILCALL: begin
        Node := NewNode(SSA_TAILCALL, PC, Line);
        Node^.OpA  := MakeRef(A, 0);   { function register }
        Node^.ImmA := A;
        Node^.ImmB := B;
        Node^.ImmC := C;
        if B > 1 then begin
          SetLength(Node^.ArgRefs, B - 1);
          for J := 0 to B - 2 do
            Node^.ArgRefs[J] := MakeRef(A + 1 + J, 0);
        end else if B = 0 then begin
          { Variable args: R(A+1) to stack top.
            Scan backward for the stack-top-setting instruction. }
          TopSetReg := -1;
          for J := High(Blk^.Nodes) downto 0 do begin
            if (Blk^.Nodes[J]^.Kind = SSA_CALL) and (Blk^.Nodes[J]^.ImmC = 0) then begin
              TopSetReg := Blk^.Nodes[J]^.ImmA;
              Break;
            end;
            if (Blk^.Nodes[J]^.Kind = SSA_VARARG) and
               (Blk^.Nodes[J]^.ImmB = 0) then begin
              TopSetReg := Blk^.Nodes[J]^.Dest.Reg;
              Break;
            end;
          end;
          if TopSetReg > A then begin
            ArgCount := TopSetReg - A;
            SetLength(Node^.ArgRefs, ArgCount);
            for J := 0 to ArgCount - 1 do
              Node^.ArgRefs[J] := MakeRef(A + 1 + J, 0);
          end;
        end;
        Add(Node);
      end;
      OP_RETURN: begin
        Node := NewNode(SSA_RETURN, PC, Line);
        Node^.ImmA := A;
        Node^.ImmB := B;
        if B > 1 then begin
          SetLength(Node^.ArgRefs, B - 1);
          for J := 0 to B - 2 do
            Node^.ArgRefs[J] := MakeRef(A + J, 0);
        end else if B = 0 then begin
          { Return all from R(A) to top - scan backward for top-setter }
          TopSetReg := -1;
          for J := High(Blk^.Nodes) downto 0 do begin
            if (Blk^.Nodes[J]^.Kind = SSA_CALL) and (Blk^.Nodes[J]^.ImmC = 0) then begin
              TopSetReg := Blk^.Nodes[J]^.ImmA;
              Break;
            end;
            if (Blk^.Nodes[J]^.Kind = SSA_VARARG) and
               (Blk^.Nodes[J]^.ImmB = 0) then begin
              TopSetReg := Blk^.Nodes[J]^.Dest.Reg;
              Break;
            end;
          end;
          if TopSetReg >= A then begin
            ArgCount := TopSetReg - A + 1;
            SetLength(Node^.ArgRefs, ArgCount);
            for J := 0 to ArgCount - 1 do
              Node^.ArgRefs[J] := MakeRef(A + J, 0);
          end;
        end;
        Add(Node);
      end;
      OP_FORLOOP: begin
        Node := NewNode(SSA_FORLOOP, PC, Line);
        Node^.ImmA       := A;
        Node^.Dest       := MakeRef(A + 3, 0); { exposed loop variable R(A+3) }
        Node^.TargetTrue := PC + 1 + sBx;  { loop back }
        Add(Node);
      end;
      OP_FORPREP: begin
        Node := NewNode(SSA_FORPREP, PC, Line);
        Node^.ImmA       := A;
        Node^.Dest       := MakeRef(A, 0);  { internal index R(A) }
        Node^.TargetTrue := PC + 1 + sBx;  { -> FORLOOP }
        Add(Node);
      end;
      OP_TFORLOOP: begin
        Node := NewNode(SSA_TFORLOOP, PC, Line);
        Node^.ImmA := A;
        Node^.ImmC := C;  { number of results }
        Add(Node);
      end;
      OP_SETLIST: begin
        Node := NewNode(SSA_SETLIST, PC, Line);
        Node^.ImmA := A;
        Node^.ImmB := B;
        Node^.ImmC := C;
        Add(Node);
      end;
      OP_CLOSE: begin
        Node := NewNode(SSA_CLOSE, PC, Line);
        Node^.ImmA := A;
        Add(Node);
      end;
      OP_CLOSURE: begin
        Node := NewNode(SSA_CLOSURE, PC, Line);
        Node^.Dest     := MakeRef(A, 0);
        Node^.ConstIdx := Bx;  { sub-proto index }
        Add(Node);
        { CLOSURE is followed by NUP pseudo-instructions (MOVE/GETUPVAL)
          for upvalue capture; skip them by consuming the block's codes }
        if Bx < Length(Proto^.P) then begin
          for I := 1 to Proto^.P[Bx]^.NUps do begin
            Inc(PC);
            if PC > Blk^.EndPC then Break;
            { emit as NOP to preserve PC mapping }
            Node := NewNode(SSA_NOP, PC, -1);
            Add(Node);
          end;
        end;
      end;
      OP_VARARG: begin
        Node := NewNode(SSA_VARARG, PC, Line);
        Node^.Dest := MakeRef(A, 0);
        Node^.ImmA := A;
        Node^.ImmB := B;  { number of results + 1, 0 = variable }
        Add(Node);
      end;
    end; { case Op }
    Inc(PC);
  end; { while PC }
end;

procedure LiftAllBlocks(SF: PSSAFunction);
var
  I: Integer;
begin
  for I := 0 to High(SF^.Blocks) do
    LiftBlock(SF, I);
end;

{ ======================================================================
  Step 5 – Phi-function insertion (standard worklist algorithm)
  ====================================================================== }

{ Return True if register Reg is defined anywhere in the block's original code }
function BlockDefinesReg(const Blk: TBasicBlock; Reg: Integer;
  LuaVersion: Byte): Boolean;
var
  I: Integer;
  N: PSSANode;
  TForBase: Integer;  { first user-visible loop var register }
begin
  for I := 0 to High(Blk.Nodes) do begin
    N := Blk.Nodes[I];
    if (N^.Dest.Reg = Reg) then begin
      Result := True; Exit;
    end;
    { LOADNIL defines a range }
    if (N^.Kind = SSA_LOADNIL) and (Reg >= N^.ImmA) and (Reg <= N^.ImmB) then begin
      Result := True; Exit;
    end;
    { FORLOOP defines R(A)..R(A+3) }
    if (N^.Kind = SSA_FORLOOP) and (Reg >= N^.ImmA) and (Reg <= N^.ImmA + 3) then begin
      Result := True; Exit;
    end;
    { TFORLOOP defines loop variable registers.
      Lua 5.1-5.3, 5.5: R(A+3)..R(A+2+C)  (3 internal vars)
      Lua 5.4 only:      R(A+4)..R(A+3+C)  (4 internal vars: added to-be-closed slot) }
    if N^.Kind = SSA_TFORLOOP then begin
      if LuaVersion = $54 then
        TForBase := N^.ImmA + 4
      else
        TForBase := N^.ImmA + 3;
      if (Reg >= TForBase) and
         (Reg < TForBase + N^.ImmC) then begin
        Result := True; Exit;
      end;
    end;
    { SELF A B C: R(A+1) := R(B), R(A) := R(B)[RK(C)]
      Dest covers R(A), but R(A+1) is also defined (the self slot).
      ImmA stores A+1 at lift time. }
    if (N^.Kind = SSA_SELF) and (Reg = N^.ImmA) then begin
      Result := True; Exit;
    end;
    { CALL with fixed multi-return: C >= 3 means (C-1) return values.
      Dest covers R(A), but R(A+1)..R(A+C-2) are also overwritten.
      Without this, a register used as both argument and return slot
      (e.g., R1 holds CLOSURE before CALL, but gets pcall's 2nd return after)
      keeps a stale version from before the CALL. }
    if (N^.Kind = SSA_CALL) and (N^.ImmC >= 3) and
       (Reg > N^.ImmA) and (Reg <= N^.ImmA + N^.ImmC - 2) then begin
      Result := True; Exit;
    end;
  end;
  Result := False;
end;

procedure InsertPhiFunctions(SF: PSSAFunction);
var
  NBlocks : Integer;
  Reg, I, J, Y: Integer;
  M, ShiftIdx: Integer;
  HasPhi  : array of array of Boolean;  { [block][reg] }
  OrigDef : array of Boolean;  { [block] - True if block originally defined Reg }
  WorkList: array of Integer;
  WLen, WHead: Integer;
  InWorklist: array of Boolean;
  Phi  : PSSANode;
  NumPreds: Integer;

  procedure WPush(B: Integer);
  begin
    if InWorklist[B] then Exit;
    InWorklist[B] := True;
    if WLen >= Length(WorkList) then
      SetLength(WorkList, WLen * 2 + 8);
    WorkList[WLen] := B;
    Inc(WLen);
  end;

  function WPop: Integer;
  begin
    Dec(WLen);
    Result := WorkList[WLen];
    InWorklist[Result] := False;
  end;

begin
  NBlocks := Length(SF^.Blocks);
  if NBlocks = 0 then Exit;
  SetLength(HasPhi, NBlocks);
  SetLength(InWorklist, NBlocks);
  SetLength(WorkList, NBlocks);
  WLen  := 0;
  WHead := 0;
  for I := 0 to NBlocks - 1 do begin
    SetLength(HasPhi[I], SF^.NumRegs);
    for J := 0 to SF^.NumRegs - 1 do HasPhi[I][J] := False;
    InWorklist[I] := False;
  end;

  SetLength(OrigDef, NBlocks);
  for Reg := 0 to SF^.NumRegs - 1 do begin
    { Build worklist of all blocks that define Reg.
      Track which blocks originally define Reg (before PHI insertion)
      so the cascading worklist propagation works correctly. }
    WLen := 0;
    for I := 0 to NBlocks - 1 do begin
      InWorklist[I] := False;
      OrigDef[I] := BlockDefinesReg(SF^.Blocks[I], Reg, SF^.LuaVersion);
    end;
    for I := 0 to NBlocks - 1 do
      if OrigDef[I] then
        WPush(I);

    while WLen > 0 do begin
      I := WPop;
      for J := 0 to High(SF^.Blocks[I].DF) do begin
        Y := SF^.Blocks[I].DF[J];
        if not HasPhi[Y][Reg] then begin
          HasPhi[Y][Reg] := True;
          { Insert SSA_PHI at the front of block Y }
          NumPreds := Length(SF^.Blocks[Y].Preds);
          Phi := NewNode(SSA_PHI, SF^.Blocks[Y].StartPC, -1);
          Phi^.Dest := MakeRef(Reg, 0);
          SetLength(Phi^.Operands, NumPreds);
          SetLength(Phi^.PhiBlocks, NumPreds);
          for M := 0 to NumPreds - 1 do begin
            Phi^.Operands[M]  := MakeRef(Reg, 0);  { placeholders }
            Phi^.PhiBlocks[M] := SF^.Blocks[Y].Preds[M];
          end;
          { Prepend to block's node list }
          SetLength(SF^.Blocks[Y].Nodes, Length(SF^.Blocks[Y].Nodes) + 1);
          for ShiftIdx := High(SF^.Blocks[Y].Nodes) downto 1 do
            SF^.Blocks[Y].Nodes[ShiftIdx] := SF^.Blocks[Y].Nodes[ShiftIdx-1];
          SF^.Blocks[Y].Nodes[0] := Phi;
          SetLength(SF^.AllNodes, Length(SF^.AllNodes) + 1);
          SF^.AllNodes[High(SF^.AllNodes)] := Phi;
          { Add Y to worklist if it didn't originally define Reg
            (the newly-inserted PHI counts as a new definition) }
          if not OrigDef[Y] then
            WPush(Y);
        end;
      end;
    end;
  end;
end;

{ ======================================================================
  Step 6 – Rename pass (dominator tree walk)
  ====================================================================== }

type
  TVersionStack = record
    Items: array of Integer;
    Top  : Integer;
  end;

procedure VSPush(var VS: TVersionStack; V: Integer);
begin
  if VS.Top >= Length(VS.Items) then
    SetLength(VS.Items, VS.Top * 2 + 4);
  VS.Items[VS.Top] := V;
  Inc(VS.Top);
end;

function VSPeek(const VS: TVersionStack): Integer;
begin
  if VS.Top = 0 then Result := 0
  else Result := VS.Items[VS.Top - 1];
end;

procedure VSPop(var VS: TVersionStack);
begin
  if VS.Top > 0 then Dec(VS.Top);
end;

type
  TRenameState = record
    Counter: array of Integer;   { next version to assign per register }
    Stack  : array of TVersionStack;
  end;

procedure RenameDef(var RS: TRenameState; var Ref: TSSARef);
var
  R, V: Integer;
begin
  if Ref.Reg < 0 then Exit;
  R := Ref.Reg;
  V := RS.Counter[R];
  Inc(RS.Counter[R]);
  VSPush(RS.Stack[R], V);
  Ref.Version := V;
end;

procedure RenameUse(const RS: TRenameState; var Ref: TSSARef);
begin
  if Ref.Reg < 0 then Exit;
  Ref.Version := VSPeek(RS.Stack[Ref.Reg]);
end;

procedure PopDef(var RS: TRenameState; Reg: Integer);
begin
  if Reg >= 0 then VSPop(RS.Stack[Reg]);
end;

procedure RenameBlock(SF: PSSAFunction; BIdx: Integer; var RS: TRenameState);
var
  I, J, Reg: Integer;
  Node : PSSANode;
  Blk  : PBasicBlock;
  Succ : Integer;
  PredIdx: Integer;
  Defs : array of Integer;  { list of (reg, old_top_before_def) for popping }
  NDefs: Integer;
  ExtraRef: TSSARef;
  TForBase: Integer;
  PseudoNode: PSSANode;
  PseudoNodes: array of PSSANode;
  PseudoCount: Integer;

  procedure TrackDef(R: Integer);
  begin
    if R < 0 then Exit;
    SetLength(Defs, NDefs + 1);
    Defs[NDefs] := R;
    Inc(NDefs);
  end;

begin
  Blk  := @SF^.Blocks[BIdx];
  NDefs := 0;
  PseudoCount := 0;
  SetLength(Defs, 0);
  SetLength(PseudoNodes, 0);

  for I := 0 to High(Blk^.Nodes) do begin
    Node := Blk^.Nodes[I];

    if Node^.Kind = SSA_PHI then begin
      { Phi-node: rename definition only; uses are renamed when filling }
      RenameDef(RS, Node^.Dest);
      TrackDef(Node^.Dest.Reg);
      Continue;
    end;

    { Rename uses first }
    RenameUse(RS, Node^.OpA);
    RenameUse(RS, Node^.OpB);
    RenameUse(RS, Node^.OpC);

    { Rename ArgRefs (CALL/TAILCALL/RETURN argument references) }
    for J := 0 to High(Node^.ArgRefs) do
      RenameUse(RS, Node^.ArgRefs[J]);

    { Special: CONCAT operands are in a range ImmA..ImmB }
    if Node^.Kind = SSA_CONCAT then begin
      { operands stored implicitly; OpA/B will hold range refs if needed }
      Node^.OpA := MakeRef(Node^.ImmA, VSPeek(RS.Stack[Node^.ImmA]));
      Node^.OpB := MakeRef(Node^.ImmB, VSPeek(RS.Stack[Node^.ImmB]));
    end;

    { Rename definition }
    if Node^.Dest.Reg >= 0 then begin
      RenameDef(RS, Node^.Dest);
      TrackDef(Node^.Dest.Reg);
    end;

    { LOADNIL defines a range A..B - create pseudo-def nodes for extra regs.
      Pseudo-nodes are collected and inserted into Blk^.Nodes after the main
      loop to avoid corrupting the for-loop iteration bounds. }
    if (Node^.Kind = SSA_LOADNIL) and (Node^.ImmB > Node^.ImmA) then begin
      for Reg := Node^.ImmA + 1 to Node^.ImmB do begin
        ExtraRef := MakeRef(Reg, 0);
        RenameDef(RS, ExtraRef);
        TrackDef(Reg);
        { Create pseudo-def node for this register so it can carry LocVarIdx }
        PseudoNode := NewNode(SSA_LOADNIL, Node^.PC, Node^.Line);
        PseudoNode^.Dest := ExtraRef;  { already renamed by RenameDef }
        PseudoNode^.ImmA := Reg;
        PseudoNode^.ImmB := Reg;  { single-register range }
        PseudoNode^.IsMetaOnly := True;
        { Collect for deferred insertion }
        SetLength(PseudoNodes, PseudoCount + 1);
        PseudoNodes[PseudoCount] := PseudoNode;
        Inc(PseudoCount);
        { Add to AllNodes immediately (safe - we don't iterate AllNodes here) }
        SetLength(SF^.AllNodes, Length(SF^.AllNodes) + 1);
        SF^.AllNodes[High(SF^.AllNodes)] := PseudoNode;
      end;
    end;

    { FORLOOP defines internal regs in addition to the user variable (Dest).
      Lua 5.1-5.4: 3 internal vars R(A)..R(A+2), user var = R(A+3)
      Lua 5.5:     2 internal vars R(A)..R(A+1), user var = R(A+2) }
    if Node^.Kind = SSA_FORLOOP then begin
      if SF^.LuaVersion >= $55 then
        Reg := Node^.ImmA + 1
      else
        Reg := Node^.ImmA + 2;
      for TForBase := Node^.ImmA to Reg do begin
        ExtraRef := MakeRef(TForBase, 0);
        RenameDef(RS, ExtraRef);
        TrackDef(TForBase);
      end;
    end;

    { TFORLOOP defines loop variable regs.
      Lua 5.1-5.3, 5.5: R(A+3)..R(A+2+C)  (3 internal vars)
      Lua 5.4 only:      R(A+4)..R(A+3+C)  (4 internal vars: to-be-closed slot added)
      These are the user-visible loop variables (e.g., k, v in "for k,v in pairs(t)").
      Without this, the rename pass doesn't track these writes and the body
      block references stale versions, causing wrong variable name resolution. }
    if Node^.Kind = SSA_TFORLOOP then begin
      if SF^.LuaVersion = $54 then
        TForBase := Node^.ImmA + 4
      else
        TForBase := Node^.ImmA + 3;
      for Reg := TForBase to TForBase + Node^.ImmC - 1 do begin
        ExtraRef := MakeRef(Reg, 0);
        RenameDef(RS, ExtraRef);
        TrackDef(Reg);
        { Record implicit def so BuildDefNodeMap can populate FDefNodeMap }
        J := Length(SF^.ImplicitDefs);
        SetLength(SF^.ImplicitDefs, J + 1);
        SF^.ImplicitDefs[J].Reg := ExtraRef.Reg;
        SF^.ImplicitDefs[J].Version := ExtraRef.Version;
        SF^.ImplicitDefs[J].ParentNode := Node;
      end;
    end;

    { SELF A B C does: R(A+1) := R(B); R(A) := R(B)[RK(C)]
      Dest already covers R(A), but R(A+1) (the implicit "self" copy) is also
      written.  Without this def, subsequent uses of R(A+1) see a stale version
      from before SELF, inflating its use count and causing spurious emissions. }
    if Node^.Kind = SSA_SELF then begin
      Reg := Node^.ImmA;  { A + 1 was stored in ImmA at lift time }
      if Reg >= 0 then begin
        ExtraRef := MakeRef(Reg, 0);
        RenameDef(RS, ExtraRef);
        TrackDef(Reg);
        { Record implicit def for SELF R(A+1) }
        J := Length(SF^.ImplicitDefs);
        SetLength(SF^.ImplicitDefs, J + 1);
        SF^.ImplicitDefs[J].Reg := ExtraRef.Reg;
        SF^.ImplicitDefs[J].Version := ExtraRef.Version;
        SF^.ImplicitDefs[J].ParentNode := Node;
      end;
    end;

    { CALL with fixed multi-return: C >= 3 means (C-1) return values.
      Dest covers R(A), but R(A+1)..R(A+C-2) are also overwritten by the CALL.
      Without this, a register used as both a call argument and a return slot
      (e.g., R1 holds CLOSURE before CALL, but gets pcall's 2nd return after)
      keeps its pre-CALL SSA version, causing ExprOf to resolve it to the
      argument expression instead of the return value. }
    if (Node^.Kind = SSA_CALL) and (Node^.ImmC >= 3) then begin
      for Reg := Node^.ImmA + 1 to Node^.ImmA + Node^.ImmC - 2 do begin
        ExtraRef := MakeRef(Reg, 0);
        RenameDef(RS, ExtraRef);
        TrackDef(Reg);
        { Record implicit def for CALL extra return register }
        J := Length(SF^.ImplicitDefs);
        SetLength(SF^.ImplicitDefs, J + 1);
        SF^.ImplicitDefs[J].Reg := ExtraRef.Reg;
        SF^.ImplicitDefs[J].Version := ExtraRef.Version;
        SF^.ImplicitDefs[J].ParentNode := Node;
      end;
    end;
  end;

  { Insert deferred LOADNIL pseudo-def nodes into Blk^.Nodes.
    We append them at the end since they share the same PC as the primary
    LOADNIL and their ordering relative to other nodes is not critical -
    they exist solely for LocVar binding (IsMetaOnly = True). }
  if PseudoCount > 0 then begin
    J := Length(Blk^.Nodes);
    SetLength(Blk^.Nodes, J + PseudoCount);
    for I := 0 to PseudoCount - 1 do
      Blk^.Nodes[J + I] := PseudoNodes[I];
  end;

  { Fill Phi-uses in successors }
  for I := 0 to High(Blk^.Succs) do begin
    Succ := Blk^.Succs[I];
    { find BIdx in Succ's predecessor list }
    PredIdx := -1;
    for J := 0 to High(SF^.Blocks[Succ].Preds) do
      if SF^.Blocks[Succ].Preds[J] = BIdx then begin
        PredIdx := J; Break;
      end;
    if PredIdx < 0 then Continue;
    for J := 0 to High(SF^.Blocks[Succ].Nodes) do begin
      Node := SF^.Blocks[Succ].Nodes[J];
      if Node^.Kind <> SSA_PHI then Break;
      Reg := Node^.Dest.Reg;
      if (PredIdx < Length(Node^.Operands)) and (Reg >= 0) then
        Node^.Operands[PredIdx] := MakeRef(Reg, VSPeek(RS.Stack[Reg]));
    end;
  end;

  { Recurse into dominator tree children }
  for I := 0 to High(Blk^.DomChildren) do
    RenameBlock(SF, Blk^.DomChildren[I], RS);

  { Pop definitions pushed in this block }
  for I := NDefs - 1 downto 0 do
    VSPop(RS.Stack[Defs[I]]);
end;

procedure RenamePass(SF: PSSAFunction);
var
  RS : TRenameState;
  I  : Integer;
begin
  SetLength(RS.Counter, SF^.NumRegs);
  SetLength(RS.Stack, SF^.NumRegs);
  { Start all counters at 1, reserving version 0 for "initial value".
    For parameters, version 0 represents the incoming argument.
    For non-parameters, version 0 represents the VM's implicit nil
    (Lua initialises all stack slots to nil).  This ensures that a
    register used before its first definition gets version 0, which
    no SSA node defines, letting ExprOf resolve it to the correct
    initial value (parameter name or 'nil'). }
  for I := 0 to SF^.NumRegs - 1 do begin
    RS.Counter[I] := 1;
    RS.Stack[I].Top := 0;
  end;
  { Push version 0 onto the stack for parameters so that uses of
    a parameter before any reassignment read version 0. }
  for I := 0 to SF^.Proto^.NumParams - 1 do
    VSPush(RS.Stack[I], 0);   { version 0 = the parameter itself }
  if Length(SF^.Blocks) > 0 then
    RenameBlock(SF, 0, RS);
end;

{ ======================================================================
  Version-aware CFG + Lifting (using TSemanticOp / TOpcodeTable)
  ====================================================================== }

procedure ComputeLeadersV(Proto: PProto; const OT: TOpcodeTable;
  var Leaders: array of Boolean);
var
  I, N, Target: Integer;
  Inst: TInstruction;
  SOp: TSemanticOp;
  Bx: Integer;
begin
  N := Length(Proto^.Code);
  Leaders[0] := True;
  I := 0;
  while I < N do begin
    Inst := Proto^.Code[I];
    SOp  := DecodeOp(OT, Inst);
    case SOp of
      semJMP: begin
        if OT.Version >= $54 then
          Target := I + 1 + DecodesJ(OT, Inst)
        else
          Target := I + 1 + DecodesBx(OT, Inst);
        if (Target >= 0) and (Target < N) then Leaders[Target] := True;
        if I + 1 < N then Leaders[I + 1] := True;
      end;
      semEQ, semLT, semLE, semTEST, semTESTSET,
      semEQK, semEQI, semLTI, semLEI, semGTI, semGEI: begin
        if I + 1 < N then Leaders[I + 1] := True;
        if I + 2 < N then Leaders[I + 2] := True;
      end;
      semFORLOOP: begin
        if OT.Version >= $54 then begin
          { 5.4+: ABx format, target = PC + 1 - Bx (backward jump) }
          Bx := DecodeBx(OT, Inst);
          Target := I + 1 - Bx;
        end else
          Target := I + 1 + DecodesBx(OT, Inst);
        if (Target >= 0) and (Target < N) then Leaders[Target] := True;
        if I + 1 < N then Leaders[I + 1] := True;
      end;
      semFORPREP: begin
        if OT.Version >= $54 then begin
          { 5.4+: ABx format, target = PC + 1 + Bx (forward jump) }
          Bx := DecodeBx(OT, Inst);
          Target := I + 1 + Bx;
        end else
          Target := I + 1 + DecodesBx(OT, Inst);
        if (Target >= 0) and (Target < N) then Leaders[Target] := True;
        if I + 1 < N then Leaders[I + 1] := True;
      end;
      semTFORLOOP: begin
        { 5.1 only: followed by JMP }
        if I + 1 < N then Leaders[I + 1] := True;
        if I + 2 < N then Leaders[I + 2] := True;
      end;
      semTFORCALL: begin
        { 5.2+: followed by TFORLOOP54 which has its own jump }
        if I + 1 < N then Leaders[I + 1] := True;
        if I + 2 < N then Leaders[I + 2] := True;
      end;
      semTFORLOOP54: begin
        { 5.2+: ABx/AsBx format, jumps backward }
        if OT.Version >= $54 then begin
          Bx := DecodeBx(OT, Inst);
          Target := I + 1 - Bx;
        end else
          Target := I + 1 + DecodesBx(OT, Inst);
        if (Target >= 0) and (Target < N) then Leaders[Target] := True;
        if I + 1 < N then Leaders[I + 1] := True;
      end;
      semTFORPREP: begin
        { 5.4+: ABx format, target = PC + 1 + Bx }
        Bx := DecodeBx(OT, Inst);
        Target := I + 1 + Bx;
        if (Target >= 0) and (Target < N) then Leaders[Target] := True;
        if I + 1 < N then Leaders[I + 1] := True;
      end;
      semLOADBOOL: begin
        { LOADBOOL with C=1 skips next instruction (5.1-5.3) }
        if DecodeC(OT, Inst) <> 0 then begin
          if I + 1 < N then Leaders[I + 1] := True;
          if I + 2 < N then Leaders[I + 2] := True;
        end;
      end;
      semLFALSESKIP: begin
        { 5.4+: skips next instruction }
        if I + 1 < N then Leaders[I + 1] := True;
        if I + 2 < N then Leaders[I + 2] := True;
      end;
      semRETURN, semRETURN0, semRETURN1, semTAILCALL: begin
        if I + 1 < N then Leaders[I + 1] := True;
      end;
    end;
    Inc(I);
  end;
end;

procedure BuildCFGV(SF: PSSAFunction; const OT: TOpcodeTable);
var
  Proto  : PProto;
  N      : Integer;
  Leaders: array of Boolean;
  PCMap  : array of Integer;
  I, BIdx: Integer;
  Inst   : TInstruction;
  SOp    : TSemanticOp;
  Target : Integer;
  Bx     : Integer;
  NBB    : Integer;
  Blk    : PBasicBlock;

  procedure AddSucc(Src, Dst: Integer);
  var J: Integer;
  begin
    if Dst < 0 then Exit;
    for J := 0 to High(SF^.Blocks[Src].Succs) do
      if SF^.Blocks[Src].Succs[J] = Dst then Exit;
    SetLength(SF^.Blocks[Src].Succs, Length(SF^.Blocks[Src].Succs) + 1);
    SF^.Blocks[Src].Succs[High(SF^.Blocks[Src].Succs)] := Dst;
    SetLength(SF^.Blocks[Dst].Preds, Length(SF^.Blocks[Dst].Preds) + 1);
    SF^.Blocks[Dst].Preds[High(SF^.Blocks[Dst].Preds)] := Src;
  end;

begin
  Proto := SF^.Proto;
  N     := Length(Proto^.Code);
  if N = 0 then Exit;

  SetLength(Leaders, N);
  SetLength(PCMap, N);
  for I := 0 to N - 1 do begin Leaders[I] := False; PCMap[I] := -1; end;

  ComputeLeadersV(Proto, OT, Leaders);

  NBB := 0;
  for I := 0 to N - 1 do
    if Leaders[I] then begin
      PCMap[I] := NBB;
      Inc(NBB);
    end;

  BIdx := -1;
  for I := 0 to N - 1 do begin
    if Leaders[I] then BIdx := PCMap[I];
    PCMap[I] := BIdx;
  end;

  SetLength(SF^.Blocks, NBB);
  for I := 0 to NBB - 1 do begin
    SF^.Blocks[I] := Default(TBasicBlock);
    SF^.Blocks[I].Index   := I;
    SF^.Blocks[I].StartPC := -1;
    SF^.Blocks[I].EndPC   := -1;
    SF^.Blocks[I].IDom    := -1;
  end;

  BIdx := -1;
  for I := 0 to N - 1 do begin
    if Leaders[I] then begin
      BIdx := PCMap[I];
      SF^.Blocks[BIdx].StartPC := I;
    end;
    SF^.Blocks[BIdx].EndPC := I;
  end;

  { Add edges }
  for BIdx := 0 to NBB - 1 do begin
    Blk  := @SF^.Blocks[BIdx];
    I    := Blk^.EndPC;
    Inst := Proto^.Code[I];
    SOp  := DecodeOp(OT, Inst);
    case SOp of
      semJMP: begin
        if OT.Version >= $54 then
          Target := I + 1 + DecodesJ(OT, Inst)
        else
          Target := I + 1 + DecodesBx(OT, Inst);
        AddSucc(BIdx, PCToBlock(PCMap, Target));
      end;
      semEQ, semLT, semLE, semTEST, semTESTSET,
      semEQK, semEQI, semLTI, semLEI, semGTI, semGEI: begin
        AddSucc(BIdx, PCToBlock(PCMap, I + 1));
        AddSucc(BIdx, PCToBlock(PCMap, I + 2));
      end;
      semFORLOOP: begin
        if OT.Version >= $54 then begin
          Bx := DecodeBx(OT, Inst);
          Target := I + 1 - Bx;
        end else
          Target := I + 1 + DecodesBx(OT, Inst);
        AddSucc(BIdx, PCToBlock(PCMap, Target));
        AddSucc(BIdx, PCToBlock(PCMap, I + 1));
      end;
      semFORPREP: begin
        if OT.Version >= $54 then begin
          Bx := DecodeBx(OT, Inst);
          Target := I + 1 + Bx;
        end else
          Target := I + 1 + DecodesBx(OT, Inst);
        AddSucc(BIdx, PCToBlock(PCMap, Target));
      end;
      semTFORLOOP: begin
        { 5.1: followed by JMP }
        AddSucc(BIdx, PCToBlock(PCMap, I + 1));
        AddSucc(BIdx, PCToBlock(PCMap, I + 2));
      end;
      semTFORCALL: begin
        { 5.2+: followed by TFORLOOP54 }
        AddSucc(BIdx, PCToBlock(PCMap, I + 1));
        AddSucc(BIdx, PCToBlock(PCMap, I + 2));
      end;
      semTFORLOOP54: begin
        if OT.Version >= $54 then begin
          Bx := DecodeBx(OT, Inst);
          Target := I + 1 - Bx;
        end else
          Target := I + 1 + DecodesBx(OT, Inst);
        AddSucc(BIdx, PCToBlock(PCMap, Target));
        AddSucc(BIdx, PCToBlock(PCMap, I + 1));
      end;
      semTFORPREP: begin
        Bx := DecodeBx(OT, Inst);
        Target := I + 1 + Bx;
        AddSucc(BIdx, PCToBlock(PCMap, Target));
      end;
      semLOADBOOL: begin
        if DecodeC(OT, Inst) <> 0 then
          AddSucc(BIdx, PCToBlock(PCMap, I + 2))
        else if I + 1 < N then
          AddSucc(BIdx, PCToBlock(PCMap, I + 1));
      end;
      semLFALSESKIP: begin
        AddSucc(BIdx, PCToBlock(PCMap, I + 2));
      end;
      semRETURN, semRETURN0, semRETURN1, semTAILCALL:
        { no successors } ;
    else
      if I + 1 < N then
        AddSucc(BIdx, PCToBlock(PCMap, I + 1));
    end;
  end;
end;

{ ======================================================================
  Version-aware instruction lifting
  ====================================================================== }

function IsEnvUpval(Proto: PProto; Idx: Integer): Boolean;
{ Check if upvalue at Idx is _ENV. In 5.2+ nested closures, _ENV can be at
  any upvalue index, not just 0. Falls back to index=0 if no debug names. }
begin
  if (Idx >= 0) and (Idx < Length(Proto^.UpvalueNames)) then
    Result := Proto^.UpvalueNames[Idx] = '_ENV'
  else
    Result := (Idx = 0);  { no debug info: assume index 0 is _ENV (common case) }
end;

procedure LiftBlockV(SF: PSSAFunction; BIdx: Integer; const OT: TOpcodeTable);
var
  Proto : PProto;
  Blk   : PBasicBlock;
  PC    : Integer;
  Inst  : TInstruction;
  SOp   : TSemanticOp;
  A, B, C, Bx, sBx, sJ: Integer;
  sB, sC: Integer;
  KFlag : Boolean;
  Node  : PSSANode;
  Line  : Integer;
  J, ArgCount, TopSetReg: Integer;
  NextInst: TInstruction;
  AxVal : Integer;

  procedure Add(N: PSSANode);
  begin
    SetLength(Blk^.Nodes, Length(Blk^.Nodes) + 1);
    Blk^.Nodes[High(Blk^.Nodes)] := N;
    SetLength(SF^.AllNodes, Length(SF^.AllNodes) + 1);
    SF^.AllNodes[High(SF^.AllNodes)] := N;
  end;

begin
  Proto := SF^.Proto;
  Blk   := @SF^.Blocks[BIdx];
  PC := Blk^.StartPC;
  while PC <= Blk^.EndPC do begin
    Inst := Proto^.Code[PC];
    SOp  := DecodeOp(OT, Inst);
    A    := DecodeA(OT, Inst);
    B    := DecodeB(OT, Inst);
    C    := DecodeC(OT, Inst);
    Bx   := DecodeBx(OT, Inst);
    sBx  := DecodesBx(OT, Inst);
    KFlag := DecodeK(OT, Inst);
    { For ivABC format (5.5 NEWTABLE/SETLIST), re-decode B and C with
      correct bit widths: vB=6 bits, vC=10 bits instead of standard 8/8 }
    if IsIvABCFormat(OT, Inst) then begin
      B := DecodeVB(OT, Inst);
      C := DecodeVC(OT, Inst);
    end;
    if PC < Length(Proto^.LineInfo) then Line := Proto^.LineInfo[PC]
    else Line := -1;

    case SOp of
      { ---- MOVE ---- }
      semMOVE: begin
        Node := NewNode(SSA_MOVE, PC, Line);
        Node^.Dest := MakeRef(A, 0);
        Node^.OpA  := MakeRef(B, 0);
        Add(Node);
      end;

      { ---- LOADK ---- }
      semLOADK: begin
        Node := NewNode(SSA_LOADK, PC, Line);
        Node^.Dest     := MakeRef(A, 0);
        Node^.ConstIdx := Bx;
        Add(Node);
      end;

      { ---- LOADKX ---- }
      semLOADKX: begin
        Node := NewNode(SSA_LOADK, PC, Line);
        Node^.Dest := MakeRef(A, 0);
        { Peek next instruction for EXTRAARG Ax value }
        if PC + 1 < Length(Proto^.Code) then begin
          NextInst := Proto^.Code[PC + 1];
          AxVal := DecodeAx(OT, NextInst);
          Node^.ConstIdx := AxVal;
        end else
          Node^.ConstIdx := Bx;
        Add(Node);
        { Emit NOP for the EXTRAARG instruction }
        Inc(PC);
        if PC <= Blk^.EndPC then begin
          Node := NewNode(SSA_NOP, PC, -1);
          Add(Node);
        end;
      end;

      { ---- LOADBOOL ---- }
      semLOADBOOL: begin
        Node := NewNode(SSA_LOADBOOL, PC, Line);
        Node^.Dest := MakeRef(A, 0);
        Node^.ImmA := B;  { 0 or 1 }
        Node^.ImmB := C;  { skip flag }
        Add(Node);
      end;

      { ---- LOADNIL ---- }
      semLOADNIL: begin
        Node := NewNode(SSA_LOADNIL, PC, Line);
        if OT.Version >= $52 then begin
          { 5.2+: LOADNIL A B means R(A)..R(A+B) := nil }
          Node^.ImmA := A;
          Node^.ImmB := A + B;
        end else begin
          { 5.1: LOADNIL A B means R(A)..R(B) := nil }
          Node^.ImmA := A;
          Node^.ImmB := B;
        end;
        Node^.Dest := MakeRef(A, 0);
        Add(Node);
      end;

      { ---- LOADI (5.4+) ---- }
      semLOADI: begin
        Node := NewNode(SSA_LOADK, PC, Line);
        Node^.Dest     := MakeRef(A, 0);
        Node^.ConstIdx := AddSyntheticConst(Proto, sBx);
        Add(Node);
      end;

      { ---- LOADF (5.4+) ---- }
      semLOADF: begin
        Node := NewNode(SSA_LOADK, PC, Line);
        Node^.Dest     := MakeRef(A, 0);
        Node^.ConstIdx := AddSyntheticFloatConst(Proto, Double(sBx));
        Add(Node);
      end;

      { ---- LOADFALSE (5.4+) ---- }
      semLOADFALSE: begin
        Node := NewNode(SSA_LOADBOOL, PC, Line);
        Node^.Dest := MakeRef(A, 0);
        Node^.ImmA := 0;  { false }
        Node^.ImmB := 0;  { no skip }
        Add(Node);
      end;

      { ---- LOADTRUE (5.4+) ---- }
      semLOADTRUE: begin
        Node := NewNode(SSA_LOADBOOL, PC, Line);
        Node^.Dest := MakeRef(A, 0);
        Node^.ImmA := 1;  { true }
        Node^.ImmB := 0;  { no skip }
        Add(Node);
      end;

      { ---- LFALSESKIP (5.4+) ---- }
      semLFALSESKIP: begin
        Node := NewNode(SSA_LOADBOOL, PC, Line);
        Node^.Dest := MakeRef(A, 0);
        Node^.ImmA := 0;  { false }
        Node^.ImmB := 1;  { skip next instruction }
        Add(Node);
      end;

      { ---- GETUPVAL ---- }
      semGETUPVAL: begin
        Node := NewNode(SSA_GETUPVAL, PC, Line);
        Node^.Dest     := MakeRef(A, 0);
        Node^.UpvalIdx := B;
        Add(Node);
      end;

      { ---- SETUPVAL ---- }
      semSETUPVAL: begin
        Node := NewNode(SSA_SETUPVAL, PC, Line);
        Node^.OpA      := MakeRef(A, 0);
        Node^.UpvalIdx := B;
        Add(Node);
      end;

      { ---- GETGLOBAL (5.1 only) ---- }
      semGETGLOBAL: begin
        Node := NewNode(SSA_GETGLOBAL, PC, Line);
        Node^.Dest     := MakeRef(A, 0);
        Node^.ConstIdx := Bx;
        Add(Node);
      end;

      { ---- SETGLOBAL (5.1 only) ---- }
      semSETGLOBAL: begin
        Node := NewNode(SSA_SETGLOBAL, PC, Line);
        Node^.OpA      := MakeRef(A, 0);
        Node^.ConstIdx := Bx;
        Add(Node);
      end;

      { ---- GETTABUP (5.2+) ---- }
      semGETTABUP: begin
        if IsEnvUpval(Proto, B) then begin
          { Upval is _ENV: normalize to GETGLOBAL }
          Node := NewNode(SSA_GETGLOBAL, PC, Line);
          Node^.Dest     := MakeRef(A, 0);
          if OT.HasKFlag then
            Node^.ConstIdx := C
          else
            Node^.ConstIdx := RKIndex(OT, C);
        end else begin
          { Generic upvalue table access }
          Node := NewNode(SSA_GETTABLE, PC, Line);
          Node^.Dest := MakeRef(A, 0);
          { OpA references the upvalue; mark as upval ref using UpvalIdx }
          Node^.UpvalIdx := B;
          Node^.OpA  := SSA_NO_REF; { no register for upval }
          if OT.HasKFlag then
            Node^.OpB := MakeConstRef(C)
          else
            Node^.OpB := RKRefV(OT, C);
        end;
        Add(Node);
      end;

      { ---- SETTABUP (5.2+) ---- }
      semSETTABUP: begin
        if IsEnvUpval(Proto, A) then begin
          { Upval is _ENV: normalize to SETGLOBAL }
          Node := NewNode(SSA_SETGLOBAL, PC, Line);
          if OT.HasKFlag then begin
            Node^.ConstIdx := B;
            if KFlag then
              Node^.OpA := MakeConstRef(C)
            else
              Node^.OpA := MakeRef(C, 0);
          end else begin
            Node^.ConstIdx := RKIndex(OT, B);
            Node^.OpA := RKRefV(OT, C);
          end;
        end else begin
          { Generic upvalue table set }
          Node := NewNode(SSA_SETTABLE, PC, Line);
          Node^.UpvalIdx := A;
          Node^.OpA := SSA_NO_REF;
          if OT.HasKFlag then begin
            Node^.OpB := MakeConstRef(B);
            if KFlag then
              Node^.OpC := MakeConstRef(C)
            else
              Node^.OpC := MakeRef(C, 0);
          end else begin
            Node^.OpB := RKRefV(OT, B);
            Node^.OpC := RKRefV(OT, C);
          end;
        end;
        Add(Node);
      end;

      { ---- GETTABLE ---- }
      semGETTABLE: begin
        Node := NewNode(SSA_GETTABLE, PC, Line);
        Node^.Dest := MakeRef(A, 0);
        Node^.OpA  := MakeRef(B, 0);
        if OT.HasKFlag then
          Node^.OpB := MakeRef(C, 0)  { 5.4+: C is always register }
        else
          Node^.OpB := RKRefV(OT, C);
        Add(Node);
      end;

      { ---- GETI (5.4+) ---- }
      semGETI: begin
        Node := NewNode(SSA_GETTABLE, PC, Line);
        Node^.Dest := MakeRef(A, 0);
        Node^.OpA  := MakeRef(B, 0);
        Node^.OpB  := MakeConstRef(AddSyntheticConst(Proto, C));
        Add(Node);
      end;

      { ---- GETFIELD (5.4+) ---- }
      semGETFIELD: begin
        Node := NewNode(SSA_GETTABLE, PC, Line);
        Node^.Dest := MakeRef(A, 0);
        Node^.OpA  := MakeRef(B, 0);
        Node^.OpB  := MakeConstRef(C);
        Add(Node);
      end;

      { ---- SETTABLE ---- }
      semSETTABLE: begin
        Node := NewNode(SSA_SETTABLE, PC, Line);
        Node^.OpA := MakeRef(A, 0);
        if OT.HasKFlag then begin
          Node^.OpB := MakeRef(B, 0);
          if KFlag then
            Node^.OpC := MakeConstRef(C)
          else
            Node^.OpC := MakeRef(C, 0);
        end else begin
          Node^.OpB := RKRefV(OT, B);
          Node^.OpC := RKRefV(OT, C);
        end;
        Add(Node);
      end;

      { ---- SETI (5.4+) ---- }
      semSETI: begin
        Node := NewNode(SSA_SETTABLE, PC, Line);
        Node^.OpA := MakeRef(A, 0);
        Node^.OpB := MakeConstRef(AddSyntheticConst(Proto, B));
        if KFlag then
          Node^.OpC := MakeConstRef(C)
        else
          Node^.OpC := MakeRef(C, 0);
        Add(Node);
      end;

      { ---- SETFIELD (5.4+) ---- }
      semSETFIELD: begin
        Node := NewNode(SSA_SETTABLE, PC, Line);
        Node^.OpA := MakeRef(A, 0);
        Node^.OpB := MakeConstRef(B);
        if KFlag then
          Node^.OpC := MakeConstRef(C)
        else
          Node^.OpC := MakeRef(C, 0);
        Add(Node);
      end;

      { ---- NEWTABLE ---- }
      semNEWTABLE: begin
        Node := NewNode(SSA_NEWTABLE, PC, Line);
        Node^.Dest := MakeRef(A, 0);
        Node^.ImmA := B;
        Node^.ImmB := C;
        Add(Node);
      end;

      { ---- SELF ---- }
      semSELF: begin
        Node := NewNode(SSA_SELF, PC, Line);
        Node^.Dest := MakeRef(A, 0);
        Node^.OpA  := MakeRef(B, 0);
        if OT.Version >= $55 then
          { Lua 5.5: SELF A B C - C is always K[C]:shortstring (like GETFIELD) }
          Node^.OpB := MakeConstRef(C)
        else if OT.HasKFlag then begin
          { Lua 5.4: SELF A B C - RK(C) with k-flag }
          if KFlag then
            Node^.OpB := MakeConstRef(C)
          else
            Node^.OpB := MakeRef(C, 0);
        end else
          Node^.OpB := RKRefV(OT, C);
        Node^.ImmA := A + 1;  { self slot }
        Add(Node);
      end;

      { ---- Binary arithmetic (register operands) ---- }
      semADD, semSUB, semMUL, semDIV, semMOD, semPOW,
      semIDIV, semBAND, semBOR, semBXOR, semSHL, semSHR: begin
        Node := NewNode(SSA_BINOP, PC, Line);
        Node^.Dest := MakeRef(A, 0);
        if OT.HasKFlag then begin
          Node^.OpA := MakeRef(B, 0);
          Node^.OpB := MakeRef(C, 0);
        end else begin
          Node^.OpA := RKRefV(OT, B);
          Node^.OpB := RKRefV(OT, C);
        end;
        case SOp of
          semADD:  Node^.BinOp := bopAdd;
          semSUB:  Node^.BinOp := bopSub;
          semMUL:  Node^.BinOp := bopMul;
          semDIV:  Node^.BinOp := bopDiv;
          semMOD:  Node^.BinOp := bopMod;
          semPOW:  Node^.BinOp := bopPow;
          semIDIV: Node^.BinOp := bopIDiv;
          semBAND: Node^.BinOp := bopBAnd;
          semBOR:  Node^.BinOp := bopBOr;
          semBXOR: Node^.BinOp := bopBXor;
          semSHL:  Node^.BinOp := bopSHL;
          semSHR:  Node^.BinOp := bopSHR;
        end;
        Add(Node);
      end;

      { ---- Constant-keyed arithmetic (5.4+) ---- }
      semADDK, semSUBK, semMULK, semMODK, semPOWK,
      semDIVK, semIDIVK, semBANDK, semBORK, semBXORK: begin
        Node := NewNode(SSA_BINOP, PC, Line);
        Node^.Dest := MakeRef(A, 0);
        Node^.OpA  := MakeRef(B, 0);
        Node^.OpB  := MakeConstRef(C);
        case SOp of
          semADDK:  Node^.BinOp := bopAdd;
          semSUBK:  Node^.BinOp := bopSub;
          semMULK:  Node^.BinOp := bopMul;
          semMODK:  Node^.BinOp := bopMod;
          semPOWK:  Node^.BinOp := bopPow;
          semDIVK:  Node^.BinOp := bopDiv;
          semIDIVK: Node^.BinOp := bopIDiv;
          semBANDK: Node^.BinOp := bopBAnd;
          semBORK:  Node^.BinOp := bopBOr;
          semBXORK: Node^.BinOp := bopBXor;
        end;
        Add(Node);
      end;

      { ---- ADDI (5.4+) ---- }
      semADDI: begin
        sC := DecodeSC(OT, Inst);
        Node := NewNode(SSA_BINOP, PC, Line);
        Node^.Dest  := MakeRef(A, 0);
        Node^.OpA   := MakeRef(B, 0);
        Node^.OpB   := MakeConstRef(AddSyntheticConst(Proto, sC));
        Node^.BinOp := bopAdd;
        Add(Node);
      end;

      { ---- SHRI (5.4+) ---- }
      semSHRI: begin
        sC := DecodeSC(OT, Inst);
        Node := NewNode(SSA_BINOP, PC, Line);
        Node^.Dest  := MakeRef(A, 0);
        Node^.OpA   := MakeRef(B, 0);
        Node^.OpB   := MakeConstRef(AddSyntheticConst(Proto, sC));
        Node^.BinOp := bopSHR;
        Add(Node);
      end;

      { ---- SHLI (5.4+): sC << R(B), operands reversed ---- }
      semSHLI: begin
        sC := DecodeSC(OT, Inst);
        Node := NewNode(SSA_BINOP, PC, Line);
        Node^.Dest  := MakeRef(A, 0);
        Node^.OpA   := MakeConstRef(AddSyntheticConst(Proto, sC));
        Node^.OpB   := MakeRef(B, 0);
        Node^.BinOp := bopSHL;
        Add(Node);
      end;

      { ---- Unary ops ---- }
      semUNM, semNOT, semLEN, semBNOT: begin
        Node := NewNode(SSA_UNOP, PC, Line);
        Node^.Dest := MakeRef(A, 0);
        Node^.OpA  := MakeRef(B, 0);
        case SOp of
          semUNM:  Node^.UnOp := uopNeg;
          semNOT:  Node^.UnOp := uopNot;
          semLEN:  Node^.UnOp := uopLen;
          semBNOT: Node^.UnOp := uopBNot;
        end;
        Add(Node);
      end;

      { ---- CONCAT ---- }
      semCONCAT: begin
        Node := NewNode(SSA_CONCAT, PC, Line);
        Node^.Dest := MakeRef(A, 0);
        if OT.Version >= $54 then begin
          { 5.4+: CONCAT A B -> R[A] := R[A].. ... ..R[A+B-1] (B operands) }
          Node^.ImmA := A;          { first register }
          Node^.ImmB := A + B - 1;  { last register }
        end else begin
          { 5.1-5.3: CONCAT A B C -> R(A) := R(B)..R(C) }
          Node^.ImmA := B;
          Node^.ImmB := C;
        end;
        Add(Node);
      end;

      { ---- JMP ---- }
      semJMP: begin
        Node := NewNode(SSA_JUMP, PC, Line);
        if OT.Version >= $54 then begin
          sJ := DecodesJ(OT, Inst);
          Node^.TargetTrue := PC + 1 + sJ;
        end else
          Node^.TargetTrue := PC + 1 + sBx;
        Add(Node);
      end;

      { ---- EQ, LT, LE ---- }
      semEQ, semLT, semLE: begin
        Node := NewNode(SSA_BRANCH, PC, Line);
        case SOp of
          semEQ: Node^.RelOp := ropEQ;
          semLT: Node^.RelOp := ropLT;
          semLE: Node^.RelOp := ropLE;
        end;
        if OT.HasKFlag then begin
          { 5.4+: operands are registers A and B, invert via k-flag }
          Node^.OpA    := MakeRef(A, 0);
          Node^.OpB    := MakeRef(B, 0);
          Node^.Invert := KFlag;
        end else begin
          { 5.1-5.3: operands are RK(B) and RK(C), invert = A!=0 }
          Node^.OpA    := RKRefV(OT, B);
          Node^.OpB    := RKRefV(OT, C);
          Node^.Invert := A <> 0;
        end;
        Add(Node);
      end;

      { ---- EQK (5.4+) ---- }
      semEQK: begin
        Node := NewNode(SSA_BRANCH, PC, Line);
        Node^.RelOp  := ropEQ;
        Node^.OpA    := MakeRef(A, 0);
        Node^.OpB    := MakeConstRef(B);
        Node^.Invert := KFlag;
        Add(Node);
      end;

      { ---- EQI (5.4+) ---- }
      semEQI: begin
        sB := DecodeSB(OT, Inst);
        Node := NewNode(SSA_BRANCH, PC, Line);
        Node^.RelOp  := ropEQ;
        Node^.OpA    := MakeRef(A, 0);
        Node^.OpB    := MakeConstRef(AddSyntheticConst(Proto, sB));
        Node^.Invert := KFlag;
        Add(Node);
      end;

      { ---- LTI (5.4+) ---- }
      semLTI: begin
        sB := DecodeSB(OT, Inst);
        Node := NewNode(SSA_BRANCH, PC, Line);
        Node^.RelOp  := ropLT;
        Node^.OpA    := MakeRef(A, 0);
        Node^.OpB    := MakeConstRef(AddSyntheticConst(Proto, sB));
        Node^.Invert := KFlag;
        Add(Node);
      end;

      { ---- LEI (5.4+) ---- }
      semLEI: begin
        sB := DecodeSB(OT, Inst);
        Node := NewNode(SSA_BRANCH, PC, Line);
        Node^.RelOp  := ropLE;
        Node^.OpA    := MakeRef(A, 0);
        Node^.OpB    := MakeConstRef(AddSyntheticConst(Proto, sB));
        Node^.Invert := KFlag;
        Add(Node);
      end;

      { ---- GTI (5.4+): R(A) > sB => sB < R(A) ---- }
      semGTI: begin
        sB := DecodeSB(OT, Inst);
        Node := NewNode(SSA_BRANCH, PC, Line);
        Node^.RelOp  := ropLT;
        { Swap operands: GT(A, sB) becomes LT(sB, A) }
        Node^.OpA    := MakeConstRef(AddSyntheticConst(Proto, sB));
        Node^.OpB    := MakeRef(A, 0);
        Node^.Invert := KFlag;
        Add(Node);
      end;

      { ---- GEI (5.4+): R(A) >= sB => sB <= R(A) ---- }
      semGEI: begin
        sB := DecodeSB(OT, Inst);
        Node := NewNode(SSA_BRANCH, PC, Line);
        Node^.RelOp  := ropLE;
        { Swap operands: GE(A, sB) becomes LE(sB, A) }
        Node^.OpA    := MakeConstRef(AddSyntheticConst(Proto, sB));
        Node^.OpB    := MakeRef(A, 0);
        Node^.Invert := KFlag;
        Add(Node);
      end;

      { ---- TEST ---- }
      semTEST: begin
        Node := NewNode(SSA_BRANCH, PC, Line);
        Node^.RelOp := ropTest;
        Node^.OpA   := MakeRef(A, 0);
        if OT.HasKFlag then
          Node^.Invert := KFlag
        else
          Node^.Invert := C <> 0;
        Add(Node);
      end;

      { ---- TESTSET ---- }
      semTESTSET: begin
        Node := NewNode(SSA_BRANCH, PC, Line);
        Node^.RelOp := ropTestSet;
        Node^.Dest  := MakeRef(A, 0);
        Node^.OpA   := MakeRef(B, 0);
        if OT.HasKFlag then
          Node^.Invert := KFlag
        else
          Node^.Invert := C <> 0;
        Add(Node);
      end;

      { ---- CALL ---- }
      semCALL: begin
        Node := NewNode(SSA_CALL, PC, Line);
        Node^.Dest := MakeRef(A, 0);
        Node^.OpA  := MakeRef(A, 0);
        Node^.ImmA := A;
        Node^.ImmB := B;
        Node^.ImmC := C;
        if B > 1 then begin
          SetLength(Node^.ArgRefs, B - 1);
          for J := 0 to B - 2 do
            Node^.ArgRefs[J] := MakeRef(A + 1 + J, 0);
        end else if B = 0 then begin
          TopSetReg := -1;
          for J := High(Blk^.Nodes) downto 0 do begin
            if (Blk^.Nodes[J]^.Kind = SSA_CALL) and (Blk^.Nodes[J]^.ImmC = 0) then begin
              TopSetReg := Blk^.Nodes[J]^.ImmA;
              Break;
            end;
            if (Blk^.Nodes[J]^.Kind = SSA_VARARG) and
               (Blk^.Nodes[J]^.ImmB = 0) then begin
              TopSetReg := Blk^.Nodes[J]^.Dest.Reg;
              Break;
            end;
          end;
          if TopSetReg > A then begin
            ArgCount := TopSetReg - A;
            SetLength(Node^.ArgRefs, ArgCount);
            for J := 0 to ArgCount - 1 do
              Node^.ArgRefs[J] := MakeRef(A + 1 + J, 0);
          end;
        end;
        Add(Node);
      end;

      { ---- TAILCALL ---- }
      semTAILCALL: begin
        Node := NewNode(SSA_TAILCALL, PC, Line);
        Node^.OpA  := MakeRef(A, 0);
        Node^.ImmA := A;
        Node^.ImmB := B;
        Node^.ImmC := C;
        if B > 1 then begin
          SetLength(Node^.ArgRefs, B - 1);
          for J := 0 to B - 2 do
            Node^.ArgRefs[J] := MakeRef(A + 1 + J, 0);
        end else if B = 0 then begin
          { Variable args: R(A+1) to stack top.
            Scan backward for the stack-top-setting instruction. }
          TopSetReg := -1;
          for J := High(Blk^.Nodes) downto 0 do begin
            if (Blk^.Nodes[J]^.Kind = SSA_CALL) and (Blk^.Nodes[J]^.ImmC = 0) then begin
              TopSetReg := Blk^.Nodes[J]^.ImmA;
              Break;
            end;
            if (Blk^.Nodes[J]^.Kind = SSA_VARARG) and
               (Blk^.Nodes[J]^.ImmB = 0) then begin
              TopSetReg := Blk^.Nodes[J]^.Dest.Reg;
              Break;
            end;
          end;
          if TopSetReg > A then begin
            ArgCount := TopSetReg - A;
            SetLength(Node^.ArgRefs, ArgCount);
            for J := 0 to ArgCount - 1 do
              Node^.ArgRefs[J] := MakeRef(A + 1 + J, 0);
          end;
        end;
        Add(Node);
      end;

      { ---- RETURN ---- }
      semRETURN: begin
        Node := NewNode(SSA_RETURN, PC, Line);
        Node^.ImmA := A;
        Node^.ImmB := B;
        if B > 1 then begin
          SetLength(Node^.ArgRefs, B - 1);
          for J := 0 to B - 2 do
            Node^.ArgRefs[J] := MakeRef(A + J, 0);
        end else if B = 0 then begin
          TopSetReg := -1;
          for J := High(Blk^.Nodes) downto 0 do begin
            if (Blk^.Nodes[J]^.Kind = SSA_CALL) and (Blk^.Nodes[J]^.ImmC = 0) then begin
              TopSetReg := Blk^.Nodes[J]^.ImmA;
              Break;
            end;
            if (Blk^.Nodes[J]^.Kind = SSA_VARARG) and
               (Blk^.Nodes[J]^.ImmB = 0) then begin
              TopSetReg := Blk^.Nodes[J]^.Dest.Reg;
              Break;
            end;
          end;
          if TopSetReg >= A then begin
            ArgCount := TopSetReg - A + 1;
            SetLength(Node^.ArgRefs, ArgCount);
            for J := 0 to ArgCount - 1 do
              Node^.ArgRefs[J] := MakeRef(A + J, 0);
          end;
        end;
        Add(Node);
      end;

      { ---- RETURN0 (5.4+) ---- }
      semRETURN0: begin
        Node := NewNode(SSA_RETURN, PC, Line);
        Node^.ImmA := 0;
        Node^.ImmB := 1;  { B=1 means no return values }
        Add(Node);
      end;

      { ---- RETURN1 (5.4+) ---- }
      semRETURN1: begin
        Node := NewNode(SSA_RETURN, PC, Line);
        Node^.ImmA := A;
        Node^.ImmB := 2;  { B=2 means one return value }
        SetLength(Node^.ArgRefs, 1);
        Node^.ArgRefs[0] := MakeRef(A, 0);
        Add(Node);
      end;

      { ---- FORLOOP ---- }
      semFORLOOP: begin
        Node := NewNode(SSA_FORLOOP, PC, Line);
        Node^.ImmA := A;
        { Lua 5.1-5.4: 3 internal vars, user var at R(A+3)
          Lua 5.5:      2 internal vars, user var at R(A+2) }
        if OT.Version >= $55 then
          Node^.Dest := MakeRef(A + 2, 0)
        else
          Node^.Dest := MakeRef(A + 3, 0);
        if OT.Version >= $54 then begin
          Bx := DecodeBx(OT, Inst);
          Node^.TargetTrue := PC + 1 - Bx;
        end else
          Node^.TargetTrue := PC + 1 + sBx;
        Add(Node);
      end;

      { ---- FORPREP ---- }
      semFORPREP: begin
        Node := NewNode(SSA_FORPREP, PC, Line);
        Node^.ImmA := A;
        Node^.Dest := MakeRef(A, 0);
        if OT.Version >= $54 then begin
          Bx := DecodeBx(OT, Inst);
          Node^.TargetTrue := PC + 1 + Bx;
        end else
          Node^.TargetTrue := PC + 1 + sBx;
        Add(Node);
      end;

      { ---- TFORLOOP (5.1 only) ---- }
      semTFORLOOP: begin
        Node := NewNode(SSA_TFORLOOP, PC, Line);
        Node^.ImmA := A;
        Node^.ImmC := C;
        Add(Node);
      end;

      { ---- TFORCALL (5.2+) ---- }
      semTFORCALL: begin
        Node := NewNode(SSA_TFORLOOP, PC, Line);
        Node^.ImmA := A;
        Node^.ImmC := C;
        Add(Node);
      end;

      { ---- TFORLOOP54 (5.2+) ---- }
      semTFORLOOP54: begin
        { Loop-back instruction for generic for; emit as FORLOOP-like }
        Node := NewNode(SSA_FORLOOP, PC, Line);
        Node^.ImmA := A;
        Node^.Dest := MakeRef(A, 0);
        if OT.Version >= $54 then begin
          Bx := DecodeBx(OT, Inst);
          Node^.TargetTrue := PC + 1 - Bx;
        end else
          Node^.TargetTrue := PC + 1 + DecodesBx(OT, Inst);
        Add(Node);
      end;

      { ---- TFORPREP (5.4+) ---- }
      semTFORPREP: begin
        Node := NewNode(SSA_JUMP, PC, Line);
        Bx := DecodeBx(OT, Inst);
        Node^.TargetTrue := PC + 1 + Bx;
        Add(Node);
      end;

      { ---- SETLIST ---- }
      semSETLIST: begin
        Node := NewNode(SSA_SETLIST, PC, Line);
        Node^.ImmA := A;
        Node^.ImmB := B;
        Node^.ImmC := C;
        Add(Node);
      end;

      { ---- CLOSE ---- }
      semCLOSE: begin
        Node := NewNode(SSA_CLOSE, PC, Line);
        Node^.ImmA := A;
        Add(Node);
      end;

      { ---- TBC (5.4+) ---- }
      semTBC: begin
        Node := NewNode(SSA_NOP, PC, Line);
        Add(Node);
      end;

      { ---- CLOSURE ---- }
      semCLOSURE: begin
        Node := NewNode(SSA_CLOSURE, PC, Line);
        Node^.Dest     := MakeRef(A, 0);
        Node^.ConstIdx := Bx;
        Add(Node);
        { 5.1 only: CLOSURE is followed by pseudo-instructions for upvalue capture }
        if OT.Version < $52 then begin
          if Bx < Length(Proto^.P) then begin
            for J := 1 to Proto^.P[Bx]^.NUps do begin
              Inc(PC);
              if PC > Blk^.EndPC then Break;
              Node := NewNode(SSA_NOP, PC, -1);
              Add(Node);
            end;
          end;
        end;
      end;

      { ---- VARARG ---- }
      semVARARG: begin
        Node := NewNode(SSA_VARARG, PC, Line);
        Node^.Dest := MakeRef(A, 0);
        Node^.ImmA := A;
        { In 5.4+, VARARG A C uses the C field for the count;
          in 5.1-5.3, VARARG A B uses the B field. }
        if OT.Version >= $54 then
          Node^.ImmB := C
        else
          Node^.ImmB := B;
        if OT.Version >= $55 then
          Node^.ImmC := B; { hidden vararg table register when k is set }
        Add(Node);
      end;

      { ---- GETVARG (5.5) ---- }
      semGETVARG: begin
        Node := NewNode(SSA_GETTABLE, PC, Line);
        Node^.Dest := MakeRef(A, 0);
        Node^.OpA  := MakeRef(B, 0);
        Node^.OpB  := MakeRef(C, 0);
        Add(Node);
      end;

      { ---- VARARGPREP (5.4+) ---- }
      semVARARGPREP: begin
        Node := NewNode(SSA_NOP, PC, Line);
        Add(Node);
      end;

      { ---- Metamethod hints (5.4+) ---- }
      semMMBIN, semMMBINI, semMMBINK: begin
        Node := NewNode(SSA_NOP, PC, Line);
        Add(Node);
      end;

      { ---- EXTRAARG ---- }
      semEXTRAARG: begin
        Node := NewNode(SSA_NOP, PC, Line);
        Add(Node);
      end;

      { ---- ERRNNIL (5.5) ---- }
      semERRNNIL: begin
        Node := NewNode(SSA_NOP, PC, Line);
        Add(Node);
      end;

      { ---- Unknown ---- }
      semUNKNOWN: begin
        Node := NewNode(SSA_NOP, PC, Line);
        Add(Node);
      end;
    else
      begin
        Node := NewNode(SSA_NOP, PC, Line);
        Add(Node);
      end;
    end; { case SOp }
    Inc(PC);
  end; { while PC }
end;

procedure LiftAllBlocksV(SF: PSSAFunction; const OT: TOpcodeTable);
var
  I: Integer;
begin
  for I := 0 to High(SF^.Blocks) do
    LiftBlockV(SF, I, OT);
end;

{ ======================================================================
  BuildSSAFunction  (public entry points)
  ====================================================================== }

function BuildSSAFunction(Proto: PProto): PSSAFunction;
begin
  New(Result);
  Result^ := Default(TSSAFunction);
  Result^.Proto   := Proto;
  Result^.NumRegs := Proto^.MaxStack;
  Result^.LuaVersion := $51;  { legacy path = Lua 5.1 }

  BuildCFG(Result);
  ComputeDominators(Result);
  ComputeDominanceFrontier(Result);
  LiftAllBlocks(Result);
  InsertPhiFunctions(Result);
  RenamePass(Result);
end;

function BuildSSAFunction(Proto: PProto; const OT: POpcodeTable): PSSAFunction;
begin
  if OT = nil then begin
    Result := BuildSSAFunction(Proto);
    Exit;
  end;

  New(Result);
  Result^ := Default(TSSAFunction);
  Result^.Proto   := Proto;
  Result^.NumRegs := Proto^.MaxStack;
  Result^.LuaVersion := OT^.Version;

  BuildCFGV(Result, OT^);
  ComputeDominators(Result);
  ComputeDominanceFrontier(Result);
  LiftAllBlocksV(Result, OT^);
  InsertPhiFunctions(Result);
  RenamePass(Result);
end;

{ ======================================================================
  DumpSSA
  ====================================================================== }

procedure DumpSSA(const F: PSSAFunction);
var
  I, J, K : Integer;
  Blk  : PBasicBlock;
  Node : PSSANode;

  function KindName(K: TSSAKind): AnsiString;
  begin
    case K of
      SSA_NOP:      Result := 'NOP';
      SSA_PHI:      Result := 'PHI';
      SSA_MOVE:     Result := 'MOVE';
      SSA_LOADK:    Result := 'LOADK';
      SSA_LOADBOOL: Result := 'LOADBOOL';
      SSA_LOADNIL:  Result := 'LOADNIL';
      SSA_GETUPVAL: Result := 'GETUPVAL';
      SSA_GETGLOBAL:Result := 'GETGLOBAL';
      SSA_GETTABLE: Result := 'GETTABLE';
      SSA_SETGLOBAL:Result := 'SETGLOBAL';
      SSA_SETUPVAL: Result := 'SETUPVAL';
      SSA_SETTABLE: Result := 'SETTABLE';
      SSA_NEWTABLE: Result := 'NEWTABLE';
      SSA_SELF:     Result := 'SELF';
      SSA_BINOP:    Result := 'BINOP';
      SSA_UNOP:     Result := 'UNOP';
      SSA_CONCAT:   Result := 'CONCAT';
      SSA_JUMP:     Result := 'JUMP';
      SSA_BRANCH:   Result := 'BRANCH';
      SSA_CALL:     Result := 'CALL';
      SSA_TAILCALL: Result := 'TAILCALL';
      SSA_RETURN:   Result := 'RETURN';
      SSA_FORPREP:  Result := 'FORPREP';
      SSA_FORLOOP:  Result := 'FORLOOP';
      SSA_TFORLOOP: Result := 'TFORLOOP';
      SSA_SETLIST:  Result := 'SETLIST';
      SSA_CLOSE:    Result := 'CLOSE';
      SSA_CLOSURE:  Result := 'CLOSURE';
      SSA_VARARG:   Result := 'VARARG';
    end;
  end;

begin
  WriteLn('-- SSA Dump --');
  for I := 0 to High(F^.Blocks) do begin
    Blk := @F^.Blocks[I];
    Write('BB', I, ' [pc ', Blk^.StartPC, '..', Blk^.EndPC, ']');
    Write(' preds:[');
    for J := 0 to High(Blk^.Preds) do begin
      if J > 0 then Write(',');
      Write(Blk^.Preds[J]);
    end;
    Write('] succs:[');
    for J := 0 to High(Blk^.Succs) do begin
      if J > 0 then Write(',');
      Write(Blk^.Succs[J]);
    end;
    Write('] idom=', Blk^.IDom);
    WriteLn;
    for J := 0 to High(Blk^.Nodes) do begin
      Node := Blk^.Nodes[J];
      Write('  [', Node^.PC, '] ', KindName(Node^.Kind), ' ');
      if Node^.Dest.Reg >= 0 then
        Write(RefToStr(Node^.Dest), ' := ');
      if Node^.Kind = SSA_PHI then begin
        Write('phi(');
        for K := 0 to High(Node^.Operands) do begin
          if K > 0 then Write(', ');
          Write(RefToStr(Node^.Operands[K]), ' from BB', Node^.PhiBlocks[K]);
        end;
        Write(')');
      end else begin
        { Show operator detail for BINOP and UNOP }
        if Node^.Kind = SSA_BINOP then begin
          case Node^.BinOp of
            bopAdd:  Write('[+] ');
            bopSub:  Write('[-] ');
            bopMul:  Write('[*] ');
            bopDiv:  Write('[/] ');
            bopMod:  Write('[%] ');
            bopPow:  Write('[^] ');
            bopIDiv: Write('[//] ');
            bopBAnd: Write('[&] ');
            bopBOr:  Write('[|] ');
            bopBXor: Write('[~] ');
            bopSHL:  Write('[<<] ');
            bopSHR:  Write('[>>] ');
          end;
        end;
        if Node^.Kind = SSA_UNOP then begin
          case Node^.UnOp of
            uopNeg:  Write('[-] ');
            uopNot:  Write('[not] ');
            uopLen:  Write('[#] ');
            uopBNot: Write('[~] ');
          end;
        end;
        if Node^.Kind = SSA_BRANCH then begin
          case Node^.RelOp of
            ropEQ:      Write('[==] ');
            ropLT:      Write('[<] ');
            ropLE:      Write('[<=] ');
            ropTest:    Write('[test] ');
            ropTestSet: Write('[testset] ');
          end;
          if Node^.Invert then Write('inv ');
        end;
        if Node^.OpA.Reg >= -1 then Write(RefToStr(Node^.OpA), ' ');
        if Node^.OpB.Reg >= -1 then Write(RefToStr(Node^.OpB), ' ');
        if Node^.OpC.Reg >= -1 then Write(RefToStr(Node^.OpC), ' ');
      end;
      WriteLn;
    end;
  end;
  WriteLn;
end;

{ ======================================================================
  FreeSSAFunction
  ====================================================================== }

procedure FreeSSAFunction(F: PSSAFunction);
var
  I: Integer;
begin
  if F = nil then Exit;
  for I := 0 to High(F^.AllNodes) do begin
    SetLength(F^.AllNodes[I]^.Operands, 0);
    SetLength(F^.AllNodes[I]^.PhiBlocks, 0);
    Dispose(F^.AllNodes[I]);
  end;
  SetLength(F^.AllNodes, 0);
  for I := 0 to High(F^.Blocks) do begin
    SetLength(F^.Blocks[I].Nodes, 0);
    SetLength(F^.Blocks[I].Succs, 0);
    SetLength(F^.Blocks[I].Preds, 0);
    SetLength(F^.Blocks[I].DomChildren, 0);
    SetLength(F^.Blocks[I].DF, 0);
  end;
  SetLength(F^.Blocks, 0);
  SetLength(F^.ImplicitDefs, 0);
  Dispose(F);
end;

end.
