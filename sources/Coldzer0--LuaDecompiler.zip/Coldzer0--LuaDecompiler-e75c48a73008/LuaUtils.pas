Unit LuaUtils;

{$mode ObjFPC}{$H+}

Interface

Uses
  SysUtils;

Function EscapeString(Const S: AnsiString): AnsiString;

Implementation

Function EscapeString(Const S: AnsiString): AnsiString;
Var
  i: Integer;

  Function ByteEscape(B: Byte): AnsiString;
  Begin
    Result := '\' +
              Chr(Ord('0') + (B div 100)) +
              Chr(Ord('0') + ((B div 10) mod 10)) +
              Chr(Ord('0') + (B mod 10));
  End;

Begin
  Result := '';
  For i := 1 To Length(S) Do
    Case S[i] Of
      #10: Result += '\n';
      #13: Result += '\r';
      #9: Result += '\t';
      '\': Result += '\\';
      '"': Result += '\"';
      Else
        If (Ord(S[i]) < 32) Or (Ord(S[i]) > 126) Then
          Result += ByteEscape(Ord(S[i]))
        Else
          Result += S[i];
    End;
End;

End.
