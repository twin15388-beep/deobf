-- Local function declaration pattern edge cases
-- Tests CLOSURE + MOVE patterns and local function vs local = function

-- local function syntax (syntactic sugar, creates self-referencing upvalue)
local function f1(n)
  if n <= 0 then return 0 end
  return f1(n - 1) + n
end

-- local = function syntax (different bytecode: no self-reference upvalue)
local f2 = function(n)
  return n * 2
end

-- Forward declaration pattern
local f3
f3 = function(n)
  if n <= 0 then return 0 end
  return f3(n - 1) + n
end

-- Local function with upvalues from enclosing scope
local function make_pair()
  local value = 0

  local function get()
    return value
  end

  local function set(v)
    value = v
  end

  return get, set
end

-- Local function defined in loop
local function funcs_in_loop()
  local result = {}
  for i = 1, 5 do
    local function handler(x)
      return x + i
    end
    result[i] = handler
  end
  return result
end

-- Local function defined in conditional
local function func_in_cond(flag)
  local handler
  if flag then
    local function positive(x)
      return x
    end
    handler = positive
  else
    local function negative(x)
      return -x
    end
    handler = negative
  end
  return handler
end

-- Multiple local functions declared in sequence
local function sequence()
  local function step1(x) return x + 1 end
  local function step2(x) return x * 2 end
  local function step3(x) return x - 3 end
  return step3(step2(step1(10)))
end

-- Local function as argument to another function
local function as_callback()
  local function compare(a, b)
    return a < b
  end
  table.sort(data, compare)
end

-- Nested local function declarations
local function outer()
  local function mid()
    local function inner()
      return "inner"
    end
    return inner()
  end
  return mid()
end

print(f1(10))
print(f2(5))
print(f3(10))
local get, set = make_pair()
set(42)
print(get())
print(sequence())
print(outer())
