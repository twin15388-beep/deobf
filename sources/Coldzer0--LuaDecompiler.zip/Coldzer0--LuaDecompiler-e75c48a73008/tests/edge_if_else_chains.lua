-- If/elseif/else chain edge cases
-- Tests branch target resolution and merge block detection

-- Long elseif chain
local function long_elseif(x)
  if x == 1 then
    return "one"
  elseif x == 2 then
    return "two"
  elseif x == 3 then
    return "three"
  elseif x == 4 then
    return "four"
  elseif x == 5 then
    return "five"
  elseif x == 6 then
    return "six"
  elseif x == 7 then
    return "seven"
  else
    return "other"
  end
end

-- If-else with different ending patterns
local function if_else_endings(x)
  local result
  if x > 0 then
    result = "positive"
  else
    result = "non-positive"
  end
  return result
end

-- If without else, followed by code
local function if_no_else(x)
  if x > 0 then
    print("positive")
  end
  print("always")
end

-- Nested if-else where inner else merges with outer
local function nested_merge(a, b)
  if a then
    if b then
      print("both")
    else
      print("only a")
    end
  else
    if b then
      print("only b")
    else
      print("neither")
    end
  end
end

-- If-else with early return in then branch
local function early_return(x)
  if x == nil then
    return "nil"
  end
  if x < 0 then
    return "negative"
  end
  return "ok: " .. tostring(x)
end

-- If-else with assignments in both branches
local function branch_assign(x)
  local a, b
  if x > 0 then
    a = x
    b = x * 2
  else
    a = 0
    b = 0
  end
  return a, b
end

-- If chain where each branch has different control flow
local function mixed_flow(x, t)
  if x == 1 then
    for i = 1, 10 do print(i) end
  elseif x == 2 then
    while t do t = t.next end
  elseif x == 3 then
    repeat t = update(t) until not t
  else
    return nil
  end
  return t
end

-- Empty then/else bodies
local function empty_branches(x)
  if x then
  else
    print("false")
  end
  if x then
    print("true")
  else
  end
end

-- Single-line if (still same bytecode as multi-line)
local function single_line(x)
  if x then f() end
  if x then f() else g() end
end

-- If inside loop with break
local function if_break(t)
  for i = 1, #t do
    if t[i] == nil then
      break
    elseif t[i] < 0 then
      t[i] = 0
    else
      t[i] = t[i] + 1
    end
  end
end

print(long_elseif(3))
print(early_return(-1))
print(branch_assign(5))
