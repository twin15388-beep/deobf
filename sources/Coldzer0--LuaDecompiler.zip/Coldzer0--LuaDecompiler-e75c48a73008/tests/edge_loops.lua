-- Loop edge cases
-- Tests FORPREP, FORLOOP, TFORLOOP, and loop/break/continue patterns

-- Numeric for with negative step
for i = 10, 1, -1 do
  print(i)
end

-- Numeric for with computed bounds
local function computed_for(a, b, c)
  for i = a * 2, b + c, c - a do
    print(i)
  end
end

-- Numeric for with float step
for i = 0.0, 1.0, 0.1 do
  print(i)
end

-- Generic for with pairs
for k, v in pairs({a = 1, b = 2, c = 3}) do
  print(k, v)
end

-- Generic for with ipairs
for i, v in ipairs({10, 20, 30}) do
  print(i, v)
end

-- Generic for with next
for k, v in next, {x = 1, y = 2} do
  print(k, v)
end

-- Generic for with custom iterator (stateless)
local function squares(max, current)
  current = current + 1
  if current > max then return nil end
  return current, current * current
end

for i, sq in squares, 5, 0 do
  print(i, sq)
end

-- Generic for with custom iterator (stateful closure)
local function range(n)
  local i = 0
  return function()
    i = i + 1
    if i <= n then return i end
  end
end

for v in range(5) do
  print(v)
end

-- While with complex condition
local x = 100
while x > 0 and not done do
  x = x - 1
  if x == 50 then
    done = true
  end
end

-- While true (infinite loop with break)
local count = 0
while true do
  count = count + 1
  if count > 10 then
    break
  end
end

-- Repeat with complex until condition
local attempts = 0
repeat
  attempts = attempts + 1
  local result = try_something()
until result == true or attempts >= 3

-- Nested loops with break in inner
for i = 1, 10 do
  for j = 1, 10 do
    if i * j > 50 then
      break
    end
    print(i, j)
  end
end

-- Break in middle of loop body
for i = 1, 100 do
  local x = compute(i)
  if x == nil then break end
  local y = process(x)
  if y < 0 then break end
  store(y)
end

-- Empty loop body
for i = 1, 1000000 do end

-- Single-iteration for
for i = 1, 1 do
  print(i)
end

-- For loop with upvalue capture of loop variable
local funcs = {}
for i = 1, 5 do
  funcs[i] = function() return i end
end

-- Nested for loops sharing same variable names in different scopes
for i = 1, 3 do
  for i = 1, 3 do
    print(i)
  end
end

-- While loop immediately followed by another while
while a do
  a = f()
end
while b do
  b = g()
end

-- Repeat inside while
while running do
  repeat
    local event = poll()
  until event ~= nil
  handle(event)
end

computed_for(1, 10, 2)
