local function check(items)
  for i = 1, #items do
    local v = items[i]
    if v == nil then return "nil_found" end
    if type(v) ~= "table" then return "not_table" end
    if v.valid ~= true then return "invalid" end
    print(v.name)
  end
  return "all_ok"
end
return check
