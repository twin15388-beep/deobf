-- Coroutine edge cases
-- Tests closure and call patterns around coroutine API

-- Basic coroutine
local function basic_coro()
  local co = coroutine.create(function(x)
    print("first yield")
    coroutine.yield(x + 1)
    print("second yield")
    coroutine.yield(x + 2)
    print("returning")
    return x + 3
  end)

  print(coroutine.resume(co, 10))
  print(coroutine.resume(co))
  print(coroutine.resume(co))
end

-- Coroutine wrap (returns iterator function)
local function wrap_coro()
  local gen = coroutine.wrap(function()
    for i = 1, 5 do
      coroutine.yield(i, i * i)
    end
  end)

  for a, b in gen do
    print(a, b)
  end
end

-- Coroutine as producer-consumer
local function producer()
  return coroutine.create(function()
    local i = 0
    while true do
      i = i + 1
      coroutine.yield(i)
    end
  end)
end

local function consumer(prod, n)
  for i = 1, n do
    local ok, val = coroutine.resume(prod)
    if ok then
      print(val)
    end
  end
end

-- Coroutine status checks
local function status_test()
  local co = coroutine.create(function()
    coroutine.yield()
  end)
  print(coroutine.status(co))  -- suspended
  coroutine.resume(co)
  print(coroutine.status(co))  -- suspended
  coroutine.resume(co)
  print(coroutine.status(co))  -- dead
end

-- Nested coroutines
local function nested_coro()
  local inner_co = coroutine.create(function()
    coroutine.yield("from inner")
    return "inner done"
  end)

  local outer_co = coroutine.create(function()
    local ok, val = coroutine.resume(inner_co)
    coroutine.yield("outer got: " .. val)
    ok, val = coroutine.resume(inner_co)
    return "outer done, inner: " .. val
  end)

  print(coroutine.resume(outer_co))
  print(coroutine.resume(outer_co))
end

-- Coroutine with upvalue
local function coro_upval()
  local shared = 0
  local co = coroutine.create(function()
    while true do
      shared = shared + 1
      coroutine.yield(shared)
    end
  end)
  coroutine.resume(co)
  coroutine.resume(co)
  print(shared)
end

basic_coro()
wrap_coro()
consumer(producer(), 5)
status_test()
nested_coro()
coro_upval()
