-- CONCAT instruction edge cases
-- Tests CONCAT with varying operand counts and nested concat patterns

-- Two-operand concat
local a = x .. y

-- Three-operand concat (single CONCAT instruction)
local b = x .. y .. z

-- Many operand concat (single CONCAT)
local c = a1 .. a2 .. a3 .. a4 .. a5 .. a6 .. a7 .. a8

-- Concat with literals
local d = "hello" .. " " .. "world"

-- Concat with tostring
local e = "value: " .. tostring(42)

-- Concat with number (implicit tostring by VM)
local f = "count: " .. 42

-- Nested concat with different grouping (two separate CONCAT instructions)
local g = (x .. y) .. (z .. w)

-- Concat in function call
print("a" .. "b" .. "c")

-- Concat in assignment target value
t.key = "prefix_" .. name .. "_suffix"

-- Concat in return
local function concat_return(a, b)
  return a .. " and " .. b
end

-- Concat in condition
local function concat_cond(s)
  if s .. "!" == "hello!" then
    print("match")
  end
end

-- Concat in loop building long string
local function build_csv(t)
  local result = ""
  for i = 1, #t do
    if i > 1 then
      result = result .. ","
    end
    result = result .. tostring(t[i])
  end
  return result
end

-- Concat with method result
local function method_concat(obj)
  return "Name: " .. obj:getName() .. " Age: " .. tostring(obj:getAge())
end

-- Concat mixed with arithmetic (forces separate expression trees)
local function mixed_ops(x, y)
  local s = "sum=" .. tostring(x + y) .. " prod=" .. tostring(x * y)
  return s
end

print(a, b, c, d, e, f, g)
print(concat_return("hello", "world"))
print(build_csv({1, 2, 3, 4}))
