-- Unary operator edge cases
-- Tests UNM, NOT, LEN opcodes and their expression recovery

-- Unary minus
local function unary_minus(x)
  local a = -x
  local b = -(-x)
  local c = -(x + 1)
  local d = -x + 1
  return a, b, c, d
end

-- Length operator
local function length_test(t, s)
  local a = #t
  local b = #s
  local c = #"literal"
  local d = #{1, 2, 3}
  return a, b, c, d
end

-- Length in expressions
local function len_expr(t)
  for i = 1, #t do
    print(t[i])
  end
  if #t > 0 then
    print("not empty")
  end
  local n = #t + 1
  t[n] = "new"
end

-- Not operator
local function not_test(x, y)
  local a = not x
  local b = not not x
  local c = not (x and y)
  local d = not (x or y)
  return a, b, c, d
end

-- Combined unary operators
local function combined(x)
  local a = -#x
  local b = #x + 1
  local c = not (#x > 0)
  return a, b, c
end

-- Unary in function call
local function unary_in_call(t)
  f(-x)
  g(#t)
  h(not flag)
end

-- Unary minus on constant (may be folded by compiler)
local function neg_const()
  local a = -1
  local b = -0
  local c = -3.14
  return a, b, c
end

print(unary_minus(5))
print(length_test({1,2,3}, "hello"))
print(not_test(true, false))
print(neg_const())
