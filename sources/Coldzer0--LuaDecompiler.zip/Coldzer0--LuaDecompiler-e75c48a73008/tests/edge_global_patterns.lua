-- Global variable access patterns
-- Tests GETGLOBAL/SETGLOBAL (5.1) and GETTABUP (5.2+) patterns

-- Simple global read/write
x = 1
y = x + 1
z = x + y

-- Global function definition
function global_func(a, b)
  return a + b
end

-- Nested global function (rare but valid)
function module.sub.func(x)
  return x * 2
end

-- Global as upvalue in closure
local function use_global()
  return function()
    return x + y
  end
end

-- Global modified in loop
function modify_globals(n)
  counter = 0
  for i = 1, n do
    counter = counter + 1
  end
  return counter
end

-- Global table operations
config = {}
config.debug = true
config.verbose = false
config.level = 3

-- Global function called as method
function obj_func(self, x)
  return self.value + x
end

-- Standard library globals
local function stdlib_globals()
  local s = tostring(42)
  local n = tonumber("42")
  local t = type(s)
  print(s, n, t)
  error("test")
end

-- Multiple globals in one expression
local function multi_global()
  return math.sin(x) + math.cos(y) + math.sqrt(z)
end

-- Global assigned from function result
result = compute()
status, err = pcall(dangerous)

-- Chained global access
local function chained_global()
  return os.clock()
end

-- Global in condition
if debug_mode then
  print("debug is on")
end

print(x, y, z)
print(global_func(1, 2))
print(config.debug, config.level)
