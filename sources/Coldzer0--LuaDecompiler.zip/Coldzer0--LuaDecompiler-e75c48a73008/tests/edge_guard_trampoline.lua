local function validate(a, b, c)
  if a > 0 then
    if b > 0 then
      if c > 0 then
        return "all_positive"
      end
      return "c_bad"
    end
    return "b_bad"
  end
  return "a_bad"
end
return validate
