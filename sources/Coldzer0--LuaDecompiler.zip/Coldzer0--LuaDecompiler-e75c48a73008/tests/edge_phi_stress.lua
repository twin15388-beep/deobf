-- PHI node and SSA edge cases
-- Tests patterns that generate complex PHI functions in SSA form

-- Variable assigned in both branches of if
local function phi_basic(x)
  local a
  if x > 0 then
    a = "positive"
  else
    a = "negative"
  end
  return a
end

-- Variable assigned in multiple elseif branches
local function phi_multi_branch(x)
  local result
  if x == 1 then
    result = "one"
  elseif x == 2 then
    result = "two"
  elseif x == 3 then
    result = "three"
  else
    result = "other"
  end
  return result
end

-- Variable modified in loop (loop-carried PHI)
local function phi_loop()
  local sum = 0
  for i = 1, 100 do
    sum = sum + i
  end
  return sum
end

-- Multiple variables with PHI at same merge point
local function phi_multi_var(x)
  local a, b
  if x then
    a = 1
    b = 2
  else
    a = 3
    b = 4
  end
  return a + b
end

-- PHI from nested if
local function phi_nested(x, y)
  local a = 0
  if x > 0 then
    if y > 0 then
      a = 1
    else
      a = 2
    end
  else
    a = 3
  end
  return a
end

-- PHI from while loop with conditional assignment
local function phi_while(limit)
  local last = nil
  local i = 0
  while i < limit do
    if i % 2 == 0 then
      last = i
    end
    i = i + 1
  end
  return last
end

-- PHI from repeat-until
local function phi_repeat()
  local x = 0
  local count = 0
  repeat
    x = x + math.random()
    count = count + 1
  until x > 10
  return count
end

-- Variable conditionally initialized then always used
local function phi_conditional_init(flag, x)
  local y
  if flag then
    y = x * 2
  else
    y = x * 3
  end
  print(y)
  return y + 1
end

-- Accumulator pattern (common SSA stress)
local function accumulate(t)
  local sum = 0
  local min = math.huge
  local max = -math.huge
  for i = 1, #t do
    sum = sum + t[i]
    if t[i] < min then min = t[i] end
    if t[i] > max then max = t[i] end
  end
  return sum, min, max
end

-- Boolean PHI (LOADBOOL skip pattern)
local function bool_phi(x, y)
  local result
  if x > y then
    result = true
  else
    result = false
  end
  return result
end

-- PHI with different types in branches
local function type_phi(x)
  local v
  if x == 1 then
    v = "string"
  elseif x == 2 then
    v = 42
  elseif x == 3 then
    v = true
  else
    v = nil
  end
  return v
end

print(phi_basic(1))
print(phi_multi_branch(2))
print(phi_loop())
print(phi_nested(1, -1))
print(accumulate({3, 1, 4, 1, 5, 9, 2, 6}))
print(type_phi(2))
