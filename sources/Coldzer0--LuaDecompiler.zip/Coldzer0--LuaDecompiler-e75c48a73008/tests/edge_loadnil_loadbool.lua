-- LOADNIL and LOADBOOL edge cases
-- Tests LOADNIL range patterns and LOADBOOL skip patterns

-- LOADNIL to single register
local a = nil

-- LOADNIL to range of registers
local b, c, d = nil, nil, nil

-- LOADNIL mixed with other inits
local e = nil
local f = 1
local g = nil

-- LOADBOOL patterns
local t1 = true
local f1 = false

-- LOADBOOL from comparison (generates LOADBOOL with skip)
local function compare_to_bool(x, y)
  local eq = x == y
  local lt = x < y
  local gt = x > y
  return eq, lt, gt
end

-- LOADBOOL in conditional context
local function bool_conditional(x)
  local a
  if x then
    a = true
  else
    a = false
  end
  return a
end

-- Nil check pattern
local function nil_check(x)
  if x == nil then
    return "is nil"
  end
  if x ~= nil then
    return "not nil"
  end
end

-- Nil assignment after use
local function nil_after_use()
  local x = compute()
  process(x)
  x = nil
  return x
end

-- Multiple nils in multi-assign
local function multi_nil()
  local a, b, c
  a, b, c = nil, nil, nil
  return a, b, c
end

-- Bool in table
local function bool_table()
  return {true, false, nil, true}
end

-- Bool from function
local function returns_true()
  return true
end

local function returns_false()
  return false
end

-- Chain of bool assignments
local function bool_chain(x)
  local a = x == 1
  local b = x == 2
  local c = x > 0
  local d = not a
  return a, b, c, d
end

print(compare_to_bool(1, 2))
print(bool_conditional(true))
print(nil_check(nil))
print(bool_chain(1))
