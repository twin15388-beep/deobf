-- Edge test: reverse multi-assign patterns (temp eval → reverse MOVE to locals)
-- Tests the pattern where Lua compiler evaluates RHS into temps, then
-- assigns to target registers in reverse order.

-- CASE 1: Simple reverse multi-assign with parameter pass-through
-- Mirrors tween.lua's performEasingOnSubject pattern
local function case1(clock, data, duration)
  local t, b, c, d
  t, b, c, d = clock, data[1], data[2] - data[1], duration
  return t, b, c, d
end

-- CASE 2: Reverse multi-assign with all computed values (no pass-through)
local function case2(x, y)
  local a, b, c
  a, b, c = x + 1, y + 2, x * y
  return a, b, c
end

-- CASE 3: Two-variable reverse assign
local function case3(x, y)
  local a, b
  a, b = x + 1, y + 2
  return a, b
end

-- CASE 4: Reverse multi-assign inside loop
local function case4(items, scale)
  local results = {}
  for i = 1, #items do
    local x, y, z
    x, y, z = items[i], items[i] * scale, items[i] + scale
    results[i] = x + y + z
  end
  return results
end

-- CASE 5: Reverse multi-assign with function call result (single-return)
local function getValue() return 42 end
local function case5(a, b)
  local x, y, z
  x, y, z = getValue(), a + b, a - b
  return x, y, z
end

-- CASE 6: Five-variable reverse assign
local function case6(a, b, c, d, e)
  local v, w, x, y, z
  v, w, x, y, z = a + 1, b + 2, c + 3, d + 4, e + 5
  return v, w, x, y, z
end

-- Run all cases
print(case1(10, {100, 200}, 5))
print(case2(3, 4))
print(case3(3, 4))
local r = case4({1, 2, 3}, 10)
print(r[1], r[2], r[3])
print(case5(10, 20))
print(case6(1, 2, 3, 4, 5))
