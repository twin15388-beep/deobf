-- Lua 5.5 specific edge cases
-- Tests new 5.5 features: generalized iteration back to 3 internal vars,
-- new opcodes, and other 5.5-specific patterns

-- Generic for in 5.5 (back to 3 internal vars like 5.1-5.3)
-- User variables at R(A+3) instead of R(A+4) like 5.4
local function basic_for_55(t)
  for k, v in pairs(t) do
    print(k, v)
  end
end

-- Nested generic for in 5.5
local function nested_55(t1, t2)
  for k1, v1 in pairs(t1) do
    for k2, v2 in pairs(t2) do
      print(k1, v1, k2, v2)
    end
  end
end

-- Generic for with break in 5.5
local function for_break_55(t, target)
  for k, v in pairs(t) do
    if v == target then
      return k
    end
  end
end

-- Numeric for (5.5 may have layout differences)
local function numeric_55()
  for i = 1, 10 do
    print(i)
  end
  for i = 10, 1, -1 do
    print(i)
  end
  for i = 1, 100, 3 do
    print(i)
  end
end

-- Complex loop nesting in 5.5
local function complex_55(data)
  local result = {}
  for i, row in ipairs(data) do
    for j, cell in ipairs(row) do
      if cell > 0 then
        result[#result + 1] = {i = i, j = j, val = cell}
      end
    end
  end
  return result
end

basic_for_55({a = 1, b = 2, c = 3})
nested_55({x = 1}, {y = 2})
numeric_55()
