-- Complex control flow patterns that stress decompiler CF recovery
-- Tests interaction of break, return, and nested loops

-- Break from multiple nesting levels (only breaks innermost)
local function multi_break(data)
  local found = nil
  for i = 1, #data do
    for j = 1, #data[i] do
      if data[i][j] == "target" then
        found = {i, j}
        break
      end
    end
    if found then
      break
    end
  end
  return found
end

-- Return from deeply nested context
local function deep_return(t)
  for i = 1, #t do
    for j = 1, #t[i] do
      for k = 1, #t[i][j] do
        if t[i][j][k] == 0 then
          return i, j, k
        end
      end
    end
  end
  return nil
end

-- While with multiple exit conditions
local function multi_exit(iter)
  local count = 0
  local last = nil
  while true do
    local val = iter()
    if val == nil then
      break
    end
    count = count + 1
    if count > 1000 then
      break
    end
    last = val
    if last == "stop" then
      break
    end
  end
  return count, last
end

-- If-else where both branches return
local function both_return(x)
  if x > 0 then
    return "positive"
  else
    return "non-positive"
  end
end

-- If-else where only one branch returns
local function one_return(x)
  if x > 0 then
    return "positive"
  end
  print("continuing")
  return "done"
end

-- Guard clause pattern (multiple early returns)
local function guard_clauses(x, y, z)
  if x == nil then return nil, "x is nil" end
  if y == nil then return nil, "y is nil" end
  if z == nil then return nil, "z is nil" end
  if x < 0 then return nil, "x negative" end
  if y < 0 then return nil, "y negative" end
  return x + y + z
end

-- Loop with continue-like pattern (5.1 style using nested if)
local function pseudo_continue(t)
  local result = {}
  for i = 1, #t do
    if t[i] >= 0 then
      if t[i] % 2 == 0 then
        result[#result + 1] = t[i]
      end
    end
  end
  return result
end

-- Complex repeat-until with local visible in condition
local function repeat_local_in_cond()
  repeat
    local line = io.read()
    if line then
      process(line)
    end
  until not line
end

-- Interleaved loops and conditions
local function interleaved(a, b)
  local x = 0
  while a > 0 do
    if b > 0 then
      for i = 1, b do
        x = x + i
      end
    else
      repeat
        x = x - 1
        a = a - 1
      until x <= 0
    end
    a = a - 1
  end
  return x
end

-- Loop with if-else-if chain in body
local function loop_chain(items)
  for i = 1, #items do
    local item = items[i]
    if item.type == "A" then
      handle_a(item)
    elseif item.type == "B" then
      handle_b(item)
      if item.sub then
        handle_sub(item.sub)
      end
    elseif item.type == "C" then
      if item.priority > 5 then
        handle_urgent(item)
      else
        handle_c(item)
      end
    else
      handle_default(item)
    end
  end
end

-- Switch-like pattern using if-elseif
local function switch_pattern(op, a, b)
  if op == "add" then
    return a + b
  elseif op == "sub" then
    return a - b
  elseif op == "mul" then
    return a * b
  elseif op == "div" then
    if b == 0 then
      return nil, "division by zero"
    end
    return a / b
  elseif op == "mod" then
    return a % b
  elseif op == "pow" then
    return a ^ b
  else
    return nil, "unknown op: " .. op
  end
end

print(both_return(1))
print(guard_clauses(1, 2, 3))
print(switch_pattern("add", 10, 20))
