-- Empty and minimal function edge cases
-- Tests decompiler handling of functions with no meaningful body

-- Completely empty function
local function empty()
end

-- Function with only return
local function just_return()
  return
end

-- Function with only return nil
local function return_nil()
  return nil
end

-- Function with only a single statement
local function one_stmt()
  print("hello")
end

-- Function with only local declarations (no usage)
local function only_decls()
  local a, b, c
end

-- Empty method
function obj:empty_method()
end

-- Empty closure
local cb = function() end

-- Empty vararg function
local function empty_vararg(...)
end

-- Closure returning closure returning nothing
local function nested_empty()
  return function()
    return function()
    end
  end
end

-- Function with empty if body
local function empty_if(x)
  if x then
  end
end

-- Function with empty loop body
local function empty_loop()
  for i = 1, 10 do
  end
  while false do
  end
end

-- Function body is just a comment (compiles to empty)
local function just_comment()
  -- this is just a comment
end

empty()
just_return()
print(return_nil())
one_stmt()
only_decls()
print(nested_empty()()())
