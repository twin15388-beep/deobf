-- Lua 5.3+ integer subtype edge cases
-- Tests LOADK for integer vs float constants, integer arithmetic

-- Integer literal patterns
local a = 0
local b = 1
local c = -1
local d = 2147483647         -- max 32-bit int
local e = -2147483648        -- min 32-bit int
local f = 9223372036854775807   -- max 64-bit int (if size_t allows)

-- Float literal patterns
local g = 0.0
local h = 1.0
local i = -1.0
local j = 1e100
local k = 1e-100

-- Hex integer literals
local hex1 = 0x0
local hex2 = 0xFF
local hex3 = 0xDEADBEEF

-- Integer modulo (% operator on integers)
local function imod(a, b)
  return a % b
end

-- Integer power (^ always returns float in 5.3)
local function ipow(a, b)
  return a ^ b
end

-- Integer string conversion (tostring(int) vs tostring(float))
local function int_str()
  print(tostring(42))     -- "42"
  print(tostring(42.0))   -- "42.0"
end

-- math.type distinguishing (tests runtime but exercises constant loading)
local function type_test()
  local x = 42
  local y = 42.0
  return type(x), type(y)
end

print(a, b, c, d, e, f)
print(g, h, i, j, k)
print(hex1, hex2, hex3)
print(imod(7, 3))
print(ipow(2, 10))
int_str()
