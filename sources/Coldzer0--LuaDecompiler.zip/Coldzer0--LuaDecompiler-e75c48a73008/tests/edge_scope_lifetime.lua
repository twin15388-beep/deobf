-- Variable scope and lifetime edge cases
-- Tests local declaration patterns, do-end scope, and register reuse

-- Locals declared in sequence with interleaved usage
local a = 1
print(a)
local b = 2
print(a, b)
local c = 3
print(a, b, c)

-- Locals reusing registers after going out of scope
do
  local x = 10
  print(x)
end
do
  local y = 20  -- may reuse same register as x
  print(y)
end

-- Many nested do-end scopes
do
  local a = 1
  do
    local b = 2
    do
      local c = 3
      do
        local d = 4
        print(a, b, c, d)
      end
      print(a, b, c)
    end
    print(a, b)
  end
  print(a)
end

-- Local variable shadowing
local x = "outer"
do
  local x = "inner"
  print(x)
end
print(x)

-- For loop variable scope
for i = 1, 3 do
  -- i is scoped to loop body
end
-- i should not be accessible here

-- Generic for variable scope
for k, v in pairs({}) do
  -- k, v scoped to loop body
end

-- Local in condition body
if true then
  local cond_local = "in if"
  print(cond_local)
end

-- Multiple locals on one line, partial init
local p, q, r = 1, 2
print(p, q, r)  -- r is nil

-- Local reuse across branches
local function branch_locals(x)
  if x then
    local a = "then"
    print(a)
  else
    local a = "else"  -- different 'a', may share register
    print(a)
  end
end

-- Locals that are assigned but never read (dead stores)
local function dead_stores()
  local unused = compute()
  local result = other()
  return result
end

-- Local declared at different points in loop
local function loop_locals()
  for i = 1, 5 do
    local x = i * 2
    if x > 6 then
      local y = x - 6
      print(y)
    end
  end
end

branch_locals(true)
branch_locals(false)
loop_locals()
