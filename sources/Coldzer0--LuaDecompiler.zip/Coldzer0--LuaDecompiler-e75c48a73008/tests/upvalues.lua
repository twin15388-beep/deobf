-- ORIGINAL FILE, DO NOT EDIT --

function foo ()
 function makeAdder (withWhat)
   return function (a)
     local b = a + withWhat
     withWhat = withWhat + 10
     return b
   end, function (a)
     return a + withWhat --Will be affected by the above function
   end
 end

 f1, f2 = makeAdder (6)
end

foo ()
print (f1 (2))  --> 8
print (f2 (2))  --> 18


local up1 = "up1"
local up2 = "up2"
local function test1(a, b, x, y)
  if b == x then
    if a == 0 and b ~= 1 or x == 99 and y ~= 0 then
      print("check 1")
      if x > 0 then
        print("check 2")
      else
        print("nope")
      end
      x = b
    end
    print("done")
  end
  function check_values()
    print("upvalues check: " .. up1 .. " - " .. up2)
  end
  check_values()
end
test1(0, 2, 2, 4)
