@echo off
setlocal

where luac5.1.exe >nul 2>nul
if errorlevel 1 (
    echo ERROR: luac5.1.exe not found in PATH
    pause
    exit /b 1
)

for %%F in (*.lua) do (
    echo [*] Compiling %%F
    luac5.1.exe -o "..\compiled\%%~nF.luac" "%%F"
    if errorlevel 1 (
        echo [!] Failed compiling %%F
    )
)

echo Build complete.
