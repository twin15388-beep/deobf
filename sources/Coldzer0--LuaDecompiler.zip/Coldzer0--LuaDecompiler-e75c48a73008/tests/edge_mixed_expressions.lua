-- Mixed expression edge cases
-- Tests expression tree building with complex operator combinations

-- Deeply nested arithmetic (tests parenthesization recovery)
local function deep_arith(a, b, c, d, e)
  local x = ((a + b) * (c - d)) / (e + 1)
  local y = a + (b * (c + (d * (e + 1))))
  local z = (((a + b) + c) + d) + e
  return x, y, z
end

-- Operator precedence stress
local function precedence(a, b, c, d)
  local v1 = a + b * c          -- a + (b * c)
  local v2 = (a + b) * c        -- explicit parens
  local v3 = a ^ b ^ c          -- right-assoc: a ^ (b ^ c)
  local v4 = (a ^ b) ^ c        -- explicit left-assoc
  local v5 = a .. b .. c        -- right-assoc: a .. (b .. c)
  local v6 = (a .. b) .. c      -- explicit left-assoc
  local v7 = -a ^ b             -- -(a ^ b)
  local v8 = (-a) ^ b           -- explicit
  local v9 = not a == b         -- (not a) == b
  local v10 = a + b % c         -- a + (b % c)
  return v1, v2, v3, v4, v5, v6, v7, v8, v9, v10
end

-- Expression as function argument
local function expr_in_call(x, y)
  f(x + y, x - y, x * y)
  g(x == y, x < y, x <= y)
  h(x and y, x or y, not x)
  print(x .. " " .. y)
end

-- Expression as table value
local function expr_in_table(x, y)
  return {
    sum = x + y,
    diff = x - y,
    prod = x * y,
    cond = x > 0 and x or -x,
  }
end

-- Expression as loop bound
local function expr_bounds(t)
  for i = 1, #t - 1 do
    for j = i + 1, #t do
      if t[i] > t[j] then
        t[i], t[j] = t[j], t[i]
      end
    end
  end
end

-- Expression with method call result
local function method_expr(obj)
  local x = obj:getValue() + 1
  local y = obj:getA() * obj:getB()
  local z = obj:calculate(x, y) + obj:offset()
  return z
end

-- Complex conditional expression
local function complex_cond(a, b, c, d)
  if (a > 0 and b > 0) or (c > 0 and d > 0) then
    if not (a == b and c == d) then
      return true
    end
  end
  return false
end

-- Concat with conversion
local function concat_convert(n, b, t)
  local s = "num=" .. tostring(n) .. " bool=" .. tostring(b)
  return s
end

-- Expression involving constants and globals
local function const_expr()
  local x = math.pi * 2
  local y = math.huge
  local z = math.maxinteger or 2^53
  return x, y, z
end

print(deep_arith(1, 2, 3, 4, 5))
print(precedence(2, 3, 4, 5))
print(complex_cond(1, 1, -1, -1))
