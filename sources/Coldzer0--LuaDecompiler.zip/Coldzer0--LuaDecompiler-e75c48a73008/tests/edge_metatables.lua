-- Metatable and metamethod edge cases
-- Tests GETTABLE/SETTABLE/SELF patterns combined with setmetatable

-- Class-like OOP pattern
local Animal = {}
Animal.__index = Animal

function Animal.new(name, sound)
  return setmetatable({
    name = name,
    sound = sound,
    alive = true,
  }, Animal)
end

function Animal:speak()
  if self.alive then
    print(self.name .. " says " .. self.sound)
  end
end

function Animal:getName()
  return self.name
end

-- Inheritance pattern
local Dog = setmetatable({}, {__index = Animal})
Dog.__index = Dog

function Dog.new(name)
  local self = Animal.new(name, "woof")
  return setmetatable(self, Dog)
end

function Dog:fetch(item)
  print(self.name .. " fetches " .. item)
end

-- Operator overloading
local Vector = {}
Vector.__index = Vector

function Vector.new(x, y)
  return setmetatable({x = x, y = y}, Vector)
end

function Vector.__add(a, b)
  return Vector.new(a.x + b.x, a.y + b.y)
end

function Vector.__sub(a, b)
  return Vector.new(a.x - b.x, a.y - b.y)
end

function Vector.__mul(a, b)
  if type(a) == "number" then
    return Vector.new(a * b.x, a * b.y)
  elseif type(b) == "number" then
    return Vector.new(a.x * b, a.y * b)
  end
  return a.x * b.x + a.y * b.y
end

function Vector.__eq(a, b)
  return a.x == b.x and a.y == b.y
end

function Vector.__lt(a, b)
  return (a.x * a.x + a.y * a.y) < (b.x * b.x + b.y * b.y)
end

function Vector.__tostring(v)
  return "(" .. v.x .. ", " .. v.y .. ")"
end

function Vector.__len(v)
  return math.sqrt(v.x * v.x + v.y * v.y)
end

function Vector.__unm(v)
  return Vector.new(-v.x, -v.y)
end

function Vector.__concat(a, b)
  return tostring(a) .. tostring(b)
end

-- __index as function
local Proxy = {}
Proxy.__index = function(self, key)
  return rawget(self, "_data")[key]
end
Proxy.__newindex = function(self, key, value)
  rawget(self, "_data")[key] = value
end

local function make_proxy(data)
  return setmetatable({_data = data}, Proxy)
end

-- __call metamethod
local Callable = {}
Callable.__index = Callable
Callable.__call = function(self, ...)
  return self.fn(...)
end

local function make_callable(fn)
  return setmetatable({fn = fn}, Callable)
end

-- Chained metamethods
local v1 = Vector.new(1, 2)
local v2 = Vector.new(3, 4)
local v3 = v1 + v2
local v4 = v3 * 2
local v5 = -v4

-- rawget/rawset patterns
local function raw_access(t)
  rawset(t, "key", "value")
  local v = rawget(t, "key")
  return v
end

local dog = Dog.new("Rex")
dog:speak()
dog:fetch("ball")

local p = make_proxy({x = 10, y = 20})
print(p.x, p.y)

local add = make_callable(function(a, b) return a + b end)
print(add(1, 2))
