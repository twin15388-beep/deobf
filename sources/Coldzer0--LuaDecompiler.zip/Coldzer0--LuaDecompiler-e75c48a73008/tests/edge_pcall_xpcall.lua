-- pcall/xpcall and error handling edge cases
-- Tests CALL patterns with error handling idioms

-- Basic pcall
local function basic_pcall()
  local ok, result = pcall(dangerous_function)
  if ok then
    print("success:", result)
  else
    print("error:", result)
  end
end

-- pcall with anonymous function
local function pcall_anon()
  local ok, err = pcall(function()
    error("boom")
  end)
  return ok, err
end

-- pcall with arguments
local function pcall_args(x, y)
  local ok, a, b = pcall(multi_return_func, x, y)
  return ok, a, b
end

-- Nested pcall
local function nested_pcall()
  local ok1, result1 = pcall(function()
    local ok2, result2 = pcall(function()
      error("inner error")
    end)
    if not ok2 then
      error("outer error: " .. result2)
    end
  end)
  return ok1, result1
end

-- xpcall with message handler
local function xpcall_test()
  local ok, result = xpcall(
    function()
      error("test error")
    end,
    function(err)
      return "handled: " .. err
    end
  )
  return ok, result
end

-- Error with level
local function error_levels()
  local function inner()
    error("error at level 2", 2)
  end
  local function outer()
    inner()
  end
  return pcall(outer)
end

-- Error with table value
local function error_table()
  local ok, err = pcall(function()
    error({code = 404, msg = "not found"})
  end)
  if not ok then
    print(err.code, err.msg)
  end
end

-- Protected method call
local function safe_method(obj, method, ...)
  return pcall(obj[method], obj, ...)
end

-- Retry pattern
local function retry(fn, max_attempts)
  local last_err
  for i = 1, max_attempts do
    local ok, result = pcall(fn)
    if ok then
      return result
    end
    last_err = result
  end
  error("failed after " .. max_attempts .. " attempts: " .. tostring(last_err))
end

basic_pcall()
print(pcall_anon())
print(xpcall_test())
print(error_levels())
error_table()
