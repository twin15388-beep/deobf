-- Lua 5.4+ warn function and other 5.4-specific patterns
-- Tests handling of 5.4-specific library functions and patterns

-- warn function (5.4+)
warn("@on")
warn("this is a warning")
warn("@off")

-- Conditional warn
local function maybe_warn(x)
  if x > 100 then
    warn("value too large: ", tostring(x))
  end
end

-- math.maxinteger / math.mininteger (5.3+ but commonly used with 5.4 patterns)
local function int_limits()
  local max = math.maxinteger
  local min = math.mininteger
  return max, min
end

-- Coroutine close (5.4+)
local function coro_close()
  local co = coroutine.create(function()
    coroutine.yield(1)
    coroutine.yield(2)
  end)
  local ok, val = coroutine.resume(co)
  print(ok, val)
  coroutine.close(co)
end

-- Table move (5.3+ but tests table operations)
local function table_move_test()
  local t = {1, 2, 3, 4, 5}
  table.move(t, 1, 3, 2)
  return t
end

maybe_warn(200)
print(int_limits())
coro_close()
