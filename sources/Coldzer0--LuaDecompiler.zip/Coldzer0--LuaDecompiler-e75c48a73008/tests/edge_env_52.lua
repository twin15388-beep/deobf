-- Lua 5.2+ _ENV manipulation edge cases
-- Tests GETTABUP/SETTABUP patterns (5.2 replaced GETGLOBAL/SETGLOBAL)

-- Basic global access (through _ENV upvalue in 5.2+)
x = 1
y = x + 1
print(x, y)

-- Explicit _ENV manipulation
local function sandboxed()
  local _ENV = {print = print, math = math}
  print(math.pi)
end

-- _ENV as parameter
local function with_env(_ENV)
  x = 1
  print(x)
end

-- Nested _ENV
local function outer_env()
  local _ENV = {print = print}
  local function inner()
    print("inner sees outer _ENV")
  end
  inner()
end

-- Global vs local shadowing with _ENV
local function shadow_test()
  local print = print
  local _ENV = {}
  print("still works via local")
end

sandboxed()
with_env({print = print})
outer_env()
shadow_test()
