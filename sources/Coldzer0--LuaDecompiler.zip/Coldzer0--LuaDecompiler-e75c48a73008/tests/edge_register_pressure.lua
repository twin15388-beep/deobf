-- Register pressure edge cases
-- Tests patterns that use many registers simultaneously

-- Many local variables
local function many_locals()
  local a, b, c, d, e, f, g, h = 1, 2, 3, 4, 5, 6, 7, 8
  local i, j, k, l, m, n, o, p = 9, 10, 11, 12, 13, 14, 15, 16
  return a + b + c + d + e + f + g + h + i + j + k + l + m + n + o + p
end

-- Function with many parameters
local function many_params(a, b, c, d, e, f, g, h, i, j)
  return a + b + c + d + e + f + g + h + i + j
end

-- Function call with many arguments
local function many_args()
  return f(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12)
end

-- Complex expression using many temporaries
local function complex_expr(a, b, c, d)
  return (a + b) * (c - d) + (a - b) * (c + d) + (a * c) - (b * d)
end

-- Nested function calls (each level uses stack space)
local function nested_calls(x)
  return f(g(h(i(j(x)))))
end

-- Multiple function calls in same expression
local function multi_call_expr()
  return f() + g() + h() + i() + j()
end

-- Table constructor with computed values
local function computed_table(x)
  return {
    a = x + 1,
    b = x + 2,
    c = x * 2,
    d = x * 3,
    e = x ^ 2,
    f = -x,
    g = x + 10,
    h = x - 10,
  }
end

-- Many locals that go in and out of scope
local function scope_pressure()
  local result = 0
  do
    local a, b = 1, 2
    result = result + a + b
  end
  do
    local c, d = 3, 4
    result = result + c + d
  end
  do
    local e, f = 5, 6
    result = result + e + f
  end
  do
    local g, h = 7, 8
    result = result + g + h
  end
  return result
end

-- Interleaved variable uses
local function interleaved()
  local a = f()
  local b = g()
  local c = h()
  print(a, b)
  local d = i()
  print(c, d)
  local e = j()
  print(a, c, e)
  return b + d
end

print(many_locals())
print(many_params(1, 2, 3, 4, 5, 6, 7, 8, 9, 10))
print(scope_pressure())
