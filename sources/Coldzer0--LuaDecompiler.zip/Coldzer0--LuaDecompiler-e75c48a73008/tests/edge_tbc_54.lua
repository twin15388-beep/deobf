-- Lua 5.4+ to-be-closed variable edge cases
-- Tests TBC opcode and <close> attribute recovery

-- Basic to-be-closed variable
local function basic_tbc()
  local f <close> = io.open("test.txt", "r")
  if f then
    return f:read("*a")
  end
end

-- To-be-closed with __close metamethod
local function custom_close()
  local obj <close> = setmetatable({}, {
    __close = function(self, err)
      print("closing", err)
    end,
  })
  print("using obj")
end

-- Multiple to-be-closed in same scope
local function multi_tbc()
  local f1 <close> = io.open("file1.txt", "r")
  local f2 <close> = io.open("file2.txt", "r")
  if f1 and f2 then
    return f1:read("*l"), f2:read("*l")
  end
end

-- To-be-closed in loop
local function tbc_in_loop(files)
  for _, name in ipairs(files) do
    local f <close> = io.open(name, "r")
    if f then
      process(f:read("*a"))
    end
  end
end

-- To-be-closed with error handling
local function tbc_error()
  local f <close> = io.open("test.txt")
  error("something went wrong")
  -- f should still be closed
end

-- To-be-closed in nested scopes
local function tbc_nested()
  local outer <close> = make_resource("outer")
  do
    local inner <close> = make_resource("inner")
    use(inner)
  end
  -- inner is closed here, outer still open
  use(outer)
end

-- Const attribute (5.4+)
local function const_test()
  local PI <const> = 3.14159265358979
  local NAME <const> = "constant"
  return PI, NAME
end

-- Mix of const and close
local function mixed_attrs()
  local MAX <const> = 100
  local f <close> = io.open("data.txt")
  for i = 1, MAX do
    if f then
      local line = f:read("*l")
      if not line then break end
      process(line)
    end
  end
end

basic_tbc()
custom_close()
multi_tbc()
const_test()
