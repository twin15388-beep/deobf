-- Lua 5.3+ integer division and bitwise operator edge cases
-- Tests IDIV, BAND, BOR, BXOR, BNOT, SHL, SHR opcodes

-- Integer division operator
local function int_division(a, b)
  return a // b
end

-- Integer division vs float division
local function div_compare(a, b)
  local float_div = a / b
  local int_div = a // b
  return float_div, int_div
end

-- Integer division with negative numbers
local function neg_idiv()
  local a = 7 // 2      -- 3
  local b = -7 // 2     -- -4
  local c = 7 // -2     -- -4
  local d = -7 // -2    -- 3
  return a, b, c, d
end

-- Bitwise AND
local function band_test(a, b)
  return a & b
end

-- Bitwise OR
local function bor_test(a, b)
  return a | b
end

-- Bitwise XOR
local function bxor_test(a, b)
  return a ~ b
end

-- Bitwise NOT
local function bnot_test(a)
  return ~a
end

-- Left shift
local function shl_test(a, n)
  return a << n
end

-- Right shift
local function shr_test(a, n)
  return a >> n
end

-- Combined bitwise operations
local function bitmask_ops(flags, mask)
  local set = flags | mask
  local clear = flags & ~mask
  local toggle = flags ~ mask
  local check = (flags & mask) ~= 0
  return set, clear, toggle, check
end

-- Bitwise in conditions
local function bit_condition(flags)
  if flags & 0x01 ~= 0 then
    print("bit 0 set")
  end
  if flags & 0x02 ~= 0 then
    print("bit 1 set")
  end
  if flags & 0x04 ~= 0 then
    print("bit 2 set")
  end
end

-- Operator precedence: bitwise vs arithmetic vs comparison
local function precedence_test(a, b, c)
  local x = a + b & c       -- (a + b) & c
  local y = a & b + c       -- a & (b + c)
  local z = a | b & c       -- a | (b & c)
  local w = a << b + c      -- a << (b + c)
  return x, y, z, w
end

-- Integer constants (5.3 distinguishes int from float)
local function int_constants()
  local int = 42
  local float = 42.0
  local hex = 0xFF
  local big = 9007199254740992
  return int, float, hex, big
end

-- Mixed int/float arithmetic
local function mixed_arithmetic(a, b)
  local int_result = a + b           -- int if both are int
  local float_result = a + b + 0.0   -- forces float
  local floor_result = a // 1        -- floor to int
  return int_result, float_result, floor_result
end

-- Shift patterns for power of 2
local function pow2(n)
  return 1 << n
end

-- Bit extraction
local function extract_bits(value, offset, width)
  return (value >> offset) & ((1 << width) - 1)
end

print(int_division(7, 2))
print(neg_idiv())
print(band_test(0xFF, 0x0F))
print(bor_test(0xF0, 0x0F))
print(bxor_test(0xFF, 0x0F))
print(bnot_test(0))
print(shl_test(1, 8))
print(shr_test(256, 4))
print(bitmask_ops(0x05, 0x03))
bit_condition(0x07)
print(pow2(10))
print(extract_bits(0xABCD, 4, 8))
