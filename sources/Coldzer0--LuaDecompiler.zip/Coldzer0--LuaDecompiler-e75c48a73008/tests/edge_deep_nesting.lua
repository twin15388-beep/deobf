-- Deep nesting stress test: nested if/while/for/repeat to 6+ levels
-- Tests structured CF recovery under deep nesting

local function deep_control(a, b, c, d, e, f)
  if a > 0 then
    while b > 0 do
      for i = 1, c do
        repeat
          if d == 1 then
            if e then
              for j = 1, f do
                print(i, j)
              end
            else
              while e == nil do
                e = f
                break
              end
            end
          elseif d == 2 then
            repeat
              if a > b then
                for k = c, 1, -1 do
                  if k == d then
                    print("found", k)
                  end
                end
              end
              d = d - 1
            until d <= 0
          end
          f = f - 1
        until f <= 0
      end
      b = b - 1
    end
  end
end

-- Deeply nested table access
local function deep_table_access(t)
  if t then
    if t.a then
      if t.a.b then
        if t.a.b.c then
          if t.a.b.c.d then
            return t.a.b.c.d.e
          end
        end
      end
    end
  end
  return nil
end

-- Nested closures with upvalue chains
local function outer(x)
  local function mid(y)
    local function inner(z)
      return x + y + z
    end
    return inner
  end
  return mid
end

deep_control(5, 3, 2, 1, true, 4)
print(deep_table_access({a = {b = {c = {d = {e = 42}}}}}))
print(outer(1)(2)(3))
