-- Complex table constructor edge cases
-- Tests NEWTABLE, SETLIST, SETTABLE inlining patterns

-- Empty table
local empty = {}

-- Table with exactly 50 elements (SETLIST flush boundary at LFIELDS_PER_FLUSH=50)
local big = {
  1, 2, 3, 4, 5, 6, 7, 8, 9, 10,
  11, 12, 13, 14, 15, 16, 17, 18, 19, 20,
  21, 22, 23, 24, 25, 26, 27, 28, 29, 30,
  31, 32, 33, 34, 35, 36, 37, 38, 39, 40,
  41, 42, 43, 44, 45, 46, 47, 48, 49, 50
}

-- Table with 51 elements (crosses SETLIST boundary)
local big2 = {
  1, 2, 3, 4, 5, 6, 7, 8, 9, 10,
  11, 12, 13, 14, 15, 16, 17, 18, 19, 20,
  21, 22, 23, 24, 25, 26, 27, 28, 29, 30,
  31, 32, 33, 34, 35, 36, 37, 38, 39, 40,
  41, 42, 43, 44, 45, 46, 47, 48, 49, 50,
  51
}

-- Mixed array + hash parts
local mixed = {
  "first",
  "second",
  name = "test",
  value = 42,
  "third",
  nested = {1, 2, 3},
  "fourth",
}

-- Nested table constructors
local nested = {
  {1, 2, 3},
  {4, 5, 6},
  {a = {b = {c = "deep"}}},
}

-- Table with function call as last element (vararg tail)
local with_call = {1, 2, 3, f()}

-- Table with function call NOT as last element (adjusted to 1)
local with_call_mid = {1, f(), 3, 4}

-- Table with only hash part
local hash_only = {
  x = 1,
  y = 2,
  z = 3,
  w = 4,
}

-- I added this missing function 
local function f(arg1)
  return arg1
end

-- Table with expression keys
local expr_keys = {
  [1 + 1] = "two",
  ["hello" .. "world"] = true,
  [f(1)] = "dynamic", -- I added an arg to it can run
  [true] = "bool_key",
}

-- Table with method-style values
local with_methods = {
  name = "obj",
  getValue = function(self)
    return self.name
  end,
  process = function(self, x)
    return x * 2
  end,
}

-- Single-element tables
local one_array = {42}
local one_hash = {x = 1}
local one_expr = {[3] = "three"}

-- Table constructor used directly in function call
print({1, 2, 3})
f({a = 1, b = 2})

-- Table constructor used in assignment to table field
local t = {}
t.sub = {1, 2, 3}
t[1] = {a = "b"}
