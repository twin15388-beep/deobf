-- Early return, do-return, and multiple return path edge cases
-- Tests return instruction placement and CLOSE before return

-- do return end in middle of function
local function early_do_return(x)
  if x == 0 then
    do return "zero" end
  end
  print("not zero")
  return "nonzero"
end

-- Multiple return statements in different branches
local function multi_return_paths(x, y)
  if x > 0 then
    if y > 0 then
      return "both positive"
    else
      return "x positive"
    end
  elseif x < 0 then
    return "x negative"
  end
  return "x zero"
end

-- Return with no values
local function return_nothing(x)
  if x then
    return
  end
  print("reached")
end

-- Return with multiple values
local function return_multi()
  return 1, 2, 3
end

-- Return with function call (vararg return)
local function return_call()
  return f()
end

-- Return with adjusted function call
local function return_adjusted_call()
  return (f())
end

-- Return from within try-like pattern
local function return_from_try()
  local ok, err = pcall(function()
    if condition then
      return "from inner"
    end
  end)
  if not ok then
    return nil, err
  end
  return "ok"
end

-- Implicit return (end of function with no explicit return)
local function implicit_return()
  print("hello")
end

-- Return from repeat-until
local function return_from_repeat()
  repeat
    local x = compute()
    if x > 100 then
      return x
    end
  until false
end

-- Return table constructor
local function return_table()
  return {1, 2, 3, key = "value"}
end

-- Return closure
local function return_closure(x)
  return function(y)
    return x + y
  end
end

-- Return with concat
local function return_concat(a, b)
  return a .. ": " .. b
end

-- Return boolean expression
local function return_bool_expr(x, y)
  return x and y or "default"
end

print(early_do_return(0))
print(early_do_return(1))
print(multi_return_paths(1, -1))
print(return_multi())
print(return_bool_expr(nil, "y"))
