-- Closure edge cases
-- Tests CLOSURE opcode, upvalue encoding, and closure patterns

-- Closure as immediate call (IIFE)
local result = (function(x) return x * 2 end)(21)

-- Closure returned from closure
local function make_adder(x)
  return function(y)
    return function(z)
      return x + y + z
    end
  end
end

-- Closure with no upvalues
local function no_upval()
  return function(x) return x end
end

-- Closure with many upvalues
local function many_upvals()
  local a, b, c, d, e, f, g, h = 1, 2, 3, 4, 5, 6, 7, 8
  return function()
    return a + b + c + d + e + f + g + h
  end
end

-- Closure that captures loop variable and local
local function capture_mix()
  local base = 100
  local results = {}
  for i = 1, 5 do
    local offset = i * 10
    results[i] = function()
      return base + offset
    end
  end
  return results
end

-- Recursive local function (self-reference via upvalue)
local function make_recursive()
  local function helper(n)
    if n <= 0 then return 0 end
    return n + helper(n - 1)
  end
  return helper
end

-- Mutual recursion between closures
local function mutual()
  local f, g
  f = function(n)
    if n <= 0 then return "done" end
    return g(n - 1)
  end
  g = function(n)
    if n <= 0 then return "done" end
    return f(n - 1)
  end
  return f, g
end

-- Closure as method value
local obj = {}
obj.method = function(self, x)
  return self.name .. ": " .. tostring(x)
end

-- Closure with vararg
local function vararg_closure(...)
  local args = {...}
  return function()
    return args
  end
end

-- Closure assigned to global
callback = function(event)
  print("Event: " .. event)
end

-- Closure in table constructor
local handlers = {
  on_click = function(x, y)
    print("click", x, y)
  end,
  on_key = function(key)
    print("key", key)
  end,
}

-- Deeply nested closure chain
local function deep_closure()
  local a = 1
  return function()
    local b = 2
    return function()
      local c = 3
      return function()
        local d = 4
        return function()
          return a + b + c + d
        end
      end
    end
  end
end

print(result)
print(make_adder(1)(2)(3))
print(many_upvals()())
print(make_recursive()(10))
print(deep_closure()()()()())
