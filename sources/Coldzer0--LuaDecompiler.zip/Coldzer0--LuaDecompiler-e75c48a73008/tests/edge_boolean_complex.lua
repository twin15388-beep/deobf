-- Complex boolean expression edge cases
-- Tests TEST/TESTSET opcode patterns and boolean expression recovery

-- Ternary idiom: (cond and true_val or false_val)
local function ternary(cond, a, b)
  return cond and a or b
end

-- Nested ternary
local function nested_ternary(x)
  return x > 0 and "positive" or (x < 0 and "negative" or "zero")
end

-- Short-circuit with side effects
local function short_circuit()
  local x = a() and b() and c()
  local y = a() or b() or c()
  return x, y
end

-- Boolean assign with not
local function bool_not(x)
  local a = not x
  local b = not not x
  return a, b
end

-- Boolean in table constructor
local function bool_in_table(x, y)
  return {
    flag1 = x and true or false,
    flag2 = x or y,
    flag3 = not x,
  }
end

-- Boolean as function argument
local function bool_arg(x, y)
  f(x and y)
  g(x or y)
  h(not x)
end

-- Complex condition in while
local function complex_while(a, b, c)
  while (a or b) and not c do
    a = step()
    if a and b then
      c = true
    end
  end
end

-- Complex condition in repeat-until
local function complex_repeat()
  local x, y
  repeat
    x = get_x()
    y = get_y()
  until (x and y) or (not x and not y)
end

-- Mixed comparison and boolean
local function mixed_compare(a, b, c, d)
  if a > b and c <= d then
    print("case1")
  elseif a == b or c ~= d then
    print("case2")
  elseif not (a >= c) then
    print("case3")
  end
end

-- Boolean value as return
local function returns_bool(x, y)
  return x == y
end

-- Boolean value assigned from comparison
local function compare_assign(x, y)
  local eq = x == y
  local lt = x < y
  local le = x <= y
  return eq, lt, le
end

-- De Morgan patterns that compilers may optimize
local function demorgan(a, b)
  local x = not (a and b)
  local y = not (a or b)
  return x, y
end

-- Chained comparisons pattern
local function in_range(x, lo, hi)
  return x >= lo and x <= hi
end

-- Multiple boolean assigns on same line
local function multi_bool()
  local a, b = x and y, x or z
  return a, b
end

print(ternary(true, 1, 2))
print(nested_ternary(0))
print(returns_bool(1, 1))
print(in_range(5, 1, 10))
