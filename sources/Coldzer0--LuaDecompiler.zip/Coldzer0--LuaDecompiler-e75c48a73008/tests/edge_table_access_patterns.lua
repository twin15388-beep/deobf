-- Table access pattern edge cases
-- Tests GETTABLE, SETTABLE, SELF with various key types and nesting

-- Dot access vs bracket access
local function access_patterns(t)
  local a = t.name          -- GETTABLE with string key
  local b = t["name"]       -- same bytecode as dot
  local c = t[1]            -- GETTABLE with integer key
  local d = t[key]          -- GETTABLE with variable key
  local e = t[f()]          -- GETTABLE with call result
  return a, b, c, d, e
end

-- Chained dot access
local function chain_access(t)
  return t.a.b.c.d.e
end

-- Mixed dot and bracket
local function mixed_access(t, key)
  return t.list[1].name
end

-- Table set patterns
local function set_patterns(t)
  t.name = "value"
  t["key"] = "value"
  t[1] = "first"
  t[key] = "dynamic"
  t.sub.field = 42
  t[1][2] = "nested"
end

-- Increment pattern (get + set same field)
local function increment(t)
  t.count = t.count + 1
  t[1] = t[1] * 2
  t.stats.total = t.stats.total + t.stats.current
end

-- Table as array with various operations
local function array_ops(t)
  local n = #t
  t[n + 1] = "append"
  t[#t + 1] = "also append"
  local last = t[#t]
  t[#t] = nil
  return last
end

-- Table field as function (non-method call)
local function field_call(t)
  t.callback(1, 2)
  t["on_event"]("click")
  t[1]()
end

-- Table field access in loop
local function field_in_loop(items)
  for i = 1, #items do
    local item = items[i]
    if item.enabled then
      item.value = item.value + item.increment
    end
  end
end

-- Rawget/rawset patterns
local function raw_patterns(t)
  rawset(t, "key", rawget(t, "other"))
  rawset(t, 1, rawget(t, 2))
end

-- Table used as both array and hash
local function dual_use()
  local t = {}
  t[1] = "array1"
  t[2] = "array2"
  t.name = "hash1"
  t.value = "hash2"
  t[3] = "array3"
  return t
end

-- Computed field names
local function computed_fields(t, prefix)
  t[prefix .. "_name"] = "value"
  t[prefix .. "_count"] = 0
  local val = t[prefix .. "_name"]
  return val
end

-- Self-referencing table construction
local function self_ref()
  local t = {}
  t.self = t
  t.children = {t}
  return t
end

local t = {name = "test", list = {{name = "sub"}}, count = 0, stats = {total = 0, current = 5}}
access_patterns(t)
print(chain_access({a = {b = {c = {d = {e = 42}}}}}))
increment(t)
print(t.count)
