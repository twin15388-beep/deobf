-- Tail call edge cases
-- Tests TAILCALL opcode recognition and emission

-- Simple tail call
local function simple_tail(x)
  return f(x)
end

-- Tail call with multiple args
local function multi_arg_tail(a, b, c)
  return g(a, b, c)
end

-- Tail call to method
local function method_tail(obj, x)
  return obj:method(x)
end

-- Tail call in if branch
local function conditional_tail(x)
  if x > 0 then
    return positive(x)
  else
    return negative(x)
  end
end

-- Tail call in elseif chain
local function elseif_tail(x)
  if x == 1 then
    return handle_one(x)
  elseif x == 2 then
    return handle_two(x)
  elseif x == 3 then
    return handle_three(x)
  else
    return handle_default(x)
  end
end

-- NOT a tail call (value used after call)
local function not_tail(x)
  return f(x) + 1
end

-- NOT a tail call (multiple returns, not tail position)
local function not_tail2(x)
  return f(x), g(x)
end

-- Mutual recursion via tail calls
local function is_even(n)
  if n == 0 then return true end
  return is_odd(n - 1)
end

local function is_odd(n)
  if n == 0 then return false end
  return is_even(n - 1)
end

-- Tail call through vararg
local function vararg_tail(...)
  return f(...)
end

-- Tail call inside loop (not really tail - just return from function)
local function loop_return(t)
  for i = 1, #t do
    if t[i] == target then
      return found(i)
    end
  end
  return not_found()
end

-- Recursive tail call
local function factorial(n, acc)
  acc = acc or 1
  if n <= 1 then
    return acc
  end
  return factorial(n - 1, n * acc)
end

print(simple_tail(1))
print(conditional_tail(5))
print(is_even(10))
print(factorial(10))
