-- Method call and SELF opcode edge cases
-- Tests SELF instruction, colon syntax recovery, and dot vs colon patterns

-- Basic method definition and call
local MyClass = {}
MyClass.__index = MyClass

function MyClass.new(name)
  local self = setmetatable({}, MyClass)
  self.name = name
  return self
end

function MyClass:getName()
  return self.name
end

function MyClass:setName(name)
  self.name = name
end

-- Chained method calls
function MyClass:chain()
  return self
end

-- Method call on result of method call
local function chained_methods(obj)
  obj:chain():chain():setName("test")
end

-- Method call on table access
local function method_on_access(t)
  t.sub:method()
  t[1]:method()
  t["key"]:method()
end

-- Method call vs function call on same object
local function mixed_calls(obj)
  obj:method1()       -- SELF opcode
  obj.method2(obj)    -- GETTABLE + CALL (no SELF)
end

-- Method call with multiple returns
local function method_multi_return(obj)
  local a, b, c = obj:getValues()
  return a, b, c
end

-- Method as argument
local function method_as_arg(obj)
  process(obj:getValue())
end

-- Method in condition
local function method_in_cond(obj)
  if obj:isValid() then
    obj:process()
  end
  while obj:hasNext() do
    obj:advance()
  end
end

-- Nested method calls
local function nested_method(a, b)
  return a:transform(b:getValue())
end

-- Method call with vararg
local function method_vararg(obj, ...)
  return obj:process(...)
end

-- Method definition with vararg
function MyClass:varargMethod(...)
  return self.name, ...
end

-- Self call in table constructor
local function method_in_table(obj)
  return {
    name = obj:getName(),
    valid = obj:isValid(),
  }
end

local obj = MyClass.new("test")
print(obj:getName())
obj:setName("changed")
chained_methods(obj)
