-- Vararg edge cases
-- Tests VARARG opcode handling and adjustment patterns

-- Basic vararg forwarding
local function forward(...)
  return f(...)
end

-- Vararg with fixed params before it
local function mixed_params(a, b, ...)
  print(a, b, ...)
  return ...
end

-- Vararg in table constructor (tail position)
local function vararg_in_table(...)
  return {...}
end

-- Vararg in table constructor (non-tail position)
local function vararg_in_table_mid(...)
  return {..., "end"}
end

-- Vararg stored to locals
local function vararg_to_locals(...)
  local a, b, c = ...
  print(a, b, c)
end

-- Vararg with select
local function vararg_count(...)
  local n = select("#", ...)
  for i = 1, n do
    print(select(i, ...))
  end
end

-- Vararg passed to multiple functions
local function vararg_multi(...)
  f(...)
  g(...)
  return h(...)
end

-- Nested vararg functions
local function outer(...)
  local args = {...}
  local function inner(...)
    return args, {...}
  end
  return inner(...)
end

-- Vararg as single value (parenthesized)
local function vararg_single(...)
  local a = (...)
  print(a)
end

-- Vararg in binary operation
local function vararg_in_op(...)
  local a = (...) + 1
  return a
end

-- Empty vararg function
local function no_use(...)
end

-- Vararg forwarded to method call
local function vararg_method(obj, ...)
  return obj:method(...)
end

-- Vararg with adjustment in multi-return context
local function vararg_adjust(...)
  local a, b = ..., 42
  return a, b
end

forward(1, 2, 3)
mixed_params(1, 2, 3, 4, 5)
print(vararg_in_table(1, 2, 3))
vararg_to_locals(10, 20, 30)
vararg_count(1, 2, 3, 4)
