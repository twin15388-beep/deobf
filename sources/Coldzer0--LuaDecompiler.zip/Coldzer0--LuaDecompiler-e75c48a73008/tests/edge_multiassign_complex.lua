-- Complex multi-assignment edge cases
-- Tests register allocation and value adjustment in multi-assign patterns

-- Swap pattern
local function swap(a, b)
  a, b = b, a
  return a, b
end

-- Triple rotate
local function rotate(a, b, c)
  a, b, c = b, c, a
  return a, b, c
end

-- Multi-assign with function calls
local function multi_call()
  local a, b = f(), g()
  return a, b
end

-- Multi-assign where last is function call (expanded)
local function multi_expand()
  local a, b, c = 1, f()
  return a, b, c
end

-- Multi-assign where function call is not last (adjusted)
local function multi_adjust()
  local a, b, c = f(), 2, 3
  return a, b, c
end

-- Multi-assign to globals
local function global_multi()
  x, y, z = 1, 2, 3
end

-- Multi-assign to table fields
local function table_multi(t)
  t.a, t.b, t.c = 1, 2, 3
  t[1], t[2] = t[2], t[1]
end

-- Multi-assign with complex expressions
local function expr_multi(x, y)
  local a, b = x + y, x - y
  local c, d = x * y, x / y
  return a, b, c, d
end

-- Multi-assign with boolean expressions
local function bool_multi(x, y)
  local a, b = x and y, x or y
  return a, b
end

-- Multi-assign from method calls
local function method_multi(obj)
  local x, y = obj:getPos()
  local w, h = obj:getSize()
  return x, y, w, h
end

-- Multi-assign with nil padding
local function nil_pad()
  local a, b, c = 1
  return a, b, c
end

-- Multi-assign with more values than receivers
local function excess_values()
  local a, b = 1, 2, 3
  return a, b
end

-- Multi-assign to mixed targets
local function mixed_targets(t)
  local a
  a, t.x, g_var = f()
  return a
end

-- Complex swap with table fields
local function table_swap(t, i, j)
  t[i], t[j] = t[j], t[i]
end

-- Multi-assign in loop
local function loop_multi()
  local a, b = 0, 1
  for i = 1, 10 do
    a, b = b, a + b
  end
  return a, b
end

print(swap(1, 2))
print(rotate(1, 2, 3))
print(nil_pad())
print(loop_multi())
