-- multi_assign_semantics_test.lua
-- Purpose: Detect incorrect decompiler handling of Lua multi-assignment semantics.
-- This script includes cases that break if a decompiler splits/reorders multi-assign.

_G.a = nil
_G.mr = nil
_G.x = nil

setmetatable(_G, {
  __newindex = function(_, k, _)
    error("NEW GLOBAL WRITE: " .. tostring(k), 2)
  end
})

local function sep(title)
  print(("\n==== %s ===="):format(title))
end
sep("CASE 1: RHS eval order + positional mapping")
do
  local log = {}
  local function push(tag)
    log[#log + 1] = tag
    return tag
  end
  local t, b, c, d
  t, b, c, d = push("t"), push("b"), push("c"), push("d")
  print("log:", table.concat(log, ","))
  print("vals:", t, b, c, d)
  assert(table.concat(log, ",") == "t,b,c,d", "FAIL: RHS evaluation order changed")
  assert(t == "t" and b == "b" and c == "c" and d == "d", "FAIL: positional mapping changed")
end
sep("CASE 2: LHS/RHS aliasing (index depends on i)")
do
  local a = {"A", "B", "C"}
  local i = 1
  a[i], i = 2, a[i]
  print("a:", a[1], a[2], a[3], "i:", i)
  assert(a[1] == 2, "FAIL: wrong table slot modified (a[1] must be 2)")
  assert(i == "A", "FAIL: i must receive old a[1] value ('A')")
end
sep("CASE 3: multiple return capture rules")
do
  local function mr()
    return 10, 20, 30
  end
  local a, b, c
  a, b, c = mr()
  print("mr() ->", a, b, c)
  assert(a == 10 and b == 20 and c == 30, "FAIL: mr() multi-return capture broken (simple)")
  local x, y, z
  x, y, z = 1, mr()      
  print("1, mr() ->", x, y, z)
  assert(x == 1 and y == 10 and z == 20, "FAIL: only last RHS should expand to fill remaining LHS")
  local p, q, r
  p, q, r = mr(), 99
  print("mr(), 99 ->", p, q, r)
  assert(p == 10 and q == 99 and r == nil, "FAIL: non-last RHS must not expand (only first return used)")
end
sep("CASE 4: side-effect timing vs LHS mutation")
do
  local x = 0
  local function inc()
    x = x + 1
    return x
  end
  local a, b
  a, b = inc(), inc()
  print("a,b,x ->", a, b, x)
  assert(a == 1 and b == 2 and x == 2, "FAIL: inc() order/mapping changed")
end
print("\nALL TESTS PASSED")