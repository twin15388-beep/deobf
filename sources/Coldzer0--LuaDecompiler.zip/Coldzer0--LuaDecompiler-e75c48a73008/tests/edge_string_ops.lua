-- String operation and constant edge cases
-- Tests LOADK with various string constants and CONCAT patterns

-- Empty string
local empty = ""

-- String with escape sequences
local escapes = "hello\nworld\ttab\\backslash\"quote"

-- String with null byte
local with_null = "before\0after"

-- Long string (bracket notation is lost in bytecode, but tests LOADK)
local long = "this is a long string that has many words in it"

-- Very long concat chain (tests CONCAT with many operands)
local function long_concat(a, b, c, d, e)
  return a .. b .. c .. d .. e
end

-- Concat mixed with other operations
local function mixed_concat(x, y)
  return "result: " .. tostring(x + y) .. " done"
end

-- Concat in loop
local function build_string(n)
  local s = ""
  for i = 1, n do
    s = s .. tostring(i) .. ","
  end
  return s
end

-- String as table key
local t = {}
t["hello world"] = 1
t[""] = 2
t["with\nnewline"] = 3

-- String comparison
local function str_compare(a, b)
  if a == "test" then
    return 1
  elseif a < b then
    return -1
  else
    return 0
  end
end

-- Length operator on string
local function str_len(s)
  return #s
end

-- Numeric constants edge cases
local zero = 0
local neg = -1
local big_int = 2147483647
local neg_big = -2147483648
local float = 3.14159265358979
local tiny = 0.00001
local sci = 1e10
local neg_sci = 1e-10
local inf = 1/0
local neg_inf = -1/0
local nan = 0/0

print(empty, escapes, with_null)
print(long_concat("a", "b", "c", "d", "e"))
print(str_len("hello"))
print(zero, neg, big_int, float)
