-- Multiple return value edge cases
-- Tests CALL with C=0 (multi-return) and result adjustment patterns

-- Function returning multiple values
local function multi()
  return 1, 2, 3
end

-- Multi-return in last position of assignment (expanded)
local a, b, c = multi()

-- Multi-return in non-last position (adjusted to 1)
local d, e, f = multi(), 10, 20

-- Multi-return in function call (last arg = expanded)
print(multi())

-- Multi-return in function call (not last = adjusted to 1)
print(multi(), "end")

-- Multi-return in table constructor (last = expanded)
local t1 = {multi()}

-- Multi-return in table constructor (not last = adjusted to 1)
local t2 = {multi(), "end"}

-- Multi-return from nested calls
local function nested_multi()
  return multi(), multi()
end

-- Chain of multi-return functions
local function chain()
  local x, y = multi()
  local z, w = multi()
  return x + z, y + w
end

-- Multi-return in return statement (tail)
local function forward_multi()
  return multi()
end

-- Multi-return adjusted in return
local function partial_forward()
  return (multi())
end

-- Discarded multi-return
local function discard()
  multi()
  return "done"
end

-- Multi-return to single local
local function single_capture()
  local x = multi()
  return x
end

-- Multi-return with more receivers than values
local function over_capture()
  local a, b, c, d, e = multi()
  return a, b, c, d, e
end

-- Tail call with multi-return
local function tail_multi()
  return multi()
end

-- Multi-return in boolean context
local function multi_bool()
  if multi() then
    print("truthy")
  end
end

-- Chained method calls with multi-return
local function method_chain(obj)
  local a, b = obj:first()
  local c, d = obj:second(a, b)
  return c, d
end

print(a, b, c)
print(d, e, f)
print(nested_multi())
print(chain())
print(forward_multi())
print(partial_forward())
