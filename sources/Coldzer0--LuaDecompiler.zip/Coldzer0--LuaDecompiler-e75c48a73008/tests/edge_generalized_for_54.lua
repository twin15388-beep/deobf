-- Lua 5.4 generalized for-loop edge cases
-- Tests TFORPREP/TFORCALL/TFORLOOP with 4 internal variables
-- In 5.4, generic for has: (for iterator), (for state), (for control), (for to-be-closed)
-- User variables start at R(A+4)

-- Basic generic for with pairs
local function basic_pairs(t)
  for k, v in pairs(t) do
    print(k, v)
  end
end

-- Generic for with ipairs
local function basic_ipairs(t)
  for i, v in ipairs(t) do
    print(i, v)
  end
end

-- Generic for with single user variable
local function single_var(t)
  for line in io.lines("test.txt") do
    print(line)
  end
end

-- Generic for with many user variables
local function many_vars()
  for a, b, c, d in custom_iter() do
    print(a, b, c, d)
  end
end

-- Nested generic for loops
local function nested_for(t1, t2)
  for k1, v1 in pairs(t1) do
    for k2, v2 in pairs(t2) do
      if k1 == k2 then
        print(k1, v1, v2)
      end
    end
  end
end

-- Generic for with break
local function for_break(t, target)
  for k, v in pairs(t) do
    if v == target then
      return k
    end
  end
  return nil
end

-- Generic for with upvalue capture
local function for_closure(t)
  local results = {}
  for k, v in pairs(t) do
    results[k] = function()
      return v
    end
  end
  return results
end

-- Generic for with complex body
local function for_complex(t)
  local sum = 0
  local count = 0
  for k, v in pairs(t) do
    if type(v) == "number" then
      sum = sum + v
      count = count + 1
      if count > 100 then
        break
      end
    elseif type(v) == "table" then
      for _, inner_v in ipairs(v) do
        sum = sum + inner_v
        count = count + 1
      end
    end
  end
  return sum, count
end

-- Mixed numeric and generic for
local function mixed_for(t)
  for i = 1, #t do
    for k, v in pairs(t[i]) do
      print(i, k, v)
    end
  end
end

basic_pairs({a = 1, b = 2})
basic_ipairs({10, 20, 30})
nested_for({x = 1}, {x = 2})
print(for_break({a = 1, b = 2, c = 3}, 2))
