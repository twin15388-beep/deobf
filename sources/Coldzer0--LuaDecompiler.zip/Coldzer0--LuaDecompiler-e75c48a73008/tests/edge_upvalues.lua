-- Upvalue edge cases
-- Tests GETUPVAL, SETUPVAL, CLOSE, and upvalue sharing patterns

-- Basic upvalue capture
local function make_counter()
  local count = 0
  return function()
    count = count + 1
    return count
  end
end

-- Multiple closures sharing the same upvalue
local function shared_upval()
  local shared = 0
  local function inc()
    shared = shared + 1
  end
  local function dec()
    shared = shared - 1
  end
  local function get()
    return shared
  end
  return inc, dec, get
end

-- Upvalue from loop variable (each iteration creates new upvalue)
local function loop_upvals()
  local closures = {}
  for i = 1, 5 do
    closures[i] = function()
      return i
    end
  end
  return closures
end

-- Nested upvalue chains (3 levels deep)
local function level1()
  local a = "L1"
  local function level2()
    local b = "L2"
    local function level3()
      return a .. b
    end
    return level3
  end
  return level2
end

-- Upvalue mutation from inner closure
local function mutator()
  local x = 10
  local function set(v)
    x = v
  end
  local function get()
    return x
  end
  set(42)
  return get()
end

-- Upvalue with do-end scope (CLOSE instruction)
local function scoped_upval()
  local result
  do
    local temp = compute()
    result = function()
      return temp
    end
  end
  return result
end

-- Upvalue captured in table constructor
local function upval_in_table()
  local x = 1
  local y = 2
  return {
    getX = function() return x end,
    getY = function() return y end,
    setX = function(v) x = v end,
  }
end

-- Upvalue from function parameter
local function param_upval(x, y)
  return function(z)
    return x + y + z
  end
end

-- Self-referencing closure (closure captures itself via upvalue)
local fib
fib = function(n)
  if n < 2 then return n end
  return fib(n - 1) + fib(n - 2)
end

-- Multiple upvalue levels with mutation
local function multi_level_mutation()
  local x = 0
  local function mid()
    local function inner()
      x = x + 1
    end
    inner()
    inner()
    return x
  end
  mid()
  return x
end

-- Upvalue in repeat-until (upvalue visible in condition)
local function repeat_upval()
  local done = false
  local function stop()
    done = true
  end
  repeat
    local x = compute()
    if x > 100 then
      stop()
    end
  until done
end

print(make_counter()())
local inc, dec, get = shared_upval()
inc(); inc(); dec()
print(get())
print(level1()()())
print(mutator())
print(fib(10))
print(multi_level_mutation())
