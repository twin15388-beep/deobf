const cp = require('child_process');
const fs = require('fs');
const path = require('path');
const vscode = require('vscode');

const VIEW_TYPE = 'cluaDecompiler.decompiledLuac';
const VIRTUAL_SCHEME = 'clua-decompiler';

class DecompiledLuaContentProvider {
  constructor(context) {
    this.context = context;
    this._onDidChange = new vscode.EventEmitter();
    this.onDidChange = this._onDidChange.event;
  }

  async provideTextDocumentContent(uri, token) {
    const sourceUri = sourceUriFromVirtualUri(uri);
    const result = await decompileFile(this.context, sourceUri, token);
    let output = result.stdout || '-- cLuaDecompiler produced no output.\n';

    if (result.stderr) {
      output += '\n--[[\ncLuaDecompiler stderr:\n' + result.stderr.replace(/\]\]/g, '] ]') + '\n]]\n';
    }

    return output;
  }
}

class DecompiledLuacDocument {
  constructor(uri) {
    this.uri = uri;
  }

  dispose() {
  }
}

class DecompiledLuacEditorProvider {
  constructor(context) {
    this.context = context;
  }

  async openCustomDocument(uri) {
    return new DecompiledLuacDocument(uri);
  }

  async resolveCustomEditor(document, webviewPanel, token) {
    webviewPanel.webview.html = renderStatusHtml(document.uri, 'Opening decompiled Lua editor...');

    try {
      await openDecompiledLua(this.context, document.uri, {
        viewColumn: webviewPanel.viewColumn || vscode.ViewColumn.Active
      });
      if (!token.isCancellationRequested) {
        webviewPanel.dispose();
      }
    } catch (err) {
      webviewPanel.webview.html = renderErrorHtml(document.uri, err);
    }
  }
}

function activate(context) {
  const contentProvider = new DecompiledLuaContentProvider(context);
  const editorProvider = new DecompiledLuacEditorProvider(context);

  context.subscriptions.push(
    vscode.workspace.registerTextDocumentContentProvider(VIRTUAL_SCHEME, contentProvider)
  );

  context.subscriptions.push(
    vscode.window.registerCustomEditorProvider(VIEW_TYPE, editorProvider, {
      webviewOptions: {
        retainContextWhenHidden: false
      },
      supportsMultipleEditorsPerDocument: false
    })
  );

  context.subscriptions.push(
    vscode.commands.registerCommand('cluaDecompiler.openDecompiled', async (uri) => {
      const target = uri || vscode.window.activeTextEditor?.document?.uri;
      if (!target) {
        vscode.window.showWarningMessage('No .luac file is selected.');
        return;
      }
      await openDecompiledLua(context, target);
    })
  );

  context.subscriptions.push(
    vscode.commands.registerCommand('cluaDecompiler.refreshDecompiled', async () => {
      const active = vscode.window.activeTextEditor?.document?.uri;
      if (!active || active.scheme !== VIRTUAL_SCHEME) {
        vscode.window.showWarningMessage('Open a decompiled .luac view first.');
        return;
      }
      await openDecompiledLua(context, sourceUriFromVirtualUri(active), {
        viewColumn: vscode.window.activeTextEditor?.viewColumn || vscode.ViewColumn.Active
      });
    })
  );
}

function deactivate() {
}

async function openDecompiledLua(context, uri, options = {}) {
  const sourceUri = uri.scheme === VIRTUAL_SCHEME ? sourceUriFromVirtualUri(uri) : uri;
  if (sourceUri.scheme !== 'file') {
    throw new Error(`Only local file URIs are supported. Got: ${sourceUri.toString()}`);
  }

  const virtualUri = virtualUriForSource(sourceUri);
  const document = await vscode.window.withProgress(
    {
      location: vscode.ProgressLocation.Window,
      title: 'Decompiling Lua bytecode'
    },
    async () => vscode.workspace.openTextDocument(virtualUri)
  );

  if (document.languageId !== 'lua') {
    await vscode.languages.setTextDocumentLanguage(document, 'lua');
  }

  return vscode.window.showTextDocument(document, {
    preview: false,
    viewColumn: options.viewColumn || vscode.ViewColumn.Active
  });
}

async function decompileFile(context, uri, token) {
  if (uri.scheme !== 'file') {
    throw new Error(`Only local file URIs are supported. Got: ${uri.toString()}`);
  }

  const executable = resolveDecompilerPath(context, uri);
  const config = vscode.workspace.getConfiguration('cluaDecompiler', uri);
  const timeoutMs = config.get('timeoutMs', 30000);
  const showSuccessfulStderr = config.get('showSuccessfulStderr', false);

  const result = await execFile(executable, ['--dec', uri.fsPath], {
    cwd: path.dirname(executable),
    timeout: timeoutMs,
    token
  });

  if (result.exitCode !== 0) {
    const details = result.stderr || result.stdout || `process exited with ${result.exitCode}`;
    const error = new Error(details.trim());
    error.executable = executable;
    error.exitCode = result.exitCode;
    error.stderr = result.stderr;
    error.stdout = result.stdout;
    throw error;
  }

  return {
    executable,
    stdout: result.stdout,
    stderr: showSuccessfulStderr ? result.stderr : ''
  };
}

function execFile(file, args, options) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const child = cp.execFile(
      file,
      args,
      {
        cwd: options.cwd,
        encoding: 'utf8',
        timeout: options.timeout,
        maxBuffer: 64 * 1024 * 1024,
        windowsHide: true
      },
      (error, stdout, stderr) => {
        if (settled) {
          return;
        }
        settled = true;

        if (error && error.killed && error.signal === 'SIGTERM') {
          reject(new Error(`cLuaDecompiler timed out after ${options.timeout} ms.`));
          return;
        }

        resolve({
          exitCode: error && typeof error.code === 'number' ? error.code : 0,
          stdout: stdout || '',
          stderr: stderr || ''
        });
      }
    );

    if (options.token) {
      options.token.onCancellationRequested(() => {
        if (!settled) {
          settled = true;
          child.kill();
          reject(new Error('Decompilation was cancelled.'));
        }
      });
    }
  });
}

function virtualUriForSource(sourceUri) {
  const params = new URLSearchParams({
    source: sourceUri.toString(),
    t: String(Date.now())
  });
  const name = decompiledName(sourceUri);

  return vscode.Uri.from({
    scheme: VIRTUAL_SCHEME,
    path: '/' + name,
    query: params.toString()
  });
}

function sourceUriFromVirtualUri(uri) {
  const params = new URLSearchParams(uri.query);
  const source = params.get('source');
  if (!source) {
    throw new Error('Decompiled document is missing its original source URI.');
  }
  return vscode.Uri.parse(source);
}

function decompiledName(sourceUri) {
  let base = path.basename(sourceUri.fsPath || 'bytecode.luac');
  if (base.toLowerCase().endsWith('.luac')) {
    base = base.slice(0, -5);
  }
  base = base.replace(/[^A-Za-z0-9_.-]+/g, '_') || 'bytecode';
  return base + '.decompiled.lua';
}

function resolveDecompilerPath(context, uri) {
  const config = vscode.workspace.getConfiguration('cluaDecompiler', uri);
  const configured = config.get('executablePath', '').trim();

  if (configured) {
    const expanded = expandPathVariables(configured, context, uri);
    if (!fs.existsSync(expanded)) {
      throw new Error(`Configured cLuaDecompiler.exe was not found: ${expanded}`);
    }
    return expanded;
  }

  const candidates = [];
  const workspaceFolder = vscode.workspace.getWorkspaceFolder(uri);
  if (workspaceFolder) {
    candidates.push(path.join(workspaceFolder.uri.fsPath, 'cLuaDecompiler.exe'));
  }

  candidates.push(path.resolve(context.extensionUri.fsPath, '..', 'cLuaDecompiler.exe'));
  candidates.push(path.join(context.extensionUri.fsPath, 'cLuaDecompiler.exe'));

  for (const candidate of candidates) {
    if (fs.existsSync(candidate)) {
      return candidate;
    }
  }

  return 'cLuaDecompiler.exe';
}

function expandPathVariables(value, context, uri) {
  const workspaceFolder = vscode.workspace.getWorkspaceFolder(uri);
  const workspacePath = workspaceFolder ? workspaceFolder.uri.fsPath : '';
  const filePath = uri.scheme === 'file' ? uri.fsPath : '';
  const fileDirname = filePath ? path.dirname(filePath) : '';

  return value
    .replace(/\$\{workspaceFolder\}/g, workspacePath)
    .replace(/\$\{extensionPath\}/g, context.extensionUri.fsPath)
    .replace(/\$\{fileDirname\}/g, fileDirname)
    .replace(/\$\{file\}/g, filePath)
    .replace(/\$\{env:([^}]+)\}/g, (_, name) => process.env[name] || '');
}

function renderStatusHtml(uri, message) {
  return renderPage(uri, `<p>${escapeHtml(message)}</p>`);
}

function renderErrorHtml(uri, err) {
  const parts = [];
  if (err.executable) {
    parts.push(`<p><strong>Executable:</strong> ${escapeHtml(err.executable)}</p>`);
  }
  if (typeof err.exitCode === 'number') {
    parts.push(`<p><strong>Exit code:</strong> ${err.exitCode}</p>`);
  }
  if (err.stdout) {
    parts.push(`<details><summary>stdout</summary><pre>${escapeHtml(err.stdout)}</pre></details>`);
  }
  if (err.stderr) {
    parts.push(`<details><summary>stderr</summary><pre>${escapeHtml(err.stderr)}</pre></details>`);
  }

  return renderPage(
    uri,
    `<p class="error">${escapeHtml(err.message || String(err))}</p>${parts.join('\n')}`
  );
}

function renderPage(uri, body) {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${escapeHtml(path.basename(uri.fsPath))}</title>
  <style>
    body {
      padding: 16px;
      color: var(--vscode-editor-foreground);
      background: var(--vscode-editor-background);
      font-family: var(--vscode-font-family);
    }
    .error {
      color: var(--vscode-errorForeground);
      white-space: pre-wrap;
    }
    pre {
      white-space: pre-wrap;
    }
  </style>
</head>
<body>${body}</body>
</html>`;
}

function escapeHtml(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

module.exports = {
  activate,
  deactivate
};
