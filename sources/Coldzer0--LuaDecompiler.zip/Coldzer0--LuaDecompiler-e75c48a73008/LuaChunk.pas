unit LuaChunk;

{
  LuaChunk.pas - Multi-version Lua binary chunk parser and Proto structures.

  Parses the binary format produced by luac 5.1-5.5 into an in-memory tree of
  TProto records that mirrors the internal ldump.c / ldo.c layout.

  Supports Lua 5.1, 5.2, 5.3, 5.4, and 5.5 bytecode formats.
}

{$mode objfpc}{$H+}

interface

uses
  SysUtils, LuaOpcodes;

const
  LUA_MAGIC    : array[0..3] of AnsiChar = (#$1B,'L','u','a');
  LUA_VERSION  = $51;
  LUA_TNIL     = 0;
  LUA_TBOOLEAN = 1;
  LUA_TNUMBER  = 3;
  LUA_TSTRING  = 4;
  { 5.3 constant tags (variant 0 = float, variant 1 = integer) }
  LUA_TNUMFLT_53  = $03;  { 5.3: LUA_TNUMBER | (0 << 4) = float }
  LUA_TNUMINT_53  = $13;  { 5.3: LUA_TNUMBER | (1 << 4) = integer }
  { 5.4+ constant tags (swapped: variant 0 = integer, variant 1 = float) }
  LUA_VNUMINT_54  = $03;  { 5.4+: LUA_TNUMBER | (0 << 4) = integer }
  LUA_VNUMFLT_54  = $13;  { 5.4+: LUA_TNUMBER | (1 << 4) = float }
  { Aliases for backward compatibility }
  LUA_TNUMINT  = $13;  { 5.3 integer constant tag }
  LUA_TNUMFLT  = $03;  { 5.3 float constant tag }

  { Instruction field sizes }
  SIZE_OP   = 6;
  SIZE_A    = 8;
  SIZE_B    = 9;
  SIZE_C    = 9;
  SIZE_Bx   = SIZE_B + SIZE_C;   { 18 }
  MAXARG_A  = (1 shl SIZE_A) - 1;
  MAXARG_B  = (1 shl SIZE_B) - 1;
  MAXARG_C  = (1 shl SIZE_C) - 1;
  MAXARG_Bx = (1 shl SIZE_Bx) - 1;
  MAXARG_sBx = MAXARG_Bx shr 1;  { 131071 -- bias for signed Bx }

  { Constant bit flag in B/C: if set the argument is a constant index }
  BITRK = 1 shl (SIZE_B - 1);   { 256 }

  { Opcode count }
  NUM_OPCODES = 38;

type
  { ------------------------------------------------------------------ }
  {  Raw instruction word                                               }
  { ------------------------------------------------------------------ }
  TInstruction = LongWord;   { 32-bit }

  { ------------------------------------------------------------------ }
  {  Decoded instruction fields                                         }
  { ------------------------------------------------------------------ }
  TOpCode = (
    OP_MOVE,      { 00 }
    OP_LOADK,     { 01 }
    OP_LOADBOOL,  { 02 }
    OP_LOADNIL,   { 03 }
    OP_GETUPVAL,  { 04 }
    OP_GETGLOBAL, { 05 }
    OP_GETTABLE,  { 06 }
    OP_SETGLOBAL, { 07 }
    OP_SETUPVAL,  { 08 }
    OP_SETTABLE,  { 09 }
    OP_NEWTABLE,  { 10 }
    OP_SELF,      { 11 }
    OP_ADD,       { 12 }
    OP_SUB,       { 13 }
    OP_MUL,       { 14 }
    OP_DIV,       { 15 }
    OP_MOD,       { 16 }
    OP_POW,       { 17 }
    OP_UNM,       { 18 }
    OP_NOT,       { 19 }
    OP_LEN,       { 20 }
    OP_CONCAT,    { 21 }
    OP_JMP,       { 22 }
    OP_EQ,        { 23 }
    OP_LT,        { 24 }
    OP_LE,        { 25 }
    OP_TEST,      { 26 }
    OP_TESTSET,   { 27 }
    OP_CALL,      { 28 }
    OP_TAILCALL,  { 29 }
    OP_RETURN,    { 30 }
    OP_FORLOOP,   { 31 }
    OP_FORPREP,   { 32 }
    OP_TFORLOOP,  { 33 }
    OP_SETLIST,   { 34 }
    OP_CLOSE,     { 35 }
    OP_CLOSURE,   { 36 }
    OP_VARARG     { 37 }
  );

  { Instruction encoding format }
  TInstFormat = (ifABC, ifABx, ifAsBx);

  { ------------------------------------------------------------------ }
  {  Constant value                                                     }
  { ------------------------------------------------------------------ }
  TLuaConstKind = (lckNil, lckBoolean, lckNumber, lckString, lckInteger, lckFloat);

  TLuaConst = record
    Kind   : TLuaConstKind;
    BValue : Boolean;       { lckBoolean }
    NValue : Double;        { lckNumber / lckFloat }
    SValue : AnsiString;    { lckString  }
    IValue : Int64;         { lckInteger (5.3+) }
  end;

  { ------------------------------------------------------------------ }
  {  Local variable debug info                                          }
  { ------------------------------------------------------------------ }
  TLocVar = record
    Name    : AnsiString;
    StartPC : Integer;  { first instruction where var is active }
    EndPC   : Integer;  { first instruction where var is dead   }
  end;

  { ------------------------------------------------------------------ }
  {  Upvalue descriptor (5.2+)                                         }
  { ------------------------------------------------------------------ }
  TUpvalDesc = record
    InStack : Boolean;
    Idx     : Byte;
    Kind    : Byte;         { 5.4+ }
    Name    : AnsiString;
  end;

  { ------------------------------------------------------------------ }
  {  Function prototype (mirrors GCproto / Proto in lobject.h)         }
  { ------------------------------------------------------------------ }
  PProto = ^TProto;
  TProto = record
    { identity / source }
    Source          : AnsiString;
    LineDefined     : Integer;
    LastLineDefined : Integer;

    { code }
    Code            : array of TInstruction;
    LineInfo        : array of Integer;    { one entry per instruction }

    { constants }
    K               : array of TLuaConst;

    { upvalues }
    NUps            : Byte;
    UpvalueNames    : array of AnsiString;
    UpvalDescs      : array of TUpvalDesc;   { 5.2+ upvalue descriptors }

    { nested protos (inner functions / closures) }
    P               : array of PProto;

    { local variable debug info }
    LocVars         : array of TLocVar;

    { register / parameter info }
    MaxStack        : Byte;
    NumParams       : Byte;
    IsVarArg        : Byte;  { bit 0 = VARARG_HASARG, bit 1 = VARARG_ISVARARG, bit 2 = VARARG_NEEDSARG }

    { version tag (set by parser) }
    LuaVersion      : Byte;  { $51, $52, $53, $54, $55 }
  end;

  { ------------------------------------------------------------------ }
  {  Top-level binary chunk header                                      }
  { ------------------------------------------------------------------ }
  TChunkHeader = record
    Version      : Byte;
    Format       : Byte;
    LittleEndian : Boolean;
    IntSize      : Byte;
    SizeTSize    : Byte;
    InstSize     : Byte;
    NumberSize   : Byte;
    Integral     : Byte;
    { 5.3+ additions }
    IntegerSize  : Byte;   { size of lua_Integer }
    FloatSize    : Byte;   { size of lua_Number (float) }
  end;

  TLuaChunk = record
    Header  : TChunkHeader;
    Root    : PProto;
    OpTable : TOpcodeTable;
  end;

  { ------------------------------------------------------------------ }
  {  Parser                                                             }
  { ------------------------------------------------------------------ }
  TChunkParser = class
  private
    FData       : array of Byte;
    FPos        : Integer;
    FHeader     : TChunkHeader;
    FSavedStrs  : array of AnsiString;  { 5.5 string dedup table }
    FSavedCount : Integer;              { number of saved strings }

    procedure Error(const Msg: AnsiString);
    function  ReadByte: Byte;
    function  ReadInt: Integer;
    function  ReadSizeT: QWord;
    function  ReadInstruction: TInstruction;
    function  ReadNumber: Double;
    function  ReadString: AnsiString;
    function  ReadInteger: Int64;        { 5.3-5.4 fixed-size lua_Integer }
    function  ReadIntegerVarint55: Int64; { 5.5 varint + zigzag lua_Integer }
    function  ReadFloat: Double;         { 5.3+ lua_Number (float) }
    function  ReadString53: AnsiString;  { 5.3+ string format with 1-byte short length }
    function  ReadVarint54: QWord;        { 5.4 varint: last byte has bit 7 set }
    function  ReadVarint55: QWord;        { 5.5 varint: continuation bytes have bit 7 set }
    function  ReadVarint: QWord;          { dispatches to 54 or 55 based on version }
    function  ReadString54: AnsiString;   { 5.4 string: varint length, no NUL }
    function  ReadString55: AnsiString;   { 5.5 string: varint length, with NUL, dedup }

    { Version-aware helpers: dispatch based on FHeader.Version }
    function  ReadIntV: Integer;         { ReadVarint for 5.4+, ReadInt for earlier }
    function  ReadStringV: AnsiString;   { version-dispatched string reader }

    { Version-specific header parsing }
    procedure ParseHeader;
    procedure ParseHeader51;
    procedure ParseHeader52;
    procedure ParseHeader53;
    procedure ParseHeader54;
    procedure ParseHeader55;

    { Proto parsing - dispatches by version }
    function  ParseProto: PProto;
    procedure ParseProto51(P: PProto);
    procedure ParseProto52(P: PProto);
    procedure ParseProto53(P: PProto);
    procedure ParseProto54(P: PProto);
    procedure ParseProto55(P: PProto);

    { Shared sub-parsers }
    procedure ParseCode(Proto: PProto);
    procedure ParseConstants(Proto: PProto);     { 5.1-5.2 constants }
    procedure ParseConstants53(Proto: PProto);   { 5.3+ constants (lckInteger/lckFloat) }
    procedure ParseUpvalues(Proto: PProto);      { 5.1 nups byte }
    procedure ParseUpvalDescs(Proto: PProto);    { 5.2+ upvalue descriptors }
    procedure ParseSubProtos(Proto: PProto);
    procedure ParseLineInfo(Proto: PProto);
    procedure ParseAbsLineInfo(Proto: PProto);   { 5.4+ absolute line info }
    procedure ParseLocVars(Proto: PProto);
    procedure ParseUpvalueNames(Proto: PProto);
  public
    constructor Create(const AData: array of Byte; ALen: Integer);
    function Parse: TLuaChunk;
  end;

{ ------------------------------------------------------------------ }
{  Instruction decode helpers (module-level)                          }
{ ------------------------------------------------------------------ }
function GET_OPCODE(i: TInstruction): TOpCode;
function GETARG_A(i: TInstruction): Integer;
function GETARG_B(i: TInstruction): Integer;
function GETARG_C(i: TInstruction): Integer;
function GETARG_Bx(i: TInstruction): Integer;
function GETARG_sBx(i: TInstruction): Integer;
function ISK(x: Integer): Boolean;           { true if x is a constant index }
function INDEXRK(x: Integer): Integer;       { strip the RK bit }
function OpcodeFormat(Op: TOpCode): TInstFormat;
function OpcodeName(Op: TOpCode): AnsiString;

{ Free a proto tree }
procedure FreeProto(P: PProto);

{ Load chunk from file }
function LoadChunkFromFile(const FileName: AnsiString; out Chunk: TLuaChunk): Boolean;

implementation

{ ======================================================================
  Instruction decode helpers
  ====================================================================== }

function GET_OPCODE(i: TInstruction): TOpCode;
begin
  Result := TOpCode(i and $3F);  { low 6 bits }
end;

function GETARG_A(i: TInstruction): Integer;
begin
  Result := (i shr 6) and $FF;   { bits 6..13 }
end;

function GETARG_C(i: TInstruction): Integer;
begin
  Result := (i shr 14) and $1FF;  { bits 14..22 }
end;

function GETARG_B(i: TInstruction): Integer;
begin
  Result := (i shr 23) and $1FF;  { bits 23..31 }
end;

function GETARG_Bx(i: TInstruction): Integer;
begin
  Result := (i shr 14) and $3FFFF;  { bits 14..31, 18 bits }
end;

function GETARG_sBx(i: TInstruction): Integer;
begin
  Result := GETARG_Bx(i) - MAXARG_sBx;
end;

function ISK(x: Integer): Boolean;
begin
  Result := (x and BITRK) <> 0;
end;

function INDEXRK(x: Integer): Integer;
begin
  Result := x and (BITRK - 1);
end;

{ Instruction format table (indexed by opcode ordinal) }
const
  OpFmtTable: array[TOpCode] of TInstFormat = (
    ifABC,   { MOVE      }
    ifABx,   { LOADK     }
    ifABC,   { LOADBOOL  }
    ifABC,   { LOADNIL   }
    ifABC,   { GETUPVAL  }
    ifABx,   { GETGLOBAL }
    ifABC,   { GETTABLE  }
    ifABx,   { SETGLOBAL }
    ifABC,   { SETUPVAL  }
    ifABC,   { SETTABLE  }
    ifABC,   { NEWTABLE  }
    ifABC,   { SELF      }
    ifABC,   { ADD       }
    ifABC,   { SUB       }
    ifABC,   { MUL       }
    ifABC,   { DIV       }
    ifABC,   { MOD       }
    ifABC,   { POW       }
    ifABC,   { UNM       }
    ifABC,   { NOT       }
    ifABC,   { LEN       }
    ifABC,   { CONCAT    }
    ifAsBx,  { JMP       }
    ifABC,   { EQ        }
    ifABC,   { LT        }
    ifABC,   { LE        }
    ifABC,   { TEST      }
    ifABC,   { TESTSET   }
    ifABC,   { CALL      }
    ifABC,   { TAILCALL  }
    ifABC,   { RETURN    }
    ifAsBx,  { FORLOOP   }
    ifAsBx,  { FORPREP   }
    ifABC,   { TFORLOOP  }
    ifABC,   { SETLIST   }
    ifABC,   { CLOSE     }
    ifABx,   { CLOSURE   }
    ifABC    { VARARG    }
  );

const
  OpcodeNames: array[TOpCode] of AnsiString = (
    'MOVE','LOADK','LOADBOOL','LOADNIL','GETUPVAL','GETGLOBAL','GETTABLE',
    'SETGLOBAL','SETUPVAL','SETTABLE','NEWTABLE','SELF','ADD','SUB','MUL',
    'DIV','MOD','POW','UNM','NOT','LEN','CONCAT','JMP','EQ','LT','LE',
    'TEST','TESTSET','CALL','TAILCALL','RETURN','FORLOOP','FORPREP',
    'TFORLOOP','SETLIST','CLOSE','CLOSURE','VARARG'
  );

function OpcodeFormat(Op: TOpCode): TInstFormat;
begin
  Result := OpFmtTable[Op];
end;

function OpcodeName(Op: TOpCode): AnsiString;
begin
  Result := OpcodeNames[Op];
end;

{ ======================================================================
  FreeProto
  ====================================================================== }

procedure FreeProto(P: PProto);
var
  I: Integer;
begin
  if P = nil then Exit;
  for I := 0 to High(P^.P) do
    FreeProto(P^.P[I]);
  SetLength(P^.Code, 0);
  SetLength(P^.LineInfo, 0);
  SetLength(P^.K, 0);
  SetLength(P^.UpvalueNames, 0);
  SetLength(P^.UpvalDescs, 0);
  SetLength(P^.P, 0);
  SetLength(P^.LocVars, 0);
  Dispose(P);
end;

{ ======================================================================
  TChunkParser
  ====================================================================== }

constructor TChunkParser.Create(const AData: array of Byte; ALen: Integer);
begin
  inherited Create;
  SetLength(FData, ALen);
  if ALen > 0 then
    Move(AData[0], FData[0], ALen);
  FPos := 0;
  FSavedCount := 0;
  SetLength(FSavedStrs, 0);
end;

procedure TChunkParser.Error(const Msg: AnsiString);
begin
  raise Exception.CreateFmt('LuaChunk parse error at offset %d: %s', [FPos, Msg]);
end;

function TChunkParser.ReadByte: Byte;
begin
  if FPos >= Length(FData) then
    Error('unexpected end of data');
  Result := FData[FPos];
  Inc(FPos);
end;

function TChunkParser.ReadInt: Integer;
var
  B: array[0..7] of Byte;
  I: Integer;
begin
  if FPos + FHeader.IntSize > Length(FData) then
    Error('unexpected end of data reading int');
  for I := 0 to FHeader.IntSize - 1 do
    B[I] := FData[FPos + I];
  Inc(FPos, FHeader.IntSize);
  Result := 0;
  if FHeader.LittleEndian then
    Move(B[0], Result, FHeader.IntSize)
  else begin
    { big-endian: reverse bytes into low end of Result }
    for I := 0 to FHeader.IntSize - 1 do
      Result := (Result shl 8) or B[I];
  end;
end;

function TChunkParser.ReadSizeT: QWord;
var
  B: array[0..7] of Byte;
  I: Integer;
begin
  if FPos + FHeader.SizeTSize > Length(FData) then
    Error('unexpected end of data reading size_t');
  for I := 0 to FHeader.SizeTSize - 1 do
    B[I] := FData[FPos + I];
  Inc(FPos, FHeader.SizeTSize);
  Result := 0;
  if FHeader.LittleEndian then
    Move(B[0], Result, FHeader.SizeTSize)
  else
    for I := 0 to FHeader.SizeTSize - 1 do
      Result := (Result shl 8) or B[I];
end;

function TChunkParser.ReadInstruction: TInstruction;
var
  B: array[0..3] of Byte;
  I: Integer;
begin
  if FHeader.InstSize <> 4 then
    Error('only 4-byte instructions are supported');
  if FPos + 4 > Length(FData) then
    Error('unexpected end of data reading instruction');
  for I := 0 to 3 do
    B[I] := FData[FPos + I];
  Inc(FPos, 4);
  Result := 0;
  if FHeader.LittleEndian then
    Move(B[0], Result, 4)
  else
    for I := 0 to 3 do
      Result := (Result shl 8) or B[I];
end;

function TChunkParser.ReadNumber: Double;
var
  B: array[0..7] of Byte;
  I: Integer;
  N: Double;
  Rev: array[0..7] of Byte;
begin
  if FHeader.NumberSize > 8 then
    Error('lua_Number size > 8 not supported');
  if FPos + FHeader.NumberSize > Length(FData) then
    Error('unexpected end of data reading number');
  for I := 0 to FHeader.NumberSize - 1 do
    B[I] := FData[FPos + I];
  Inc(FPos, FHeader.NumberSize);
  N := 0;
  if FHeader.LittleEndian then
    Move(B[0], N, FHeader.NumberSize)
  else begin
    { reverse bytes }
    for I := 0 to FHeader.NumberSize - 1 do
      Rev[FHeader.NumberSize - 1 - I] := B[I];
    Move(Rev[0], N, FHeader.NumberSize);
  end;
  Result := N;
end;

function TChunkParser.ReadString: AnsiString;
var
  Len: QWord;
begin
  Len := ReadSizeT;
  if Len = 0 then begin
    Result := '';
    Exit;
  end;
  { Lua includes the NUL terminator in the length }
  if FPos + Integer(Len) > Length(FData) then
    Error('unexpected end of data reading string');
  SetLength(Result, Len - 1);
  if Len > 1 then
    Move(FData[FPos], Result[1], Len - 1);
  Inc(FPos, Len);
end;

function TChunkParser.ReadInteger: Int64;
var
  B: array[0..7] of Byte;
  I: Integer;
  Rev: array[0..7] of Byte;
begin
  if FHeader.IntegerSize > 8 then
    Error('lua_Integer size > 8 not supported');
  if FPos + FHeader.IntegerSize > Length(FData) then
    Error('unexpected end of data reading integer');
  for I := 0 to FHeader.IntegerSize - 1 do
    B[I] := FData[FPos + I];
  Inc(FPos, FHeader.IntegerSize);
  Result := 0;
  if FHeader.LittleEndian then
    Move(B[0], Result, FHeader.IntegerSize)
  else begin
    for I := 0 to FHeader.IntegerSize - 1 do
      Rev[FHeader.IntegerSize - 1 - I] := B[I];
    Move(Rev[0], Result, FHeader.IntegerSize);
  end;
end;

function TChunkParser.ReadIntegerVarint55: Int64;
var
  Raw: QWord;
begin
  { 5.5 encodes lua_Integer using varint + zigzag:
    A non-negative x is coded as 2*x; a negative x is coded as -2*x - 1.
    So: encoded = if x >= 0 then 2*x else (-2*x - 1)
    Decode: if (raw and 1) = 0 then x = raw shr 1
            else x = -(Int64(raw shr 1) + 1) }
  Raw := ReadVarint55;
  if (Raw and 1) = 0 then
    Result := Int64(Raw shr 1)
  else
    Result := -(Int64(Raw shr 1) + 1);
end;

function TChunkParser.ReadFloat: Double;
var
  B: array[0..7] of Byte;
  I: Integer;
  N: Double;
  Rev: array[0..7] of Byte;
begin
  if FHeader.FloatSize > 8 then
    Error('lua_Number (float) size > 8 not supported');
  if FPos + FHeader.FloatSize > Length(FData) then
    Error('unexpected end of data reading float');
  for I := 0 to FHeader.FloatSize - 1 do
    B[I] := FData[FPos + I];
  Inc(FPos, FHeader.FloatSize);
  N := 0;
  if FHeader.LittleEndian then
    Move(B[0], N, FHeader.FloatSize)
  else begin
    for I := 0 to FHeader.FloatSize - 1 do
      Rev[FHeader.FloatSize - 1 - I] := B[I];
    Move(Rev[0], N, FHeader.FloatSize);
  end;
  Result := N;
end;

function TChunkParser.ReadString53: AnsiString;
var
  B: Byte;
  Len: QWord;
begin
  { 5.3+ string format: first byte is the length.
    0     -> nil/empty string
    <0xFF -> string length is (byte - 1)
    0xFF  -> read a size_t for the actual length }
  B := ReadByte;
  if B = 0 then begin
    Result := '';
    Exit;
  end;
  if B < $FF then
    Len := QWord(B) - 1
  else
    Len := ReadSizeT - 1;
  if Len = 0 then begin
    Result := '';
    Exit;
  end;
  if FPos + Integer(Len) > Length(FData) then
    Error('unexpected end of data reading string53');
  SetLength(Result, Len);
  Move(FData[FPos], Result[1], Len);
  Inc(FPos, Len);
end;

function TChunkParser.ReadIntV: Integer;
begin
  if FHeader.Version >= $54 then
    Result := Integer(ReadVarint)
  else
    Result := ReadInt;
end;

function TChunkParser.ReadStringV: AnsiString;
begin
  if FHeader.Version >= $55 then
    Result := ReadString55
  else if FHeader.Version >= $54 then
    Result := ReadString54
  else if FHeader.Version >= $53 then
    Result := ReadString53
  else
    Result := ReadString;
end;

function TChunkParser.ReadVarint54: QWord;
var
  B: Byte;
begin
  { 5.4 varint encoding:
    Each byte stores 7 data bits (bits 0-6).
    The LAST byte (least significant) has bit 7 SET (0x80).
    Earlier continuation bytes have bit 7 CLEAR.
    Written big-endian (MSB first). }
  Result := 0;
  repeat
    B := ReadByte;
    Result := (Result shl 7) or QWord(B and $7F);
  until (B and $80) <> 0;
end;

function TChunkParser.ReadVarint55: QWord;
var
  B: Byte;
begin
  { 5.5 varint encoding (MSB Varint):
    Each byte stores 7 data bits (bits 0-6).
    Continuation bytes (more significant) have bit 7 SET (0x80).
    The LAST byte (least significant) has bit 7 CLEAR.
    Written big-endian (MSB first). }
  Result := 0;
  repeat
    B := ReadByte;
    Result := (Result shl 7) or QWord(B and $7F);
  until (B and $80) = 0;
end;

function TChunkParser.ReadVarint: QWord;
begin
  if FHeader.Version >= $55 then
    Result := ReadVarint55
  else
    Result := ReadVarint54;
end;

function TChunkParser.ReadString54: AnsiString;
var
  Len: QWord;
begin
  { 5.4 string format: varint-encoded length.
    0 -> nil/empty string
    otherwise length = varint - 1 (DumpString adds 1 to distinguish nil from empty)
    String data does NOT include NUL terminator }
  Len := ReadVarint;
  if Len = 0 then begin
    Result := '';
    Exit;
  end;
  Dec(Len);  { actual string length = encoded length - 1 }
  if Len = 0 then begin
    Result := '';
    Exit;
  end;
  if FPos + Integer(Len) > Length(FData) then
    Error('unexpected end of data reading string54');
  SetLength(Result, Len);
  Move(FData[FPos], Result[1], Len);
  Inc(FPos, Len);
end;

function TChunkParser.ReadString55: AnsiString;
var
  Size: QWord;
  Idx: QWord;
  StrLen: QWord;
begin
  { 5.5 string format with deduplication:
    varint(0), varint(0) -> NULL string
    varint(0), varint(idx) -> reuse saved string at index (idx)
    varint(tsslen+1), data[tsslen+1] -> new string; data includes NUL terminator }
  Size := ReadVarint;
  if Size = 0 then begin
    Idx := ReadVarint;
    if Idx = 0 then begin
      Result := '';
      Exit;
    end;
    { Reuse saved string - idx is 1-based }
    if (Idx - 1) < QWord(FSavedCount) then
      Result := FSavedStrs[Idx - 1]
    else begin
      Error(Format('string dedup index %d out of range (saved=%d)', [Idx, FSavedCount]));
      Result := '';
    end;
    Exit;
  end;
  { New string: Size = tsslen + 1 (from dumpSize(D, size+1))
    Data on disk = tsslen + 1 bytes (string content + NUL terminator)
    String length = tsslen = Size - 1 }
  StrLen := Size - 1;  { tsslen: string length without NUL }
  if FPos + Integer(StrLen) + 1 > Length(FData) then
    Error('unexpected end of data reading string55');
  if StrLen = 0 then begin
    Result := '';
    Inc(FPos, 1);  { skip just the NUL }
  end else begin
    SetLength(Result, StrLen);
    Move(FData[FPos], Result[1], StrLen);
    Inc(FPos, StrLen + 1);  { skip string content + NUL terminator }
  end;
  { Save for dedup }
  if FSavedCount >= Length(FSavedStrs) then
    SetLength(FSavedStrs, FSavedCount + 64);
  FSavedStrs[FSavedCount] := Result;
  Inc(FSavedCount);
end;

{ ======================================================================
  Version-specific header parsers
  ====================================================================== }

procedure TChunkParser.ParseHeader51;
begin
  { 5.1: format, endian_flag, int_size, sizet_size, inst_size, number_size, integral_flag }
  FHeader.Format       := ReadByte;
  FHeader.LittleEndian := ReadByte = 1;
  FHeader.IntSize      := ReadByte;
  FHeader.SizeTSize    := ReadByte;
  FHeader.InstSize     := ReadByte;
  if FHeader.InstSize <> 4 then
    Error('only 4-byte instructions supported');
  FHeader.NumberSize   := ReadByte;
  FHeader.Integral     := ReadByte;
  { 5.1 defaults for fields not present }
  FHeader.IntegerSize  := 0;
  FHeader.FloatSize    := 0;
end;

procedure TChunkParser.ParseHeader52;
var
  I: Integer;
  LuacData: array[0..5] of Byte;
begin
  { 5.2: format, endian_flag, int_size, sizet_size, inst_size, number_size,
         integral_flag, LUAC_DATA (6 bytes: 0x19 0x93 0x0D 0x0A 0x1A 0x0A) }
  FHeader.Format       := ReadByte;
  FHeader.LittleEndian := ReadByte = 1;
  FHeader.IntSize      := ReadByte;
  FHeader.SizeTSize    := ReadByte;
  FHeader.InstSize     := ReadByte;
  if FHeader.InstSize <> 4 then
    Error('only 4-byte instructions supported');
  FHeader.NumberSize   := ReadByte;
  FHeader.Integral     := ReadByte;

  { Read and verify LUAC_DATA }
  for I := 0 to 5 do
    LuacData[I] := ReadByte;
  if (LuacData[0] <> $19) or (LuacData[1] <> $93) or
     (LuacData[2] <> $0D) or (LuacData[3] <> $0A) or
     (LuacData[4] <> $1A) or (LuacData[5] <> $0A) then
    Error('invalid LUAC_DATA in 5.2 header');

  FHeader.IntegerSize  := 0;
  FHeader.FloatSize    := 0;
end;

procedure TChunkParser.ParseHeader53;
var
  I: Integer;
  LuacData: array[0..5] of Byte;
  TestInt: Int64;
  B: array[0..7] of Byte;
begin
  { 5.3: format, LUAC_DATA (6 bytes), int_size, sizet_size, inst_size,
         integer_size, float_size, LUAC_INT (0x5678 test), LUAC_NUM (370.5 test) }
  FHeader.Format := ReadByte;

  { Read and verify LUAC_DATA }
  for I := 0 to 5 do
    LuacData[I] := ReadByte;
  if (LuacData[0] <> $19) or (LuacData[1] <> $93) or
     (LuacData[2] <> $0D) or (LuacData[3] <> $0A) or
     (LuacData[4] <> $1A) or (LuacData[5] <> $0A) then
    Error('invalid LUAC_DATA in 5.3 header');

  FHeader.IntSize     := ReadByte;
  FHeader.SizeTSize   := ReadByte;
  FHeader.InstSize    := ReadByte;
  if FHeader.InstSize <> 4 then
    Error('only 4-byte instructions supported');
  FHeader.IntegerSize := ReadByte;
  FHeader.FloatSize   := ReadByte;
  FHeader.NumberSize  := FHeader.FloatSize;

  { Read LUAC_INT test value to detect endianness }
  if FHeader.IntegerSize > 8 then
    Error('lua_Integer size > 8 not supported');
  if FPos + FHeader.IntegerSize > Length(FData) then
    Error('unexpected end of data reading LUAC_INT');
  for I := 0 to FHeader.IntegerSize - 1 do
    B[I] := FData[FPos + I];

  { Try little-endian first }
  TestInt := 0;
  Move(B[0], TestInt, FHeader.IntegerSize);
  if TestInt = $5678 then
    FHeader.LittleEndian := True
  else begin
    { Try big-endian }
    FHeader.LittleEndian := False;
    TestInt := 0;
    for I := 0 to FHeader.IntegerSize - 1 do
      TestInt := (TestInt shl 8) or B[I];
    if TestInt <> $5678 then
      Error(Format('LUAC_INT test failed: got %d, expected %d', [TestInt, $5678]));
  end;
  Inc(FPos, FHeader.IntegerSize);

  { Read LUAC_NUM test value (370.5) }
  if FHeader.FloatSize > 8 then
    Error('lua_Number (float) size > 8 not supported');
  if FPos + FHeader.FloatSize > Length(FData) then
    Error('unexpected end of data reading LUAC_NUM');
  { Just skip the test value - endianness already determined }
  Inc(FPos, FHeader.FloatSize);

  FHeader.Integral := 0;
end;

procedure TChunkParser.ParseHeader54;
var
  I: Integer;
  LuacData: array[0..5] of Byte;
  TestInt: Int64;
  B: array[0..7] of Byte;
begin
  { 5.4/5.5: format, LUAC_DATA (6 bytes), inst_size, integer_size, float_size,
             LUAC_INT (0x5678 test), LUAC_NUM (370.5 test) }
  FHeader.Format := ReadByte;

  { Read and verify LUAC_DATA }
  for I := 0 to 5 do
    LuacData[I] := ReadByte;
  if (LuacData[0] <> $19) or (LuacData[1] <> $93) or
     (LuacData[2] <> $0D) or (LuacData[3] <> $0A) or
     (LuacData[4] <> $1A) or (LuacData[5] <> $0A) then
    Error('invalid LUAC_DATA in 5.4+ header');

  { 5.4+ omits int_size and sizet_size from header }
  FHeader.InstSize    := ReadByte;
  if FHeader.InstSize <> 4 then
    Error('only 4-byte instructions supported');
  FHeader.IntegerSize := ReadByte;
  FHeader.FloatSize   := ReadByte;
  FHeader.NumberSize  := FHeader.FloatSize;
  { 5.4+ uses varint for sizes, so set defaults for int/sizet }
  FHeader.IntSize     := FHeader.IntegerSize;
  FHeader.SizeTSize   := FHeader.IntegerSize;

  { Read LUAC_INT test value to detect endianness }
  if FHeader.IntegerSize > 8 then
    Error('lua_Integer size > 8 not supported');
  if FPos + FHeader.IntegerSize > Length(FData) then
    Error('unexpected end of data reading LUAC_INT');
  for I := 0 to FHeader.IntegerSize - 1 do
    B[I] := FData[FPos + I];

  { Try little-endian first }
  TestInt := 0;
  Move(B[0], TestInt, FHeader.IntegerSize);
  if TestInt = $5678 then
    FHeader.LittleEndian := True
  else begin
    FHeader.LittleEndian := False;
    TestInt := 0;
    for I := 0 to FHeader.IntegerSize - 1 do
      TestInt := (TestInt shl 8) or B[I];
    if TestInt <> $5678 then
      Error(Format('LUAC_INT test failed: got %d, expected %d', [TestInt, $5678]));
  end;
  Inc(FPos, FHeader.IntegerSize);

  { Read LUAC_NUM test value (370.5) - just skip, endianness already known }
  if FHeader.FloatSize > 8 then
    Error('lua_Number (float) size > 8 not supported');
  if FPos + FHeader.FloatSize > Length(FData) then
    Error('unexpected end of data reading LUAC_NUM');
  Inc(FPos, FHeader.FloatSize);

  FHeader.Integral := 0;
end;

procedure TChunkParser.ParseHeader55;
var
  I: Integer;
  LuacData: array[0..5] of Byte;
  IntSize, InstSize, IntegerSize, FloatSize: Byte;
  TestInt32: LongInt;
  TestInst: LongWord;
  TestInt64: Int64;
  TestNum: Double;
  B: array[0..7] of Byte;
  Rev: array[0..7] of Byte;
begin
  { 5.5: format, LUAC_DATA (6 bytes), then 4 dumpNumInfo blocks:
    each block = size_byte + test_value (size_byte bytes)
    1) int: sizeof(int), LUAC_INT (-0x5678)
    2) Instruction: sizeof(Instruction), LUAC_INST (0x12345678)
    3) lua_Integer: sizeof(lua_Integer), LUAC_INT (-0x5678)
    4) lua_Number: sizeof(lua_Number), LUAC_NUM (-370.5) }
  FHeader.Format := ReadByte;

  { Read and verify LUAC_DATA }
  for I := 0 to 5 do
    LuacData[I] := ReadByte;
  if (LuacData[0] <> $19) or (LuacData[1] <> $93) or
     (LuacData[2] <> $0D) or (LuacData[3] <> $0A) or
     (LuacData[4] <> $1A) or (LuacData[5] <> $0A) then
    Error('invalid LUAC_DATA in 5.5 header');

  { Block 1: int }
  IntSize := ReadByte;
  FHeader.IntSize := IntSize;
  if IntSize > 8 then Error('int size > 8 not supported');
  { Read test int value to detect endianness }
  for I := 0 to IntSize - 1 do
    B[I] := FData[FPos + I];
  TestInt32 := 0;
  Move(B[0], TestInt32, IntSize);
  if TestInt32 = -$5678 then
    FHeader.LittleEndian := True
  else begin
    FHeader.LittleEndian := False;
    TestInt32 := 0;
    for I := 0 to IntSize - 1 do
      Rev[IntSize - 1 - I] := B[I];
    Move(Rev[0], TestInt32, IntSize);
    if TestInt32 <> -$5678 then
      Error(Format('LUAC_INT (int) test failed in 5.5 header: got %d', [TestInt32]));
  end;
  Inc(FPos, IntSize);

  { Block 2: Instruction }
  InstSize := ReadByte;
  FHeader.InstSize := InstSize;
  if InstSize <> 4 then
    Error('only 4-byte instructions supported');
  { Read instruction test value }
  for I := 0 to InstSize - 1 do
    B[I] := FData[FPos + I];
  TestInst := 0;
  if FHeader.LittleEndian then
    Move(B[0], TestInst, InstSize)
  else begin
    for I := 0 to InstSize - 1 do
      Rev[InstSize - 1 - I] := B[I];
    Move(Rev[0], TestInst, InstSize);
  end;
  if TestInst <> $12345678 then
    Error(Format('LUAC_INST test failed in 5.5 header: got %X', [TestInst]));
  Inc(FPos, InstSize);

  { Block 3: lua_Integer }
  IntegerSize := ReadByte;
  FHeader.IntegerSize := IntegerSize;
  if IntegerSize > 8 then Error('lua_Integer size > 8 not supported');
  { Read lua_Integer test value (-0x5678) }
  for I := 0 to IntegerSize - 1 do
    B[I] := FData[FPos + I];
  TestInt64 := 0;
  if FHeader.LittleEndian then
    Move(B[0], TestInt64, IntegerSize)
  else begin
    for I := 0 to IntegerSize - 1 do
      Rev[IntegerSize - 1 - I] := B[I];
    Move(Rev[0], TestInt64, IntegerSize);
  end;
  if TestInt64 <> -$5678 then
    Error(Format('LUAC_INT (lua_Integer) test failed in 5.5 header: got %d', [TestInt64]));
  Inc(FPos, IntegerSize);

  { Block 4: lua_Number }
  FloatSize := ReadByte;
  FHeader.FloatSize := FloatSize;
  FHeader.NumberSize := FloatSize;
  if FloatSize > 8 then Error('lua_Number size > 8 not supported');
  { Read lua_Number test value (-370.5) - skip, endianness already determined }
  Inc(FPos, FloatSize);

  { Set remaining fields }
  FHeader.SizeTSize := FHeader.IntegerSize;
  FHeader.Integral  := 0;
end;

procedure TChunkParser.ParseHeader;
var
  I: Integer;
begin
  { magic - same for all versions }
  for I := 0 to 3 do
    if ReadByte <> Byte(LUA_MAGIC[I]) then
      Error('invalid Lua magic number');

  FHeader.Version := ReadByte;

  { Dispatch to version-specific header parser }
  case FHeader.Version of
    $51: ParseHeader51;
    $52: ParseHeader52;
    $53: ParseHeader53;
    $54: ParseHeader54;
    $55: ParseHeader55;
  else
    Error(Format('ParseHeader - unsupported Lua version 0x%02X', [FHeader.Version]));
  end;
end;

procedure TChunkParser.ParseCode(Proto: PProto);
var
  Count, I: Integer;
  Padding: Integer;
begin
  Count := ReadIntV;
  { 5.5+: alignment padding before instruction array }
  if FHeader.Version >= $55 then begin
    Padding := FHeader.InstSize - (FPos mod FHeader.InstSize);
    if Padding < FHeader.InstSize then
      Inc(FPos, Padding);  { skip padding bytes }
  end;
  SetLength(Proto^.Code, Count);
  for I := 0 to Count - 1 do
    Proto^.Code[I] := ReadInstruction;
end;

procedure TChunkParser.ParseConstants(Proto: PProto);
var
  Count, I: Integer;
  T: Byte;
  C: TLuaConst;
begin
  Count := ReadIntV;
  SetLength(Proto^.K, Count);
  for I := 0 to Count - 1 do begin
    T := ReadByte;
    C := Default(TLuaConst);
    case T of
      LUA_TNIL: begin
        C.Kind := lckNil;
      end;
      LUA_TBOOLEAN: begin
        C.Kind   := lckBoolean;
        C.BValue := ReadByte <> 0;
      end;
      LUA_TNUMBER: begin
        C.Kind   := lckNumber;
        C.NValue := ReadNumber;
      end;
      LUA_TSTRING: begin
        C.Kind   := lckString;
        C.SValue := ReadString;
      end;
    else
      Error(Format('unknown constant type %d', [T]));
    end;
    Proto^.K[I] := C;
  end;
end;

procedure TChunkParser.ParseUpvalues(Proto: PProto);
begin
  Proto^.NUps := ReadByte;
end;

procedure TChunkParser.ParseSubProtos(Proto: PProto);
var
  Count, I: Integer;
begin
  Count := ReadIntV;
  SetLength(Proto^.P, Count);
  for I := 0 to Count - 1 do
    Proto^.P[I] := ParseProto;
end;

procedure TChunkParser.ParseLineInfo(Proto: PProto);
var
  Count, I: Integer;
  B: Byte;
  Line: Integer;
begin
  Count := ReadIntV;
  SetLength(Proto^.LineInfo, Count);
  if FHeader.Version >= $54 then begin
    { 5.4+ stores line info as signed byte deltas from LineDefined.
      ABSLINEINFO marker = -128 (0x80) means "look up in abslineinfo table".
      A delta of 0 means "same line as previous" - NOT a marker. }
    Line := Proto^.LineDefined;
    for I := 0 to Count - 1 do begin
      B := ReadByte;
      if ShortInt(B) = -128 then
        { ABSLINEINFO marker: absolute line stored separately, keep last known line }
        Proto^.LineInfo[I] := Line
      else begin
        Line := Line + ShortInt(B);   { signed byte delta }
        Proto^.LineInfo[I] := Line;
      end;
    end;
  end else begin
    { 5.1-5.3: full int per instruction }
    for I := 0 to Count - 1 do
      Proto^.LineInfo[I] := ReadInt;
  end;
end;

procedure TChunkParser.ParseLocVars(Proto: PProto);
var
  Count, I: Integer;
begin
  Count := ReadIntV;
  SetLength(Proto^.LocVars, Count);
  for I := 0 to Count - 1 do begin
    Proto^.LocVars[I].Name := ReadStringV;
    Proto^.LocVars[I].StartPC := ReadIntV;
    Proto^.LocVars[I].EndPC   := ReadIntV;
  end;
end;

procedure TChunkParser.ParseUpvalueNames(Proto: PProto);
var
  Count, I: Integer;
begin
  Count := ReadIntV;
  SetLength(Proto^.UpvalueNames, Count);
  for I := 0 to Count - 1 do
    Proto^.UpvalueNames[I] := ReadStringV;
end;

procedure TChunkParser.ParseConstants53(Proto: PProto);
var
  Count, I: Integer;
  T: Byte;
  C: TLuaConst;
  IsInt, IsFlt: Boolean;
begin
  Count := ReadIntV;
  SetLength(Proto^.K, Count);
  for I := 0 to Count - 1 do begin
    T := ReadByte;
    C := Default(TLuaConst);

    { Determine if tag is integer or float - swapped between 5.3 and 5.4+ }
    if FHeader.Version >= $54 then begin
      IsInt := (T = LUA_VNUMINT_54);  { 0x03 = integer in 5.4+ }
      IsFlt := (T = LUA_VNUMFLT_54);  { 0x13 = float in 5.4+ }
    end else begin
      IsInt := (T = LUA_TNUMINT_53);  { 0x13 = integer in 5.3 }
      IsFlt := (T = LUA_TNUMFLT_53);  { 0x03 = float in 5.3 }
    end;

    if T = LUA_TNIL then begin   { 0x00 }
      C.Kind := lckNil;
    end
    else if T = $01 then begin  { LUA_TBOOLEAN (5.3) or LUA_VFALSE (5.4+) }
      C.Kind := lckBoolean;
      if FHeader.Version >= $54 then
        C.BValue := False        { 5.4+: tag 0x01 = VFALSE, no value byte }
      else
        C.BValue := ReadByte <> 0;  { 5.3: tag 0x01 = TBOOLEAN, then value byte }
    end
    else if T = $11 then begin  { LUA_VTRUE (5.4+) }
      C.Kind   := lckBoolean;
      C.BValue := True;
    end
    else if IsFlt then begin
      C.Kind   := lckFloat;
      C.NValue := ReadFloat;
    end
    else if IsInt then begin
      C.Kind   := lckInteger;
      if FHeader.Version >= $55 then begin
        { 5.5: integers use varint with zigzag encoding }
        C.IValue := ReadIntegerVarint55;
      end else begin
        { 5.3-5.4: fixed-size integer }
        C.IValue := ReadInteger;
      end;
      C.NValue := C.IValue;   { also store as Double for backward compat }
    end
    else if (T = $04) or (T = $14) then begin  { LUA_VSHRSTR / LUA_VLNGSTR }
      C.Kind   := lckString;
      C.SValue := ReadStringV;
    end
    else
      Error(Format('unknown constant type 0x%02X at constant %d', [T, I]));

    Proto^.K[I] := C;
  end;
end;

procedure TChunkParser.ParseUpvalDescs(Proto: PProto);
var
  Count, I: Integer;
begin
  Count := ReadIntV;
  Proto^.NUps := Count;
  SetLength(Proto^.UpvalDescs, Count);
  for I := 0 to Count - 1 do begin
    Proto^.UpvalDescs[I].InStack := ReadByte <> 0;
    Proto^.UpvalDescs[I].Idx     := ReadByte;
    if FHeader.Version >= $54 then
      Proto^.UpvalDescs[I].Kind := ReadByte
    else
      Proto^.UpvalDescs[I].Kind := 0;
    Proto^.UpvalDescs[I].Name := '';
  end;
end;

procedure TChunkParser.ParseAbsLineInfo(Proto: PProto);
var
  Count, I: Integer;
  Padding: Integer;
  AbsPC, AbsLine: Integer;
begin
  { 5.4+ absolute line info: array of (pc: int, line: int) pairs.
    These entries provide baseline (pc, line) pairs for instructions
    whose delta was marked with ABSLINEINFO (-128). After reading them,
    patch Proto^.LineInfo for any entries that still need correction. }
  Count := ReadIntV;
  if FHeader.Version >= $55 then begin
    { 5.5: alignment padding + raw fixed-size AbsLineInfo structs }
    if Count > 0 then begin
      Padding := FHeader.IntSize - (FPos mod FHeader.IntSize);
      if Padding < FHeader.IntSize then
        Inc(FPos, Padding);  { skip alignment padding }
      { Read AbsLineInfo entries and patch LineInfo.
        Each AbsLineInfo = 2 x sizeof(int): (pc, line) }
      for I := 0 to Count - 1 do begin
        AbsPC := ReadInt;
        AbsLine := ReadInt;
        { Patch: walk forward from AbsPC applying deltas until next abslineinfo }
        if (AbsPC >= 0) and (AbsPC < Length(Proto^.LineInfo)) then begin
          Proto^.LineInfo[AbsPC] := AbsLine;
          { Re-apply deltas for subsequent instructions that had the marker's
            line set to the last-known value - they need the new baseline.
            We stored raw delta bytes during ParseLineInfo when we hit -128
            by keeping Line unchanged; now correct via forward propagation. }
        end;
      end;
    end;
  end else begin
    { 5.4: varint-encoded pairs }
    for I := 0 to Count - 1 do begin
      AbsPC := ReadIntV;
      AbsLine := ReadIntV;
      { Patch LineInfo at the ABSLINEINFO marker position }
      if (AbsPC >= 0) and (AbsPC < Length(Proto^.LineInfo)) then
        Proto^.LineInfo[AbsPC] := AbsLine;
    end;
  end;
end;

{ ======================================================================
  Version-specific proto parsers
  ====================================================================== }

procedure TChunkParser.ParseProto51(P: PProto);
begin
  { 5.1 proto order: source, linedefined, lastlinedefined, nups(1 byte),
    numparams, isvararg, maxstack, code, constants, subprotos, lineinfo,
    locvars, upvalnames }
  P^.Source          := ReadString;
  P^.LineDefined     := ReadInt;
  P^.LastLineDefined := ReadInt;
  P^.NUps            := ReadByte;
  P^.NumParams       := ReadByte;
  P^.IsVarArg        := ReadByte;
  P^.MaxStack        := ReadByte;
  ParseCode(P);
  ParseConstants(P);
  ParseSubProtos(P);
  ParseLineInfo(P);
  ParseLocVars(P);
  ParseUpvalueNames(P);
end;

procedure TChunkParser.ParseProto52(P: PProto);
begin
  { 5.2 proto order (from ldump.c DumpFunction):
    linedefined, lastlinedefined, numparams, isvararg, maxstacksize,
    code, constants, subprotos, upvaldescs,
    then debug info: source, lineinfo, locvars, upvalnames }
  P^.LineDefined     := ReadInt;
  P^.LastLineDefined := ReadInt;
  P^.NumParams       := ReadByte;
  P^.IsVarArg        := ReadByte;
  P^.MaxStack        := ReadByte;
  ParseCode(P);
  ParseConstants(P);
  ParseSubProtos(P);
  ParseUpvalDescs(P);
  { Debug info section }
  P^.Source          := ReadString;
  ParseLineInfo(P);
  ParseLocVars(P);
  ParseUpvalueNames(P);
end;

procedure TChunkParser.ParseProto53(P: PProto);
begin
  { 5.3 proto order: source, linedefined, lastlinedefined, numparams,
    isvararg, maxstack, code, constants53, upvaldescs, subprotos,
    lineinfo, locvars, upvalnames }
  P^.Source          := ReadString53;
  P^.LineDefined     := ReadInt;
  P^.LastLineDefined := ReadInt;
  P^.NumParams       := ReadByte;
  P^.IsVarArg        := ReadByte;
  P^.MaxStack        := ReadByte;
  ParseCode(P);
  ParseConstants53(P);
  ParseUpvalDescs(P);
  ParseSubProtos(P);
  ParseLineInfo(P);
  ParseLocVars(P);
  ParseUpvalueNames(P);
end;

procedure TChunkParser.ParseProto54(P: PProto);
begin
  { 5.4/5.5 proto order: source(varint string), linedefined(varint),
    lastlinedefined(varint), numparams, isvararg, maxstack,
    code, constants53, upvaldescs, subprotos, lineinfo, abslineinfo,
    locvars, upvalnames }
  P^.Source          := ReadStringV;
  P^.LineDefined     := ReadIntV;
  P^.LastLineDefined := ReadIntV;
  P^.NumParams       := ReadByte;
  P^.IsVarArg        := ReadByte;
  P^.MaxStack        := ReadByte;
  ParseCode(P);
  ParseConstants53(P);
  ParseUpvalDescs(P);
  ParseSubProtos(P);
  ParseLineInfo(P);
  ParseAbsLineInfo(P);
  ParseLocVars(P);
  ParseUpvalueNames(P);
end;

procedure TChunkParser.ParseProto55(P: PProto);
begin
  { 5.5 proto order (from dumpFunction in ldump.c):
    linedefined(varint), lastlinedefined(varint), numparams, flag, maxstacksize,
    code, constants53, upvaldescs, subprotos,
    source(string55), lineinfo, abslineinfo, locvars, upvalnames }
  P^.LineDefined     := ReadIntV;
  P^.LastLineDefined := ReadIntV;
  P^.NumParams       := ReadByte;
  P^.IsVarArg        := ReadByte;  { 5.5 calls this 'flag' }
  P^.MaxStack        := ReadByte;
  ParseCode(P);
  ParseConstants53(P);
  ParseUpvalDescs(P);
  ParseSubProtos(P);
  { Debug section: source comes after protos in 5.5 }
  P^.Source          := ReadStringV;
  ParseLineInfo(P);
  ParseAbsLineInfo(P);
  ParseLocVars(P);
  ParseUpvalueNames(P);
end;

function TChunkParser.ParseProto: PProto;
begin
  New(Result);
  Result^ := Default(TProto);
  Result^.LuaVersion := FHeader.Version;

  case FHeader.Version of
    $51: ParseProto51(Result);
    $52: ParseProto52(Result);
    $53: ParseProto53(Result);
    $54: ParseProto54(Result);
    $55: ParseProto55(Result);
  else
    Error(Format('ParseProto - unsupported Lua version 0x%02X for proto parsing', [FHeader.Version]));
  end;
end;

function TChunkParser.Parse: TLuaChunk;
begin
  ParseHeader;
  Result.Header := FHeader;
  if not GetBuiltinTable(FHeader.Version, Result.OpTable) then
    Result.OpTable := Default(TOpcodeTable);

  if FHeader.Version >= $53 then begin
    { 5.3+: top-level sizeupvalues byte before root proto }
    ReadByte;  { sizeupvalues - consumed but not needed here }
  end;

  Result.Root := ParseProto;
end;

{ ======================================================================
  LoadChunkFromFile
  ====================================================================== }

function LoadChunkFromFile(const FileName: AnsiString; out Chunk: TLuaChunk): Boolean;
var
  F      : File of Byte;
  Data   : array of Byte;
  Size   : Integer;
  OldFileMode: Byte;
  Parser : TChunkParser;
begin
  Result := False;
  Chunk  := Default(TLuaChunk);
  if not FileExists(FileName) then begin
    WriteLn(StdErr, 'Error: file not found: ', FileName);
    Exit;
  end;
  AssignFile(F, FileName);
  OldFileMode := FileMode;
  FileMode := 0; { read-only; bytecode inputs may not be writable }
  try
    try
      Reset(F);
      Size := FileSize(F);
      SetLength(Data, Size);
      if Size > 0 then
        BlockRead(F, Data[0], Size);
      CloseFile(F);
    except
      on E: Exception do begin
        WriteLn(StdErr, 'Error reading file: ', E.Message);
        Exit;
      end;
    end;
  finally
    FileMode := OldFileMode;
  end;

  // Check if It's a NewWorld script
  if (Length(Data) >= 2) and (Data[0] = 4) and (Data[1] = 0) then
  begin
    Delete(Data, 0, 2);
    WriteLn('-- New World luac Detected --');
  end;

  Parser := TChunkParser.Create(Data, Length(Data));
  try
    try
      Chunk  := Parser.Parse;
      Result := True;
    except
      on E: Exception do
        WriteLn(StdErr, E.Message);
    end;
  finally
    Parser.Free;
  end;
end;

end.
