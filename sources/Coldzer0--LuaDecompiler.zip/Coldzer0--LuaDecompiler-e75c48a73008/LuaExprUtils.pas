unit LuaExprUtils;

{
  LuaExprUtils.pas - Pure string manipulation utilities for boolean expression
  handling in the Lua decompiler.

  These functions operate on expression strings and have zero dependency on
  TDecompiler, TSSANode, TProto, or any other project-specific types.
}

{$mode objfpc}{$H+}

interface

uses
  SysUtils;

{ Strip outermost balanced parentheses from an expression, if present. }
function StripOuterParens(const S: AnsiString): AnsiString;

{ Invert a single atomic condition (no and/or at top level). }
function InvertAtom(const Tok: AnsiString): AnsiString;

{ Apply De Morgan's law to negate a compound condition. }
function ApplyDeMorgan(const Cond: AnsiString): AnsiString;

{ Parenthesize comparison sub-expressions when mixed with "not" sub-expressions. }
function ParenthesizeMixedNotCompare(const Expr: AnsiString): AnsiString;

{ Group "or" sub-expressions in parentheses when adjacent to "and". }
function GroupMixedAndOr(const Expr: AnsiString): AnsiString;

implementation

function StripOuterParens(const S: AnsiString): AnsiString;
var
  Depth, I: Integer;
begin
  Result := S;
  if (Length(S) < 2) or (S[1] <> '(') or (S[Length(S)] <> ')') then Exit;
  { Check that the opening paren at position 1 matches the closing one at the end }
  Depth := 0;
  for I := 1 to Length(S) - 1 do begin
    if S[I] = '(' then Inc(Depth)
    else if S[I] = ')' then Dec(Depth);
    if Depth = 0 then Exit;  { the opening paren closed before the end }
  end;
  { The outer parens are a matched pair - strip them }
  Result := Copy(S, 2, Length(S) - 2);
end;

function InvertAtom(const Tok: AnsiString): AnsiString;
var
  Inner: AnsiString;
begin
  { If the atom is wrapped in parens, strip them and invert the inner expression.
    This avoids producing unnecessary parens like (b == c) when b ~= c is inverted. }
  if (Length(Tok) >= 2) and (Tok[1] = '(') and (Tok[Length(Tok)] = ')') then begin
    Inner := StripOuterParens(Tok);
    if Inner <> Tok then begin
      Result := InvertAtom(Inner);
      Exit;
    end;
  end;
  if Pos(' >= ', Tok) > 0 then
    Result := StringReplace(Tok, ' >= ', ' < ', [])
  else if Pos(' <= ', Tok) > 0 then
    Result := StringReplace(Tok, ' <= ', ' > ', [])
  else if Pos(' ~= ', Tok) > 0 then
    Result := StringReplace(Tok, ' ~= ', ' == ', [])
  else if Pos(' == ', Tok) > 0 then
    Result := StringReplace(Tok, ' == ', ' ~= ', [])
  else if Pos(' > ', Tok) > 0 then
    Result := StringReplace(Tok, ' > ', ' <= ', [])
  else if Pos(' < ', Tok) > 0 then
    Result := StringReplace(Tok, ' < ', ' >= ', [])
  else begin
    { Not a comparison - it's a TEST (truthy check). Wrap with "not" or unwrap. }
    if (Length(Tok) > 4) and (Copy(Tok, 1, 4) = 'not ') then
      Result := Copy(Tok, 5, Length(Tok) - 4)
    else if (Length(Tok) > 5) and (Copy(Tok, 1, 5) = '(not ') and (Tok[Length(Tok)] = ')') then
      Result := Copy(Tok, 6, Length(Tok) - 6)
    else
      Result := '(not ' + Tok + ')';
  end;
end;

function ApplyDeMorgan(const Cond: AnsiString): AnsiString;
var
  OrParts: array of AnsiString;
  AndParts: array of AnsiString;
  NOrParts, NAndParts, I, J, Start, ParenDepth: Integer;
  SubExpr: AnsiString;
begin
  Result := Cond;
  if Cond = '' then Exit;

  { Step 1: Split by " or " at top level (lower precedence).
    not(A or B or C) = not A and not B and not C }
  NOrParts := 0;
  Start := 1;
  I := 1;
  ParenDepth := 0;
  while I <= Length(Cond) do begin
    if Cond[I] = '(' then Inc(ParenDepth)
    else if Cond[I] = ')' then Dec(ParenDepth);
    if (ParenDepth = 0) and (I + 3 <= Length(Cond)) and
       (Copy(Cond, I, 4) = ' or ') then begin
      SetLength(OrParts, NOrParts + 1);
      OrParts[NOrParts] := Copy(Cond, Start, I - Start);
      Inc(NOrParts);
      Inc(I, 4);
      Start := I;
      Continue;
    end;
    Inc(I);
  end;
  SetLength(OrParts, NOrParts + 1);
  OrParts[NOrParts] := Copy(Cond, Start, Length(Cond) - Start + 1);
  Inc(NOrParts);

  { Step 2: For each or-part, it may contain " and " sub-parts.
    not(a and b and c) = not a or not b or not c
    If the or-part has multiple and-parts, the result is an "or" group
    which needs parentheses when it appears in the final "and" chain. }
  Result := '';
  for I := 0 to NOrParts - 1 do begin
    { Split this or-part by " and " }
    NAndParts := 0;
    Start := 1;
    J := 1;
    ParenDepth := 0;
    while J <= Length(OrParts[I]) do begin
      if OrParts[I][J] = '(' then Inc(ParenDepth)
      else if OrParts[I][J] = ')' then Dec(ParenDepth);
      if (ParenDepth = 0) and (J + 4 <= Length(OrParts[I])) and
         (Copy(OrParts[I], J, 5) = ' and ') then begin
        SetLength(AndParts, NAndParts + 1);
        AndParts[NAndParts] := Copy(OrParts[I], Start, J - Start);
        Inc(NAndParts);
        Inc(J, 5);
        Start := J;
        Continue;
      end;
      Inc(J);
    end;
    SetLength(AndParts, NAndParts + 1);
    AndParts[NAndParts] := Copy(OrParts[I], Start, Length(OrParts[I]) - Start + 1);
    Inc(NAndParts);

    if NAndParts = 1 then begin
      { Single atom - just invert it }
      SubExpr := InvertAtom(AndParts[0]);
    end else begin
      { Multiple and-parts: not(a and b) = not a or not b.
        Wrap in parens if NOrParts > 1 (will be joined by "and"). }
      SubExpr := InvertAtom(AndParts[0]);
      for J := 1 to NAndParts - 1 do
        SubExpr := SubExpr + ' or ' + InvertAtom(AndParts[J]);
      if NOrParts > 1 then
        SubExpr := '(' + SubExpr + ')';
    end;

    if Result = '' then
      Result := SubExpr
    else
      Result := Result + ' and ' + SubExpr;
  end;
end;

function ParenthesizeMixedNotCompare(const Expr: AnsiString): AnsiString;
var
  Parts: array of AnsiString;
  Ops: array of AnsiString;
  NParts, I, Start, ParenDepth: Integer;
  HasNot, HasCmp: Boolean;
  Tok: AnsiString;
begin
  Result := Expr;
  if Expr = '' then Exit;

  { Split by " and " / " or " tokens, respecting parentheses }
  NParts := 0;
  Start := 1;
  I := 1;
  ParenDepth := 0;
  while I <= Length(Expr) do begin
    if Expr[I] = '(' then Inc(ParenDepth)
    else if Expr[I] = ')' then Dec(ParenDepth);
    if ParenDepth = 0 then begin
      if (I + 4 <= Length(Expr)) and (Copy(Expr, I, 5) = ' and ') then begin
        SetLength(Parts, NParts + 1);
        SetLength(Ops, NParts + 1);
        Parts[NParts] := Copy(Expr, Start, I - Start);
        Ops[NParts] := 'and';
        Inc(NParts);
        Inc(I, 5);
        Start := I;
        Continue;
      end;
      if (I + 3 <= Length(Expr)) and (Copy(Expr, I, 4) = ' or ') then begin
        SetLength(Parts, NParts + 1);
        SetLength(Ops, NParts + 1);
        Parts[NParts] := Copy(Expr, Start, I - Start);
        Ops[NParts] := 'or';
        Inc(NParts);
        Inc(I, 4);
        Start := I;
        Continue;
      end;
    end;
    Inc(I);
  end;
  SetLength(Parts, NParts + 1);
  Parts[NParts] := Copy(Expr, Start, Length(Expr) - Start + 1);
  Inc(NParts);

  if NParts < 2 then Exit;

  { Check for mixed "not" and comparison parts }
  HasNot := False;
  HasCmp := False;
  for I := 0 to NParts - 1 do begin
    Tok := Parts[I];
    if (Length(Tok) > 4) and
       ((Copy(Tok, 1, 4) = 'not ') or (Copy(Tok, 1, 5) = '(not ')) then
      HasNot := True
    else if (Pos(' == ', Tok) > 0) or (Pos(' ~= ', Tok) > 0) or
            (Pos(' < ', Tok) > 0) or (Pos(' > ', Tok) > 0) or
            (Pos(' <= ', Tok) > 0) or (Pos(' >= ', Tok) > 0) then
      HasCmp := True;
  end;

  if not (HasNot and HasCmp) then Exit;

  { Wrap comparison parts in parentheses }
  for I := 0 to NParts - 1 do begin
    Tok := Parts[I];
    if (Pos(' == ', Tok) > 0) or (Pos(' ~= ', Tok) > 0) or
       (Pos(' < ', Tok) > 0) or (Pos(' > ', Tok) > 0) or
       (Pos(' <= ', Tok) > 0) or (Pos(' >= ', Tok) > 0) then begin
      if (Length(Tok) > 0) and (Tok[1] <> '(') then
        Parts[I] := '(' + Tok + ')';
    end;
  end;

  { Reassemble }
  Result := Parts[0];
  for I := 1 to NParts - 1 do begin
    if I - 1 < Length(Ops) then
      Result := Result + ' ' + Ops[I - 1] + ' ' + Parts[I]
    else
      Result := Result + ' and ' + Parts[I];
  end;
end;

function GroupMixedAndOr(const Expr: AnsiString): AnsiString;
var
  Parts: array of AnsiString;
  Ops: array of AnsiString;
  NParts, I, J, K, Start, ParenDepth: Integer;
  HasMixed, NeedWrap: Boolean;
  GroupExpr, BetweenOp: AnsiString;
begin
  Result := Expr;
  if Expr = '' then Exit;

  { Split by " and " / " or " tokens, respecting parentheses.
    Ops[i] is the operator between Parts[i] and Parts[i+1]. }
  NParts := 0;
  Start := 1;
  I := 1;
  ParenDepth := 0;
  while I <= Length(Expr) do begin
    if Expr[I] = '(' then Inc(ParenDepth)
    else if Expr[I] = ')' then Dec(ParenDepth);
    if ParenDepth = 0 then begin
      if (I + 4 <= Length(Expr)) and (Copy(Expr, I, 5) = ' and ') then begin
        SetLength(Parts, NParts + 1);
        SetLength(Ops, NParts + 1);
        Parts[NParts] := Copy(Expr, Start, I - Start);
        Ops[NParts] := 'and';
        Inc(NParts);
        Inc(I, 5);
        Start := I;
        Continue;
      end;
      if (I + 3 <= Length(Expr)) and (Copy(Expr, I, 4) = ' or ') then begin
        SetLength(Parts, NParts + 1);
        SetLength(Ops, NParts + 1);
        Parts[NParts] := Copy(Expr, Start, I - Start);
        Ops[NParts] := 'or';
        Inc(NParts);
        Inc(I, 4);
        Start := I;
        Continue;
      end;
    end;
    Inc(I);
  end;
  SetLength(Parts, NParts + 1);
  SetLength(Ops, NParts + 1);
  Parts[NParts] := Copy(Expr, Start, Length(Expr) - Start + 1);
  Ops[NParts] := ''; { no operator after the last part }
  Inc(NParts);

  if NParts < 3 then Exit; { need at least 3 parts to have mixed ops }

  { Check if there are mixed operators }
  HasMixed := False;
  for I := 0 to NParts - 3 do
    if Ops[I] <> Ops[I + 1] then begin
      HasMixed := True; Break;
    end;
  if not HasMixed then Exit;

  { Walk through grouping consecutive same-operator segments. }
  Result := '';
  I := 0;
  while I < NParts do begin
    J := I;
    while (J + 1 < NParts) and (Ops[J] = Ops[I]) and (Ops[J] <> '') do
      Inc(J);

    GroupExpr := Parts[I];
    for K := I + 1 to J do
      GroupExpr := GroupExpr + ' ' + Ops[I] + ' ' + Parts[K];

    { Wrap in parens if this is an "or" group (2+ elements) adjacent to "and" }
    if (J > I) and (Ops[I] = 'or') then begin
      NeedWrap := False;
      if (I > 0) and (Ops[I - 1] = 'and') then NeedWrap := True;
      if (J < NParts - 1) and (Ops[J] = 'and') then NeedWrap := True;
      if NeedWrap then
        GroupExpr := '(' + GroupExpr + ')';
    end;

    { Append to result }
    if Result <> '' then begin
      { The operator connecting previous group to this one is Ops[I-1] }
      BetweenOp := Ops[I - 1];
      Result := Result + ' ' + BetweenOp + ' ' + GroupExpr;
    end else
      Result := GroupExpr;
    I := J + 1;
  end;
end;

end.
