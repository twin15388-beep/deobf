unit LuaOpcodes;

{
  LuaOpcodes.pas - Semantic opcode enum, per-version opcode tables, and
  instruction decode functions for multi-version Lua support.

  Covers Lua 5.1, 5.2, 5.3, 5.4, and 5.5 bytecode formats.

  Key design:
  - TSemanticOp enum (~90 values) abstracts ALL opcodes across ALL versions.
  - TOpcodeTable maps raw ordinal -> TSemanticOp for a given Lua version.
  - Decode functions extract instruction fields respecting per-version layouts.
  - Custom opcode tables can be loaded from text files for obfuscated bytecode.
}

{$mode objfpc}{$H+}

interface

uses
  SysUtils;

type
  { ================================================================== }
  {  Instruction formats across all Lua versions                       }
  { ================================================================== }
  TInstFormat = (
    ifABC,    { A:8  B:9  C:9          (5.1-5.5) }
    ifABx,    { A:8  Bx:18             (5.1-5.5) }
    ifAsBx,   { A:8  sBx:18 (signed)   (5.1-5.5) }
    ifAx,     { Ax:26                   (5.2+)    }
    ifisJ,    { sJ:25 (signed jump)     (5.4+)    }
    ifivABC   { A:8  vB:6  vC:10 k:1   (5.5 variant ABC) }
  );

  { ================================================================== }
  {  Semantic opcode enum - covers ALL versions                        }
  { ================================================================== }
  TSemanticOp = (
    { --- Lua 5.1 core (38 opcodes) --- }
    semMOVE,          { 5.1+ : A B     R(A) := R(B) }
    semLOADK,         { 5.1+ : A Bx    R(A) := K(Bx) }
    semLOADBOOL,      { 5.1+ : A B C   R(A) := (Bool)B; if (C) pc++ }
    semLOADNIL,       { 5.1+ : A B     R(A)..R(B) := nil }
    semGETUPVAL,      { 5.1+ : A B     R(A) := UpValue[B] }
    semGETGLOBAL,     { 5.1  : A Bx    R(A) := Gbl[K(Bx)] }
    semGETTABLE,      { 5.1+ : A B C   R(A) := R(B)[RK(C)] }
    semSETGLOBAL,     { 5.1  : A Bx    Gbl[K(Bx)] := R(A) }
    semSETUPVAL,      { 5.1+ : A B     UpValue[B] := R(A) }
    semSETTABLE,      { 5.1+ : A B C   R(A)[RK(B)] := RK(C) }
    semNEWTABLE,      { 5.1+ : A B C   R(A) := new table (size B,C) }
    semSELF,          { 5.1+ : A B C   R(A+1) := R(B); R(A) := R(B)[RK(C)] }
    semADD,           { 5.1+ : A B C   R(A) := RK(B) + RK(C) }
    semSUB,           { 5.1+ : A B C   R(A) := RK(B) - RK(C) }
    semMUL,           { 5.1+ : A B C   R(A) := RK(B) * RK(C) }
    semDIV,           { 5.1+ : A B C   R(A) := RK(B) / RK(C) }
    semMOD,           { 5.1+ : A B C   R(A) := RK(B) % RK(C) }
    semPOW,           { 5.1+ : A B C   R(A) := RK(B) ^ RK(C) }
    semUNM,           { 5.1+ : A B     R(A) := -R(B) }
    semNOT,           { 5.1+ : A B     R(A) := not R(B) }
    semLEN,           { 5.1+ : A B     R(A) := #R(B) }
    semCONCAT,        { 5.1-5.3: A B C; 5.4+: A B }
    semJMP,           { 5.1+ : A sBx   pc += sBx; if A then close upvalues >= R(A-1) }
    semEQ,            { 5.1+ : A B C   if (RK(B) == RK(C)) ~= A then pc++ }
    semLT,            { 5.1+ : A B C   if (RK(B) < RK(C)) ~= A then pc++ }
    semLE,            { 5.1+ : A B C   if (RK(B) <= RK(C)) ~= A then pc++ }
    semTEST,          { 5.1+ : A C     if (R(A) <=> C) then pc++ }
    semTESTSET,       { 5.1+ : A B C   if (R(B) <=> C) then R(A) := R(B) else pc++ }
    semCALL,          { 5.1+ : A B C   R(A),...,R(A+C-2) := R(A)(R(A+1),...,R(A+B-1)) }
    semTAILCALL,      { 5.1+ : A B C   return R(A)(R(A+1),...,R(A+B-1)) }
    semRETURN,        { 5.1+ : A B     return R(A),...,R(A+B-2) }
    semFORLOOP,       { 5.1+ : A sBx   R(A) += R(A+2); if R(A) <= R(A+1) then pc += sBx }
    semFORPREP,       { 5.1+ : A sBx   R(A) -= R(A+2); pc += sBx }
    semTFORLOOP,      { 5.1  : A C     R(A+3),...,R(A+2+C) := R(A)(R(A+1),R(A+2)) }
    semSETLIST,       { 5.1+ : A B C   R(A)[(C-1)*FPF+i] := R(A+i), 1<=i<=B }
    semCLOSE,         { 5.1+ : A       close upvalues >= R(A) }
    semCLOSURE,       { 5.1+ : A Bx    R(A) := closure(Proto[Bx]) }
    semVARARG,        { 5.1+ : A B     R(A),...,R(A+B-2) := vararg }

    { --- Lua 5.2 additions --- }
    semLOADKX,        { 5.2+ : A       R(A) := K(extra arg) -- next inst is EXTRAARG }
    semGETTABUP,      { 5.2+ : A B C   R(A) := UpValue[B][RK(C)] }
    semSETTABUP,      { 5.2+ : A B C   UpValue[A][RK(B)] := RK(C) }
    semTFORCALL,      { 5.2+ : A C     R(A+3),...,R(A+2+C) := R(A)(R(A+1),R(A+2)) }
    semTFORLOOP54,    { 5.2+ : A sBx   if R(A+1) ~= nil then R(A)=R(A+1); pc+=sBx }
    semEXTRAARG,      { 5.2+ : Ax      extra argument for previous opcode }

    { --- Lua 5.3 additions (bitwise + integer division) --- }
    semIDIV,          { 5.3+ : A B C   R(A) := RK(B) // RK(C) }
    semBAND,          { 5.3+ : A B C   R(A) := RK(B) & RK(C) }
    semBOR,           { 5.3+ : A B C   R(A) := RK(B) | RK(C) }
    semBXOR,          { 5.3+ : A B C   R(A) := RK(B) ~ RK(C) }
    semSHL,           { 5.3+ : A B C   R(A) := RK(B) << RK(C) }
    semSHR,           { 5.3+ : A B C   R(A) := RK(B) >> RK(C) }
    semBNOT,          { 5.3+ : A B     R(A) := ~R(B) }

    { --- Lua 5.4 additions --- }
    { Typed loads }
    semLOADI,         { 5.4+ : A sBx   R(A) := sBx (integer) }
    semLOADF,         { 5.4+ : A sBx   R(A) := (float)sBx }
    semLOADFALSE,     { 5.4+ : A       R(A) := false }
    semLOADTRUE,      { 5.4+ : A       R(A) := true }
    semLFALSESKIP,    { 5.4+ : A       R(A) := false; pc++ }

    { Immediate arithmetic }
    semADDI,          { 5.4+ : A B sC  R(A) := R(B) + sC }
    semADDK,          { 5.4+ : A B C   R(A) := R(B) + K(C) }
    semSUBK,          { 5.4+ : A B C   R(A) := R(B) - K(C) }
    semMULK,          { 5.4+ : A B C   R(A) := R(B) * K(C) }
    semMODK,          { 5.4+ : A B C   R(A) := R(B) % K(C) }
    semPOWK,          { 5.4+ : A B C   R(A) := R(B) ^ K(C) }
    semDIVK,          { 5.4+ : A B C   R(A) := R(B) / K(C) }
    semIDIVK,         { 5.4+ : A B C   R(A) := R(B) // K(C) }
    semBANDK,         { 5.4+ : A B C   R(A) := R(B) & K(C) }
    semBORK,          { 5.4+ : A B C   R(A) := R(B) | K(C) }
    semBXORK,         { 5.4+ : A B C   R(A) := R(B) ~ K(C) }
    semSHRI,          { 5.4+ : A B sC  R(A) := R(B) >> sC }
    semSHLI,          { 5.4+ : A B sC  R(A) := sC << R(B) }

    { Typed table access }
    semGETI,          { 5.4+ : A B C   R(A) := R(B)[C] (integer key) }
    semGETFIELD,      { 5.4+ : A B C   R(A) := R(B)[K(C):string] }
    semSETI,          { 5.4+ : A B C   R(A)[B] := RK(C) (integer key) }
    semSETFIELD,      { 5.4+ : A B C   R(A)[K(B):string] := RK(C) }

    { Immediate comparisons }
    semEQK,           { 5.4+ : A B     if (R(A) == K(B)) ~= k then pc++ }
    semEQI,           { 5.4+ : A sB    if (R(A) == sB) ~= k then pc++ }
    semLTI,           { 5.4+ : A sB    if (R(A) < sB) ~= k then pc++ }
    semLEI,           { 5.4+ : A sB    if (R(A) <= sB) ~= k then pc++ }
    semGTI,           { 5.4+ : A sB    if (R(A) > sB) ~= k then pc++ }
    semGEI,           { 5.4+ : A sB    if (R(A) >= sB) ~= k then pc++ }

    { Metamethod hints }
    semMMBIN,         { 5.4+ : A B C   call metamethod for binary op C on R(A) and R(B) }
    semMMBINI,        { 5.4+ : A sB C k  call metamethod C for R(A) and sB }
    semMMBINK,        { 5.4+ : A B C k   call metamethod C for R(A) and K(B) }

    { To-be-closed / return variants / misc }
    semTBC,           { 5.4+ : A       mark R(A) as to-be-closed }
    semRETURN0,       { 5.4+ :         return (no values) }
    semRETURN1,       { 5.4+ : A       return R(A) (single value) }
    semTFORPREP,      { 5.4+ : A Bx    prepare generic for loop }
    semVARARGPREP,    { 5.4+ : A       prepare vararg function }

    { --- Lua 5.5 additions --- }
    semGETVARG,       { 5.5  : A B C   R(A) := R(B)[R(C)], B is vararg table }
    semERRNNIL,       { 5.5  : A Bx    error if R(A) is not nil }

    { --- Sentinel --- }
    semUNKNOWN        { Unknown/unmapped opcode }
  );

  { ================================================================== }
  {  Opcode table entry                                                }
  { ================================================================== }
  TOpcodeEntry = record
    SemanticOp : TSemanticOp;
    Format     : TInstFormat;
    Name       : AnsiString;
  end;

  { ================================================================== }
  {  Opcode table for a specific Lua version (or custom mapping)       }
  { ================================================================== }
  TOpcodeTable = record
    Version     : Byte;        { $51, $52, $53, $54, $55 }
    NumOpcodes  : Integer;
    Entries     : array of TOpcodeEntry;
    OpBits      : Integer;     { 6 for 5.1-5.3, 7 for 5.4+ }
    ABits       : Integer;     { 8 }
    BBits       : Integer;     { 9 for 5.1-5.3, 8 for 5.4+ }
    CBits       : Integer;     { 9 for 5.1-5.3, 8 for 5.4+ }
    HasKFlag    : Boolean;     { 5.4+ k-flag in bit 15 }
  end;
  POpcodeTable = ^TOpcodeTable;

{ ================================================================== }
{  Built-in opcode tables                                            }
{ ================================================================== }

{ Get the built-in opcode table for a standard Lua version.
  Version: $51, $52, $53, $54, $55. Returns False if unknown. }
function GetBuiltinTable(Version: Byte; out Table: TOpcodeTable): Boolean;

{ ================================================================== }
{  Instruction decode functions                                      }
{ ================================================================== }

{ Decode semantic opcode from instruction word using opcode table. }
function DecodeOp(const Table: TOpcodeTable; Inst: LongWord): TSemanticOp;

{ Decode raw opcode ordinal }
function DecodeRawOp(const Table: TOpcodeTable; Inst: LongWord): Integer;

{ Decode A field }
function DecodeA(const Table: TOpcodeTable; Inst: LongWord): Integer;

{ Decode B field (ABC format) }
function DecodeB(const Table: TOpcodeTable; Inst: LongWord): Integer;

{ Decode C field (ABC format) }
function DecodeC(const Table: TOpcodeTable; Inst: LongWord): Integer;

{ Decode Bx field (ABx format) - unsigned }
function DecodeBx(const Table: TOpcodeTable; Inst: LongWord): Integer;

{ Decode sBx field (AsBx format) - signed, bias = (2^(BBits+CBits-1) - 1) }
function DecodesBx(const Table: TOpcodeTable; Inst: LongWord): Integer;

{ Decode Ax field (Ax format, 5.2+) - uses all bits after opcode }
function DecodeAx(const Table: TOpcodeTable; Inst: LongWord): Integer;

{ Decode sJ field (isJ format, 5.4+) - signed jump offset }
function DecodesJ(const Table: TOpcodeTable; Inst: LongWord): Integer;

{ Decode k flag (5.4+ only, bit after A field) }
function DecodeK(const Table: TOpcodeTable; Inst: LongWord): Boolean;

{ Decode signed C for 5.4+ (sC = C - offset) }
function DecodeSC(const Table: TOpcodeTable; Inst: LongWord): Integer;

{ Decode signed B for 5.4+ immediate comparisons }
function DecodeSB(const Table: TOpcodeTable; Inst: LongWord): Integer;

{ Decode vB field from ivABC format (5.5): 6 bits starting after k-flag }
function DecodeVB(const Table: TOpcodeTable; Inst: LongWord): Integer;

{ Decode vC field from ivABC format (5.5): 10 bits starting after vB }
function DecodeVC(const Table: TOpcodeTable; Inst: LongWord): Integer;

{ Check if an instruction uses ivABC format based on its raw opcode }
function IsIvABCFormat(const Table: TOpcodeTable; Inst: LongWord): Boolean;

{ Check if B/C argument is a constant reference (5.1-5.3 RK encoding) }
function IsRK(const Table: TOpcodeTable; Arg: Integer): Boolean;

{ Strip RK bit to get constant index (5.1-5.3) }
function RKIndex(const Table: TOpcodeTable; Arg: Integer): Integer;

{ ================================================================== }
{  Semantic opcode name for display                                  }
{ ================================================================== }
function SemanticOpName(Op: TSemanticOp): AnsiString;

{ ================================================================== }
{  Custom opcode table loading                                       }
{ ================================================================== }

{ Load a custom opcode mapping from a text file.
  Returns True on success, sets ErrMsg on failure. }
function LoadOpcodeTableFromFile(const FileName: AnsiString;
  out Table: TOpcodeTable; out ErrMsg: AnsiString): Boolean;

{ Parse a semantic op name string (case-insensitive, without 'sem' prefix).
  Returns semUNKNOWN if not recognized. }
function ParseSemanticOpName(const Name: AnsiString): TSemanticOp;

{ Parse an instruction format name string.
  Returns ifABC if not recognized. }
function ParseInstFormat(const Name: AnsiString): TInstFormat;

implementation

{ ================================================================== }
{  Semantic op name table                                            }
{ ================================================================== }

const
  SemanticOpNames: array[TSemanticOp] of AnsiString = (
    { 5.1 core }
    'MOVE', 'LOADK', 'LOADBOOL', 'LOADNIL',
    'GETUPVAL', 'GETGLOBAL', 'GETTABLE',
    'SETGLOBAL', 'SETUPVAL', 'SETTABLE',
    'NEWTABLE', 'SELF',
    'ADD', 'SUB', 'MUL', 'DIV', 'MOD', 'POW',
    'UNM', 'NOT', 'LEN', 'CONCAT',
    'JMP', 'EQ', 'LT', 'LE', 'TEST', 'TESTSET',
    'CALL', 'TAILCALL', 'RETURN',
    'FORLOOP', 'FORPREP', 'TFORLOOP',
    'SETLIST', 'CLOSE', 'CLOSURE', 'VARARG',
    { 5.2 }
    'LOADKX', 'GETTABUP', 'SETTABUP',
    'TFORCALL', 'TFORLOOP54', 'EXTRAARG',
    { 5.3 bitwise }
    'IDIV', 'BAND', 'BOR', 'BXOR', 'SHL', 'SHR', 'BNOT',
    { 5.4 typed loads }
    'LOADI', 'LOADF', 'LOADFALSE', 'LOADTRUE', 'LFALSESKIP',
    { 5.4 immediate arithmetic }
    'ADDI', 'ADDK', 'SUBK', 'MULK', 'MODK', 'POWK', 'DIVK', 'IDIVK',
    'BANDK', 'BORK', 'BXORK', 'SHRI', 'SHLI',
    { 5.4 typed table access }
    'GETI', 'GETFIELD', 'SETI', 'SETFIELD',
    { 5.4 immediate comparisons }
    'EQK', 'EQI', 'LTI', 'LEI', 'GTI', 'GEI',
    { 5.4 metamethod hints }
    'MMBIN', 'MMBINI', 'MMBINK',
    { 5.4 to-be-closed / return variants / misc }
    'TBC', 'RETURN0', 'RETURN1', 'TFORPREP', 'VARARGPREP',
    { 5.5 }
    'GETVARG', 'ERRNNIL',
    { sentinel }
    'UNKNOWN'
  );

function SemanticOpName(Op: TSemanticOp): AnsiString;
begin
  Result := SemanticOpNames[Op];
end;

function ParseSemanticOpName(const Name: AnsiString): TSemanticOp;
var
  Upper: AnsiString;
  Op: TSemanticOp;
begin
  Upper := UpperCase(Name);
  for Op := Low(TSemanticOp) to High(TSemanticOp) do
    if UpperCase(SemanticOpNames[Op]) = Upper then begin
      Result := Op;
      Exit;
    end;
  Result := semUNKNOWN;
end;

function ParseInstFormat(const Name: AnsiString): TInstFormat;
var
  Upper: AnsiString;
begin
  Upper := UpperCase(Name);
  if Upper = 'ABC' then Result := ifABC
  else if Upper = 'ABX' then Result := ifABx
  else if Upper = 'ASBX' then Result := ifAsBx
  else if Upper = 'AX' then Result := ifAx
  else if Upper = 'ISJ' then Result := ifisJ
  else if Upper = 'IVABC' then Result := ifivABC
  else Result := ifABC;
end;

{ ================================================================== }
{  Instruction decode functions                                      }
{ ================================================================== }

function DecodeRawOp(const Table: TOpcodeTable; Inst: LongWord): Integer;
begin
  Result := Integer(Inst and ((1 shl Table.OpBits) - 1));
end;

function DecodeOp(const Table: TOpcodeTable; Inst: LongWord): TSemanticOp;
var
  Raw: Integer;
begin
  Raw := DecodeRawOp(Table, Inst);
  if (Raw >= 0) and (Raw < Table.NumOpcodes) then
    Result := Table.Entries[Raw].SemanticOp
  else
    Result := semUNKNOWN;
end;

function DecodeA(const Table: TOpcodeTable; Inst: LongWord): Integer;
begin
  Result := Integer((Inst shr Table.OpBits) and ((1 shl Table.ABits) - 1));
end;

function DecodeB(const Table: TOpcodeTable; Inst: LongWord): Integer;
var
  Shift: Integer;
begin
  if Table.HasKFlag then begin
    { 5.4+: layout is op|A|k|B|C - B is right after the k-flag }
    Shift := Table.OpBits + Table.ABits + 1;
  end else begin
    { 5.1-5.3: layout is op|A|C|B - B is in the highest bits }
    Shift := Table.OpBits + Table.ABits + Table.CBits;
  end;
  Result := Integer((Inst shr Shift) and ((1 shl Table.BBits) - 1));
end;

function DecodeC(const Table: TOpcodeTable; Inst: LongWord): Integer;
var
  Shift: Integer;
begin
  if Table.HasKFlag then begin
    { 5.4+: layout is op|A|k|B|C - C is after B }
    Shift := Table.OpBits + Table.ABits + 1 + Table.BBits;
  end else begin
    { 5.1-5.3: layout is op|A|C|B - C is right after A }
    Shift := Table.OpBits + Table.ABits;
  end;
  Result := Integer((Inst shr Shift) and ((1 shl Table.CBits) - 1));
end;

function DecodeBx(const Table: TOpcodeTable; Inst: LongWord): Integer;
var
  Shift, BxBits: Integer;
begin
  Shift := Table.OpBits + Table.ABits;
  BxBits := Table.BBits + Table.CBits;
  if Table.HasKFlag then
    BxBits := BxBits + 1; { k-flag is part of Bx in ABx mode }
  Result := Integer((Inst shr Shift) and ((1 shl BxBits) - 1));
end;

function DecodesBx(const Table: TOpcodeTable; Inst: LongWord): Integer;
var
  BxBits, Bias: Integer;
begin
  BxBits := Table.BBits + Table.CBits;
  if Table.HasKFlag then
    BxBits := BxBits + 1;
  Bias := (1 shl (BxBits - 1)) - 1;
  Result := DecodeBx(Table, Inst) - Bias;
end;

function DecodeAx(const Table: TOpcodeTable; Inst: LongWord): Integer;
var
  Shift, AxBits: Integer;
begin
  Shift := Table.OpBits;
  AxBits := 32 - Table.OpBits;
  Result := Integer((Inst shr Shift) and ((1 shl AxBits) - 1));
end;

function DecodesJ(const Table: TOpcodeTable; Inst: LongWord): Integer;
var
  Shift, JBits, Bias: Integer;
  Raw: Integer;
begin
  { sJ format: all bits after opcode are the signed jump offset }
  Shift := Table.OpBits;
  JBits := 32 - Table.OpBits;
  Bias := (1 shl (JBits - 1)) - 1;
  Raw := Integer((Inst shr Shift) and ((1 shl JBits) - 1));
  Result := Raw - Bias;
end;

function DecodeK(const Table: TOpcodeTable; Inst: LongWord): Boolean;
var
  Shift: Integer;
begin
  if not Table.HasKFlag then begin
    Result := False;
    Exit;
  end;
  { k-flag is the bit right after A }
  Shift := Table.OpBits + Table.ABits;
  Result := ((Inst shr Shift) and 1) <> 0;
end;

function DecodeSC(const Table: TOpcodeTable; Inst: LongWord): Integer;
var
  MaxC: Integer;
begin
  { sC = C - offset, where offset = 2^(CBits-1) - 1 for 5.4+ }
  MaxC := (1 shl Table.CBits) - 1;
  Result := DecodeC(Table, Inst) - (MaxC shr 1);
end;

function DecodeSB(const Table: TOpcodeTable; Inst: LongWord): Integer;
var
  MaxB: Integer;
begin
  { sB = B - offset for immediate comparisons }
  MaxB := (1 shl Table.BBits) - 1;
  Result := DecodeB(Table, Inst) - (MaxB shr 1);
end;

function DecodeVB(const Table: TOpcodeTable; Inst: LongWord): Integer;
var
  Shift: Integer;
begin
  { ivABC format (5.5): Op(7) | A(8) | k(1) | vB(6) | vC(10)
    vB is 6 bits starting at the same position as standard B }
  Shift := Table.OpBits + Table.ABits + 1; { skip Op + A + k }
  Result := Integer((Inst shr Shift) and $3F); { 6 bits }
end;

function DecodeVC(const Table: TOpcodeTable; Inst: LongWord): Integer;
var
  Shift: Integer;
begin
  { ivABC format (5.5): Op(7) | A(8) | k(1) | vB(6) | vC(10)
    vC is 10 bits starting after vB }
  Shift := Table.OpBits + Table.ABits + 1 + 6; { skip Op + A + k + vB }
  Result := Integer((Inst shr Shift) and $3FF); { 10 bits }
end;

function IsIvABCFormat(const Table: TOpcodeTable; Inst: LongWord): Boolean;
var
  RawOp: Integer;
begin
  RawOp := DecodeRawOp(Table, Inst);
  if (RawOp >= 0) and (RawOp < Table.NumOpcodes) then
    Result := Table.Entries[RawOp].Format = ifivABC
  else
    Result := False;
end;

function IsRK(const Table: TOpcodeTable; Arg: Integer): Boolean;
begin
  { In 5.1-5.3, top bit of B/C indicates constant. In 5.4+, k-flag is separate. }
  if Table.HasKFlag then
    Result := False  { use DecodeK instead }
  else
    Result := (Arg and (1 shl (Table.BBits - 1))) <> 0;
end;

function RKIndex(const Table: TOpcodeTable; Arg: Integer): Integer;
begin
  if Table.HasKFlag then
    Result := Arg
  else
    Result := Arg and ((1 shl (Table.BBits - 1)) - 1);
end;

{ ================================================================== }
{  Helper: add an opcode entry to a table                            }
{ ================================================================== }

procedure AddEntry(var Table: TOpcodeTable; Ordinal: Integer;
  Op: TSemanticOp; Fmt: TInstFormat; const Name: AnsiString);
begin
  if Ordinal >= Length(Table.Entries) then
    SetLength(Table.Entries, Ordinal + 1);
  Table.Entries[Ordinal].SemanticOp := Op;
  Table.Entries[Ordinal].Format := Fmt;
  Table.Entries[Ordinal].Name := Name;
  if Ordinal >= Table.NumOpcodes then
    Table.NumOpcodes := Ordinal + 1;
end;

{ ================================================================== }
{  Lua 5.1 opcode table (38 opcodes)                                }
{ ================================================================== }

procedure BuildTable51(out Table: TOpcodeTable);
begin
  Table.Version := $51;
  Table.NumOpcodes := 0;
  Table.OpBits := 6;
  Table.ABits := 8;
  Table.BBits := 9;
  Table.CBits := 9;
  Table.HasKFlag := False;
  SetLength(Table.Entries, 38);

  AddEntry(Table,  0, semMOVE,      ifABC,  'MOVE');
  AddEntry(Table,  1, semLOADK,     ifABx,  'LOADK');
  AddEntry(Table,  2, semLOADBOOL,  ifABC,  'LOADBOOL');
  AddEntry(Table,  3, semLOADNIL,   ifABC,  'LOADNIL');
  AddEntry(Table,  4, semGETUPVAL,  ifABC,  'GETUPVAL');
  AddEntry(Table,  5, semGETGLOBAL, ifABx,  'GETGLOBAL');
  AddEntry(Table,  6, semGETTABLE,  ifABC,  'GETTABLE');
  AddEntry(Table,  7, semSETGLOBAL, ifABx,  'SETGLOBAL');
  AddEntry(Table,  8, semSETUPVAL,  ifABC,  'SETUPVAL');
  AddEntry(Table,  9, semSETTABLE,  ifABC,  'SETTABLE');
  AddEntry(Table, 10, semNEWTABLE,  ifABC,  'NEWTABLE');
  AddEntry(Table, 11, semSELF,      ifABC,  'SELF');
  AddEntry(Table, 12, semADD,       ifABC,  'ADD');
  AddEntry(Table, 13, semSUB,       ifABC,  'SUB');
  AddEntry(Table, 14, semMUL,       ifABC,  'MUL');
  AddEntry(Table, 15, semDIV,       ifABC,  'DIV');
  AddEntry(Table, 16, semMOD,       ifABC,  'MOD');
  AddEntry(Table, 17, semPOW,       ifABC,  'POW');
  AddEntry(Table, 18, semUNM,       ifABC,  'UNM');
  AddEntry(Table, 19, semNOT,       ifABC,  'NOT');
  AddEntry(Table, 20, semLEN,       ifABC,  'LEN');
  AddEntry(Table, 21, semCONCAT,    ifABC,  'CONCAT');
  AddEntry(Table, 22, semJMP,       ifAsBx, 'JMP');
  AddEntry(Table, 23, semEQ,        ifABC,  'EQ');
  AddEntry(Table, 24, semLT,        ifABC,  'LT');
  AddEntry(Table, 25, semLE,        ifABC,  'LE');
  AddEntry(Table, 26, semTEST,      ifABC,  'TEST');
  AddEntry(Table, 27, semTESTSET,   ifABC,  'TESTSET');
  AddEntry(Table, 28, semCALL,      ifABC,  'CALL');
  AddEntry(Table, 29, semTAILCALL,  ifABC,  'TAILCALL');
  AddEntry(Table, 30, semRETURN,    ifABC,  'RETURN');
  AddEntry(Table, 31, semFORLOOP,   ifAsBx, 'FORLOOP');
  AddEntry(Table, 32, semFORPREP,   ifAsBx, 'FORPREP');
  AddEntry(Table, 33, semTFORLOOP,  ifABC,  'TFORLOOP');
  AddEntry(Table, 34, semSETLIST,   ifABC,  'SETLIST');
  AddEntry(Table, 35, semCLOSE,     ifABC,  'CLOSE');
  AddEntry(Table, 36, semCLOSURE,   ifABx,  'CLOSURE');
  AddEntry(Table, 37, semVARARG,    ifABC,  'VARARG');
end;

{ ================================================================== }
{  Lua 5.2 opcode table (40 opcodes)                                }
{ ================================================================== }

procedure BuildTable52(out Table: TOpcodeTable);
begin
  Table.Version := $52;
  Table.NumOpcodes := 0;
  Table.OpBits := 6;
  Table.ABits := 8;
  Table.BBits := 9;
  Table.CBits := 9;
  Table.HasKFlag := False;
  SetLength(Table.Entries, 40);

  AddEntry(Table,  0, semMOVE,       ifABC,  'MOVE');
  AddEntry(Table,  1, semLOADK,      ifABx,  'LOADK');
  AddEntry(Table,  2, semLOADKX,     ifABx,  'LOADKX');
  AddEntry(Table,  3, semLOADBOOL,   ifABC,  'LOADBOOL');
  AddEntry(Table,  4, semLOADNIL,    ifABC,  'LOADNIL');
  AddEntry(Table,  5, semGETUPVAL,   ifABC,  'GETUPVAL');
  AddEntry(Table,  6, semGETTABUP,   ifABC,  'GETTABUP');
  AddEntry(Table,  7, semGETTABLE,   ifABC,  'GETTABLE');
  AddEntry(Table,  8, semSETTABUP,   ifABC,  'SETTABUP');
  AddEntry(Table,  9, semSETUPVAL,   ifABC,  'SETUPVAL');
  AddEntry(Table, 10, semSETTABLE,   ifABC,  'SETTABLE');
  AddEntry(Table, 11, semNEWTABLE,   ifABC,  'NEWTABLE');
  AddEntry(Table, 12, semSELF,       ifABC,  'SELF');
  AddEntry(Table, 13, semADD,        ifABC,  'ADD');
  AddEntry(Table, 14, semSUB,        ifABC,  'SUB');
  AddEntry(Table, 15, semMUL,        ifABC,  'MUL');
  AddEntry(Table, 16, semDIV,        ifABC,  'DIV');
  AddEntry(Table, 17, semMOD,        ifABC,  'MOD');
  AddEntry(Table, 18, semPOW,        ifABC,  'POW');
  AddEntry(Table, 19, semUNM,        ifABC,  'UNM');
  AddEntry(Table, 20, semNOT,        ifABC,  'NOT');
  AddEntry(Table, 21, semLEN,        ifABC,  'LEN');
  AddEntry(Table, 22, semCONCAT,     ifABC,  'CONCAT');
  AddEntry(Table, 23, semJMP,        ifAsBx, 'JMP');
  AddEntry(Table, 24, semEQ,         ifABC,  'EQ');
  AddEntry(Table, 25, semLT,         ifABC,  'LT');
  AddEntry(Table, 26, semLE,         ifABC,  'LE');
  AddEntry(Table, 27, semTEST,       ifABC,  'TEST');
  AddEntry(Table, 28, semTESTSET,    ifABC,  'TESTSET');
  AddEntry(Table, 29, semCALL,       ifABC,  'CALL');
  AddEntry(Table, 30, semTAILCALL,   ifABC,  'TAILCALL');
  AddEntry(Table, 31, semRETURN,     ifABC,  'RETURN');
  AddEntry(Table, 32, semFORLOOP,    ifAsBx, 'FORLOOP');
  AddEntry(Table, 33, semFORPREP,    ifAsBx, 'FORPREP');
  AddEntry(Table, 34, semTFORCALL,   ifABC,  'TFORCALL');
  AddEntry(Table, 35, semTFORLOOP54, ifAsBx, 'TFORLOOP');
  AddEntry(Table, 36, semSETLIST,    ifABC,  'SETLIST');
  AddEntry(Table, 37, semCLOSURE,    ifABx,  'CLOSURE');
  AddEntry(Table, 38, semVARARG,     ifABC,  'VARARG');
  AddEntry(Table, 39, semEXTRAARG,   ifAx,   'EXTRAARG');
end;

{ ================================================================== }
{  Lua 5.3 opcode table (47 opcodes)                                }
{ ================================================================== }

procedure BuildTable53(out Table: TOpcodeTable);
begin
  Table.Version := $53;
  Table.NumOpcodes := 0;
  Table.OpBits := 6;
  Table.ABits := 8;
  Table.BBits := 9;
  Table.CBits := 9;
  Table.HasKFlag := False;
  SetLength(Table.Entries, 47);

  AddEntry(Table,  0, semMOVE,       ifABC,  'MOVE');
  AddEntry(Table,  1, semLOADK,      ifABx,  'LOADK');
  AddEntry(Table,  2, semLOADKX,     ifABx,  'LOADKX');
  AddEntry(Table,  3, semLOADBOOL,   ifABC,  'LOADBOOL');
  AddEntry(Table,  4, semLOADNIL,    ifABC,  'LOADNIL');
  AddEntry(Table,  5, semGETUPVAL,   ifABC,  'GETUPVAL');
  AddEntry(Table,  6, semGETTABUP,   ifABC,  'GETTABUP');
  AddEntry(Table,  7, semGETTABLE,   ifABC,  'GETTABLE');
  AddEntry(Table,  8, semSETTABUP,   ifABC,  'SETTABUP');
  AddEntry(Table,  9, semSETUPVAL,   ifABC,  'SETUPVAL');
  AddEntry(Table, 10, semSETTABLE,   ifABC,  'SETTABLE');
  AddEntry(Table, 11, semNEWTABLE,   ifABC,  'NEWTABLE');
  AddEntry(Table, 12, semSELF,       ifABC,  'SELF');
  AddEntry(Table, 13, semADD,        ifABC,  'ADD');
  AddEntry(Table, 14, semSUB,        ifABC,  'SUB');
  AddEntry(Table, 15, semMUL,        ifABC,  'MUL');
  AddEntry(Table, 16, semMOD,        ifABC,  'MOD');
  AddEntry(Table, 17, semPOW,        ifABC,  'POW');
  AddEntry(Table, 18, semDIV,        ifABC,  'DIV');
  AddEntry(Table, 19, semIDIV,       ifABC,  'IDIV');
  AddEntry(Table, 20, semBAND,       ifABC,  'BAND');
  AddEntry(Table, 21, semBOR,        ifABC,  'BOR');
  AddEntry(Table, 22, semBXOR,       ifABC,  'BXOR');
  AddEntry(Table, 23, semSHL,        ifABC,  'SHL');
  AddEntry(Table, 24, semSHR,        ifABC,  'SHR');
  AddEntry(Table, 25, semUNM,        ifABC,  'UNM');
  AddEntry(Table, 26, semBNOT,       ifABC,  'BNOT');
  AddEntry(Table, 27, semNOT,        ifABC,  'NOT');
  AddEntry(Table, 28, semLEN,        ifABC,  'LEN');
  AddEntry(Table, 29, semCONCAT,     ifABC,  'CONCAT');
  AddEntry(Table, 30, semJMP,        ifAsBx, 'JMP');
  AddEntry(Table, 31, semEQ,         ifABC,  'EQ');
  AddEntry(Table, 32, semLT,         ifABC,  'LT');
  AddEntry(Table, 33, semLE,         ifABC,  'LE');
  AddEntry(Table, 34, semTEST,       ifABC,  'TEST');
  AddEntry(Table, 35, semTESTSET,    ifABC,  'TESTSET');
  AddEntry(Table, 36, semCALL,       ifABC,  'CALL');
  AddEntry(Table, 37, semTAILCALL,   ifABC,  'TAILCALL');
  AddEntry(Table, 38, semRETURN,     ifABC,  'RETURN');
  AddEntry(Table, 39, semFORLOOP,    ifAsBx, 'FORLOOP');
  AddEntry(Table, 40, semFORPREP,    ifAsBx, 'FORPREP');
  AddEntry(Table, 41, semTFORCALL,   ifABC,  'TFORCALL');
  AddEntry(Table, 42, semTFORLOOP54, ifAsBx, 'TFORLOOP');
  AddEntry(Table, 43, semSETLIST,    ifABC,  'SETLIST');
  AddEntry(Table, 44, semCLOSURE,    ifABx,  'CLOSURE');
  AddEntry(Table, 45, semVARARG,     ifABC,  'VARARG');
  AddEntry(Table, 46, semEXTRAARG,   ifAx,   'EXTRAARG');
end;

{ ================================================================== }
{  Lua 5.4 opcode table (83 opcodes)                                }
{ ================================================================== }

procedure BuildTable54(out Table: TOpcodeTable);
begin
  Table.Version := $54;
  Table.NumOpcodes := 0;
  Table.OpBits := 7;
  Table.ABits := 8;
  Table.BBits := 8;
  Table.CBits := 8;
  Table.HasKFlag := True;
  SetLength(Table.Entries, 83);

  { Lua 5.4.7 lopcodes.h - 83 opcodes (0..82) }
  AddEntry(Table,  0, semMOVE,       ifABC,  'MOVE');
  AddEntry(Table,  1, semLOADI,      ifAsBx, 'LOADI');
  AddEntry(Table,  2, semLOADF,      ifAsBx, 'LOADF');
  AddEntry(Table,  3, semLOADK,      ifABx,  'LOADK');
  AddEntry(Table,  4, semLOADKX,     ifABx,  'LOADKX');
  AddEntry(Table,  5, semLOADFALSE,  ifABC,  'LOADFALSE');
  AddEntry(Table,  6, semLFALSESKIP, ifABC,  'LFALSESKIP');
  AddEntry(Table,  7, semLOADTRUE,   ifABC,  'LOADTRUE');
  AddEntry(Table,  8, semLOADNIL,    ifABC,  'LOADNIL');
  AddEntry(Table,  9, semGETUPVAL,   ifABC,  'GETUPVAL');
  AddEntry(Table, 10, semSETUPVAL,   ifABC,  'SETUPVAL');
  AddEntry(Table, 11, semGETTABUP,   ifABC,  'GETTABUP');
  AddEntry(Table, 12, semGETTABLE,   ifABC,  'GETTABLE');
  AddEntry(Table, 13, semGETI,       ifABC,  'GETI');
  AddEntry(Table, 14, semGETFIELD,   ifABC,  'GETFIELD');
  AddEntry(Table, 15, semSETTABUP,   ifABC,  'SETTABUP');
  AddEntry(Table, 16, semSETTABLE,   ifABC,  'SETTABLE');
  AddEntry(Table, 17, semSETI,       ifABC,  'SETI');
  AddEntry(Table, 18, semSETFIELD,   ifABC,  'SETFIELD');
  AddEntry(Table, 19, semNEWTABLE,   ifABC,  'NEWTABLE');
  AddEntry(Table, 20, semSELF,       ifABC,  'SELF');
  AddEntry(Table, 21, semADDI,       ifABC,  'ADDI');
  AddEntry(Table, 22, semADDK,       ifABC,  'ADDK');
  AddEntry(Table, 23, semSUBK,       ifABC,  'SUBK');
  AddEntry(Table, 24, semMULK,       ifABC,  'MULK');
  AddEntry(Table, 25, semMODK,       ifABC,  'MODK');
  AddEntry(Table, 26, semPOWK,       ifABC,  'POWK');
  AddEntry(Table, 27, semDIVK,       ifABC,  'DIVK');
  AddEntry(Table, 28, semIDIVK,      ifABC,  'IDIVK');
  AddEntry(Table, 29, semBANDK,      ifABC,  'BANDK');
  AddEntry(Table, 30, semBORK,       ifABC,  'BORK');
  AddEntry(Table, 31, semBXORK,      ifABC,  'BXORK');
  AddEntry(Table, 32, semSHRI,       ifABC,  'SHRI');
  AddEntry(Table, 33, semSHLI,       ifABC,  'SHLI');
  AddEntry(Table, 34, semADD,        ifABC,  'ADD');
  AddEntry(Table, 35, semSUB,        ifABC,  'SUB');
  AddEntry(Table, 36, semMUL,        ifABC,  'MUL');
  AddEntry(Table, 37, semMOD,        ifABC,  'MOD');
  AddEntry(Table, 38, semPOW,        ifABC,  'POW');
  AddEntry(Table, 39, semDIV,        ifABC,  'DIV');
  AddEntry(Table, 40, semIDIV,       ifABC,  'IDIV');
  AddEntry(Table, 41, semBAND,       ifABC,  'BAND');
  AddEntry(Table, 42, semBOR,        ifABC,  'BOR');
  AddEntry(Table, 43, semBXOR,       ifABC,  'BXOR');
  AddEntry(Table, 44, semSHL,        ifABC,  'SHL');
  AddEntry(Table, 45, semSHR,        ifABC,  'SHR');
  AddEntry(Table, 46, semMMBIN,      ifABC,  'MMBIN');
  AddEntry(Table, 47, semMMBINI,     ifABC,  'MMBINI');
  AddEntry(Table, 48, semMMBINK,     ifABC,  'MMBINK');
  AddEntry(Table, 49, semUNM,        ifABC,  'UNM');
  AddEntry(Table, 50, semBNOT,       ifABC,  'BNOT');
  AddEntry(Table, 51, semNOT,        ifABC,  'NOT');
  AddEntry(Table, 52, semLEN,        ifABC,  'LEN');
  AddEntry(Table, 53, semCONCAT,     ifABC,  'CONCAT');
  AddEntry(Table, 54, semCLOSE,      ifABC,  'CLOSE');
  AddEntry(Table, 55, semTBC,        ifABC,  'TBC');
  AddEntry(Table, 56, semJMP,        ifisJ,  'JMP');
  AddEntry(Table, 57, semEQ,         ifABC,  'EQ');
  AddEntry(Table, 58, semLT,         ifABC,  'LT');
  AddEntry(Table, 59, semLE,         ifABC,  'LE');
  AddEntry(Table, 60, semEQK,        ifABC,  'EQK');
  AddEntry(Table, 61, semEQI,        ifABC,  'EQI');
  AddEntry(Table, 62, semLTI,        ifABC,  'LTI');
  AddEntry(Table, 63, semLEI,        ifABC,  'LEI');
  AddEntry(Table, 64, semGTI,        ifABC,  'GTI');
  AddEntry(Table, 65, semGEI,        ifABC,  'GEI');
  AddEntry(Table, 66, semTEST,       ifABC,  'TEST');
  AddEntry(Table, 67, semTESTSET,    ifABC,  'TESTSET');
  AddEntry(Table, 68, semCALL,       ifABC,  'CALL');
  AddEntry(Table, 69, semTAILCALL,   ifABC,  'TAILCALL');
  AddEntry(Table, 70, semRETURN,     ifABC,  'RETURN');
  AddEntry(Table, 71, semRETURN0,    ifABC,  'RETURN0');
  AddEntry(Table, 72, semRETURN1,    ifABC,  'RETURN1');
  AddEntry(Table, 73, semFORLOOP,    ifABx,  'FORLOOP');
  AddEntry(Table, 74, semFORPREP,    ifABx,  'FORPREP');
  AddEntry(Table, 75, semTFORPREP,   ifABx,  'TFORPREP');
  AddEntry(Table, 76, semTFORCALL,   ifABC,  'TFORCALL');
  AddEntry(Table, 77, semTFORLOOP54, ifABx,  'TFORLOOP');
  AddEntry(Table, 78, semSETLIST,    ifABC,  'SETLIST');
  AddEntry(Table, 79, semCLOSURE,    ifABx,  'CLOSURE');
  AddEntry(Table, 80, semVARARG,     ifABC,  'VARARG');
  AddEntry(Table, 81, semVARARGPREP, ifABC,  'VARARGPREP');
  AddEntry(Table, 82, semEXTRAARG,   ifAx,   'EXTRAARG');
end;

{ ================================================================== }
{  Lua 5.5 opcode table                                             }
{  Based on 5.5-work1 / 5.5 alpha sources.                         }
{  Very similar to 5.4 with minor additions.                        }
{ ================================================================== }

procedure BuildTable55(out Table: TOpcodeTable);
begin
  { Lua 5.5 - 85 opcodes (0..84)
    Very similar to 5.4 but with a few changes:
    - SHLI and SHRI are swapped compared to 5.4
    - NEWTABLE and SETLIST use ivABC format
    - Adds GETVARG and ERRNNIL opcodes
    - Adds ivABC instruction format }
  Table.Version := $55;
  Table.NumOpcodes := 0;
  Table.OpBits := 7;
  Table.ABits := 8;
  Table.BBits := 8;
  Table.CBits := 8;
  Table.HasKFlag := True;
  SetLength(Table.Entries, 85);

  AddEntry(Table,  0, semMOVE,       ifABC,   'MOVE');
  AddEntry(Table,  1, semLOADI,      ifAsBx,  'LOADI');
  AddEntry(Table,  2, semLOADF,      ifAsBx,  'LOADF');
  AddEntry(Table,  3, semLOADK,      ifABx,   'LOADK');
  AddEntry(Table,  4, semLOADKX,     ifABx,   'LOADKX');
  AddEntry(Table,  5, semLOADFALSE,  ifABC,   'LOADFALSE');
  AddEntry(Table,  6, semLFALSESKIP, ifABC,   'LFALSESKIP');
  AddEntry(Table,  7, semLOADTRUE,   ifABC,   'LOADTRUE');
  AddEntry(Table,  8, semLOADNIL,    ifABC,   'LOADNIL');
  AddEntry(Table,  9, semGETUPVAL,   ifABC,   'GETUPVAL');
  AddEntry(Table, 10, semSETUPVAL,   ifABC,   'SETUPVAL');
  AddEntry(Table, 11, semGETTABUP,   ifABC,   'GETTABUP');
  AddEntry(Table, 12, semGETTABLE,   ifABC,   'GETTABLE');
  AddEntry(Table, 13, semGETI,       ifABC,   'GETI');
  AddEntry(Table, 14, semGETFIELD,   ifABC,   'GETFIELD');
  AddEntry(Table, 15, semSETTABUP,   ifABC,   'SETTABUP');
  AddEntry(Table, 16, semSETTABLE,   ifABC,   'SETTABLE');
  AddEntry(Table, 17, semSETI,       ifABC,   'SETI');
  AddEntry(Table, 18, semSETFIELD,   ifABC,   'SETFIELD');
  AddEntry(Table, 19, semNEWTABLE,   ifivABC, 'NEWTABLE');   { 5.5: ivABC }
  AddEntry(Table, 20, semSELF,       ifABC,   'SELF');
  AddEntry(Table, 21, semADDI,       ifABC,   'ADDI');
  AddEntry(Table, 22, semADDK,       ifABC,   'ADDK');
  AddEntry(Table, 23, semSUBK,       ifABC,   'SUBK');
  AddEntry(Table, 24, semMULK,       ifABC,   'MULK');
  AddEntry(Table, 25, semMODK,       ifABC,   'MODK');
  AddEntry(Table, 26, semPOWK,       ifABC,   'POWK');
  AddEntry(Table, 27, semDIVK,       ifABC,   'DIVK');
  AddEntry(Table, 28, semIDIVK,      ifABC,   'IDIVK');
  AddEntry(Table, 29, semBANDK,      ifABC,   'BANDK');
  AddEntry(Table, 30, semBORK,       ifABC,   'BORK');
  AddEntry(Table, 31, semBXORK,      ifABC,   'BXORK');
  AddEntry(Table, 32, semSHLI,       ifABC,   'SHLI');      { 5.5: SHLI before SHRI }
  AddEntry(Table, 33, semSHRI,       ifABC,   'SHRI');
  AddEntry(Table, 34, semADD,        ifABC,   'ADD');
  AddEntry(Table, 35, semSUB,        ifABC,   'SUB');
  AddEntry(Table, 36, semMUL,        ifABC,   'MUL');
  AddEntry(Table, 37, semMOD,        ifABC,   'MOD');
  AddEntry(Table, 38, semPOW,        ifABC,   'POW');
  AddEntry(Table, 39, semDIV,        ifABC,   'DIV');
  AddEntry(Table, 40, semIDIV,       ifABC,   'IDIV');
  AddEntry(Table, 41, semBAND,       ifABC,   'BAND');
  AddEntry(Table, 42, semBOR,        ifABC,   'BOR');
  AddEntry(Table, 43, semBXOR,       ifABC,   'BXOR');
  AddEntry(Table, 44, semSHL,        ifABC,   'SHL');
  AddEntry(Table, 45, semSHR,        ifABC,   'SHR');
  AddEntry(Table, 46, semMMBIN,      ifABC,   'MMBIN');
  AddEntry(Table, 47, semMMBINI,     ifABC,   'MMBINI');
  AddEntry(Table, 48, semMMBINK,     ifABC,   'MMBINK');
  AddEntry(Table, 49, semUNM,        ifABC,   'UNM');
  AddEntry(Table, 50, semBNOT,       ifABC,   'BNOT');
  AddEntry(Table, 51, semNOT,        ifABC,   'NOT');
  AddEntry(Table, 52, semLEN,        ifABC,   'LEN');
  AddEntry(Table, 53, semCONCAT,     ifABC,   'CONCAT');
  AddEntry(Table, 54, semCLOSE,      ifABC,   'CLOSE');
  AddEntry(Table, 55, semTBC,        ifABC,   'TBC');
  AddEntry(Table, 56, semJMP,        ifisJ,   'JMP');
  AddEntry(Table, 57, semEQ,         ifABC,   'EQ');
  AddEntry(Table, 58, semLT,         ifABC,   'LT');
  AddEntry(Table, 59, semLE,         ifABC,   'LE');
  AddEntry(Table, 60, semEQK,        ifABC,   'EQK');
  AddEntry(Table, 61, semEQI,        ifABC,   'EQI');
  AddEntry(Table, 62, semLTI,        ifABC,   'LTI');
  AddEntry(Table, 63, semLEI,        ifABC,   'LEI');
  AddEntry(Table, 64, semGTI,        ifABC,   'GTI');
  AddEntry(Table, 65, semGEI,        ifABC,   'GEI');
  AddEntry(Table, 66, semTEST,       ifABC,   'TEST');
  AddEntry(Table, 67, semTESTSET,    ifABC,   'TESTSET');
  AddEntry(Table, 68, semCALL,       ifABC,   'CALL');
  AddEntry(Table, 69, semTAILCALL,   ifABC,   'TAILCALL');
  AddEntry(Table, 70, semRETURN,     ifABC,   'RETURN');
  AddEntry(Table, 71, semRETURN0,    ifABC,   'RETURN0');
  AddEntry(Table, 72, semRETURN1,    ifABC,   'RETURN1');
  AddEntry(Table, 73, semFORLOOP,    ifABx,   'FORLOOP');
  AddEntry(Table, 74, semFORPREP,    ifABx,   'FORPREP');
  AddEntry(Table, 75, semTFORPREP,   ifABx,   'TFORPREP');
  AddEntry(Table, 76, semTFORCALL,   ifABC,   'TFORCALL');
  AddEntry(Table, 77, semTFORLOOP54, ifABx,   'TFORLOOP');
  AddEntry(Table, 78, semSETLIST,    ifivABC, 'SETLIST');    { 5.5: ivABC }
  AddEntry(Table, 79, semCLOSURE,    ifABx,   'CLOSURE');
  AddEntry(Table, 80, semVARARG,     ifABC,   'VARARG');
  AddEntry(Table, 81, semGETVARG,    ifABC,   'GETVARG');    { 5.5 new }
  AddEntry(Table, 82, semERRNNIL,    ifABx,   'ERRNNIL');    { 5.5 new }
  AddEntry(Table, 83, semVARARGPREP, ifABC,   'VARARGPREP');
  AddEntry(Table, 84, semEXTRAARG,   ifAx,    'EXTRAARG');
end;

{ ================================================================== }
{  GetBuiltinTable                                                   }
{ ================================================================== }

function GetBuiltinTable(Version: Byte; out Table: TOpcodeTable): Boolean;
begin
  Result := True;
  case Version of
    $51: BuildTable51(Table);
    $52: BuildTable52(Table);
    $53: BuildTable53(Table);
    $54: BuildTable54(Table);
    $55: BuildTable55(Table);
  else
    Result := False;
  end;
end;

{ ================================================================== }
{  Custom opcode table loader                                        }
{ ================================================================== }

function LoadOpcodeTableFromFile(const FileName: AnsiString;
  out Table: TOpcodeTable; out ErrMsg: AnsiString): Boolean;
var
  F: TextFile;
  Line, Key, Val, Trimmed: AnsiString;
  LineNum, Ordinal, SpPos, SpPos2: Integer;
  OpName, FmtName: AnsiString;
  SemOp: TSemanticOp;
  Fmt: TInstFormat;
begin
  Result := False;
  ErrMsg := '';

  { Initialize defaults }
  Table.Version := $51;
  Table.NumOpcodes := 0;
  Table.OpBits := 6;
  Table.ABits := 8;
  Table.BBits := 9;
  Table.CBits := 9;
  Table.HasKFlag := False;
  SetLength(Table.Entries, 0);

  if not FileExists(FileName) then begin
    ErrMsg := 'File not found: ' + FileName;
    Exit;
  end;

  AssignFile(F, FileName);
  try
    Reset(F);
  except
    on E: Exception do begin
      ErrMsg := 'Cannot open file: ' + E.Message;
      Exit;
    end;
  end;

  LineNum := 0;
  try
    while not Eof(F) do begin
      ReadLn(F, Line);
      Inc(LineNum);

      { Strip comments and trim }
      SpPos := Pos('#', Line);
      if SpPos > 0 then
        Line := Copy(Line, 1, SpPos - 1);
      Trimmed := Trim(Line);
      if Trimmed = '' then Continue;

      { Check for header directives (KEY VALUE) }
      SpPos := Pos(' ', Trimmed);
      if SpPos > 0 then begin
        Key := UpperCase(Copy(Trimmed, 1, SpPos - 1));
        Val := Trim(Copy(Trimmed, SpPos + 1, Length(Trimmed)));

        if Key = 'VERSION' then begin
          case StrToIntDef(Val, 0) of
            51: Table.Version := $51;
            52: Table.Version := $52;
            53: Table.Version := $53;
            54: Table.Version := $54;
            55: Table.Version := $55;
          else
            ErrMsg := Format('Line %d: unknown version "%s"', [LineNum, Val]);
            CloseFile(F);
            Exit;
          end;
          Continue;
        end;
        if Key = 'OPBITS' then begin
          Table.OpBits := StrToIntDef(Val, 6);
          Continue;
        end;
        if Key = 'ABITS' then begin
          Table.ABits := StrToIntDef(Val, 8);
          Continue;
        end;
        if Key = 'BBITS' then begin
          Table.BBits := StrToIntDef(Val, 9);
          Continue;
        end;
        if Key = 'CBITS' then begin
          Table.CBits := StrToIntDef(Val, 9);
          Continue;
        end;
        if Key = 'HASKFLAG' then begin
          Table.HasKFlag := (UpperCase(Val) = 'TRUE') or (Val = '1');
          Continue;
        end;
      end;

      { Parse opcode mapping: <ordinal> <semantic_name> <format> }
      { First token: ordinal }
      SpPos := 1;
      while (SpPos <= Length(Trimmed)) and (Trimmed[SpPos] <> ' ') and
            (Trimmed[SpPos] <> #9) do
        Inc(SpPos);

      Ordinal := StrToIntDef(Copy(Trimmed, 1, SpPos - 1), -1);
      if Ordinal < 0 then begin
        ErrMsg := Format('Line %d: invalid ordinal in "%s"', [LineNum, Trimmed]);
        CloseFile(F);
        Exit;
      end;

      { Skip whitespace }
      while (SpPos <= Length(Trimmed)) and
            ((Trimmed[SpPos] = ' ') or (Trimmed[SpPos] = #9)) do
        Inc(SpPos);

      { Second token: semantic name }
      SpPos2 := SpPos;
      while (SpPos2 <= Length(Trimmed)) and (Trimmed[SpPos2] <> ' ') and
            (Trimmed[SpPos2] <> #9) do
        Inc(SpPos2);
      OpName := Copy(Trimmed, SpPos, SpPos2 - SpPos);

      { Skip whitespace }
      while (SpPos2 <= Length(Trimmed)) and
            ((Trimmed[SpPos2] = ' ') or (Trimmed[SpPos2] = #9)) do
        Inc(SpPos2);

      { Third token: format (optional, defaults to ABC) }
      FmtName := Copy(Trimmed, SpPos2, Length(Trimmed) - SpPos2 + 1);
      if FmtName = '' then FmtName := 'ABC';

      SemOp := ParseSemanticOpName(OpName);
      if SemOp = semUNKNOWN then begin
        ErrMsg := Format('Line %d: unknown opcode name "%s"', [LineNum, OpName]);
        CloseFile(F);
        Exit;
      end;

      Fmt := ParseInstFormat(FmtName);
      AddEntry(Table, Ordinal, SemOp, Fmt, UpperCase(OpName));
    end;

    CloseFile(F);
    Result := True;
  except
    on E: Exception do begin
      ErrMsg := Format('Line %d: %s', [LineNum, E.Message]);
      try CloseFile(F); except end;
    end;
  end;
end;

end.
