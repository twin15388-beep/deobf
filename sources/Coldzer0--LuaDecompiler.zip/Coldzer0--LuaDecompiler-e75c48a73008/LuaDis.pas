unit LuaDis;

{
  LuaDis.pas - Multi-version Lua bytecode disassembler (5.1-5.5).

  Decodes every TInstruction in a TProto and prints human-readable output
  in a format similar to luac -l -l (double -l gives full constant detail).

  Example output line:
    [  1] (line 3)  LOADK      R0  K0  ; "hello"
    [  2] (line 4)  CALL       R0  2 1
    [  3] (line 4)  RETURN     R0  1

  The disassembler is intentionally self-contained and does not depend on
  LuaSSA or LuaDecomp.

  FormatInstruction  - 5.1-only legacy path (uses TOpCode enum)
  FormatInstructionV - multi-version path (uses TOpcodeTable + TSemanticOp)
}

{$mode objfpc}{$H+}

interface

uses
  SysUtils, LuaChunk, LuaOpcodes, LuaUtils;

{ Disassemble a single Proto (non-recursive) to stdout - legacy 5.1 only }
procedure DisassembleProto(const P: TProto; Indent: Integer = 0);

{ Disassemble a single Proto using version-aware opcode table }
procedure DisassembleProtoV(const P: TProto; const OT: TOpcodeTable; Indent: Integer = 0);

{ Disassemble a full chunk (recurses into sub-protos, version-aware) }
procedure DisassembleChunk(const Chunk: TLuaChunk);

{ Format a single instruction to a human-readable string - legacy 5.1 only }
function FormatInstruction(const P: TProto; PC: Integer): AnsiString;

{ Format a single instruction using version-aware opcode table }
function FormatInstructionV(const P: TProto; PC: Integer; const OT: TOpcodeTable): AnsiString;

implementation

{ ======================================================================
  Helpers
  ====================================================================== }

function PadRight(const S: AnsiString; W: Integer): AnsiString;
begin
  Result := S;
  while Length(Result) < W do
    Result := Result + ' ';
end;

{ Format a constant value for display }
function ConstToStr(const K: TLuaConst): AnsiString;
begin
  case K.Kind of
    lckNil:     Result := 'nil';
    lckBoolean: if K.BValue then Result := 'true' else Result := 'false';
    lckNumber: begin
      { Try integer display first to avoid ugly 1.0 for whole numbers }
      if (K.NValue >= -1e15) and (K.NValue <= 1e15) and
         (Frac(K.NValue) = 0) then
        Result := IntToStr(Trunc(K.NValue))
      else
        Result := FloatToStr(K.NValue);
    end;
    lckString: Result := '"' + EscapeString(K.SValue) + '"';
    lckInteger: Result := IntToStr(K.IValue);
    lckFloat: begin
      if (K.NValue >= -1e15) and (K.NValue <= 1e15) and
         (Frac(K.NValue) = 0) then
        Result := IntToStr(Trunc(K.NValue))
      else
        Result := FloatToStr(K.NValue);
    end;
  else
    Result := '?';
  end;
end;

{ Return name of a register if a LocVar covers it at PC, else "Rx" }
function RegName(const P: TProto; Reg, PC: Integer): AnsiString;
var
  I: Integer;
begin
  for I := 0 to High(P.LocVars) do
    if (P.LocVars[I].StartPC <= PC) and (PC < P.LocVars[I].EndPC) then
      if I = Reg then begin
        Result := P.LocVars[I].Name;
        Exit;
      end;
  Result := 'R' + IntToStr(Reg);
end;

{ Format an RK argument: constant or register (5.1 layout) }
function RKStr(const P: TProto; X, PC: Integer): AnsiString;
begin
  if ISK(X) then
    Result := 'K' + IntToStr(INDEXRK(X)) + '(' + ConstToStr(P.K[INDEXRK(X)]) + ')'
  else
    Result := RegName(P, X, PC);
end;

{ Format an RK argument for multi-version: uses TOpcodeTable to detect constants }
function RKStrV(const P: TProto; X, PC: Integer; const OT: TOpcodeTable): AnsiString;
var
  Idx: Integer;
begin
  if LuaOpcodes.IsRK(OT, X) then begin
    Idx := LuaOpcodes.RKIndex(OT, X);
    if (Idx >= 0) and (Idx < Length(P.K)) then
      Result := 'K' + IntToStr(Idx) + '(' + ConstToStr(P.K[Idx]) + ')'
    else
      Result := 'K' + IntToStr(Idx);
  end else
    Result := RegName(P, X, PC);
end;

{ Format a constant reference with value annotation }
function KStr(const P: TProto; Idx: Integer): AnsiString;
begin
  if (Idx >= 0) and (Idx < Length(P.K)) then
    Result := 'K' + IntToStr(Idx) + '(' + ConstToStr(P.K[Idx]) + ')'
  else
    Result := 'K' + IntToStr(Idx);
end;

{ Format upvalue name }
function UpvalName(const P: TProto; Idx: Integer): AnsiString;
begin
  if Idx < Length(P.UpvalueNames) then
    Result := P.UpvalueNames[Idx]
  else if Idx < Length(P.UpvalDescs) then begin
    if P.UpvalDescs[Idx].Name <> '' then
      Result := P.UpvalDescs[Idx].Name
    else
      Result := 'upval[' + IntToStr(Idx) + ']';
  end else
    Result := 'upval[' + IntToStr(Idx) + ']';
end;

{ ======================================================================
  FormatInstruction  (legacy 5.1 path)
  ====================================================================== }

function FormatInstruction(const P: TProto; PC: Integer): AnsiString;
var
  Inst  : TInstruction;
  Op    : TOpCode;
  A, B, C, Bx, sBx : Integer;
  Line  : AnsiString;
  Ann   : AnsiString;  { annotation }
  LineNo: Integer;
begin
  Inst := P.Code[PC];
  Op   := GET_OPCODE(Inst);
  A    := GETARG_A(Inst);
  B    := GETARG_B(Inst);
  C    := GETARG_C(Inst);
  Bx   := GETARG_Bx(Inst);
  sBx  := GETARG_sBx(Inst);
  Ann  := '';

  { PC display is 1-based }
  if (PC < Length(P.LineInfo)) and (P.LineInfo[PC] > 0) then
    LineNo := P.LineInfo[PC]
  else
    LineNo := -1;

  { Build field part }
  Line := PadRight(OpcodeName(Op), 12);

  case Op of
    OP_MOVE: begin
      Line := Line + RegName(P, A, PC) + '  ' + RegName(P, B, PC);
      Ann  := 'R' + IntToStr(A) + ' := R' + IntToStr(B);
    end;
    OP_LOADK: begin
      Line := Line + RegName(P, A, PC) + '  K' + IntToStr(Bx);
      if Bx < Length(P.K) then
        Ann := ConstToStr(P.K[Bx]);
    end;
    OP_LOADBOOL: begin
      Line := Line + RegName(P, A, PC) + '  ' + IntToStr(B) + '  ' + IntToStr(C);
      Ann  := 'R' + IntToStr(A) + ' := ' + IntToStr(B);
      if C <> 0 then Ann := Ann + '; skip next';
    end;
    OP_LOADNIL: begin
      Line := Line + RegName(P, A, PC) + '  R' + IntToStr(B);
      Ann  := 'R' + IntToStr(A) + '..R' + IntToStr(B) + ' := nil';
    end;
    OP_GETUPVAL: begin
      Line := Line + RegName(P, A, PC) + '  ' + IntToStr(B);
      if B < Length(P.UpvalueNames) then
        Ann := P.UpvalueNames[B]
      else
        Ann := 'upval[' + IntToStr(B) + ']';
    end;
    OP_GETGLOBAL: begin
      Line := Line + RegName(P, A, PC) + '  K' + IntToStr(Bx);
      if Bx < Length(P.K) then
        Ann := P.K[Bx].SValue;
    end;
    OP_GETTABLE: begin
      Line := Line + RegName(P, A, PC) + '  ' + RegName(P, B, PC) + '  ' + RKStr(P, C, PC);
      Ann  := 'R' + IntToStr(A) + ' := R' + IntToStr(B) + '[' + RKStr(P, C, PC) + ']';
    end;
    OP_SETGLOBAL: begin
      Line := Line + RegName(P, A, PC) + '  K' + IntToStr(Bx);
      if Bx < Length(P.K) then
        Ann := P.K[Bx].SValue + ' := R' + IntToStr(A);
    end;
    OP_SETUPVAL: begin
      Line := Line + RegName(P, A, PC) + '  ' + IntToStr(B);
      if B < Length(P.UpvalueNames) then
        Ann := P.UpvalueNames[B] + ' := R' + IntToStr(A);
    end;
    OP_SETTABLE: begin
      Line := Line + RegName(P, A, PC) + '  ' + RKStr(P, B, PC) + '  ' + RKStr(P, C, PC);
      Ann  := 'R' + IntToStr(A) + '[' + RKStr(P, B, PC) + '] := ' + RKStr(P, C, PC);
    end;
    OP_NEWTABLE: begin
      Line := Line + RegName(P, A, PC) + '  ' + IntToStr(B) + '  ' + IntToStr(C);
      Ann  := 'array_size=' + IntToStr(B) + ' hash_size=' + IntToStr(C);
    end;
    OP_SELF: begin
      Line := Line + RegName(P, A, PC) + '  ' + RegName(P, B, PC) + '  ' + RKStr(P, C, PC);
      Ann  := 'R' + IntToStr(A+1) + ' := R' + IntToStr(B) +
              '; R' + IntToStr(A) + ' := R' + IntToStr(B) + '[' + RKStr(P, C, PC) + ']';
    end;
    OP_ADD, OP_SUB, OP_MUL, OP_DIV, OP_MOD, OP_POW: begin
      Line := Line + RegName(P, A, PC) + '  ' + RKStr(P, B, PC) + '  ' + RKStr(P, C, PC);
      Ann  := 'R' + IntToStr(A) + ' := ' + RKStr(P, B, PC);
      case Op of
        OP_ADD: Ann := Ann + ' + ';
        OP_SUB: Ann := Ann + ' - ';
        OP_MUL: Ann := Ann + ' * ';
        OP_DIV: Ann := Ann + ' / ';
        OP_MOD: Ann := Ann + ' % ';
        OP_POW: Ann := Ann + ' ^ ';
      end;
      Ann := Ann + RKStr(P, C, PC);
    end;
    OP_UNM, OP_NOT, OP_LEN: begin
      Line := Line + RegName(P, A, PC) + '  ' + RegName(P, B, PC);
      case Op of
        OP_UNM: Ann := 'R' + IntToStr(A) + ' := -R' + IntToStr(B);
        OP_NOT: Ann := 'R' + IntToStr(A) + ' := not R' + IntToStr(B);
        OP_LEN: Ann := 'R' + IntToStr(A) + ' := #R' + IntToStr(B);
      end;
    end;
    OP_CONCAT: begin
      Line := Line + RegName(P, A, PC) + '  R' + IntToStr(B) + '  R' + IntToStr(C);
      Ann  := 'R' + IntToStr(A) + ' := R' + IntToStr(B) + '..R' + IntToStr(C);
    end;
    OP_JMP: begin
      Line := Line + IntToStr(sBx);
      Ann  := 'pc += ' + IntToStr(sBx) + ' => [' + IntToStr(PC + 1 + sBx + 1) + ']';
    end;
    OP_EQ, OP_LT, OP_LE: begin
      Line := Line + IntToStr(A) + '  ' + RKStr(P, B, PC) + '  ' + RKStr(P, C, PC);
      case Op of
        OP_EQ: Ann := 'if (' + RKStr(P, B, PC) + ' == ' + RKStr(P, C, PC) + ') ~= ' + IntToStr(A) + ' then skip';
        OP_LT: Ann := 'if (' + RKStr(P, B, PC) + ' <  ' + RKStr(P, C, PC) + ') ~= ' + IntToStr(A) + ' then skip';
        OP_LE: Ann := 'if (' + RKStr(P, B, PC) + ' <= ' + RKStr(P, C, PC) + ') ~= ' + IntToStr(A) + ' then skip';
      end;
    end;
    OP_TEST: begin
      Line := Line + RegName(P, A, PC) + '  ' + IntToStr(C);
      Ann  := 'if bool(R' + IntToStr(A) + ') ~= ' + IntToStr(C) + ' then skip';
    end;
    OP_TESTSET: begin
      Line := Line + RegName(P, A, PC) + '  ' + RegName(P, B, PC) + '  ' + IntToStr(C);
      Ann  := 'if bool(R' + IntToStr(B) + ') == ' + IntToStr(C) + ' then R' + IntToStr(A) + ' := R' + IntToStr(B);
    end;
    OP_CALL: begin
      Line := Line + RegName(P, A, PC) + '  ' + IntToStr(B) + '  ' + IntToStr(C);
      if B = 0 then Ann := 'args=top-' + IntToStr(A)
      else Ann := 'args=' + IntToStr(B-1);
      if C = 0 then Ann := Ann + ' ret=variable'
      else Ann := Ann + ' ret=' + IntToStr(C-1);
    end;
    OP_TAILCALL: begin
      Line := Line + RegName(P, A, PC) + '  ' + IntToStr(B) + '  ' + IntToStr(C);
      Ann  := 'tail call R' + IntToStr(A);
    end;
    OP_RETURN: begin
      Line := Line + RegName(P, A, PC) + '  ' + IntToStr(B);
      if B = 0 then Ann := 'return R' + IntToStr(A) + '..top'
      else if B = 1 then Ann := 'return (nothing)'
      else Ann := 'return R' + IntToStr(A) + '..R' + IntToStr(A + B - 2);
    end;
    OP_FORLOOP: begin
      Line := Line + RegName(P, A, PC) + '  ' + IntToStr(sBx);
      Ann  := 'R' + IntToStr(A) + ' += R' + IntToStr(A+2) +
              '; if R' + IntToStr(A) + ' <= R' + IntToStr(A+1) +
              ' then pc += ' + IntToStr(sBx) + ' => [' + IntToStr(PC + 1 + sBx + 1) + ']';
    end;
    OP_FORPREP: begin
      Line := Line + RegName(P, A, PC) + '  ' + IntToStr(sBx);
      Ann  := 'R' + IntToStr(A) + ' -= R' + IntToStr(A+2) +
              '; jump to FORLOOP at [' + IntToStr(PC + 1 + sBx + 1) + ']';
    end;
    OP_TFORLOOP: begin
      Line := Line + RegName(P, A, PC) + '  ' + IntToStr(C);
      Ann  := 'call R' + IntToStr(A) + '(R' + IntToStr(A+1) + ',R' + IntToStr(A+2) +
              ') -> R' + IntToStr(A+3) + '+' + IntToStr(C-1);
    end;
    OP_SETLIST: begin
      Line := Line + RegName(P, A, PC) + '  ' + IntToStr(B) + '  ' + IntToStr(C);
      Ann  := 'R' + IntToStr(A) + '[(' + IntToStr(C) + '-1)*FPF+1..' + IntToStr(B) + '] from stack';
    end;
    OP_CLOSE: begin
      Line := Line + RegName(P, A, PC);
      Ann  := 'close upvalues from R' + IntToStr(A) + ' upward';
    end;
    OP_CLOSURE: begin
      Line := Line + RegName(P, A, PC) + '  P' + IntToStr(Bx);
      Ann  := 'closure of sub-proto ' + IntToStr(Bx);
    end;
    OP_VARARG: begin
      Line := Line + RegName(P, A, PC) + '  ' + IntToStr(B);
      if B = 0 then Ann := 'load all vararg into R' + IntToStr(A) + '+'
      else Ann := 'load ' + IntToStr(B-1) + ' vararg into R' + IntToStr(A);
    end;
  else
    Line := Line + IntToStr(A) + '  ' + IntToStr(B) + '  ' + IntToStr(C);
  end;

  { Assemble final line }
  Result := '[' + PadRight(IntToStr(PC + 1), 4) + '] ';
  if LineNo >= 0 then
    Result := Result + PadRight('(line ' + IntToStr(LineNo) + ')', 12)
  else
    Result := Result + PadRight('', 12);
  Result := Result + PadRight(Line, 42);
  if Ann <> '' then
    Result := Result + '; ' + Ann;
end;

{ ======================================================================
  FormatInstructionV  (multi-version path using TOpcodeTable)
  ====================================================================== }

function FormatInstructionV(const P: TProto; PC: Integer; const OT: TOpcodeTable): AnsiString;
var
  Inst   : TInstruction;
  Sem    : TSemanticOp;
  Fmt    : LuaOpcodes.TInstFormat;
  RawOp  : Integer;
  A, B, C, Bx, sBx, sJ, Ax, sC, sB : Integer;
  KFlag  : Boolean;
  Line   : AnsiString;
  Ann    : AnsiString;
  LineNo : Integer;
  OpName : AnsiString;
  BinSym : AnsiString;
  Target : Integer;
begin
  Inst  := P.Code[PC];
  Sem   := DecodeOp(OT, Inst);
  RawOp := DecodeRawOp(OT, Inst);
  A     := DecodeA(OT, Inst);
  Ann   := '';

  { Determine format from opcode table }
  if (RawOp >= 0) and (RawOp < OT.NumOpcodes) then begin
    Fmt    := OT.Entries[RawOp].Format;
    OpName := OT.Entries[RawOp].Name;
  end else begin
    Fmt    := LuaOpcodes.ifABC;
    OpName := 'OP_' + IntToStr(RawOp);
  end;

  { Decode fields based on format }
  B := 0; C := 0; Bx := 0; sBx := 0; sJ := 0; Ax := 0;
  sC := 0; sB := 0; KFlag := False;

  case Fmt of
    LuaOpcodes.ifABC: begin
      B := DecodeB(OT, Inst);
      C := DecodeC(OT, Inst);
      if OT.HasKFlag then
        KFlag := DecodeK(OT, Inst);
    end;
    LuaOpcodes.ifivABC: begin
      B := DecodeVB(OT, Inst);
      C := DecodeVC(OT, Inst);
      if OT.HasKFlag then
        KFlag := DecodeK(OT, Inst);
    end;
    LuaOpcodes.ifABx: begin
      Bx := DecodeBx(OT, Inst);
    end;
    LuaOpcodes.ifAsBx: begin
      sBx := DecodesBx(OT, Inst);
    end;
    LuaOpcodes.ifAx: begin
      Ax := DecodeAx(OT, Inst);
    end;
    LuaOpcodes.ifisJ: begin
      sJ := DecodesJ(OT, Inst);
    end;
  end;

  { Decode signed variants for immediate ops }
  if OT.HasKFlag then begin
    sC := DecodeSC(OT, Inst);
    sB := DecodeSB(OT, Inst);
  end;

  { Line number }
  if (PC < Length(P.LineInfo)) and (P.LineInfo[PC] > 0) then
    LineNo := P.LineInfo[PC]
  else
    LineNo := -1;

  { Build opcode name field }
  Line := PadRight(OpName, 12);

  { ----------------------------------------------------------------
    Semantic dispatch: group opcodes by category
    ---------------------------------------------------------------- }
  case Sem of

    { === Register moves and loads === }
    semMOVE: begin
      Line := Line + RegName(P, A, PC) + '  ' + RegName(P, B, PC);
      Ann  := 'R' + IntToStr(A) + ' := R' + IntToStr(B);
    end;

    semLOADK: begin
      Line := Line + RegName(P, A, PC) + '  K' + IntToStr(Bx);
      if (Bx >= 0) and (Bx < Length(P.K)) then
        Ann := ConstToStr(P.K[Bx]);
    end;

    semLOADKX: begin
      Line := Line + RegName(P, A, PC);
      Ann  := 'R' + IntToStr(A) + ' := K(extra arg)';
    end;

    semLOADBOOL: begin
      Line := Line + RegName(P, A, PC) + '  ' + IntToStr(B) + '  ' + IntToStr(C);
      Ann  := 'R' + IntToStr(A) + ' := ' + IntToStr(B);
      if C <> 0 then Ann := Ann + '; skip next';
    end;

    semLOADNIL: begin
      Line := Line + RegName(P, A, PC) + '  ' + IntToStr(B);
      if OT.Version = $51 then
        Ann := 'R' + IntToStr(A) + '..R' + IntToStr(B) + ' := nil'
      else
        Ann := 'R' + IntToStr(A) + '..R' + IntToStr(A + B) + ' := nil';
    end;

    semLOADI: begin
      Line := Line + RegName(P, A, PC) + '  ' + IntToStr(sBx);
      Ann  := 'R' + IntToStr(A) + ' := ' + IntToStr(sBx);
    end;

    semLOADF: begin
      Line := Line + RegName(P, A, PC) + '  ' + IntToStr(sBx);
      Ann  := 'R' + IntToStr(A) + ' := ' + IntToStr(sBx) + '.0';
    end;

    semLOADFALSE: begin
      Line := Line + RegName(P, A, PC);
      Ann  := 'R' + IntToStr(A) + ' := false';
    end;

    semLOADTRUE: begin
      Line := Line + RegName(P, A, PC);
      Ann  := 'R' + IntToStr(A) + ' := true';
    end;

    semLFALSESKIP: begin
      Line := Line + RegName(P, A, PC);
      Ann  := 'R' + IntToStr(A) + ' := false; skip next';
    end;

    { === Upvalue access === }
    semGETUPVAL: begin
      Line := Line + RegName(P, A, PC) + '  ' + IntToStr(B);
      Ann  := UpvalName(P, B);
    end;

    semSETUPVAL: begin
      Line := Line + RegName(P, A, PC) + '  ' + IntToStr(B);
      Ann  := UpvalName(P, B) + ' := R' + IntToStr(A);
    end;

    { === Global access (5.1 only) === }
    semGETGLOBAL: begin
      Line := Line + RegName(P, A, PC) + '  K' + IntToStr(Bx);
      if (Bx >= 0) and (Bx < Length(P.K)) then
        Ann := P.K[Bx].SValue;
    end;

    semSETGLOBAL: begin
      Line := Line + RegName(P, A, PC) + '  K' + IntToStr(Bx);
      if (Bx >= 0) and (Bx < Length(P.K)) then
        Ann := P.K[Bx].SValue + ' := R' + IntToStr(A);
    end;

    { === Table access === }
    semGETTABLE: begin
      if OT.HasKFlag then begin
        { 5.4+: C is always a register }
        Line := Line + RegName(P, A, PC) + '  ' + RegName(P, B, PC) + '  ' + RegName(P, C, PC);
        Ann  := 'R' + IntToStr(A) + ' := R' + IntToStr(B) + '[R' + IntToStr(C) + ']';
      end else begin
        { 5.1-5.3: C is RK-encoded }
        Line := Line + RegName(P, A, PC) + '  ' + RegName(P, B, PC) + '  ' + RKStrV(P, C, PC, OT);
        Ann  := 'R' + IntToStr(A) + ' := R' + IntToStr(B) + '[' + RKStrV(P, C, PC, OT) + ']';
      end;
    end;

    semSETTABLE: begin
      if OT.HasKFlag then begin
        { 5.4+: B is register, C is reg or const via k-flag }
        if KFlag and (C < Length(P.K)) then begin
          Line := Line + RegName(P, A, PC) + '  ' + RegName(P, B, PC) + '  ' + KStr(P, C);
          Ann  := 'R' + IntToStr(A) + '[R' + IntToStr(B) + '] := ' + KStr(P, C);
        end else begin
          Line := Line + RegName(P, A, PC) + '  ' + RegName(P, B, PC) + '  ' + RegName(P, C, PC);
          Ann  := 'R' + IntToStr(A) + '[R' + IntToStr(B) + '] := R' + IntToStr(C);
        end;
      end else begin
        { 5.1-5.3: B and C are RK-encoded }
        Line := Line + RegName(P, A, PC) + '  ' + RKStrV(P, B, PC, OT) + '  ' + RKStrV(P, C, PC, OT);
        Ann  := 'R' + IntToStr(A) + '[' + RKStrV(P, B, PC, OT) + '] := ' + RKStrV(P, C, PC, OT);
      end;
    end;

    semGETTABUP: begin
      if OT.HasKFlag then begin
        { 5.4+: C is always a constant index }
        Line := Line + RegName(P, A, PC) + '  ' + IntToStr(B) + '  ' + KStr(P, C);
        Ann  := 'R' + IntToStr(A) + ' := ' + UpvalName(P, B) + '[' + KStr(P, C) + ']';
      end else begin
        { 5.2-5.3: C is RK-encoded }
        Line := Line + RegName(P, A, PC) + '  ' + IntToStr(B) + '  ' + RKStrV(P, C, PC, OT);
        Ann  := 'R' + IntToStr(A) + ' := ' + UpvalName(P, B) + '[' + RKStrV(P, C, PC, OT) + ']';
      end;
    end;

    semSETTABUP: begin
      if OT.HasKFlag then begin
        { 5.4+: B is always a constant index; C is reg or const via k-flag }
        if KFlag and (C < Length(P.K)) then begin
          Line := Line + IntToStr(A) + '  ' + KStr(P, B) + '  ' + KStr(P, C);
          Ann  := UpvalName(P, A) + '[' + KStr(P, B) + '] := ' + KStr(P, C);
        end else begin
          Line := Line + IntToStr(A) + '  ' + KStr(P, B) + '  ' + RegName(P, C, PC);
          Ann  := UpvalName(P, A) + '[' + KStr(P, B) + '] := R' + IntToStr(C);
        end;
      end else begin
        { 5.2-5.3: B and C are RK-encoded }
        Line := Line + IntToStr(A) + '  ' + RKStrV(P, B, PC, OT) + '  ' + RKStrV(P, C, PC, OT);
        Ann  := UpvalName(P, A) + '[' + RKStrV(P, B, PC, OT) + '] := ' + RKStrV(P, C, PC, OT);
      end;
    end;

    { 5.4+ typed table access }
    semGETI: begin
      Line := Line + RegName(P, A, PC) + '  ' + RegName(P, B, PC) + '  ' + IntToStr(C);
      Ann  := 'R' + IntToStr(A) + ' := R' + IntToStr(B) + '[' + IntToStr(C) + ']';
    end;

    semGETFIELD: begin
      Line := Line + RegName(P, A, PC) + '  ' + RegName(P, B, PC) + '  ' + KStr(P, C);
      Ann  := 'R' + IntToStr(A) + ' := R' + IntToStr(B) + '[' + KStr(P, C) + ']';
    end;

    semSETI: begin
      if KFlag and (C < Length(P.K)) then begin
        Line := Line + RegName(P, A, PC) + '  ' + IntToStr(B) + '  ' + KStr(P, C);
        Ann  := 'R' + IntToStr(A) + '[' + IntToStr(B) + '] := ' + KStr(P, C);
      end else begin
        Line := Line + RegName(P, A, PC) + '  ' + IntToStr(B) + '  ' + RegName(P, C, PC);
        Ann  := 'R' + IntToStr(A) + '[' + IntToStr(B) + '] := R' + IntToStr(C);
      end;
    end;

    semSETFIELD: begin
      if KFlag and (C < Length(P.K)) then begin
        Line := Line + RegName(P, A, PC) + '  ' + KStr(P, B) + '  ' + KStr(P, C);
        Ann  := 'R' + IntToStr(A) + '[' + KStr(P, B) + '] := ' + KStr(P, C);
      end else begin
        Line := Line + RegName(P, A, PC) + '  ' + KStr(P, B) + '  ' + RegName(P, C, PC);
        Ann  := 'R' + IntToStr(A) + '[' + KStr(P, B) + '] := R' + IntToStr(C);
      end;
    end;

    { === Table construction === }
    semNEWTABLE: begin
      Line := Line + RegName(P, A, PC) + '  ' + IntToStr(B) + '  ' + IntToStr(C);
      if OT.Version >= $54 then
        Ann := 'hash_log2=' + IntToStr(B) + ' array_size=' + IntToStr(C)
      else
        Ann := 'array_size=' + IntToStr(B) + ' hash_size=' + IntToStr(C);
      if KFlag then Ann := Ann + ' (extra arg)';
    end;

    semSELF: begin
      if OT.Version >= $55 then begin
        { Lua 5.5: C is always K[C]:shortstring (like GETFIELD) }
        Line := Line + RegName(P, A, PC) + '  ' + RegName(P, B, PC) + '  ' + KStr(P, C);
        Ann  := 'R' + IntToStr(A+1) + ' := R' + IntToStr(B) +
                '; R' + IntToStr(A) + ' := R' + IntToStr(B) + '[' + KStr(P, C) + ']';
      end else if OT.HasKFlag then begin
        { 5.4: C is reg or constant via k-flag }
        if KFlag and (C < Length(P.K)) then begin
          Line := Line + RegName(P, A, PC) + '  ' + RegName(P, B, PC) + '  ' + KStr(P, C);
          Ann  := 'R' + IntToStr(A+1) + ' := R' + IntToStr(B) +
                  '; R' + IntToStr(A) + ' := R' + IntToStr(B) + '[' + KStr(P, C) + ']';
        end else begin
          Line := Line + RegName(P, A, PC) + '  ' + RegName(P, B, PC) + '  ' + RegName(P, C, PC);
          Ann  := 'R' + IntToStr(A+1) + ' := R' + IntToStr(B) +
                  '; R' + IntToStr(A) + ' := R' + IntToStr(B) + '[R' + IntToStr(C) + ']';
        end;
      end else begin
        { 5.1-5.3: C is RK-encoded }
        Line := Line + RegName(P, A, PC) + '  ' + RegName(P, B, PC) + '  ' + RKStrV(P, C, PC, OT);
        Ann  := 'R' + IntToStr(A+1) + ' := R' + IntToStr(B) +
                '; R' + IntToStr(A) + ' := R' + IntToStr(B) + '[' + RKStrV(P, C, PC, OT) + ']';
      end;
    end;

    { === Binary arithmetic === }
    semADD, semSUB, semMUL, semDIV, semMOD, semPOW,
    semIDIV, semBAND, semBOR, semBXOR, semSHL, semSHR: begin
      case Sem of
        semADD:  BinSym := ' + ';
        semSUB:  BinSym := ' - ';
        semMUL:  BinSym := ' * ';
        semDIV:  BinSym := ' / ';
        semMOD:  BinSym := ' % ';
        semPOW:  BinSym := ' ^ ';
        semIDIV: BinSym := ' // ';
        semBAND: BinSym := ' & ';
        semBOR:  BinSym := ' | ';
        semBXOR: BinSym := ' ~ ';
        semSHL:  BinSym := ' << ';
        semSHR:  BinSym := ' >> ';
      else
        BinSym := ' ? ';
      end;
      if OT.HasKFlag then begin
        { 5.4+: operands are always registers }
        Line := Line + RegName(P, A, PC) + '  ' + RegName(P, B, PC) + '  ' + RegName(P, C, PC);
        Ann := 'R' + IntToStr(A) + ' := R' + IntToStr(B) + BinSym + 'R' + IntToStr(C);
      end else begin
        { 5.1-5.3: operands are RK-encoded }
        Line := Line + RegName(P, A, PC) + '  ' + RKStrV(P, B, PC, OT) + '  ' + RKStrV(P, C, PC, OT);
        Ann := 'R' + IntToStr(A) + ' := ' + RKStrV(P, B, PC, OT) + BinSym + RKStrV(P, C, PC, OT);
      end;
    end;

    { === 5.4+ immediate arithmetic: R(A) := R(B) op K(C) === }
    semADDK, semSUBK, semMULK, semMODK, semPOWK, semDIVK, semIDIVK,
    semBANDK, semBORK, semBXORK: begin
      Line := Line + RegName(P, A, PC) + '  ' + RegName(P, B, PC) + '  ' + KStr(P, C);
      case Sem of
        semADDK:  BinSym := ' + ';
        semSUBK:  BinSym := ' - ';
        semMULK:  BinSym := ' * ';
        semMODK:  BinSym := ' % ';
        semPOWK:  BinSym := ' ^ ';
        semDIVK:  BinSym := ' / ';
        semIDIVK: BinSym := ' // ';
        semBANDK: BinSym := ' & ';
        semBORK:  BinSym := ' | ';
        semBXORK: BinSym := ' ~ ';
      else
        BinSym := ' ? ';
      end;
      Ann := 'R' + IntToStr(A) + ' := R' + IntToStr(B) + BinSym + KStr(P, C);
    end;

    { === 5.4+ immediate arithmetic with signed C: R(A) := R(B) op sC === }
    semADDI: begin
      Line := Line + RegName(P, A, PC) + '  ' + RegName(P, B, PC) + '  ' + IntToStr(sC);
      Ann  := 'R' + IntToStr(A) + ' := R' + IntToStr(B) + ' + ' + IntToStr(sC);
    end;

    semSHRI: begin
      Line := Line + RegName(P, A, PC) + '  ' + RegName(P, B, PC) + '  ' + IntToStr(sC);
      Ann  := 'R' + IntToStr(A) + ' := R' + IntToStr(B) + ' >> ' + IntToStr(sC);
    end;

    semSHLI: begin
      Line := Line + RegName(P, A, PC) + '  ' + RegName(P, B, PC) + '  ' + IntToStr(sC);
      Ann  := 'R' + IntToStr(A) + ' := ' + IntToStr(sC) + ' << R' + IntToStr(B);
    end;

    { === Unary operators === }
    semUNM: begin
      Line := Line + RegName(P, A, PC) + '  ' + RegName(P, B, PC);
      Ann  := 'R' + IntToStr(A) + ' := -R' + IntToStr(B);
    end;

    semNOT: begin
      Line := Line + RegName(P, A, PC) + '  ' + RegName(P, B, PC);
      Ann  := 'R' + IntToStr(A) + ' := not R' + IntToStr(B);
    end;

    semLEN: begin
      Line := Line + RegName(P, A, PC) + '  ' + RegName(P, B, PC);
      Ann  := 'R' + IntToStr(A) + ' := #R' + IntToStr(B);
    end;

    semBNOT: begin
      Line := Line + RegName(P, A, PC) + '  ' + RegName(P, B, PC);
      Ann  := 'R' + IntToStr(A) + ' := ~R' + IntToStr(B);
    end;

    semCONCAT: begin
      if OT.Version >= $54 then begin
        Line := Line + RegName(P, A, PC) + '  ' + IntToStr(B);
        Ann  := 'R' + IntToStr(A) + ' := R' + IntToStr(A) +
                '..R' + IntToStr(A + B - 1);
      end else begin
        Line := Line + RegName(P, A, PC) + '  R' + IntToStr(B) + '  R' + IntToStr(C);
        Ann  := 'R' + IntToStr(A) + ' := R' + IntToStr(B) + '..R' + IntToStr(C);
      end;
    end;

    { === Jump === }
    semJMP: begin
      if Fmt = LuaOpcodes.ifisJ then begin
        { 5.4+: sJ format }
        Target := PC + 1 + sJ + 1;
        Line := Line + IntToStr(sJ);
        Ann  := 'pc += ' + IntToStr(sJ) + ' => [' + IntToStr(Target) + ']';
      end else begin
        { 5.1-5.3: AsBx format }
        Target := PC + 1 + sBx + 1;
        Line := Line + IntToStr(sBx);
        Ann  := 'pc += ' + IntToStr(sBx) + ' => [' + IntToStr(Target) + ']';
        if A > 0 then
          Ann := Ann + '; close upvals >= R' + IntToStr(A - 1);
      end;
    end;

    { === Comparisons (5.1-5.3 RK style) === }
    semEQ, semLT, semLE: begin
      if OT.HasKFlag then begin
        { 5.4+: A B C with k-flag }
        Line := Line + RegName(P, A, PC) + '  ' + RegName(P, B, PC);
        case Sem of
          semEQ: Ann := 'if (R' + IntToStr(A) + ' == R' + IntToStr(B) + ')';
          semLT: Ann := 'if (R' + IntToStr(A) + ' < R' + IntToStr(B) + ')';
          semLE: Ann := 'if (R' + IntToStr(A) + ' <= R' + IntToStr(B) + ')';
        end;
        if KFlag then Ann := Ann + ' == true' else Ann := Ann + ' ~= true';
        Ann := Ann + ' then skip';
      end else begin
        { 5.1-5.3: A RK(B) RK(C) }
        Line := Line + IntToStr(A) + '  ' + RKStrV(P, B, PC, OT) + '  ' + RKStrV(P, C, PC, OT);
        case Sem of
          semEQ: Ann := 'if (' + RKStrV(P, B, PC, OT) + ' == ' + RKStrV(P, C, PC, OT) + ') ~= ' + IntToStr(A) + ' then skip';
          semLT: Ann := 'if (' + RKStrV(P, B, PC, OT) + ' <  ' + RKStrV(P, C, PC, OT) + ') ~= ' + IntToStr(A) + ' then skip';
          semLE: Ann := 'if (' + RKStrV(P, B, PC, OT) + ' <= ' + RKStrV(P, C, PC, OT) + ') ~= ' + IntToStr(A) + ' then skip';
        end;
      end;
    end;

    { === 5.4+ immediate comparisons === }
    semEQK: begin
      Line := Line + RegName(P, A, PC) + '  ' + KStr(P, B);
      Ann  := 'if (R' + IntToStr(A) + ' == ' + KStr(P, B) + ')';
      if KFlag then Ann := Ann + ' then skip' else Ann := Ann + ' ~= true then skip';
    end;

    semEQI: begin
      Line := Line + RegName(P, A, PC) + '  ' + IntToStr(sB);
      Ann  := 'if (R' + IntToStr(A) + ' == ' + IntToStr(sB) + ')';
      if KFlag then Ann := Ann + ' then skip' else Ann := Ann + ' ~= true then skip';
    end;

    semLTI: begin
      Line := Line + RegName(P, A, PC) + '  ' + IntToStr(sB);
      Ann  := 'if (R' + IntToStr(A) + ' < ' + IntToStr(sB) + ')';
      if KFlag then Ann := Ann + ' then skip' else Ann := Ann + ' ~= true then skip';
    end;

    semLEI: begin
      Line := Line + RegName(P, A, PC) + '  ' + IntToStr(sB);
      Ann  := 'if (R' + IntToStr(A) + ' <= ' + IntToStr(sB) + ')';
      if KFlag then Ann := Ann + ' then skip' else Ann := Ann + ' ~= true then skip';
    end;

    semGTI: begin
      Line := Line + RegName(P, A, PC) + '  ' + IntToStr(sB);
      Ann  := 'if (R' + IntToStr(A) + ' > ' + IntToStr(sB) + ')';
      if KFlag then Ann := Ann + ' then skip' else Ann := Ann + ' ~= true then skip';
    end;

    semGEI: begin
      Line := Line + RegName(P, A, PC) + '  ' + IntToStr(sB);
      Ann  := 'if (R' + IntToStr(A) + ' >= ' + IntToStr(sB) + ')';
      if KFlag then Ann := Ann + ' then skip' else Ann := Ann + ' ~= true then skip';
    end;

    { === Test / TestSet === }
    semTEST: begin
      if OT.HasKFlag then begin
        { 5.4+: TEST A k }
        Line := Line + RegName(P, A, PC);
        if KFlag then
          Ann := 'if R' + IntToStr(A) + ' then skip'
        else
          Ann := 'if not R' + IntToStr(A) + ' then skip';
      end else begin
        { 5.1-5.3: TEST A C }
        Line := Line + RegName(P, A, PC) + '  ' + IntToStr(C);
        Ann  := 'if bool(R' + IntToStr(A) + ') ~= ' + IntToStr(C) + ' then skip';
      end;
    end;

    semTESTSET: begin
      Line := Line + RegName(P, A, PC) + '  ' + RegName(P, B, PC) + '  ' + IntToStr(C);
      if OT.HasKFlag then begin
        if KFlag then
          Ann := 'if R' + IntToStr(B) + ' then R' + IntToStr(A) + ' := R' + IntToStr(B) + ' else skip'
        else
          Ann := 'if not R' + IntToStr(B) + ' then R' + IntToStr(A) + ' := R' + IntToStr(B) + ' else skip';
      end else
        Ann := 'if bool(R' + IntToStr(B) + ') == ' + IntToStr(C) +
               ' then R' + IntToStr(A) + ' := R' + IntToStr(B);
    end;

    { === Call / Return === }
    semCALL: begin
      Line := Line + RegName(P, A, PC) + '  ' + IntToStr(B) + '  ' + IntToStr(C);
      if B = 0 then Ann := 'args=top-' + IntToStr(A)
      else Ann := 'args=' + IntToStr(B-1);
      if C = 0 then Ann := Ann + ' ret=variable'
      else Ann := Ann + ' ret=' + IntToStr(C-1);
    end;

    semTAILCALL: begin
      Line := Line + RegName(P, A, PC) + '  ' + IntToStr(B) + '  ' + IntToStr(C);
      Ann  := 'tail call R' + IntToStr(A);
    end;

    semRETURN: begin
      Line := Line + RegName(P, A, PC) + '  ' + IntToStr(B);
      if B = 0 then Ann := 'return R' + IntToStr(A) + '..top'
      else if B = 1 then Ann := 'return (nothing)'
      else Ann := 'return R' + IntToStr(A) + '..R' + IntToStr(A + B - 2);
      if OT.HasKFlag and KFlag then
        Ann := Ann + '; close upvals';
    end;

    semRETURN0: begin
      Line := Line;
      Ann  := 'return';
    end;

    semRETURN1: begin
      Line := Line + RegName(P, A, PC);
      Ann  := 'return R' + IntToStr(A);
    end;

    { === Loops === }
    semFORLOOP: begin
      if Fmt = LuaOpcodes.ifABx then begin
        { 5.4+: ABx format with unsigned Bx as jump-back offset }
        Target := PC + 1 - Bx + 1;
        Line := Line + RegName(P, A, PC) + '  ' + IntToStr(Bx);
        Ann  := 'R' + IntToStr(A) + ' += R' + IntToStr(A+2) +
                '; if R' + IntToStr(A) + ' <= R' + IntToStr(A+1) +
                ' then pc -= ' + IntToStr(Bx) + ' => [' + IntToStr(Target) + ']';
      end else begin
        { 5.1-5.3: AsBx }
        Target := PC + 1 + sBx + 1;
        Line := Line + RegName(P, A, PC) + '  ' + IntToStr(sBx);
        Ann  := 'R' + IntToStr(A) + ' += R' + IntToStr(A+2) +
                '; if R' + IntToStr(A) + ' <= R' + IntToStr(A+1) +
                ' then pc += ' + IntToStr(sBx) + ' => [' + IntToStr(Target) + ']';
      end;
    end;

    semFORPREP: begin
      if Fmt = LuaOpcodes.ifABx then begin
        { 5.4+: ABx format, jump forward by Bx }
        Target := PC + 1 + Bx + 1;
        Line := Line + RegName(P, A, PC) + '  ' + IntToStr(Bx);
        Ann  := 'prepare for loop; jump to [' + IntToStr(Target) + ']';
      end else begin
        { 5.1-5.3: AsBx }
        Target := PC + 1 + sBx + 1;
        Line := Line + RegName(P, A, PC) + '  ' + IntToStr(sBx);
        Ann  := 'R' + IntToStr(A) + ' -= R' + IntToStr(A+2) +
                '; jump to FORLOOP at [' + IntToStr(Target) + ']';
      end;
    end;

    semTFORLOOP: begin
      { 5.1: TFORLOOP A C - call iterator }
      Line := Line + RegName(P, A, PC) + '  ' + IntToStr(C);
      Ann  := 'call R' + IntToStr(A) + '(R' + IntToStr(A+1) + ',R' + IntToStr(A+2) +
              ') -> R' + IntToStr(A+3) + '+' + IntToStr(C-1);
    end;

    semTFORCALL: begin
      { 5.2+: TFORCALL A C - call iterator function.
        Lua 5.4: results to R(A+4)..R(A+3+C) (4 internal vars)
        Lua 5.2-5.3, 5.5: results to R(A+3)..R(A+2+C) (3 internal vars) }
      Line := Line + RegName(P, A, PC) + '  ' + IntToStr(C);
      if OT.Version = $54 then
        Ann  := 'R' + IntToStr(A+4) + '..R' + IntToStr(A+3+C) + ' := R' + IntToStr(A) +
                '(R' + IntToStr(A+1) + ',R' + IntToStr(A+2) + ')'
      else
        Ann  := 'R' + IntToStr(A+3) + '..R' + IntToStr(A+2+C) + ' := R' + IntToStr(A) +
                '(R' + IntToStr(A+1) + ',R' + IntToStr(A+2) + ')';
    end;

    semTFORLOOP54: begin
      { 5.2+: TFORLOOP A sBx/Bx - loop back if control var is not nil }
      if Fmt = LuaOpcodes.ifABx then begin
        Target := PC + 1 - Bx + 1;
        Line := Line + RegName(P, A, PC) + '  ' + IntToStr(Bx);
      end else begin
        Target := PC + 1 + sBx + 1;
        Line := Line + RegName(P, A, PC) + '  ' + IntToStr(sBx);
      end;
      if OT.Version = $54 then
        Ann := 'if R' + IntToStr(A+4) + ' ~= nil then R' + IntToStr(A+2) +
               ' := R' + IntToStr(A+4) + '; pc => [' + IntToStr(Target) + ']'
      else if OT.Version >= $55 then
        Ann := 'if R' + IntToStr(A+3) + ' ~= nil then pc => [' +
               IntToStr(Target) + ']'
      else
        Ann := 'if R' + IntToStr(A+1) + ' ~= nil then R' + IntToStr(A) +
               ' := R' + IntToStr(A+1) + '; pc => [' + IntToStr(Target) + ']';
    end;

    semTFORPREP: begin
      { 5.4+: TFORPREP A Bx - prepare generic for loop }
      Target := PC + 1 + Bx + 1;
      Line := Line + RegName(P, A, PC) + '  ' + IntToStr(Bx);
      Ann  := 'prepare generic for; jump to [' + IntToStr(Target) + ']';
    end;

    { === Set list === }
    semSETLIST: begin
      Line := Line + RegName(P, A, PC) + '  ' + IntToStr(B) + '  ' + IntToStr(C);
      Ann  := 'R' + IntToStr(A) + '[(' + IntToStr(C) + '-1)*FPF+1..' + IntToStr(B) + '] from stack';
      if KFlag then Ann := Ann + ' (extra arg)';
    end;

    { === Closures and upvalues === }
    semCLOSE: begin
      Line := Line + RegName(P, A, PC);
      Ann  := 'close upvalues from R' + IntToStr(A) + ' upward';
    end;

    semTBC: begin
      Line := Line + RegName(P, A, PC);
      Ann  := 'mark R' + IntToStr(A) + ' as to-be-closed';
    end;

    semCLOSURE: begin
      Line := Line + RegName(P, A, PC) + '  P' + IntToStr(Bx);
      Ann  := 'closure of sub-proto ' + IntToStr(Bx);
    end;

    { === Vararg === }
    semVARARG: begin
      { In 5.4+, VARARG A C uses C for the count; in 5.1-5.3, B }
      if OT.Version >= $55 then begin
        Line := Line + RegName(P, A, PC) + '  ' + IntToStr(B) + '  ' + IntToStr(C);
        if C = 0 then Ann := 'load all vararg into R' + IntToStr(A) + '+'
        else Ann := 'load ' + IntToStr(C-1) + ' vararg into R' + IntToStr(A);
        if KFlag then Ann := Ann + '; vararg table=R' + IntToStr(B);
      end else if OT.Version >= $54 then begin
        Line := Line + RegName(P, A, PC) + '  ' + IntToStr(C);
        if C = 0 then Ann := 'load all vararg into R' + IntToStr(A) + '+'
        else Ann := 'load ' + IntToStr(C-1) + ' vararg into R' + IntToStr(A);
      end else begin
        Line := Line + RegName(P, A, PC) + '  ' + IntToStr(B);
        if B = 0 then Ann := 'load all vararg into R' + IntToStr(A) + '+'
        else Ann := 'load ' + IntToStr(B-1) + ' vararg into R' + IntToStr(A);
      end;
    end;

    semVARARGPREP: begin
      Line := Line + IntToStr(A);
      Ann  := 'prepare vararg (numfixed=' + IntToStr(A) + ')';
    end;

    semGETVARG: begin
      Line := Line + RegName(P, A, PC) + '  ' + RegName(P, B, PC) + '  ' + RegName(P, C, PC);
      Ann  := 'R' + IntToStr(A) + ' := R' + IntToStr(B) + '[R' + IntToStr(C) + ']';
    end;

    { === Extra arg === }
    semEXTRAARG: begin
      Line := Line + IntToStr(Ax);
      Ann  := 'extra arg = ' + IntToStr(Ax);
    end;

    { === Metamethod hints (5.4+) === }
    semMMBIN: begin
      Line := Line + RegName(P, A, PC) + '  ' + RegName(P, B, PC) + '  ' + IntToStr(C);
      Ann  := 'metamethod hint op=' + IntToStr(C) + ' on R' + IntToStr(A) + ', R' + IntToStr(B);
    end;

    semMMBINI: begin
      Line := Line + RegName(P, A, PC) + '  ' + IntToStr(sB) + '  ' + IntToStr(C);
      Ann  := 'metamethod hint op=' + IntToStr(C) + ' on R' + IntToStr(A) + ', ' + IntToStr(sB);
      if KFlag then Ann := Ann + ' (k)';
    end;

    semMMBINK: begin
      Line := Line + RegName(P, A, PC) + '  ' + KStr(P, B) + '  ' + IntToStr(C);
      Ann  := 'metamethod hint op=' + IntToStr(C) + ' on R' + IntToStr(A) + ', ' + KStr(P, B);
      if KFlag then Ann := Ann + ' (k)';
    end;

    { === 5.5 specific === }
    semERRNNIL: begin
      Line := Line + RegName(P, A, PC) + '  ' + IntToStr(Bx);
      Ann  := 'error if R' + IntToStr(A) + ' is not nil';
      if (Bx > 0) and (Bx - 1 < Length(P.K)) then
        Ann := Ann + ' (' + KStr(P, Bx - 1) + ')';
    end;

    { === Unknown / unmapped === }
  else
    { Generic fallback: show raw fields based on format }
    case Fmt of
      LuaOpcodes.ifABC, LuaOpcodes.ifivABC:
        Line := Line + IntToStr(A) + '  ' + IntToStr(B) + '  ' + IntToStr(C);
      LuaOpcodes.ifABx:
        Line := Line + IntToStr(A) + '  ' + IntToStr(Bx);
      LuaOpcodes.ifAsBx:
        Line := Line + IntToStr(A) + '  ' + IntToStr(sBx);
      LuaOpcodes.ifAx:
        Line := Line + IntToStr(Ax);
      LuaOpcodes.ifisJ:
        Line := Line + IntToStr(sJ);
    end;
    if KFlag then Ann := 'k=1';
  end;

  { Assemble final line }
  Result := '[' + PadRight(IntToStr(PC + 1), 4) + '] ';
  if LineNo >= 0 then
    Result := Result + PadRight('(line ' + IntToStr(LineNo) + ')', 12)
  else
    Result := Result + PadRight('', 12);
  Result := Result + PadRight(Line, 42);
  if Ann <> '' then
    Result := Result + '; ' + Ann;
end;

{ ======================================================================
  DisassembleProto  (legacy 5.1 path)
  ====================================================================== }

procedure DisassembleProto(const P: TProto; Indent: Integer);
var
  Pad   : AnsiString;
  I     : Integer;
  Src   : AnsiString;
begin
  Pad := StringOfChar(' ', Indent * 2);

  { Header }
  if P.Source <> '' then Src := P.Source else Src := '(?)';
  WriteLn(Pad, '== function ', Src, ':',
          IntToStr(P.LineDefined), '..',
          IntToStr(P.LastLineDefined), ' ==');
  WriteLn(Pad, '   params=', P.NumParams,
          ' is_vararg=', P.IsVarArg,
          ' maxstack=', P.MaxStack,
          ' upvals=', P.NUps,
          ' locals=', Length(P.LocVars),
          ' constants=', Length(P.K),
          ' sub-protos=', Length(P.P));

  { Constants }
  if Length(P.K) > 0 then begin
    WriteLn(Pad, '   -- constants --');
    for I := 0 to High(P.K) do
      WriteLn(Pad, '   K', I, ' = ', ConstToStr(P.K[I]));
  end;

  { Local vars }
  if Length(P.LocVars) > 0 then begin
    WriteLn(Pad, '   -- locals --');
    for I := 0 to High(P.LocVars) do
      WriteLn(Pad, '   L', I, ' "', P.LocVars[I].Name,
              '" [pc ', P.LocVars[I].StartPC, '..', P.LocVars[I].EndPC - 1, ']');
  end;

  { Upvalue names }
  if Length(P.UpvalueNames) > 0 then begin
    WriteLn(Pad, '   -- upvalues --');
    for I := 0 to High(P.UpvalueNames) do
      WriteLn(Pad, '   U', I, ' "', P.UpvalueNames[I], '"');
  end;

  { Instructions }
  WriteLn(Pad, '   -- code --');
  for I := 0 to High(P.Code) do
    WriteLn(Pad, '   ', FormatInstruction(P, I));

  WriteLn;
end;

{ ======================================================================
  DisassembleProtoV  (multi-version path)
  ====================================================================== }

procedure DisassembleProtoV(const P: TProto; const OT: TOpcodeTable; Indent: Integer);
var
  Pad   : AnsiString;
  I     : Integer;
  Src   : AnsiString;
begin
  Pad := StringOfChar(' ', Indent * 2);

  { Header }
  if P.Source <> '' then Src := P.Source else Src := '(?)';
  WriteLn(Pad, '== function ', Src, ':',
          IntToStr(P.LineDefined), '..',
          IntToStr(P.LastLineDefined), ' ==');
  WriteLn(Pad, '   params=', P.NumParams,
          ' is_vararg=', P.IsVarArg,
          ' maxstack=', P.MaxStack,
          ' upvals=', P.NUps,
          ' locals=', Length(P.LocVars),
          ' constants=', Length(P.K),
          ' sub-protos=', Length(P.P));

  { Constants }
  if Length(P.K) > 0 then begin
    WriteLn(Pad, '   -- constants --');
    for I := 0 to High(P.K) do
      WriteLn(Pad, '   K', I, ' = ', ConstToStr(P.K[I]));
  end;

  { Local vars }
  if Length(P.LocVars) > 0 then begin
    WriteLn(Pad, '   -- locals --');
    for I := 0 to High(P.LocVars) do
      WriteLn(Pad, '   L', I, ' "', P.LocVars[I].Name,
              '" [pc ', P.LocVars[I].StartPC, '..', P.LocVars[I].EndPC - 1, ']');
  end;

  { Upvalue names / descriptors }
  if Length(P.UpvalueNames) > 0 then begin
    WriteLn(Pad, '   -- upvalues --');
    for I := 0 to High(P.UpvalueNames) do
      WriteLn(Pad, '   U', I, ' "', P.UpvalueNames[I], '"');
  end else if Length(P.UpvalDescs) > 0 then begin
    WriteLn(Pad, '   -- upvalues --');
    for I := 0 to High(P.UpvalDescs) do begin
      if P.UpvalDescs[I].Name <> '' then
        WriteLn(Pad, '   U', I, ' "', P.UpvalDescs[I].Name,
                '" instack=', Ord(P.UpvalDescs[I].InStack), ' idx=', P.UpvalDescs[I].Idx)
      else
        WriteLn(Pad, '   U', I, ' instack=', Ord(P.UpvalDescs[I].InStack),
                ' idx=', P.UpvalDescs[I].Idx);
    end;
  end;

  { Instructions }
  WriteLn(Pad, '   -- code --');
  for I := 0 to High(P.Code) do
    WriteLn(Pad, '   ', FormatInstructionV(P, I, OT));

  WriteLn;
end;

{ ======================================================================
  DisassembleChunk  (recursive, version-aware)
  ====================================================================== }

procedure DisassembleProtoRecV(const P: PProto; const OT: TOpcodeTable; Indent: Integer);
var
  I: Integer;
begin
  if P = nil then Exit;
  DisassembleProtoV(P^, OT, Indent);
  for I := 0 to High(P^.P) do
    DisassembleProtoRecV(P^.P[I], OT, Indent + 1);
end;

function VersionStr(Version: Byte): AnsiString;
begin
  case Version of
    $51: Result := '5.1';
    $52: Result := '5.2';
    $53: Result := '5.3';
    $54: Result := '5.4';
    $55: Result := '5.5';
  else
    Result := Format('0x%02X', [Version]);
  end;
end;

procedure DisassembleChunk(const Chunk: TLuaChunk);
begin
  WriteLn('-- Lua ', VersionStr(Chunk.Header.Version), ' Disassembly --');
  WriteLn;

  if (Chunk.OpTable.NumOpcodes > 0) then
    DisassembleProtoRecV(Chunk.Root, Chunk.OpTable, 0)
  else begin
    { Fallback: no opcode table available, use legacy 5.1 path }
    if Chunk.Root <> nil then
      DisassembleProto(Chunk.Root^, 0);
  end;
end;

end.
