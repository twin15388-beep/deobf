unit LuaDecomp;

{
  LuaDecomp.pas - Structured control flow recovery and Lua source emitter.

  Takes a TSSAFunction (from LuaSSA) and reconstructs high-level Lua 5.x
  pseudo-source code.

  Algorithm overview
  ------------------
  1. ConstantFold   – evaluate compile-time constant SSA_BINOP / SSA_UNOP nodes.
  2. CopyPropagate  – replace trivial SSA_MOVE / single-operand SSA_PHI uses.
  3. DeadEliminate  – mark nodes whose dest has no uses; skip them at emit.
  4. ExprBuild      – recursively convert each SSA value to an expression string.
  5. CFGStructure   – identify loops (back-edges), if/then/else, for-loops etc.
  6. EmitRegion     – walk the structured CFG and emit Lua code.

  The emitter works on the raw SSA CFG (blocks + nodes) with a recursive
  region-detection approach:
    • A "loop region" is identified by a block whose dominator chain contains
      the block itself (back-edge target = loop header).
    • An "if region" is identified by a branch node whose two successors share
      a common post-dominator (the merge block).
    • Remaining blocks are emitted linearly.

  Variable naming
  ---------------
  Debug info (LocVars) is used when available.  Temporaries fall back to
  "t<n>" names.  Globals and upvalues use their string keys directly.
}

{$mode objfpc}{$H+}

interface

uses
  SysUtils, Math, LuaChunk, LuaSSA, LuaOpcodes, LuaUtils, LuaExprUtils, LuaDis;

type
  { Options controlling the emitter }
  TDecompOptions = record
    Annotate    : Boolean;  { emit disassembly comments above each statement }
    Debug       : Boolean;  { emit debug trace to stderr }
    Indent      : AnsiString; { indentation string, default '  ' }
    FileName    : AnsiString;
    OT          : POpcodeTable;  { nil = Lua 5.1 legacy path }
  end;

{ Decompile a single proto (non-recursive) to a string }
function DecompileProto(Proto: PProto; const Opts: TDecompOptions): AnsiString;

{ Decompile full chunk (recurses into sub-protos) and print to stdout }
procedure DecompileChunk(const Chunk: TLuaChunk; const Opts: TDecompOptions);

implementation

{ ======================================================================
  Internal types
  ====================================================================== }

type
  TAnsiStringArray = array of AnsiString;

  { Use-def tracking for dead-code elimination and copy propagation }
  TUseCount = array of Integer;  { indexed by (Reg * MaxVer + Ver) }

  TExprMap = array of AnsiString;  { cached expression strings per SSA value index }

  { Multi-assign detector result }
  TMultiAssignResult = (maNotMatched, maEmitted);

  { Structured region classification }
  TRegionKind = (rgLinear, rgIfThen, rgIfThenElse, rgWhile, rgRepeat,
                 rgNumericFor, rgGenericFor, rgReturn);

  TRegion = record
    Kind     : TRegionKind;
    Header   : Integer;   { block index }
    TrueBlk  : Integer;
    FalseBlk : Integer;
    MergeBlk : Integer;
    LoopBack : Integer;
    BodyBlk  : Integer;
    ExitBlk  : Integer;
  end;

{ ======================================================================
  TStringList (lightweight)
  ====================================================================== }

type
  TStringList = class
  private
    FLines: array of AnsiString;
    FCount: Integer;
  public
    procedure Add(const S: AnsiString);
    function  Text: AnsiString;
    function  Count: Integer;
    function  GetLine(Idx: Integer): AnsiString;
    procedure SetLine(Idx: Integer; const S: AnsiString);
    procedure Insert(Idx: Integer; const S: AnsiString);
    procedure DeleteLast;
  end;

{ ======================================================================
  TRunMode - controls output format of Run()
  ====================================================================== }

type
  TRunMode = (
    rmChunk,     { top-level entry: emit body directly, no function wrapper }
    rmFunction,  { full function(...)...end wrapper (standalone proto dump) }
    rmBodyOnly   { body only, no wrapper. For embedding into parent closures }
  );

{ ======================================================================
  TDecompiler  (private class per proto)
  ====================================================================== }

type
  TDecompiler = class
  private
    FProto   : PProto;
    FSF      : PSSAFunction;
    FOpts    : TDecompOptions;
    FOutput  : TStringList;
    FIndent  : Integer;

    { max version seen per register (for indexing) }
    FMaxVer  : Integer;

    { use counts: (reg * FMaxVer + ver) -> count }
    FUseCnt  : array of Integer;
    { expression strings for each SSA value (same indexing) }
    FExprStr : array of AnsiString;
    { set of nodes already inlined into expressions (don't emit again) }
    FInlined : array of Boolean;
    { visited set for cycle detection in ExprOf }
    FVisited : array of Boolean;
    { recursion depth counter for ExprOf }
    FExprDepth : Integer;

    { block visit tracking for CFG walk }
    FEmitted : array of Boolean;
    { set to True whenever EmitStmt/EmitStruct emits 'break' or 'return', cleared on other emits }
    FLastBreak : Boolean;
    { count of real emitted constructs (for SSA emission invariant) }
    FStmtCount : Integer;
    { track which sub-protos were inlined (skip in DecompileProtoRec) }
    FInlinedProtos : array of Boolean;
    { track which LocVars have been declared (for 'local' keyword emission) }
    FDeclared : array of Boolean;
    { track which temp registers (t<N>) have been declared local in stripped mode }
    FTempDeclared : array of Boolean;
    { stack of loop exit block indices for break detection }
    FLoopExitStack : array of Integer;
    FLoopExitTop   : Integer;
    { upvalue names resolved from parent context (for stripped bytecode) }
    FUpvalNames    : array of AnsiString;
    { parameter name overrides (for collision avoidance with upvalue names) }
    FParamOverrides : array of AnsiString;

    { Global do..end scope tracking (computed once, used during emission) }
    FPendingScopes : array of record
      StartPC: Integer;     { PC at which to emit "do" (LocVar.StartPC - 1) }
      EndPC: Integer;       { PC at which to emit "end" (LocVar.EndPC) }
    end;
    FPendingScopeCount : Integer;
    FActiveScopeStack  : array of Integer;  { indices into FPendingScopes }
    FActiveScopeTop    : Integer;
    FNextPendingScope  : Integer;

    { SSA definition lookup map: [Reg][Version] --> defining node }
    FDefNodeMap : array of array of PSSANode;

    { Annotation support: PC of the current node being emitted (-1 = none) }
    FAnnotatePC : Integer;
    { Set of PCs already annotated (avoid duplicate annotations) }
    FAnnotatedPCs : array of Boolean;

    procedure PushLoopExit(ExitBlk: Integer);
    procedure PopLoopExit;
    function  CurrentLoopExit: Integer;
    function  IsBreakTarget(Blk: Integer): Boolean;

    procedure Indent;
    procedure Dedent;
    procedure Emit(const S: AnsiString);
    procedure EmitAny(const S: AnsiString; CountAsStmt: Boolean);
    procedure EmitStmt(const S: AnsiString);
    procedure EmitStruct(const S: AnsiString);
    procedure EmitEmbed(const S: AnsiString);
    procedure EmitLine(const S: AnsiString);  { backward-compat alias for EmitStmt }
    procedure EmitAnnotation(PC: Integer);

    function  NodeIdx(Reg, Ver: Integer): Integer;
    function  CountPhiUses(Reg, Ver: Integer): Integer;
    function  ConstStr(Idx: Integer): AnsiString;
    function  LocVarInScope(VarIdx, PC: Integer): Boolean;
    function  LocalName(Reg, PC: Integer): AnsiString;
    function  UpvalName(Idx: Integer): AnsiString;
    function  RegRef(const R: TSSARef; PC: Integer): AnsiString;

    { Expression building }
    function  ExprOf(const R: TSSARef; PC: Integer): AnsiString;
    function  NodeExpr(Node: PSSANode): AnsiString;
    function  BinOpStr(Op: TBinOp): AnsiString;
    function  BinOpPrec(Op: TBinOp): Integer;
    function  UnOpStr(Op: TUnOp): AnsiString;
    function  RelOpStr(Op: TRelOp; Invert: Boolean): AnsiString;
    function  FlippedRelOpStr(Op: TRelOp; Invert: Boolean): AnsiString;
    function  BuildCompare(const OpA, OpB: TSSARef;
                           Op: TRelOp; Invert: Boolean;
                           PC: Integer): AnsiString;

    { Constant folding }
    procedure FoldConstants;

    { Count uses of each SSA value across all nodes }
    procedure CountUses;

    { SSA-level LocVar binding }
    procedure BindLocVarsToSSA;

    { Global do..end scope computation }
    function  FindLocVarDefPC(VarIdx: Integer): Integer;
    procedure ComputeDoEndScopes;

    { Node-based naming (LocVarIdx-based, no PC heuristics) }
    function  NodeIsLocal(Node: PSSANode): Boolean;
    function  NodeNeedsDecl(Node: PSSANode): Boolean;
    function  NodeLocalName(Node: PSSANode): AnsiString;
    procedure NodeMarkDeclared(Node: PSSANode);
    function  NodeIsEmittableLocal(Node: PSSANode): Boolean;

    { SSA DefNodeMap: (Reg, Version) --> defining node }
    procedure BuildDefNodeMap;
    function  DefNodeFor(const Op: TSSARef): PSSANode;

    { SSA definition lookup }
    function  FindDefNode(BIdx, Reg: Integer): PSSANode;
    function  FindDefNodeAll(Reg: Integer): PSSANode;
    function  RegExpr(Reg, PC: Integer): AnsiString;
    function  CallFuncExpr(Reg, BeforePC: Integer): AnsiString;
    function  IsUserLocal(Reg, PC: Integer): Boolean;
    function  IsUserLocalStrict(Reg, PC: Integer): Boolean;
    function  ShouldEmitAsLocal(Reg, PC: Integer): Boolean;
    function  LocalNameForEmit(Reg, PC: Integer): AnsiString;
    function  NeedsLocalDecl(Reg, PC: Integer): Boolean;
    function  IsBareLocalDecl(Reg, PC: Integer): Boolean;
    function  IsOnlyPhiUsed(Reg, Version: Integer): Boolean;
    function  IsOnlyTrivialPhiUsed(Reg, Version: Integer): Boolean;
    function  IsUpvalCaptured(Reg, DefPC: Integer): Boolean;
    function  ShouldEmitTemp(Reg, Version, PC: Integer): Boolean;
    function  NeedsTempLocal(Reg: Integer): Boolean;
    function  TempName(Reg: Integer): AnsiString;

    { Structured emission }
    function  FindMerge(BranchBlk, TrueBlk, FalseBlk: Integer): Integer;
    function  IsLoopHeader(BIdx: Integer): Boolean;
    function  FindLoopExit(HeaderIdx: Integer): Integer;
    function  IsRepeatUntilLoop(HeaderIdx: Integer): Boolean;
    function  FindRepeatUntilExit(HeaderIdx: Integer): Integer;
    function  EmitForNumericLoop(BIdx: Integer): Integer;
    function  EmitForGenericLoop(BIdx: Integer): Integer;
    procedure EmitBlock(BIdx: Integer);
    procedure EmitRegion(BIdx: Integer; StopAt: Integer = -1);
    procedure EmitIfRegion(BranchBlk, TrueBlk, FalseBlk, MergeBlk: Integer);
    procedure EmitIfRegionCompound(BranchBlk, TrueBlk, FalseBlk, MergeBlk: Integer;
                                    const CompoundCond: AnsiString);
    procedure EmitWhileRegion(HeaderBlk: Integer);
    procedure EmitRepeatRegion(HeaderBlk: Integer);
    procedure EmitNode(Node: PSSANode; BIdx: Integer);
    procedure EmitReturnOnly(BlkIdx: Integer);
    function  TryEmitBreakIf(BranchBlk, TrueBlk, FalseBlk: Integer;
                             out NextBlk: Integer): Boolean;
    function  TryEmitOrAnd(BranchBlk, TrueBlk, FalseBlk: Integer): Boolean;
    function  TryCacheBranchValueSelect(BranchBlk, TrueBlk, FalseBlk: Integer): Boolean;
    function  TryBuildCompoundCond(BranchBlk: Integer;
                                   out CondExpr: AnsiString;
                                   out TrueTarget, FalseTarget: Integer): Boolean;
    function  TryBuildComparisonExpr(PhiNode: PSSANode): AnsiString;
    function  TryBuildOrAndExpr(PhiNode: PSSANode): AnsiString;
    function  TryBuildNegatedCompoundExpr(PhiNode: PSSANode): AnsiString;
    function  TryBuildChainedPhiExpr(PhiNode: PSSANode): AnsiString;
    function  TryEmitMultiLocal(BIdx, StartIdx: Integer; out ConsumedCount: Integer): Boolean;
    function  TryEmitMultiAssign(BIdx, StartIdx: Integer; out ConsumedCount: Integer): TMultiAssignResult;
    function  TryEmitMultiReturnAssign(BIdx, StartIdx: Integer; out ConsumedCount: Integer): TMultiAssignResult;
    function  TryEmitReverseMultiAssign(BIdx, StartIdx: Integer; out ConsumedCount: Integer): TMultiAssignResult;
    function  TryEmitSwap(BIdx, StartIdx: Integer; out ConsumedCount: Integer): TMultiAssignResult;
    function  TryEmitTableSwap(BIdx, StartIdx: Integer; out ConsumedCount: Integer): Boolean;
    function  TryEmitTableConstructor(BIdx, StartIdx: Integer; out ConsumedCount: Integer): Boolean;
    procedure EmitTempLoweredMultiAssign(
                const LHSNames: array of AnsiString;
                const RHSExprs: array of AnsiString;
                const LHSNeedsLocalDecl: array of Boolean;
                const LHSIsTableAccess: array of Boolean);
    function  MultiAssignNeedsTemps(Blk: PBasicBlock;
                ComputeStart, ComputeEnd: Integer;
                WriteBackStart, WriteBackEnd: Integer): Boolean;
    function  TryBuildInnerTableCtor(BIdx, StartIdx: Integer;
                                      out ConsumedCount: Integer;
                                      out CtorStr: AnsiString): Boolean;
    function  IsSelfRefClosure(Node: PSSANode): Boolean;
    function  ResolveUpvalNames(ClosurePC, SubProtoIdx: Integer): TAnsiStringArray;
    function  BuildSubProtoParams(SubProto: PProto;
                                   const UpvalNames: TAnsiStringArray;
                                   SkipSelf: Boolean = False): AnsiString;
    function  DecompileSubProto(SubProtoIdx: Integer; ClosurePC: Integer = -1): AnsiString;
    procedure EmitClosureReturn(ClosureNode: PSSANode);
    function  TryEmitInlineFunction(SetNode: PSSANode; const FuncName: AnsiString): Boolean;
    function  TryEmitLocalFunction(ClosureNode: PSSANode; const FuncName: AnsiString; IsLocal: Boolean): Boolean;
    function  TryEmitSettableFunction(Node: PSSANode): Boolean;
    function  FuncHeader: AnsiString;

    { Post-emission single-line collapse helpers }
    function  TryCollapseSingleLineBlock(OpenIdx: Integer; StartPC, EndPC: Integer): Boolean;
    function  TryCollapseIfElseBlock(OpenIdx: Integer; StartPC, EndPC: Integer): Boolean;

    { Constant propagation / inline helpers }
    function  IsInlineable(const R: TSSARef): Boolean;

  public
    constructor Create(Proto: PProto; const Opts: TDecompOptions);
    constructor Create(Proto: PProto; const Opts: TDecompOptions;
                       const UpvalNames: TAnsiStringArray);
    destructor Destroy; override;
    function  Run(Mode: TRunMode = rmChunk): AnsiString;
  end;

procedure TStringList.Add(const S: AnsiString);
begin
  if FCount >= Length(FLines) then
    SetLength(FLines, FCount * 2 + 8);
  FLines[FCount] := S;
  Inc(FCount);
end;

function TStringList.Text: AnsiString;
var
  I: Integer;
begin
  Result := '';
  for I := 0 to FCount - 1 do
    Result := Result + FLines[I] + LineEnding;
end;

function TStringList.Count: Integer;
begin
  Result := FCount;
end;

function TStringList.GetLine(Idx: Integer): AnsiString;
begin
  if (Idx >= 0) and (Idx < FCount) then
    Result := FLines[Idx]
  else
    Result := '';
end;

procedure TStringList.SetLine(Idx: Integer; const S: AnsiString);
begin
  if (Idx >= 0) and (Idx < FCount) then
    FLines[Idx] := S;
end;

procedure TStringList.Insert(Idx: Integer; const S: AnsiString);
var
  I: Integer;
begin
  if Idx < 0 then Idx := 0;
  if Idx > FCount then Idx := FCount;
  if FCount >= Length(FLines) then
    SetLength(FLines, FCount * 2 + 8);
  for I := FCount downto Idx + 1 do
    FLines[I] := FLines[I - 1];
  FLines[Idx] := S;
  Inc(FCount);
end;

procedure TStringList.DeleteLast;
begin
  if FCount > 0 then
    Dec(FCount);
end;


{ String manipulation utilities (StripOuterParens, InvertAtom, ApplyDeMorgan,
  ParenthesizeMixedNotCompare, GroupMixedAndOr) moved to LuaExprUtils.pas }

{ ======================================================================
  TDecompiler implementation
  ====================================================================== }

constructor TDecompiler.Create(Proto: PProto; const Opts: TDecompOptions);
var
  I: Integer;
begin
  inherited Create;
  FProto  := Proto;
  FOpts   := Opts;
  FOutput := TStringList.Create;
  FIndent := 0;
  FExprDepth := 0;
  FLoopExitTop := -1;
  FAnnotatePC := -1;
  FSF     := BuildSSAFunction(Proto, FOpts.OT);
  { Compute FMaxVer from the actual maximum SSA version seen across all nodes }
  FMaxVer := 1;
  for I := 0 to High(FSF^.AllNodes) do begin
    if FSF^.AllNodes[I]^.Dest.Version >= FMaxVer then
      FMaxVer := FSF^.AllNodes[I]^.Dest.Version + 1;
  end;
  if FMaxVer < Proto^.MaxStack * 4 + 16 then
    FMaxVer := Proto^.MaxStack * 4 + 16;  { minimum safety margin }
  SetLength(FInlinedProtos, Length(Proto^.P));
  if FOpts.Annotate then
    SetLength(FAnnotatedPCs, Length(Proto^.Code));
end;

constructor TDecompiler.Create(Proto: PProto; const Opts: TDecompOptions;
                               const UpvalNames: TAnsiStringArray);
var
  I, J: Integer;
  ParamName: AnsiString;
  Collision: Boolean;
begin
  Create(Proto, Opts);
  SetLength(FUpvalNames, Length(UpvalNames));
  for I := 0 to High(UpvalNames) do
    FUpvalNames[I] := UpvalNames[I];

  { Detect collisions between upvalue names and parameter names.
    When a parameter name would collide with an upvalue name,
    override the parameter to use 'arg<N>' instead. }
  SetLength(FParamOverrides, Proto^.NumParams);
  for I := 0 to Proto^.NumParams - 1 do begin
    if I < Length(Proto^.LocVars) then
      ParamName := Proto^.LocVars[I].Name
    else
      ParamName := 'a' + IntToStr(I);
    Collision := False;
    for J := 0 to High(FUpvalNames) do begin
      if FUpvalNames[J] = ParamName then begin
        Collision := True;
        Break;
      end;
    end;
    if Collision then
      FParamOverrides[I] := 'arg' + IntToStr(I)
    else
      FParamOverrides[I] := ''; { no override needed }
  end;
end;

destructor TDecompiler.Destroy;
begin
  FOutput.Free;
  FreeSSAFunction(FSF);
  inherited;
end;

{ Loop exit stack helpers for break detection }

procedure TDecompiler.PushLoopExit(ExitBlk: Integer);
begin
  Inc(FLoopExitTop);
  if FLoopExitTop >= Length(FLoopExitStack) then
    SetLength(FLoopExitStack, FLoopExitTop + 8);
  FLoopExitStack[FLoopExitTop] := ExitBlk;
end;

procedure TDecompiler.PopLoopExit;
begin
  if FLoopExitTop >= 0 then Dec(FLoopExitTop);
end;

function TDecompiler.CurrentLoopExit: Integer;
begin
  if FLoopExitTop >= 0 then
    Result := FLoopExitStack[FLoopExitTop]
  else
    Result := -1;
end;

function TDecompiler.IsBreakTarget(Blk: Integer): Boolean;
{ Check if Blk is (or leads to) the current loop exit block.
  A break target is either the exit block itself, or a JMP-only
  trampoline block whose sole successor is the exit block. }
var
  ExitB, J: Integer;
  IsJmp: Boolean;
begin
  Result := False;
  ExitB := CurrentLoopExit;
  if ExitB < 0 then Exit;
  if Blk = ExitB then begin Result := True; Exit; end;
  { Check if Blk is a JMP-only block leading to ExitB }
  if (Blk >= 0) and (Blk < Length(FSF^.Blocks)) then begin
    if Length(FSF^.Blocks[Blk].Succs) = 1 then begin
      IsJmp := True;
      for J := 0 to High(FSF^.Blocks[Blk].Nodes) do
        if not (FSF^.Blocks[Blk].Nodes[J]^.Kind in [SSA_JUMP, SSA_PHI, SSA_NOP]) then begin
          IsJmp := False; Break;
        end;
      if IsJmp and (FSF^.Blocks[Blk].Succs[0] = ExitB) then
        Result := True;
    end;
  end;
end;

procedure TDecompiler.Indent;
begin
  Inc(FIndent);
end;

procedure TDecompiler.Dedent;
begin
  if FIndent > 0 then Dec(FIndent);
end;

procedure TDecompiler.Emit(const S: AnsiString);
var
  Pad: AnsiString;
  P, LineStart: Integer;
  Line: AnsiString;
begin
  Pad := StringOfChar(' ', FIndent * 2);
  { If S contains embedded newlines (multi-line expressions like closures),
    indent each line individually so the output is properly formatted. }
  if Pos(#10, S) > 0 then begin
    P := 1;
    while P <= Length(S) do begin
      LineStart := P;
      while (P <= Length(S)) and (S[P] <> #10) do
        Inc(P);
      Line := Copy(S, LineStart, P - LineStart);
      if (Length(Line) > 0) and (Line[Length(Line)] = #13) then
        Line := Copy(Line, 1, Length(Line) - 1);
      FOutput.Add(Pad + Line);
      Inc(P); { skip LF }
    end;
  end else
    FOutput.Add(Pad + S);
end;

procedure TDecompiler.EmitAny(const S: AnsiString; CountAsStmt: Boolean);
var
  LastIdx: Integer;
  LastLine, TrimmedLast: AnsiString;
begin
  if (FAnnotatePC >= 0) and FOpts.Annotate then
    EmitAnnotation(FAnnotatePC);
  if CountAsStmt and FLastBreak and
     (S <> 'end') and (S <> 'else') and
     (Copy(S, 1, 7) <> 'elseif ') then begin
    LastIdx := FOutput.Count - 1;
    if LastIdx >= 0 then begin
      LastLine := FOutput.GetLine(LastIdx);
      TrimmedLast := Trim(LastLine);
      if ((TrimmedLast = 'break') or (Copy(TrimmedLast, 1, 6) = 'return')) and
         (Copy(TrimmedLast, 1, 3) <> 'do ') then
        FOutput.SetLine(LastIdx, StringOfChar(' ', FIndent * 2) +
          'do ' + TrimmedLast + ' end');
    end;
  end;
  FLastBreak := (S = 'break') or (Copy(S, 1, 6) = 'return');
  if CountAsStmt then Inc(FStmtCount);
  Emit(S);
end;

procedure TDecompiler.EmitStmt(const S: AnsiString);
begin EmitAny(S, True); end;

procedure TDecompiler.EmitStruct(const S: AnsiString);
begin EmitAny(S, False); end;

procedure TDecompiler.EmitEmbed(const S: AnsiString);
begin Emit(S); end;  { raw re-emit: no annotation, no FLastBreak, no counting }

procedure TDecompiler.EmitLine(const S: AnsiString);
begin EmitStmt(S); end;  { backward-compat alias }

procedure TDecompiler.EmitAnnotation(PC: Integer);
var
  DisStr: AnsiString;
begin
  if not FOpts.Annotate then Exit;
  if (PC < 0) or (PC > High(FProto^.Code)) then Exit;
  { Skip if already annotated this PC }
  if (PC < Length(FAnnotatedPCs)) and FAnnotatedPCs[PC] then Exit;
  if PC < Length(FAnnotatedPCs) then
    FAnnotatedPCs[PC] := True;
  { Format the instruction }
  if FOpts.OT <> nil then
    DisStr := FormatInstructionV(FProto^, PC, FOpts.OT^)
  else
    DisStr := FormatInstruction(FProto^, PC);
  Emit('-- ' + DisStr);
end;

function TDecompiler.TryCollapseSingleLineBlock(OpenIdx: Integer; StartPC, EndPC: Integer): Boolean;
{ Try to collapse a block like:
    if cond then       (OpenIdx)
      body             (OpenIdx+1)
    end                (OpenIdx+2)
  into: if cond then body end

  Also handles: for...do...end, while...do...end, repeat...until

  OpenIdx: FOutput index of the opening line
  StartPC: PC of the opening instruction (BRANCH/FORPREP/TEST etc.)
  EndPC:   PC of the closing instruction (JMP after body / FORLOOP / BRANCH at tail).
           All LineInfo entries from StartPC to EndPC must map to the same source line.
           Pass StartPC=-1 to skip LineInfo check.
  Returns True if collapsed. }
var
  CurCount: Integer;
  OpenLine, BodyLine, CloseLine: AnsiString;
  Collapsed: AnsiString;
  SrcLine, I: Integer;
begin
  Result := False;
  CurCount := FOutput.Count;
  { Need exactly 3 lines: open, body, close }
  if CurCount <> OpenIdx + 3 then Exit;

  OpenLine := Trim(FOutput.GetLine(OpenIdx));
  BodyLine := Trim(FOutput.GetLine(OpenIdx + 1));
  CloseLine := Trim(FOutput.GetLine(OpenIdx + 2));

  { Opening line must end with 'then', 'do', or be 'repeat' }
  if not ((Length(OpenLine) >= 4) and (Copy(OpenLine, Length(OpenLine) - 3, 4) = 'then')) and
     not ((Length(OpenLine) >= 2) and (Copy(OpenLine, Length(OpenLine) - 1, 2) = 'do')) and
     not (OpenLine = 'repeat') then
    Exit;

  { Closing line must be 'end' or start with 'until ' }
  if (CloseLine <> 'end') and (Copy(CloseLine, 1, 6) <> 'until ') then
    Exit;

  { Body must not itself be a block opener }
  if (Copy(BodyLine, 1, 3) = 'if ') or
     (Copy(BodyLine, 1, 4) = 'for ') or
     (Copy(BodyLine, 1, 6) = 'while ') or
     (Copy(BodyLine, 1, 7) = 'repeat ') or
     (Copy(BodyLine, 1, 3) = 'do ') then
    Exit;

  { LineInfo check: all PCs from StartPC to EndPC must be on the same source line }
  if (StartPC >= 0) and (StartPC < Length(FProto^.LineInfo)) and
     (EndPC >= StartPC) and (EndPC < Length(FProto^.LineInfo)) then begin
    SrcLine := FProto^.LineInfo[StartPC];
    if SrcLine <= 0 then Exit;
    for I := StartPC + 1 to EndPC do begin
      if FProto^.LineInfo[I] <> SrcLine then
        Exit; { Multi-line block - don't collapse }
    end;
  end else if StartPC >= 0 then
    Exit; { Invalid PC range - don't collapse }

  { Build collapsed line }
  if CloseLine = 'end' then
    Collapsed := OpenLine + ' ' + BodyLine + ' end'
  else
    Collapsed := OpenLine + ' ' + BodyLine + ' ' + CloseLine;

  { Check length (with indentation) }
  if FIndent * 2 + Length(Collapsed) >= 80 then Exit;

  { Perform collapse: replace open with collapsed, remove body+close }
  FOutput.SetLine(OpenIdx, StringOfChar(' ', FIndent * 2) + Collapsed);
  FOutput.DeleteLast; { remove close line }
  FOutput.DeleteLast; { remove body line }
  Result := True;
end;

function TDecompiler.TryCollapseIfElseBlock(OpenIdx: Integer; StartPC, EndPC: Integer): Boolean;
{ Try to collapse an if-then-else block:
    if cond then        (OpenIdx)
      body1             (OpenIdx+1)
    else                (OpenIdx+2)
      body2             (OpenIdx+3)
    end                 (OpenIdx+4)
  into: if cond then body1 else body2 end

  StartPC/EndPC: LineInfo range to verify single-line origin.
  Returns True if collapsed. }
var
  CurCount: Integer;
  IfLine, Body1, ElseLine, Body2, EndLine: AnsiString;
  Collapsed: AnsiString;
  SrcLine, I: Integer;
begin
  Result := False;
  CurCount := FOutput.Count;
  { Need exactly 5 lines: if, body1, else, body2, end }
  if CurCount <> OpenIdx + 5 then Exit;

  IfLine   := Trim(FOutput.GetLine(OpenIdx));
  Body1    := Trim(FOutput.GetLine(OpenIdx + 1));
  ElseLine := Trim(FOutput.GetLine(OpenIdx + 2));
  Body2    := Trim(FOutput.GetLine(OpenIdx + 3));
  EndLine  := Trim(FOutput.GetLine(OpenIdx + 4));

  { Validate structure }
  if not ((Length(IfLine) >= 4) and (Copy(IfLine, Length(IfLine) - 3, 4) = 'then')) then Exit;
  if ElseLine <> 'else' then Exit;
  if EndLine <> 'end' then Exit;

  { Bodies must not be block openers }
  if (Copy(Body1, 1, 3) = 'if ') or (Copy(Body1, 1, 4) = 'for ') or
     (Copy(Body1, 1, 6) = 'while ') or (Copy(Body1, 1, 7) = 'repeat') or
     (Copy(Body1, 1, 3) = 'do ') then Exit;
  if (Copy(Body2, 1, 3) = 'if ') or (Copy(Body2, 1, 4) = 'for ') or
     (Copy(Body2, 1, 6) = 'while ') or (Copy(Body2, 1, 7) = 'repeat') or
     (Copy(Body2, 1, 3) = 'do ') then Exit;

  { LineInfo check }
  if (StartPC >= 0) and (StartPC < Length(FProto^.LineInfo)) and
     (EndPC >= StartPC) and (EndPC < Length(FProto^.LineInfo)) then begin
    SrcLine := FProto^.LineInfo[StartPC];
    if SrcLine <= 0 then Exit;
    for I := StartPC + 1 to EndPC do begin
      if FProto^.LineInfo[I] <> SrcLine then
        Exit;
    end;
  end else if StartPC >= 0 then
    Exit;

  Collapsed := IfLine + ' ' + Body1 + ' else ' + Body2 + ' end';
  if FIndent * 2 + Length(Collapsed) >= 80 then Exit;

  FOutput.SetLine(OpenIdx, StringOfChar(' ', FIndent * 2) + Collapsed);
  FOutput.DeleteLast; { end }
  FOutput.DeleteLast; { body2 }
  FOutput.DeleteLast; { else }
  FOutput.DeleteLast; { body1 }
  Result := True;
end;

{ ======================================================================
  Utility: valid Lua identifier check (used by dot-notation logic)
  ====================================================================== }

function IsValidLuaIdent(const S: AnsiString): Boolean;
var
  I: Integer;
begin
  Result := False;
  if Length(S) = 0 then Exit;
  if (S = 'and') or (S = 'break') or (S = 'do') or (S = 'else') or
     (S = 'elseif') or (S = 'end') or (S = 'false') or (S = 'for') or
     (S = 'function') or (S = 'if') or (S = 'in') or (S = 'local') or
     (S = 'nil') or (S = 'not') or (S = 'or') or (S = 'repeat') or
     (S = 'return') or (S = 'then') or (S = 'true') or (S = 'until') or
     (S = 'while') then Exit;
  if not (S[1] in ['A'..'Z','a'..'z','_']) then Exit;
  for I := 2 to Length(S) do
    if not (S[I] in ['A'..'Z','a'..'z','0'..'9','_']) then Exit;
  Result := True;
end;

{ ======================================================================
  BuildDefNodeMap: populate FDefNodeMap[Reg][Version] --> defining node.
  Called once in Run(), after FoldConstants (which mutates Node^.Kind),
  before BindLocVarsToSSA.
  ====================================================================== }

procedure TDecompiler.BuildDefNodeMap;
var
  I, R, V, MaxReg: Integer;
  Node: PSSANode;
  MaxVer: array of Integer;
begin
  { Pass 1: find max register }
  MaxReg := -1;
  for I := 0 to High(FSF^.AllNodes) do begin
    Node := FSF^.AllNodes[I];
    R := Node^.Dest.Reg;
    if R > MaxReg then MaxReg := R;
  end;
  { Include implicit defs (TFORLOOP loop vars, CALL extra returns, SELF R(A+1)) }
  for I := 0 to High(FSF^.ImplicitDefs) do
    if FSF^.ImplicitDefs[I].Reg > MaxReg then
      MaxReg := FSF^.ImplicitDefs[I].Reg;
  if MaxReg < 0 then Exit;

  { Find max version per register }
  SetLength(MaxVer, MaxReg + 1);
  for I := 0 to MaxReg do MaxVer[I] := -1;
  for I := 0 to High(FSF^.AllNodes) do begin
    Node := FSF^.AllNodes[I];
    R := Node^.Dest.Reg;
    if (R >= 0) and (Node^.Dest.Version > MaxVer[R]) then
      MaxVer[R] := Node^.Dest.Version;
  end;
  for I := 0 to High(FSF^.ImplicitDefs) do begin
    R := FSF^.ImplicitDefs[I].Reg;
    if (R >= 0) and (R <= MaxReg) and
       (FSF^.ImplicitDefs[I].Version > MaxVer[R]) then
      MaxVer[R] := FSF^.ImplicitDefs[I].Version;
  end;

  { Allocate }
  SetLength(FDefNodeMap, MaxReg + 1);
  for R := 0 to MaxReg do begin
    if MaxVer[R] >= 0 then begin
      SetLength(FDefNodeMap[R], MaxVer[R] + 1);
      for V := 0 to MaxVer[R] do
        FDefNodeMap[R][V] := nil;
    end;
  end;

  { Pass 2: populate with uniqueness assertion }
  for I := 0 to High(FSF^.AllNodes) do begin
    Node := FSF^.AllNodes[I];
    R := Node^.Dest.Reg;
    V := Node^.Dest.Version;
    if (R >= 0) and (V >= 0) and (R < Length(FDefNodeMap)) and
       (V < Length(FDefNodeMap[R])) then begin
      if FDefNodeMap[R][V] <> nil then begin
        if FOpts.Debug then
          WriteLn(StdErr, 'WARNING: duplicate def for R', R, '_', V,
                  ' at PC ', Node^.PC, ' (existing at PC ',
                  FDefNodeMap[R][V]^.PC, ')');
      end else
        FDefNodeMap[R][V] := Node;
    end;
  end;

  { Pass 3: populate implicit defs (TFORLOOP loop vars, CALL multi-return,
    SELF implicit copy). Maps (Reg,Version) --> parent node.
    Never overwrite: if an AllNodes entry already claimed this slot, keep it. }
  for I := 0 to High(FSF^.ImplicitDefs) do begin
    R := FSF^.ImplicitDefs[I].Reg;
    V := FSF^.ImplicitDefs[I].Version;
    if (R >= 0) and (V >= 0) and (R < Length(FDefNodeMap)) and
       (V < Length(FDefNodeMap[R])) then begin
      if FDefNodeMap[R][V] = nil then
        FDefNodeMap[R][V] := FSF^.ImplicitDefs[I].ParentNode;
    end;
  end;
end;

{ DefNodeFor: resolve (Reg, Version) --> defining PSSANode.
  Returns nil for constants (Reg=-2), no-ref (Reg=-1), or out-of-range. }

function TDecompiler.DefNodeFor(const Op: TSSARef): PSSANode;
begin
  if (Op.Reg < 0) or (Op.Reg >= Length(FDefNodeMap)) then Exit(nil);
  if (Op.Version < 0) or (Op.Version >= Length(FDefNodeMap[Op.Reg])) then Exit(nil);
  Result := FDefNodeMap[Op.Reg][Op.Version];
end;

{ NodeIsEmittableLocal: True only for user-visible locals (not internal
  for-loop vars, not implicit 'arg' in 5.1 vararg). No PC scanning. }

function TDecompiler.NodeIsEmittableLocal(Node: PSSANode): Boolean;
var
  Name: AnsiString;
begin
  Result := False;
  if (Node = nil) or (Node^.LocVarIdx < 0) or
     (Node^.LocVarIdx > High(FProto^.LocVars)) then Exit;
  Name := FProto^.LocVars[Node^.LocVarIdx].Name;
  if Length(Name) = 0 then Exit;
  { Exclude internal for-loop locals: (for index), (for limit), etc. }
  if Name[1] = '(' then Exit;
  { Exclude implicit 'arg' local in Lua 5.1 vararg functions }
  if (FSF^.LuaVersion <= $51) and (Name = 'arg') and
     ((FProto^.IsVarArg and 1) <> 0) and
     (Node^.Dest.Reg = FProto^.NumParams) then Exit;
  { First char must be letter or underscore }
  if not (Name[1] in ['a'..'z', 'A'..'Z', '_']) then Exit;
  Result := True;
end;

procedure TDecompiler.EmitReturnOnly(BlkIdx: Integer);
{ Emit only SSA_RETURN and SSA_TAILCALL nodes from a block using EmitNode.
  No scope management, no successor traversal, no FEmitted mutation.
  Handles all RETURN variants (bare, single/multi-value, closure return,
  tailcall, vararg) via existing EmitNode dispatch. }
var
  I: Integer;
  Node: PSSANode;
begin
  if (BlkIdx < 0) or (BlkIdx >= Length(FSF^.Blocks)) then Exit;
  for I := 0 to High(FSF^.Blocks[BlkIdx].Nodes) do begin
    Node := FSF^.Blocks[BlkIdx].Nodes[I];
    if Node^.Kind in [SSA_RETURN, SSA_TAILCALL] then
      EmitNode(Node, BlkIdx);
  end;
end;

{ ======================================================================
  Include files: method implementations split for maintainability
  ====================================================================== }

{$I LuaDecompNaming.inc}
{$I LuaDecompExpr.inc}
{ Strip only terminal CR/LF characters from a string (not other whitespace) }
function StripTrailingNewline(const S: AnsiString): AnsiString;
var
  L: Integer;
begin
  L := Length(S);
  while (L > 0) and (S[L] in [#10, #13]) do Dec(L);
  Result := Copy(S, 1, L);
end;

{$I LuaDecompCF.inc}
{$I LuaDecompEmitNode.inc}
{$I LuaDecompBoolean.inc}
{$I LuaDecompMulti.inc}
{$I LuaDecompClosure.inc}

procedure TDecompiler.EmitBlock(BIdx: Integer);
var
  I, J: Integer;
  Node: PSSANode;
  SwapCount: Integer;
begin
  I := 0;
  while I <= High(FSF^.Blocks[BIdx].Nodes) do begin
    Node := FSF^.Blocks[BIdx].Nodes[I];

    { Skip pseudo-definition nodes (IsMetaOnly) - they exist solely for
      LocVar binding in SSA and must not be emitted or processed by
      multi-assign detectors. }
    if Node^.IsMetaOnly then begin Inc(I); Continue; end;

    { Close expired do..end scopes (inner-first = top of stack first) }
    while FActiveScopeTop > 0 do begin
      if Node^.PC < FPendingScopes[FActiveScopeStack[FActiveScopeTop - 1]].EndPC then
        Break;
      Dec(FActiveScopeTop);
      Dedent;
      EmitStruct('end');
    end;

    { Open pending do..end scopes (outer-first = ascending order) }
    while FNextPendingScope < FPendingScopeCount do begin
      if Node^.PC < FPendingScopes[FNextPendingScope].StartPC then Break;
      EmitStruct('do');
      Indent;
      FActiveScopeStack[FActiveScopeTop] := FNextPendingScope;
      Inc(FActiveScopeTop);
      Inc(FNextPendingScope);
    end;

    { Try to detect multiple assignment (local a, b, c = 1, 2, 3) }
    if (Node^.Kind in [SSA_LOADK, SSA_LOADBOOL, SSA_LOADNIL,
                        SSA_GETGLOBAL, SSA_GETTABLE, SSA_GETUPVAL,
                        SSA_MOVE, SSA_BINOP, SSA_UNOP, SSA_CONCAT]) then
      case TryEmitMultiAssign(BIdx, I, SwapCount) of
        maEmitted: begin Inc(I, SwapCount); Continue; end;
        maNotMatched: ;
      end;
    { Try to detect multi-return CALL/VARARG + MOVEs (p, a, s = func(...)  or  a, b = ...) }
    if (Node^.Kind in [SSA_CALL, SSA_VARARG]) then
      case TryEmitMultiReturnAssign(BIdx, I, SwapCount) of
        maEmitted: begin Inc(I, SwapCount); Continue; end;
        maNotMatched: ;
      end;
    { Try to detect reverse multi-assign: value-compute + reverse MOVEs
      Handles: a, b = ...  |  a, b, c = 1, ...  |  a, b, c = 1, f(multi)
      Also: a, b, c = f(single-ret), 1, 2 (CALL with ImmC=2 + LOADKs + MOVEs)
      Also: t, b, c, d = clock, initial[k], v - initial[k], duration
      (eval into temps + reverse MOVEs to user locals, with optional direct writes) }
    if (Node^.Kind in [SSA_LOADK, SSA_LOADBOOL, SSA_LOADNIL,
                        SSA_GETGLOBAL, SSA_GETTABLE, SSA_GETUPVAL,
                        SSA_MOVE, SSA_BINOP, SSA_UNOP, SSA_CONCAT,
                        SSA_VARARG, SSA_CALL, SSA_NEWTABLE]) then
      case TryEmitReverseMultiAssign(BIdx, I, SwapCount) of
        maEmitted: begin Inc(I, SwapCount); Continue; end;
        maNotMatched: ;
      end;
    { Try to detect variable swap pattern (3 consecutive MOVEs) }
    if (Node^.Kind = SSA_MOVE) then
      case TryEmitSwap(BIdx, I, SwapCount) of
        maEmitted: begin Inc(I, SwapCount); Continue; end;
        maNotMatched: ;
      end;
    { Try to detect table element swap: t[a],t[b] = t[b],t[a] }
    if (Node^.Kind = SSA_GETTABLE) and TryEmitTableSwap(BIdx, I, SwapCount) then begin
      Inc(I, SwapCount);
      Continue;
    end;
    { Try to detect inline table constructor (NEWTABLE + LOADKs + SETTABLEs + SETLIST) }
    if (Node^.Kind = SSA_NEWTABLE) and TryEmitTableConstructor(BIdx, I, SwapCount) then begin
      Inc(I, SwapCount);
      Continue;
    end;
    { Try to detect multi-local declaration with trailing nil stripping:
      local v, w = 0  (instead of "local v = 0; local w") }
    if (Node^.Kind in [SSA_LOADK, SSA_LOADBOOL, SSA_MOVE, SSA_GETGLOBAL,
                        SSA_GETTABLE, SSA_GETUPVAL, SSA_BINOP, SSA_UNOP,
                        SSA_CONCAT, SSA_CALL]) and
       TryEmitMultiLocal(BIdx, I, SwapCount) then begin
      Inc(I, SwapCount);
      Continue;
    end;
    { Skip nodes that write to a temp register which will be overwritten by
      a subsequent CALL multi-return or VARARG in the same block.  This prevents
      spurious "local tN = ..." for CALL argument setup registers.
      Two cases:
        (a) Register is clearly not a user local at current PC --> skip freely.
        (b) Register looks like a future local (ShouldEmitAsLocal=true), but the
            CALL/VARARG output range covers it.  In that case the LocVar is the
            CALL's return value, not this temp - still safe to skip. }
    if (Node^.Kind in [SSA_LOADK, SSA_LOADBOOL, SSA_LOADNIL,
                        SSA_GETGLOBAL, SSA_GETTABLE, SSA_GETUPVAL,
                        SSA_MOVE, SSA_BINOP, SSA_UNOP, SSA_CONCAT]) and
       (Node^.Dest.Reg >= 0) and
       (not IsUserLocal(Node^.Dest.Reg, Node^.PC)) and
       (not IsUserLocal(Node^.Dest.Reg, Node^.PC + 1)) then begin
      SwapCount := 0;
      for J := I + 1 to High(FSF^.Blocks[BIdx].Nodes) do begin
        if (FSF^.Blocks[BIdx].Nodes[J]^.Kind = SSA_CALL) and (FSF^.Blocks[BIdx].Nodes[J]^.ImmC >= 3) and
           (Node^.Dest.Reg >= FSF^.Blocks[BIdx].Nodes[J]^.ImmA) and
           (Node^.Dest.Reg <= FSF^.Blocks[BIdx].Nodes[J]^.ImmA + FSF^.Blocks[BIdx].Nodes[J]^.ImmC - 2) then begin
          SwapCount := 1; Break;
        end;
        if (FSF^.Blocks[BIdx].Nodes[J]^.Kind = SSA_VARARG) and (FSF^.Blocks[BIdx].Nodes[J]^.ImmB >= 3) and
           (Node^.Dest.Reg >= FSF^.Blocks[BIdx].Nodes[J]^.ImmA) and
           (Node^.Dest.Reg <= FSF^.Blocks[BIdx].Nodes[J]^.ImmA + FSF^.Blocks[BIdx].Nodes[J]^.ImmB - 2) then begin
          SwapCount := 1; Break;
        end;
      end;
      if SwapCount > 0 then begin
        Inc(I);
        Continue;
      end;
    end;
    EmitNode(Node, BIdx);
    Inc(I);
  end;
end;

{ ======================================================================
  EmitRegion  (main recursive region emitter)
  ====================================================================== }

procedure TDecompiler.EmitRegion(BIdx: Integer; StopAt: Integer);
var
  I, Succ0, Succ1: Integer;
  HasBranch: Boolean;
  HasForPrep: Boolean;
  HasTForLoop: Boolean;
  Blk: PBasicBlock;
  BrNode: PSSANode;
  MergeBlk: Integer;
  NextBlk: Integer;
  CompCond: AnsiString;
  CompBody, CompMerge: Integer;
  { Nested repeat-until detection vars }
  InnerExit, MaxBackEdge, OuterBranchBlk, OuterExitBlk: Integer;
  OuterCondNode: PSSANode;
  OuterCondExpr: AnsiString;
  IsOuterJmpOnly: Boolean;
  P, S, J2: Integer;
  ValExpr: AnsiString;
  TmpFlag, TmpFlag2: Boolean;
begin
  while (BIdx >= 0) and (BIdx < Length(FSF^.Blocks)) and
        ((StopAt < 0) or (BIdx < StopAt)) do begin
    if FEmitted[BIdx] then begin
      Inc(BIdx); Continue;
    end;

    if FOpts.Debug then
      WriteLn(StdErr, 'EmitRegion step: BB', BIdx, ' StopAt=', StopAt);

    Blk := @FSF^.Blocks[BIdx];

    { Check for FORPREP (numeric for) }
    HasForPrep := False;
    for I := 0 to High(Blk^.Nodes) do
      if Blk^.Nodes[I]^.Kind = SSA_FORPREP then begin
        HasForPrep := True; Break;
      end;
    if HasForPrep then begin
      NextBlk := EmitForNumericLoop(BIdx);
      FEmitted[BIdx] := True;
      if NextBlk >= 0 then begin
        BIdx := NextBlk; Continue;
      end;
    end;

    { Check for TFORLOOP (generic for) }
    HasTForLoop := False;
    for I := 0 to High(Blk^.Nodes) do
      if Blk^.Nodes[I]^.Kind = SSA_TFORLOOP then begin
        HasTForLoop := True; Break;
      end;
    if HasTForLoop then begin
      NextBlk := EmitForGenericLoop(BIdx);
      FEmitted[BIdx] := True;
      if NextBlk >= 0 then begin
        BIdx := NextBlk; Continue;
      end;
    end;

    FEmitted[BIdx] := True;

    { Skip unreachable dead-code blocks (no predecessors, entry block excluded)
      that contain only RETURN/NOP/JUMP/PHI - these are compiler-generated
      trailing returns after TAILCALL or dead branches.  Without this,
      "return" is spuriously emitted after if/else blocks where all branches
      already contain return/tailcall. }
    if (BIdx > 0) and (Length(Blk^.Preds) = 0) then begin
      TmpFlag := True; { assume dead }
      for I := 0 to High(Blk^.Nodes) do
        if not (Blk^.Nodes[I]^.Kind in [SSA_RETURN, SSA_NOP, SSA_JUMP, SSA_PHI]) then begin
          TmpFlag := False; Break;
        end;
      if TmpFlag then begin
        Inc(BIdx); Continue;
      end;
    end;

    { Check for while/repeat (back-edge loop) }
    if IsLoopHeader(BIdx) then begin
      { ---- Nested repeat-until with shared header detection ----
        Only triggered if the header is a repeat-until style (has body
        statements like CALL before the BRANCH), NOT a while-style header
        (only condition evaluation + BRANCH, no side-effect statements). }
      begin
        { Check if header has body-level statements (CALL, SETTABLE, etc.) }
        HasBranch := False;  { reuse: here means "has body statements" }
        for I := 0 to High(Blk^.Nodes) do begin
          if Blk^.Nodes[I]^.Kind in [SSA_CALL, SSA_TAILCALL, SSA_SETGLOBAL,
             SSA_SETUPVAL, SSA_SETTABLE, SSA_SETLIST] then begin
            HasBranch := True; Break;
          end;
        end;
        InnerExit := -1;
        MaxBackEdge := -1;
        if HasBranch then begin { Only for repeat-until style headers }
        InnerExit := FindLoopExit(BIdx);
        MaxBackEdge := -1;
        for I := 0 to High(FSF^.Blocks[BIdx].Preds) do begin
          P := FSF^.Blocks[BIdx].Preds[I];
          if (P >= BIdx) and (not FEmitted[P]) then
            if P > MaxBackEdge then MaxBackEdge := P;
        end;
        { Skip if MaxBackEdge is just a JMP-only trampoline back to
          the header - that's the same loop's back-edge, not an outer loop. }
        TmpFlag := False;
        if (MaxBackEdge > InnerExit) and (MaxBackEdge < Length(FSF^.Blocks)) then begin
          TmpFlag := True;
          for I := 0 to High(FSF^.Blocks[MaxBackEdge].Nodes) do
            if not (FSF^.Blocks[MaxBackEdge].Nodes[I]^.Kind in
                    [SSA_JUMP, SSA_PHI, SSA_NOP]) then begin
              TmpFlag := False; Break;
            end;
          if TmpFlag and (Length(FSF^.Blocks[MaxBackEdge].Succs) = 1) and
             (FSF^.Blocks[MaxBackEdge].Succs[0] = BIdx) then
            { MaxBackEdge is a JMP-only block back to header - same loop }
            MaxBackEdge := InnerExit; { prevent entering nested detection }
        end;
        if (MaxBackEdge > InnerExit) then begin
          { Found an outer back-edge beyond the inner exit.
            Find the branching block that leads to the outer back-edge. }
          OuterBranchBlk := -1;
          OuterExitBlk := -1;
          for I := InnerExit to MaxBackEdge do begin
            if Length(FSF^.Blocks[I].Succs) >= 2 then begin
              for J2 := 0 to High(FSF^.Blocks[I].Succs) do begin
                S := FSF^.Blocks[I].Succs[J2];
                if S = MaxBackEdge then begin
                  OuterBranchBlk := I;
                  Break;
                end;
                { Also check if this block directly has a back-edge to header }
                if S = BIdx then begin
                  OuterBranchBlk := I;
                  Break;
                end;
              end;
              if OuterBranchBlk >= 0 then Break;
            end;
          end;
          if OuterBranchBlk >= 0 then begin
            { Find the exit (the non-back-edge successor) }
            for J2 := 0 to High(FSF^.Blocks[OuterBranchBlk].Succs) do begin
              S := FSF^.Blocks[OuterBranchBlk].Succs[J2];
              if (S <> MaxBackEdge) and (S <> BIdx) then begin
                OuterExitBlk := S; Break;
              end;
            end;
            if OuterExitBlk > BIdx then begin
              { Find the condition expression from the outer branch block }
              OuterCondNode := nil;
              for I := High(FSF^.Blocks[OuterBranchBlk].Nodes) downto 0 do
                if FSF^.Blocks[OuterBranchBlk].Nodes[I]^.Kind = SSA_BRANCH then begin
                  OuterCondNode := FSF^.Blocks[OuterBranchBlk].Nodes[I]; Break;
                end;
              if OuterCondNode <> nil then begin
                { Determine which successor is the JMP-only back-edge vs exit }
                IsOuterJmpOnly := (FSF^.Blocks[OuterBranchBlk].Succs[0] = MaxBackEdge) or
                                  (FSF^.Blocks[OuterBranchBlk].Succs[0] = BIdx);
                case OuterCondNode^.RelOp of
                  ropEQ, ropLT, ropLE:
                    if IsOuterJmpOnly then
                      OuterCondExpr := BuildCompare(OuterCondNode^.OpA, OuterCondNode^.OpB,
                                                     OuterCondNode^.RelOp, not OuterCondNode^.Invert,
                                                     OuterCondNode^.PC)
                    else
                      OuterCondExpr := BuildCompare(OuterCondNode^.OpA, OuterCondNode^.OpB,
                                                     OuterCondNode^.RelOp, OuterCondNode^.Invert,
                                                     OuterCondNode^.PC);
                  ropTest, ropTestSet:
                    if IsOuterJmpOnly then begin
                      { Succs[0] is back-edge (fall-through = continue loop).
                        TEST C=0 (Invert=false): truthy --> skip --> exit --> until <expr>
                        TEST C=1 (Invert=true): falsy --> skip --> exit --> until not <expr> }
                      if OuterCondNode^.Invert then
                        OuterCondExpr := 'not ' + ExprOf(OuterCondNode^.OpA, OuterCondNode^.PC)
                      else
                        OuterCondExpr := ExprOf(OuterCondNode^.OpA, OuterCondNode^.PC);
                    end else begin
                      { Succs[0] is exit (fall-through = exit loop).
                        TEST C=0 (Invert=false): truthy --> skip --> continue --> until not <expr>
                        TEST C=1 (Invert=true): falsy --> skip --> continue --> until <expr> }
                      if OuterCondNode^.Invert then
                        OuterCondExpr := ExprOf(OuterCondNode^.OpA, OuterCondNode^.PC)
                      else
                        OuterCondExpr := 'not ' + ExprOf(OuterCondNode^.OpA, OuterCondNode^.PC);
                    end;
                else
                  OuterCondExpr := '';
                end;
                if OuterCondExpr <> '' then begin
                  { Mark the JMP-only back-edge block as emitted BEFORE
                    recursion to prevent infinite re-detection of the outer
                    loop.  The outer branch block is NOT marked yet because
                    it may contain body statements that need emitting. }
                  if MaxBackEdge < Length(FSF^.Blocks) then
                    FEmitted[MaxBackEdge] := True;
                  { Emit outer repeat ... until wrapper }
                  EmitLine('repeat');
                  Indent;
                  PushLoopExit(OuterExitBlk);
                  FEmitted[BIdx] := False; { Re-process BIdx as inner loop }
                  { Emit body up to (but not including) the outer branch block }
                  EmitRegion(BIdx, OuterBranchBlk);
                  { Emit non-branch body statements from the outer branch block }
                  FEmitted[OuterBranchBlk] := True;
                  for I := 0 to High(FSF^.Blocks[OuterBranchBlk].Nodes) do begin
                    if FSF^.Blocks[OuterBranchBlk].Nodes[I]^.Kind in
                       [SSA_BRANCH, SSA_PHI, SSA_NOP, SSA_JUMP] then Continue;
                    EmitNode(FSF^.Blocks[OuterBranchBlk].Nodes[I], OuterBranchBlk);
                  end;
                  PopLoopExit;
                  Dedent;
                  EmitLine('until ' + OuterCondExpr);
                  BIdx := OuterExitBlk;
                  Continue;
                end;
              end;
            end;
          end;
        end;
      end; { if HasBranch (body-in-header check) }
      end;

      { Determine if condition is at top (while) or bottom (repeat).
        IsRepeatUntilLoop checks whether the header's branch (if any) exits
        the loop. If both successors stay inside the loop, it's repeat-until. }
      if IsRepeatUntilLoop(BIdx) then begin
        NextBlk := FindRepeatUntilExit(BIdx);
        if NextBlk < 0 then NextBlk := FindLoopExit(BIdx);
        EmitRepeatRegion(BIdx);
        BIdx := NextBlk;
      end else begin
        EmitWhileRegion(BIdx);
        BIdx := FindLoopExit(BIdx);
      end;
      Continue;
    end;

    { Check for if/then/else (branch node with forward targets) }
    HasBranch := False;
    BrNode := nil;
    Succ0 := -1; Succ1 := -1;
    for I := 0 to High(Blk^.Nodes) do
      if Blk^.Nodes[I]^.Kind = SSA_BRANCH then begin
        HasBranch := True;
        BrNode := Blk^.Nodes[I];
        { CFG successor ordering:
            Succs[0] = the JMP block (PC+1, fall-through to the JMP instruction)
            Succs[1] = the skip target (PC+2, where comparison-skip lands)
          For EQ/LT/LE with Invert=false: condition true --> skip --> Succs[1]
          So "then" body = Succs[1], "else" body = Succs[0].
          We swap here so TrueBlk=Succs[1] and FalseBlk=Succs[0]. }
        if Length(Blk^.Succs) >= 2 then begin
          Succ0 := Blk^.Succs[1];  { TrueBlk = skip target }
          Succ1 := Blk^.Succs[0];  { FalseBlk = JMP block  }
        end else if Length(Blk^.Succs) = 1 then
          Succ0 := Blk^.Succs[0];
        Break;
      end;

    if HasBranch and (Succ0 > BIdx) then begin
      { Check for LOADBOOL comparison pattern:
        BRANCH --> JMP-block --> LOADBOOL-true-block --> merge-block (PHI + RETURN)
                --> LOADBOOL-false-block (skip) --> merge-block
        This pattern ONLY applies to comparison branches (EQ/LT/LE), NOT to
        TEST/TESTSET branches.  TEST-based branches are or/and value expressions
        which should be handled by TryEmitOrAnd instead. }
      if (BrNode <> nil) and (BrNode^.RelOp in [ropEQ, ropLT, ropLE]) and
         (Succ0 >= 0) and (Succ0 < Length(FSF^.Blocks)) and
         (Succ1 >= 0) and (Succ1 < Length(FSF^.Blocks)) and
         (Length(FSF^.Blocks[Succ0].Nodes) = 1) and
         (Length(FSF^.Blocks[Succ1].Nodes) = 1) then begin
        if ((FSF^.Blocks[Succ0].Nodes[0]^.Kind = SSA_LOADBOOL) and
            (FSF^.Blocks[Succ1].Nodes[0]^.Kind = SSA_JUMP)) or
           ((FSF^.Blocks[Succ1].Nodes[0]^.Kind = SSA_LOADBOOL) and
            (FSF^.Blocks[Succ0].Nodes[0]^.Kind = SSA_JUMP)) then begin
          { Mark branch block, both LOADBOOL blocks, and the JMP target as emitted }
          FEmitted[Succ0] := True;
          FEmitted[Succ1] := True;
          { Find the JMP target - only mark it emitted if it's a simple
            LOADBOOL block (part of the comparison pattern).  If the JMP
            leads to a merge block that contains additional statements
            (CALL nodes, etc.), do NOT mark it emitted - it still needs
            to be visited by EmitRegion. }
          if FSF^.Blocks[Succ0].Nodes[0]^.Kind = SSA_JUMP then begin
            if Length(FSF^.Blocks[Succ0].Succs) > 0 then begin
              NextBlk := FSF^.Blocks[Succ0].Succs[0];
              if (NextBlk < Length(FSF^.Blocks)) and
                 (Length(FSF^.Blocks[NextBlk].Nodes) = 1) and
                 (FSF^.Blocks[NextBlk].Nodes[0]^.Kind = SSA_LOADBOOL) then
                FEmitted[NextBlk] := True;
            end;
          end;
          if FSF^.Blocks[Succ1].Nodes[0]^.Kind = SSA_JUMP then begin
            if Length(FSF^.Blocks[Succ1].Succs) > 0 then begin
              NextBlk := FSF^.Blocks[Succ1].Succs[0];
              if (NextBlk < Length(FSF^.Blocks)) and
                 (Length(FSF^.Blocks[NextBlk].Nodes) = 1) and
                 (FSF^.Blocks[NextBlk].Nodes[0]^.Kind = SSA_LOADBOOL) then
                FEmitted[NextBlk] := True;
            end;
          end;
          { Advance to the merge block (where the PHI + RETURN lives) }
          EmitBlock(BIdx);  { emit any non-branch nodes in the branch block }
          NextBlk := BIdx + 1;
          while (NextBlk < Length(FSF^.Blocks)) and FEmitted[NextBlk] and
                (NextBlk <> StopAt) do
            Inc(NextBlk);
          BIdx := NextBlk;
          Continue;
        end;
      end;

      { Try compound and/or condition FIRST: "if a and b or c then"
        TryBuildCompoundCond collects the chain of branch-only blocks into a
        single compound expression and returns the true/false targets.
        This MUST be checked before TryEmitOrAnd because TryEmitOrAnd's
        multi-operand PHI path can incorrectly consume compound if-conditions. }
      begin
        CompCond := '';
        CompBody := -1;
        CompMerge := -1;
        if TryBuildCompoundCond(BIdx, CompCond, CompBody, CompMerge) then begin
          if CompCond = '' then begin
            { LOADBOOL compound pattern: expression was cached in PHI.
              Emit the branch block's non-branch content (if any) and advance
              to the PHI merge block (CompBody = CompMerge = merge block). }
            EmitBlock(BIdx);
            BIdx := CompBody;
            { Advance past any already-emitted blocks }
            while (BIdx < Length(FSF^.Blocks)) and FEmitted[BIdx] and
                  (BIdx <> StopAt) do
              Inc(BIdx);
            Continue;
          end else begin
            MergeBlk := FindMerge(BIdx, CompBody, CompMerge);
            { When FindMerge returns the body block itself as merge, it means
              the condition-failure path (CompMerge) is a return/exit block
              and the "one branch returns" fallback selected the body as merge.
              This causes EmitIfRegionCompound to think HasTrueBody=False
              (body=merge --> skipped), producing an empty if-then-end.
              Fix: find the real continuation after the body by following
              the body's non-CompMerge successor path through JMP chains. }
            if MergeBlk = CompBody then begin
              NextBlk := -1;
              if (CompBody >= 0) and (CompBody < Length(FSF^.Blocks)) then begin
                for I := 0 to High(FSF^.Blocks[CompBody].Succs) do begin
                  S := FSF^.Blocks[CompBody].Succs[I];
                  P := 0; { safety counter }
                  while (S >= 0) and (S < Length(FSF^.Blocks)) and (P < 20) do begin
                    if S = CompMerge then Break; { leads to condition-failure exit }
                    if Length(FSF^.Blocks[S].Succs) <> 1 then Break; { not a JMP chain }
                    TmpFlag := True;
                    for J2 := 0 to High(FSF^.Blocks[S].Nodes) do
                      if not (FSF^.Blocks[S].Nodes[J2]^.Kind in
                              [SSA_JUMP, SSA_PHI, SSA_NOP]) then begin
                        TmpFlag := False; Break;
                      end;
                    if not TmpFlag then Break; { not JMP-only }
                    S := FSF^.Blocks[S].Succs[0];
                    Inc(P);
                  end;
                  if (S <> CompMerge) and (S > BIdx) then begin
                    NextBlk := S; Break;
                  end;
                end;
              end;
              if NextBlk > 0 then begin
                MergeBlk := NextBlk;
                if FOpts.Debug then
                  WriteLn(StdErr, 'CompoundCond: BB', BIdx,
                          ' fixed MergeBlk=BB', MergeBlk,
                          ' (was CompBody=BB', CompBody, ')');
              end;
            end;
            { Check if this is actually an or/and VALUE expression rather than
              a genuine if-condition.  Heuristic: if the merge block has a PHI
              with a LOADBOOL operand from the CompMerge path, the compound
              condition is a comparison-or/and expression like "b < c or d < e or f".
              In that case, skip the if-region and fall through to TryEmitOrAnd. }
            IsOuterJmpOnly := False; { reuse var: means "is value expression" }
            if (MergeBlk >= 0) and (MergeBlk < Length(FSF^.Blocks)) then begin
              for I := 0 to High(FSF^.Blocks[MergeBlk].Nodes) do begin
                OuterCondNode := FSF^.Blocks[MergeBlk].Nodes[I];
                if OuterCondNode^.Kind = SSA_PHI then begin
                  for J2 := 0 to High(OuterCondNode^.PhiBlocks) do begin
                    P := OuterCondNode^.PhiBlocks[J2];
                    if (P >= 0) and (P < Length(FSF^.Blocks)) then begin
                      { Check if this source block is a LOADBOOL block }
                      if (Length(FSF^.Blocks[P].Nodes) = 1) and
                         (FSF^.Blocks[P].Nodes[0]^.Kind = SSA_LOADBOOL) then begin
                        IsOuterJmpOnly := True; Break;
                      end;
                      { Also check if it's a JMP-->LOADBOOL block }
                      if (Length(FSF^.Blocks[P].Nodes) >= 1) then begin
                        for S := 0 to High(FSF^.Blocks[P].Nodes) do
                          if FSF^.Blocks[P].Nodes[S]^.Kind = SSA_LOADBOOL then begin
                            IsOuterJmpOnly := True; Break;
                          end;
                      end;
                      if IsOuterJmpOnly then Break;
                    end;
                  end;
                  if IsOuterJmpOnly then Break;
                end;
              end;
            end;
            if IsOuterJmpOnly then begin
              if FOpts.Debug then
                WriteLn(StdErr, 'CompoundCond BB', BIdx,
                ': detected value expression (LOADBOOL in merge PHI) MergeBlk=BB',
                MergeBlk, ' CompBody=', CompBody, ' CompMerge=', CompMerge);
              { Build the or/and chain by inverting the compound condition.
                De Morgan's law: NOT(a AND b) = (NOT a) OR (NOT b).
                The compound condition "b >= c and d >= e" becomes "b < c or d < e".
                Then append the fallback value from CompBody.
                Determine if it's an or-chain or and-chain from the LOADBOOL value
                at CompMerge: true --> or-chain, false --> and-chain. }
              begin
                { Find the LOADBOOL value at CompMerge to determine chain type }
                TmpFlag := False; { True if LOADBOOL is true }
                for I := 0 to High(FSF^.Blocks[CompMerge].Nodes) do
                  if FSF^.Blocks[CompMerge].Nodes[I]^.Kind = SSA_LOADBOOL then begin
                    { LOADBOOL value is in ImmA: 0=false, 1=true }
                    TmpFlag := (FSF^.Blocks[CompMerge].Nodes[I]^.ImmA > 0);
                    Break;
                  end;
                { Apply De Morgan's law to invert the compound condition }
                OuterCondExpr := ApplyDeMorgan(CompCond);
                { Find the fallback value expression from CompBody }
                ValExpr := '';
                if (CompBody >= 0) and (CompBody < Length(FSF^.Blocks)) then begin
                  for I := High(FSF^.Blocks[CompBody].Nodes) downto 0 do begin
                    OuterCondNode := FSF^.Blocks[CompBody].Nodes[I];
                    if OuterCondNode^.Kind in [SSA_JUMP, SSA_PHI, SSA_NOP] then Continue;
                    ValExpr := NodeExpr(OuterCondNode);
                    Break;
                  end;
                end;
                if (OuterCondExpr <> '') and (ValExpr <> '') then begin
                  { Build the full expression: inverted_chain or/and fallback }
                  if TmpFlag then
                    OuterCondExpr := OuterCondExpr + ' or ' + ValExpr
                  else
                    OuterCondExpr := OuterCondExpr + ' and ' + ValExpr;
                  if FOpts.Debug then
                    WriteLn(StdErr, 'DeMorgan result: ', OuterCondExpr);
                  { Emit non-branch content from BIdx first (e.g., CALL from
                    a preceding print(expr) when BIdx is both a merge block
                    and the start of a new boolean chain) }
                  EmitBlock(BIdx);
                  { Find the PHI at MergeBlk that holds the boolean result.
                    The result PHI is the one whose operand from CompMerge
                    traces back to a LOADBOOL node. Other PHIs at the merge
                    are for unrelated values (e.g., the function register). }
                  for I := 0 to High(FSF^.Blocks[MergeBlk].Nodes) do begin
                    OuterCondNode := FSF^.Blocks[MergeBlk].Nodes[I];
                    TmpFlag2 := False;
                    if OuterCondNode^.Kind = SSA_PHI then
                      for J2 := 0 to High(OuterCondNode^.PhiBlocks) do
                        if OuterCondNode^.PhiBlocks[J2] = CompMerge then begin
                          { Check if the operand from CompMerge is a LOADBOOL }
                          for P := 0 to High(FSF^.Blocks[CompMerge].Nodes) do
                            if (FSF^.Blocks[CompMerge].Nodes[P]^.Kind = SSA_LOADBOOL) and
                               (FSF^.Blocks[CompMerge].Nodes[P]^.Dest.Reg = OuterCondNode^.Dest.Reg) then begin
                              TmpFlag2 := True; Break;
                            end;
                          Break;
                        end;
                    if (OuterCondNode^.Kind = SSA_PHI) and TmpFlag2 then begin
                      S := NodeIdx(OuterCondNode^.Dest.Reg, OuterCondNode^.Dest.Version);
                      if (S >= 0) and (S < Length(FExprStr)) then
                        FExprStr[S] := OuterCondExpr;
                      { Emit the assignment for this PHI if it's a user local }
                      { Check if the PHI destination is a user local variable }
                      ValExpr := '';
                      if IsUserLocal(OuterCondNode^.Dest.Reg, OuterCondNode^.PC) then
                        ValExpr := LocalName(OuterCondNode^.Dest.Reg, OuterCondNode^.PC)
                      else if IsUserLocal(OuterCondNode^.Dest.Reg, OuterCondNode^.PC + 1) then
                        ValExpr := LocalName(OuterCondNode^.Dest.Reg, OuterCondNode^.PC + 1);
                      if ValExpr <> '' then
                        EmitLine(ValExpr + ' = ' + OuterCondExpr);
                    end;
                  end;
                  { Mark all intermediate blocks as emitted }
                  for I := BIdx to MergeBlk - 1 do
                    FEmitted[I] := True;
                  BIdx := MergeBlk;
                  Continue;
                end;
              end;
              { If chained PHI didn't work, fall through to TryEmitOrAnd }
            end else begin
              if FOpts.Debug then
                WriteLn(StdErr, 'CompoundCond: BB', BIdx, ' cond="', CompCond,
                        '" body=BB', CompBody, ' merge=BB', CompMerge,
                        ' MergeBlk=BB', MergeBlk);
              EmitIfRegionCompound(BIdx, CompBody, CompMerge, MergeBlk, CompCond);
              BIdx := MergeBlk;
              Continue;
            end;
          end;
          { If we didn't continue, we fall through to TryEmitOrAnd }
          if not IsOuterJmpOnly then Continue;
        end;
      end;
      { Try or/and VALUE expression pattern }
      if TryCacheBranchValueSelect(BIdx, Succ0, Succ1) then begin
        { value selection was cached on the merge PHI; advance to the merge
          so the normal SETTABLE/CALL emission consumes it once. }
        NextBlk := BIdx + 1;
        while (NextBlk < Length(FSF^.Blocks)) and FEmitted[NextBlk] and
              (NextBlk <> StopAt) do
          Inc(NextBlk);
        BIdx := NextBlk;
        Continue;
      end;

      if TryEmitOrAnd(BIdx, Succ0, Succ1) then begin
        { or/and consumed branch + both arms; advance past all emitted blocks }
        NextBlk := BIdx + 1;
        while (NextBlk < Length(FSF^.Blocks)) and FEmitted[NextBlk] and
              (NextBlk <> StopAt) do
          Inc(NextBlk);
        BIdx := NextBlk;
        Continue;
      end;
      { Check for break pattern: inside a loop, one branch leads to exit }
      if (CurrentLoopExit >= 0) and (TryEmitBreakIf(BIdx, Succ0, Succ1, NextBlk)) then begin
        BIdx := NextBlk;
        Continue;
      end;
      MergeBlk := FindMerge(BIdx, Succ0, Succ1);
      if (StopAt >= 0) and ((MergeBlk < 0) or (MergeBlk > StopAt)) then
        MergeBlk := StopAt;
      EmitIfRegion(BIdx, Succ0, Succ1, MergeBlk);
      { After emitting an if-region inside a loop: if the merge block IS
        the loop exit (all paths through the if leave the loop), we need
        an unconditional "break" statement. This handles the pattern:
          if cond then ... if inner then ... end break end }
      { (break is handled by TryEmitBreakIf above - no post-if check needed) }
      BIdx := MergeBlk;
      Continue;
    end;

    { Check if this RETURN block is followed by dead code (unreachable blocks
      with real statements).  If so, wrap the return in "do return end" so
      the dead code can be emitted after it - matching Lua's syntax for
      statements after an unconditional return/break. }
    TmpFlag := False;
    if (Length(Blk^.Succs) = 0) then begin
      if (BIdx + 1 < Length(FSF^.Blocks)) and (BIdx + 1 <> StopAt) and
         (not FEmitted[BIdx + 1]) and
         (Length(FSF^.Blocks[BIdx + 1].Preds) = 0) then begin
        for I := 0 to High(FSF^.Blocks[BIdx + 1].Nodes) do
          if not (FSF^.Blocks[BIdx + 1].Nodes[I]^.Kind in
                  [SSA_RETURN, SSA_NOP, SSA_JUMP, SSA_PHI]) then begin
            TmpFlag := True; Break;
          end;
      end;
    end;

    if TmpFlag then begin
      { Wrap return in do...end so dead code can follow.
        Use single-line "do return end" for bare returns (no values). }
      FEmitted[BIdx] := True;
      { Check if this is a bare return (no return values) }
      TmpFlag := True; { reuse: True = has return values }
      for I := 0 to High(Blk^.Nodes) do
        if Blk^.Nodes[I]^.Kind = SSA_RETURN then begin
          TmpFlag := (Blk^.Nodes[I]^.ImmB > 1); { ImmB=1 means 0 return values }
          Break;
        end;
      if not TmpFlag then
        EmitLine('do return end')
      else begin
        EmitLine('do');
        Indent;
        EmitBlock(BIdx);
        Dedent;
        EmitLine('end');
      end;
      Inc(BIdx);
      Continue;
    end;

    { Linear block }
    EmitBlock(BIdx);

    { Advance to the successor }
    if Length(Blk^.Succs) = 1 then begin
      { Check if this is a JMP-only block targeting the loop exit.
        If so, emit 'do break end' and advance sequentially (BIdx+1) instead
        of following the successor.  This handles "do break end" followed by
        dead code that should still appear inside the loop body. }
      if IsBreakTarget(BIdx) then begin
        EmitLine('do break end');
        Inc(BIdx);
      end else begin
        BIdx := Blk^.Succs[0];
      end;
    end
    else if Length(Blk^.Succs) = 0 then begin
      Break;
    end
    else begin
      { Multiple successors without a branch node detected -- just emit next }
      Inc(BIdx);
    end;
  end;
end;

{ ======================================================================
  Function header
  ====================================================================== }

function TDecompiler.FuncHeader: AnsiString;
var
  I: Integer;
  Params: AnsiString;
  Src: AnsiString;
begin
  Params := '';
  for I := 0 to FProto^.NumParams - 1 do begin
    if Params <> '' then Params := Params + ', ';
    Params := Params + LocalName(I, 0);
  end;
  { Lua 5.1: IsVarArg is a 3-bit field (bit 1 = VARARG_ISVARARG).
    Lua 5.2+: IsVarArg is a simple boolean (0 = no, 1 = yes). }
  if FSF^.LuaVersion >= $52 then begin
    if FProto^.IsVarArg <> 0 then begin
      if Params <> '' then Params := Params + ', ';
      Params := Params + '...';
    end;
  end else begin
    if (FProto^.IsVarArg and 2) <> 0 then begin
      if Params <> '' then Params := Params + ', ';
      Params := Params + '...';
    end;
  end;

  if FProto^.Source <> '' then
    Src := FProto^.Source
  else
    Src := '?';

  Result := 'function (' + Params + ')  -- ' + Src + ':' +
            IntToStr(FProto^.LineDefined);
end;

{ ======================================================================
  Run
  ====================================================================== }

function TDecompiler.Run(Mode: TRunMode): AnsiString;
var
  I, J, Reg, S, Idx: Integer;
  HasValDef, HasTForLoop: Boolean;
  BaseReg, PredBlk: Integer;
  N: PSSANode;
  DeclNames: AnsiString;
  RealNodeCount: Integer;
begin
  SetLength(FEmitted, Length(FSF^.Blocks));
  for I := 0 to High(FEmitted) do FEmitted[I] := False;

  { Initialize local declaration tracking.
    Function parameters are already declared by the function signature,
    so mark them. Parameters have StartPC = 0. }
  SetLength(FDeclared, Length(FProto^.LocVars));
  for I := 0 to High(FDeclared) do begin
    FDeclared[I] := False;
    { Mark function parameters as already declared:
      Parameters are LocVars whose StartPC = 0 and index < NumParams
      (plus the vararg parameter if present). }
    if I < FProto^.NumParams then
      FDeclared[I] := True;
    { Also mark internal for-loop variables as already declared
      (they are declared by the for syntax) }
    if (Length(FProto^.LocVars[I].Name) > 0) and
       (FProto^.LocVars[I].Name[1] = '(') then
      FDeclared[I] := True;
  end;
  { Initialize temp register declaration tracking for stripped mode.
    Parameters (a0, a1, ...) don't need local declarations. }
  SetLength(FTempDeclared, FProto^.MaxStack);
  for I := 0 to High(FTempDeclared) do
    FTempDeclared[I] := (I < FProto^.NumParams);

  CountUses;
  FoldConstants;
  BuildDefNodeMap;
  BindLocVarsToSSA;
  ComputeDoEndScopes;

  { Pre-mark generic for-loop setup nodes as inlined.
    When a TFORLOOP block has a predecessor with a MOVE/LOADNIL to the
    for-loop base register range, mark them so they aren't emitted as
    standalone statements before the for-loop. }
  for I := 0 to High(FSF^.Blocks) do begin
    HasTForLoop := False;
    for J := 0 to High(FSF^.Blocks[I].Nodes) do
      if FSF^.Blocks[I].Nodes[J]^.Kind = SSA_TFORLOOP then begin
        HasTForLoop := True;
        BaseReg := FSF^.Blocks[I].Nodes[J]^.ImmA;
        Break;
      end;
    if HasTForLoop then begin
      for J := 0 to High(FSF^.Blocks[I].Preds) do begin
        PredBlk := FSF^.Blocks[I].Preds[J];
        for S := 0 to High(FSF^.Blocks[PredBlk].Nodes) do begin
          N := FSF^.Blocks[PredBlk].Nodes[S];
          if (N^.Kind = SSA_MOVE) and (N^.Dest.Reg = BaseReg) then begin
            Idx := NodeIdx(N^.Dest.Reg, N^.Dest.Version);
            if (Idx >= 0) and (Idx < Length(FInlined)) then
              FInlined[Idx] := True;
          end;
          if (N^.Kind = SSA_LOADNIL) and
             (N^.Dest.Reg >= BaseReg) and (N^.Dest.Reg <= BaseReg + 4) then begin
            Idx := NodeIdx(N^.Dest.Reg, N^.Dest.Version);
            if (Idx >= 0) and (Idx < Length(FInlined)) then
              FInlined[Idx] := True;
          end;
        end;
      end;
    end;
  end;

  FStmtCount := 0;

  { Wrapper start (rmFunction only).
    Root vs sub-proto is determined structurally by the caller, not from
    debug metadata (LineDefined can be 0 for stripped sub-protos too). }
  if Mode = rmFunction then begin
    EmitStruct(FuncHeader);
    Indent;
  end;

  { Nil-init locals. rmChunk uses simple path; rmFunction/rmBodyOnly use
    sub-proto path (LOADNIL suppression, mutual-recursion CLOSURE groups).
    Both paths are semantically correct; they differ only in style:
    top-level emits "local x = nil" (LOADNIL not suppressed),
    sub-proto emits "local x" (LOADNIL suppressed, declaration implies nil). }
  if Mode = rmChunk then begin
    { --- Top-level nil-init path (simple) --- }
    I := FProto^.NumParams;
    { Skip implicit "arg" local in Lua 5.0/5.1 compat vararg functions }
    if (FSF^.LuaVersion <= $51) and
       (FProto^.IsVarArg and 1 <> 0) and (I <= High(FProto^.LocVars)) and
       (I = FProto^.NumParams) and (FProto^.LocVars[I].Name = 'arg') then begin
      FDeclared[I] := True;
      Inc(I);
    end;
    while I <= High(FProto^.LocVars) do begin
      if (FProto^.LocVars[I].StartPC = 0) and
         (Length(FProto^.LocVars[I].Name) > 0) and
         (FProto^.LocVars[I].Name[1] <> '(') then begin
        { Count how many consecutive LocVars share StartPC=0.
          If 2+ share the same StartPC, group them ALL into a single
          "local a, b, c" declaration, regardless of whether they have
          defining instructions (those become separate assignment statements).
          This handles "local a, b, c; a = 1; b = 2" patterns. }
        J := I + 1;
        while (J <= High(FProto^.LocVars)) and
              (FProto^.LocVars[J].StartPC = 0) and
              (Length(FProto^.LocVars[J].Name) > 0) and
              (FProto^.LocVars[J].Name[1] <> '(') do
          Inc(J);
        { J now points past the last LocVar with StartPC=0 }
        if J > I + 1 then begin
          { Multiple LocVars share StartPC=0 -> group them all }
          DeclNames := FProto^.LocVars[I].Name;
          FDeclared[I] := True;
          for Reg := I + 1 to J - 1 do begin
            DeclNames := DeclNames + ', ' + FProto^.LocVars[Reg].Name;
            FDeclared[Reg] := True;
          end;
          EmitLine('local ' + DeclNames);
          I := J;
          Continue;
        end;
        { Single LocVar with StartPC=0: check if it has a defining instruction }
        HasValDef := False;
        Reg := I;
        if (Reg < FProto^.MaxStack) and (Length(FSF^.Blocks) > 0) then begin
          for J := 0 to High(FSF^.Blocks[0].Nodes) do begin
            N := FSF^.Blocks[0].Nodes[J];
            if (N^.Dest.Reg = Reg) and (N^.PC = 0) and
               not (N^.Kind in [SSA_PHI, SSA_NOP, SSA_JUMP, SSA_BRANCH,
                                SSA_RETURN]) then begin
              HasValDef := True;
              Break;
            end;
          end;
        end;
        if not HasValDef then begin
          DeclNames := FProto^.LocVars[I].Name;
          FDeclared[I] := True;
          EmitLine('local ' + DeclNames);
          Inc(I);
          Continue;
        end;
      end;
      Inc(I);
    end;
  end else begin
    { --- Sub-proto nil-init path (rmFunction/rmBodyOnly) ---
      More sophisticated: LOADNIL suppression, mutual-recursion CLOSURE groups }
    I := FProto^.NumParams;
    { Skip implicit "arg" local in Lua 5.0/5.1 compat vararg functions.
      Only applies to 5.1 where bit 0 (VARARG_HASARG) indicates the implicit
      arg table. 5.2+ doesn't have this bit (IsVarArg is a simple boolean). }
    if (FSF^.LuaVersion <= $51) and
       (FProto^.IsVarArg and 1 <> 0) and (I <= High(FProto^.LocVars)) and
       (I = FProto^.NumParams) and (FProto^.LocVars[I].Name = 'arg') then begin
      FDeclared[I] := True;
      Inc(I);
    end;
    while I <= High(FProto^.LocVars) do begin
      if (FProto^.LocVars[I].StartPC = 0) and
         (Length(FProto^.LocVars[I].Name) > 0) and
         (FProto^.LocVars[I].Name[1] <> '(') then begin
        { Check if BB0 has a defining instruction at PC 0 for this register.
          Exclude LOADNIL: "local x" already implies nil, so a LOADNIL at
          the declaration point is redundant and should be suppressed. }
        HasValDef := False;
        Reg := I;
        if (Reg < FProto^.MaxStack) and (Length(FSF^.Blocks) > 0) then begin
          for J := 0 to High(FSF^.Blocks[0].Nodes) do begin
            N := FSF^.Blocks[0].Nodes[J];
            if (N^.Dest.Reg = Reg) and (N^.PC = 0) and
               not (N^.Kind in [SSA_PHI, SSA_NOP, SSA_JUMP, SSA_BRANCH,
                                SSA_RETURN, SSA_LOADNIL]) then begin
              { For SSA_CLOSURE at PC 0, treat as forward-declaration (not
                a value-def) when the next LocVar also starts at PC 0.
                This handles mutual recursion: local f, g; function f()...
                In 5.1, CLOSURE goes directly into the target register. }
              if (N^.Kind = SSA_CLOSURE) and
                 (I + 1 <= High(FProto^.LocVars)) and
                 (FProto^.LocVars[I + 1].StartPC = 0) and
                 (Length(FProto^.LocVars[I + 1].Name) > 0) and
                 (FProto^.LocVars[I + 1].Name[1] <> '(') then begin
                { Skip: CLOSURE is part of multi-local forward-decl group }
              end else begin
                HasValDef := True;
              end;
              Break;
            end;
          end;
        end;
        if not HasValDef then begin
          { Group consecutive nil-init locals }
          DeclNames := FProto^.LocVars[I].Name;
          FDeclared[I] := True;
          { Mark any LOADNIL at PC 0 for this register as inlined
            (the local declaration already implies nil) }
          if (I < FProto^.MaxStack) and (Length(FSF^.Blocks) > 0) then begin
            for J := 0 to High(FSF^.Blocks[0].Nodes) do begin
              N := FSF^.Blocks[0].Nodes[J];
              if (N^.Dest.Reg = I) and (N^.PC = 0) and
                 (N^.Kind = SSA_LOADNIL) then begin
                Idx := NodeIdx(N^.Dest.Reg, N^.Dest.Version);
                if (Idx >= 0) and (Idx < Length(FInlined)) then
                  FInlined[Idx] := True;
                Break;
              end;
            end;
          end;
          J := I + 1;
          while J <= High(FProto^.LocVars) do begin
            if (FProto^.LocVars[J].StartPC <> 0) or
               (Length(FProto^.LocVars[J].Name) = 0) or
               (FProto^.LocVars[J].Name[1] = '(') then
              Break;
            HasValDef := False;
            Reg := J;
            if (Reg < FProto^.MaxStack) and (Length(FSF^.Blocks) > 0) then begin
              for Reg := 0 to High(FSF^.Blocks[0].Nodes) do begin
                N := FSF^.Blocks[0].Nodes[Reg];
                if (N^.Dest.Reg = J) and (N^.PC = 0) and
                   not (N^.Kind in [SSA_PHI, SSA_NOP, SSA_JUMP, SSA_BRANCH,
                                    SSA_RETURN, SSA_LOADNIL]) then begin
                  { Same mutual-recursion check as the outer loop }
                  if (N^.Kind = SSA_CLOSURE) and
                     (J + 1 <= High(FProto^.LocVars)) and
                     (FProto^.LocVars[J + 1].StartPC = 0) and
                     (Length(FProto^.LocVars[J + 1].Name) > 0) and
                     (FProto^.LocVars[J + 1].Name[1] <> '(') then begin
                    { Skip: part of multi-local group }
                  end else begin
                    HasValDef := True;
                  end;
                  Break;
                end;
              end;
            end;
            if HasValDef then Break;
            DeclNames := DeclNames + ', ' + FProto^.LocVars[J].Name;
            FDeclared[J] := True;
            { Mark any LOADNIL at PC 0 for this register as inlined }
            if (J < FProto^.MaxStack) and (Length(FSF^.Blocks) > 0) then begin
              for Reg := 0 to High(FSF^.Blocks[0].Nodes) do begin
                N := FSF^.Blocks[0].Nodes[Reg];
                if (N^.Dest.Reg = J) and (N^.PC = 0) and
                   (N^.Kind = SSA_LOADNIL) then begin
                  Idx := NodeIdx(N^.Dest.Reg, N^.Dest.Version);
                  if (Idx >= 0) and (Idx < Length(FInlined)) then
                    FInlined[Idx] := True;
                  Break;
                end;
              end;
            end;
            Inc(J);
          end;
          EmitLine('local ' + DeclNames);
          I := J;
          Continue;
        end;
      end;
      Inc(I);
    end;
  end;

  { Common body emission (de-duplicated from the old if/else branches) }
  if Length(FSF^.Blocks) > 0 then begin
    EmitRegion(0, -1);
    { Close any remaining open do..end scopes after emission }
    while FActiveScopeTop > 0 do begin
      Dec(FActiveScopeTop);
      Dedent;
      EmitStruct('end');
    end;
  end;

  { SSA emission invariant: if proto has real code but we emitted nothing,
    something went wrong (e.g. body was silently dropped). Debug-only. }
  if FOpts.Debug then begin
    RealNodeCount := 0;
    for I := 0 to High(FSF^.Blocks) do
      for J := 0 to High(FSF^.Blocks[I].Nodes) do begin
        N := FSF^.Blocks[I].Nodes[J];
        if N^.IsMetaOnly then Continue;
        if not (N^.Kind in [SSA_PHI, SSA_NOP, SSA_JUMP, SSA_BRANCH]) then
          Inc(RealNodeCount);
      end;
    if (RealNodeCount > 0) and (FStmtCount = 0) then
      WriteLn(StdErr, 'WARNING: proto has ', RealNodeCount,
              ' real SSA nodes but emission produced 0 statements');
  end;

  { Wrapper end (rmFunction only) }
  if Mode = rmFunction then begin
    Dedent;
    EmitStruct('end');
  end;

  Result := FOutput.Text;
end;

{ ======================================================================
  Public API
  ====================================================================== }

function DecompileProto(Proto: PProto; const Opts: TDecompOptions): AnsiString;
var
  D: TDecompiler;
begin
  D := TDecompiler.Create(Proto, Opts);
  try
    Result := D.Run;
  finally
    D.Free;
  end;
end;

procedure DecompileProtoRec(Proto: PProto; const Opts: TDecompOptions;
                             Depth: Integer);
var
  I: Integer;
  Output: AnsiString;
  D: TDecompiler;
  InlinedProtos: array of Boolean;
begin
  if Proto = nil then Exit;

  D := TDecompiler.Create(Proto, Opts);
  try
    { Root proto (Depth=0) uses rmChunk; non-root protos use rmFunction
      for standalone function wrapper in recursive dump mode. }
    if Depth = 0 then
      Output := D.Run
    else
      Output := D.Run(rmFunction);
    { Copy inlined protos info before freeing }
    SetLength(InlinedProtos, Length(D.FInlinedProtos));
    for I := 0 to High(InlinedProtos) do
      InlinedProtos[I] := D.FInlinedProtos[I];
  finally
    D.Free;
  end;

  if Depth > 0 then
    WriteLn('-- [nested proto at depth ', Depth, '] --');
  Write(Output);

  for I := 0 to High(Proto^.P) do begin
    { Skip sub-protos that were inlined into the parent function body }
    if (I < Length(InlinedProtos)) and InlinedProtos[I] then
      Continue;
    DecompileProtoRec(Proto^.P[I], Opts, Depth + 1);
  end;
end;

procedure DecompileChunk(const Chunk: TLuaChunk; const Opts: TDecompOptions);
var
  Ver : byte;
begin
  Ver := Chunk.Header.Version;
  WriteLn('-- Decompiled by cLuaDecompiler (Lua 5.1 to 5.5 Decompiler) --');
  WriteLn('-- Contact: Coldzer0@protonmail.ch | Discord : Coldzer0 --');
  WriteLn('-- Copyright (c) 2019 - 2026 --');
  WriteLn(Format('-- "%s" was compiled with Lua %d.%d --', [Opts.FileName, (Ver shr 4), (Ver and $0F)]));
  WriteLn;
  DecompileProtoRec(Chunk.Root, Opts, 0);
end;

end.
