local target = assert(arg and arg[1], "missing target chunk")

local function inert()
  local proxy = {}
  local mt = {
    __index = function(t, key)
      local value = inert()
      rawset(t, key, value)
      return value
    end,
    __call = function()
      return inert()
    end
  }
  return setmetatable(proxy, mt)
end

function RequireScript(name)
  if name == "LyShineUI._Common.EntitlementsDataHandler" then
    return {
      ShopCurrencyType = {
        Coin = 0,
        PlayerLevel = 1,
        Progression = 2,
        Item = 3
      },
      GetListingCosts = function()
        return { coinCost = 0, progressionCosts = {}, itemCosts = {} }
      end
    }
  end
  return inert()
end

local module = assert(dofile(target))
local keys = {}
for key, value in pairs(module) do
  keys[#keys + 1] = tostring(key) .. ":" .. type(value)
end
table.sort(keys)
print(table.concat(keys, "\n"))
