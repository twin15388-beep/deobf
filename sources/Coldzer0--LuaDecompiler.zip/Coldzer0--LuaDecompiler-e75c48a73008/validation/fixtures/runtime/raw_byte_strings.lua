-- versions: 51 52 53 54 55

local samples = {
  "A\000B",
  "\0012",
  "\001\002\031\032\034\092\127\128\255",
  "\010\013\009end"
}

for i, value in ipairs(samples) do
  local bytes = {}
  for j = 1, #value do
    bytes[#bytes + 1] = string.byte(value, j)
  end
  print(i .. ":" .. table.concat(bytes, ","))
end
