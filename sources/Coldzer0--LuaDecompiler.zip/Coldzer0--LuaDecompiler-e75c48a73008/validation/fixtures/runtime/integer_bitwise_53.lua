-- versions: 53 54 55

local a = 0xF0
local b = 0x0F
local x = (a | b) ~ 0x33
local y = (x & 0xFF) >> 2
local z = (y << 1) // 3

print("bitwise", x, y, z)
