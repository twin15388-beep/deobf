-- versions: 51 52 53 54 55

local log = {}

local monitor = {
  enabled = true
}

function monitor:enable(name, stage)
  log[#log + 1] = "enable:" .. name .. ":" .. stage
end

function monitor:disable(name)
  log[#log + 1] = "disable:" .. name
end

function monitor:evaluate(name, value)
  if value and value > 0 and self.enabled then
    local stage = "stage1"
    if value > 1 then
      stage = "stage2"
    end
    self:enable(name, stage)
  else
    self:disable(name)
  end
end

monitor:evaluate("missing", nil)
monitor:evaluate("zero", 0)
monitor:evaluate("one", 1)
monitor.enabled = false
monitor:evaluate("disabled", 2)

print(table.concat(log, "|"))
