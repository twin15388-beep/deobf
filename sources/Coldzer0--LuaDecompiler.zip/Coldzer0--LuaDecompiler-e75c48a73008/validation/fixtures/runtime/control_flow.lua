-- versions: 51 52 53 54 55

local function classify(n)
  local acc = 0
  for i = 1, n do
    if i % 5 == 0 then
      acc = acc + 50
    elseif i % 2 == 0 then
      acc = acc + i
    else
      acc = acc - 1
    end
  end

  local guard = n
  while guard > 0 do
    if guard == 3 then
      break
    end
    guard = guard - 1
  end

  repeat
    acc = acc - 3
  until acc < 40

  return acc, guard
end

local a, b = classify(8)
print("control", a, b)
