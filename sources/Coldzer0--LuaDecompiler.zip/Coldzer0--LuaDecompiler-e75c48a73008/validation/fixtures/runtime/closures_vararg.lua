-- versions: 51 52 53 54 55

local function make_counter(start)
  local value = start
  return function(step)
    value = value + step
    return value
  end
end

local function collect(...)
  local out = {}
  for i = 1, select("#", ...) do
    out[i] = select(i, ...)
  end
  return out
end

local next_value = make_counter(10)
local packed = collect(next_value(2), next_value(5), "done")
print("closure", packed[1], packed[2], packed[3])
