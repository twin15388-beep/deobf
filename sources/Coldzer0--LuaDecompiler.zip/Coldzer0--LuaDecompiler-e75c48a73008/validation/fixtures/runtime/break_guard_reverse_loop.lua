-- versions: 51 52 53 54 55

local state = {
  enabled = true,
  items = {1, 2, 3, 4}
}

local out = {}

for i = #state.items, 1, -1 do
  if not state.enabled then
    break
  end

  local item = state.items[i]
  out[#out + 1] = item

  if item == 3 then
    state.enabled = false
  end
end

print(table.concat(out, "|"))
