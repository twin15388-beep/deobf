-- versions: 51 52 53 54 55

local function compare_like_common(left, right)
  if left == right then
    return true
  elseif type(left) == "table" then
    if type(right) ~= "table" then
      return false
    end
    return true
  else
    return false
  end
end

local out = {}
out[#out + 1] = tostring(compare_like_common(1, 2))
out[#out + 1] = tostring(compare_like_common(1, {}))
out[#out + 1] = tostring(compare_like_common({}, 1))
out[#out + 1] = tostring(compare_like_common({}, {}))
out[#out + 1] = tostring(compare_like_common("x", "x"))

print(table.concat(out, "|"))
