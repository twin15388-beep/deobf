-- versions: 5.1 5.2 5.3 5.4 5.5

local helpers = {}

function helpers.merge(base, overlay)
  if not overlay then
    return base
  end

  local out = {}
  for key, value in pairs(base) do
    out[key] = value
  end
  for key, value in pairs(overlay) do
    out[key] = value
  end
  return out
end

local merged = helpers.merge({a = 1, c = 9}, {b = 2, a = 3})
print(merged.a .. "|" .. merged.b .. "|" .. merged.c)
