-- versions: 51 52 53 54 55

local log = {}

local timeline = {}

function timeline:Add(options)
  if options.onComplete then
    options.onComplete()
  else
    log[#log + 1] = "none"
  end
end

function timeline:Play()
  log[#log + 1] = "play"
end

local owner = {name = "owner"}

local function create_pulse(options)
  options = options or {}
  options.playOnce = options.playOnce or false

  local callback = options.onComplete
  if options.onComplete then
    callback = function()
      options.onComplete(owner.name)
    end
  else
    if not options.playOnce then
      callback = function()
        timeline:Play()
      end
    end
  end

  timeline:Add({onComplete = callback})
end

create_pulse({onComplete = function(value)
  log[#log + 1] = "done:" .. value
end})
create_pulse({playOnce = false})
create_pulse({playOnce = true})

print(table.concat(log, "|"))
