-- versions: 51 52 53 54 55

local function fold(values)
  local sum = 0
  local product = 1
  for i = 1, #values do
    sum = sum + values[i]
    product = product * (values[i] + 1)
  end
  return sum, product
end

local values = {1, 3, 5, 7}
local sum, product = fold(values)
local record = {
  name = "core",
  sum = sum,
  product = product,
  nested = {values[1], values[#values]}
}

print(record.name, record.sum, record.product, record.nested[1], record.nested[2])
