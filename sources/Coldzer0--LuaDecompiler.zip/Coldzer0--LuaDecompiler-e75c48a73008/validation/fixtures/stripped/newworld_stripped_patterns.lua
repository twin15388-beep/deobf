function EntityId()
  return 42
end

function RequireScript(name)
  if name == "LyShineUI.UiDataLayer" then
    return {
      ClearDataTree = function(self, id)
        print("clear", id)
      end
    }
  end
  return {
    WorldVectorToTable = function(self, data)
      return "world:" .. data
    end
  }
end

local module = {
  Properties = {
    CloseButton = {
      default = EntityId()
    }
  },
  callbackTable = {}
}

local dataLayer = RequireScript("LyShineUI.UiDataLayer")
local worldListCommon = RequireScript("LyShineUI._Common.WorldListCommon")

function module:OnActivate()
  dataLayer:ClearDataTree(3766102462)
end

function module:OnWorldListData(payload)
  local raw = payload and payload:GetData()
  local fallback
  if (payload:GetData() or fallback) == nil then
    print("missing")
    return
  end
  print(worldListCommon:WorldVectorToTable(payload:GetData() or fallback))
end

local payload = {
  GetData = function(self)
    return "ok"
  end
}

print(module.Properties.CloseButton.default)
module:OnActivate()
module:OnWorldListData(payload)
