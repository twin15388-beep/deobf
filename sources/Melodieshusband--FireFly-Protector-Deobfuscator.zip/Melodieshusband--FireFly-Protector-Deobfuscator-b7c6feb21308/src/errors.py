class BlockFail(Exception):
    pass
