# Third-party code

## unluac

Source recovery uses the unmodified `unluac_2025_12_23.jar`, version 1.2.3.569,
from the [official unluac project](https://sourceforge.net/projects/unluac/).

- Download: [unluac_2025_12_23.jar](https://sourceforge.net/projects/unluac/files/Unstable/unluac_2025_12_23.jar/download)
- SHA-256: `98be0fa84ac73ca66dce2842a2e4512226f4c611b6500dc96415571fc5538fcc`
- License: [MIT](src/luraph_deobfuscator/vendor/UNLUAC-LICENSE.txt)
- Upstream source: [SourceForge repository](https://sourceforge.net/p/unluac/hgcode/ci/default/tree/)

The wheel and source distribution include the JAR and its license. Source
recovery verifies the JAR's checksum before launching Java. The JAR was
downloaded from upstream; this project does not claim to reproduce its build.

## Prior work

The WeAreDevs backend uses [luaparser 4.2.0](https://github.com/boolangery/py-lua-parser),
an MIT-licensed Python dependency installed with this package. Its dependencies
include the BSD-licensed ANTLR Python runtime and MIT-licensed multimethod.

The [WeAreDevs page](https://wearedevs.net/obfuscator) links to
[wcrddn/Prometheus](https://github.com/wcrddn/Prometheus). That repository was used
as a format reference. Its obfuscator runtime and implementation are not bundled
or copied into this CLI; the recovery passes and public fixtures were written
independently.

[PhoenixZeng/LuraphDeobfuscator](https://github.com/PhoenixZeng/LuraphDeobfuscator)
inspired this project. This CLI is an independent implementation; it does not
bundle that repository's source or claim compatibility with its version range.
