"""Authored fixtures for the supported structure; no third-party payloads."""

import base64
import math
import random


def quoted(data):
    if isinstance(data, str):
        data = data.encode()
    return '"' + "".join(f"\\{byte:03d}" for byte in data) + '"'


def fixture(blocks=None, *, constants=(b"hello",), seed=1, entry="entry", returns="out"):
    if blocks is None:
        blocks = {"entry": "out = {C(@constant0@)}; pc = nil"}
    rng = random.Random(seed)
    alphabet = list("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/")
    rng.shuffle(alphabet)
    alphabet = "".join(alphabet)
    standard = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
    translation = bytes.maketrans(standard, alphabet.encode())
    packed = [base64.b64encode(c).translate(translation) for c in constants]
    offset = rng.randrange(100, 99999)
    labels = dict(zip(blocks, rng.sample(range(100, 1_000_000), len(blocks)), strict=True))
    replacements = {f"@{name}@": str(label) for name, label in labels.items()}
    replacements.update({f"@constant{i}@": str(offset + i + 1) for i in range(len(constants))})

    def link(code):
        for before, after in replacements.items():
            code = code.replace(before, after)
        return code

    ordered = sorted(blocks, key=labels.get)

    def dispatch(names):
        if len(names) == 1:
            return link(blocks[names[0]])
        at = len(names) // 2
        return f"if pc < ({labels[names[at]] + 17} - 17) then\n{dispatch(names[:at])}\nelse\n{dispatch(names[at:])}\nend"

    source = f"""--!strict
return (function(...)
local data = {{{", ".join(quoted(c) for c in reversed(packed))}}}
for i = 1, math.floor(#data / 2) do
    data[i], data[#data - i + 1] = data[#data - i + 1], data[i]
end
local alphabet = {quoted(alphabet)}
local digits = {{}}
for i = 1, 64 do digits[string.sub(alphabet, i, i)] = i - 1 end
for i = 1, #data do
    local encoded, result, accumulator, bits = data[i], {{}}, 0, 0
    for j = 1, #encoded do
        local digit = digits[string.sub(encoded, j, j)]
        if digit then
            accumulator, bits = accumulator * 64 + digit, bits + 6
            if bits >= 8 then
                bits = bits - 8
                table.insert(result, string.char(math.floor(accumulator / 2 ^ bits)))
                accumulator = accumulator % 2 ^ bits
            end
        end
    end
    data[i] = table.concat(result)
end
local function C(index) return data[index - {offset}] end
return (function(env, unpacker, newproxy, setmeta, getmeta, select, argv, dispatch, make, heap, alloc, release, retain, counter)
dispatch, make, heap, alloc, release, retain, counter =
function(pc, args, caps, guard)
    local out, x, y, z, t, a, b, c, d, e, f, g, h, i, j, k, cache, pool, chars, s45, s8, floor, remove, char, length, random, byte, provider, decrypt, view
    while pc do
        {dispatch(ordered)}
    end
    pc = #guard
    return unpacker({returns})
end,
function(entry, captures)
    local proxy = retain(captures)
    local callable = function(...) return dispatch(entry, {{...}}, captures, proxy) end
    return callable
end,
{{}},
function() counter = counter + 1; heap[counter] = false; return counter end,
function(id) heap[id] = heap[id]; if false then heap[id] = nil end end,
function(captures) return {{}} end,
0
return make({labels[entry]}, {{}})(unpacker(argv))
end)(getfenv and getfenv() or _ENV, unpack or table.unpack, newproxy, setmetatable, getmetatable, select, {{...}})
end)(...)
"""
    return source.encode()


def encrypted(data, seed, mul45, add45, mul8, previous):
    state, byte_state, stack = seed % 2**45, seed % 255 + 2, []
    output = bytearray()
    for plain in data:
        if not stack:
            state = (float(state) * mul45 + add45) % 2**45
            while True:
                byte_state = byte_state * mul8 % 257
                if byte_state != 1:
                    break
            shift = byte_state % 32
            part = math.floor(state / 2 ** (13 - (byte_state - shift) / 32)) % 2**32 / 2**shift
            word = math.floor(part % 1 * 2**32) + math.floor(part)
            stack = [(word >> shift) & 255 for shift in (0, 8, 16, 24)]
        output.append((plain - previous - stack.pop()) % 256)
        previous = plain
    return bytes(output)


def cipher_fixture(
    data=b"https://example.invalid/authored-test",
    *,
    seed=912345678,
    mul45=5,
    add45=123456789,
    mul8=3,
    previous=97,
    layout=1,
):
    blocks = {
        "entry": """floor = env["math"]["floor"]; random = env["math"]["random"];
            remove = env["table"]["remove"]; char = env["string"]["char"];
            cache = alloc(); pool = alloc(); chars = alloc(); s45 = alloc(); s8 = alloc();
            heap[cache] = {}; heap[pool] = {}; heap[chars] = {}; heap[s45] = 0; heap[s8] = 2;
            x = {}; i = 1; pc = @fill@""",
        "fill": "x[i] = i; i = i + 1; pc = (i <= 256) and @fill@ or @shuffle@",
        "shuffle": "i = random(1, #x); j = remove(x, i); heap[chars][j] = char(j - 1); pc = (#x > 0) and @shuffle@ or @invoke@",
        "invoke": f"""provider = make(@random_entry@, {{pool, s45, s8}});
            decrypt = make(@decode_entry@, {{cache, pool, chars, s45, s8, provider}});
            view = env["setmetatable"]({{}}, {{__index = heap[cache]}});
            x = decrypt(C(@constant0@), {seed}); y = view[x]; out = {{y}}; pc = nil""",
        "random_entry": "pc = (#heap[caps[1]] == 0) and @random_word@ or @random_return@",
        "random_word": f"heap[caps[2]] = (heap[caps[2]] * {mul45} + {add45}) % 35184372088832; pc = @random_byte@",
        "random_byte": f"heap[caps[3]] = heap[caps[3]] * {mul8} % 257; pc = (heap[caps[3]] == 1) and @random_byte@ or @random_rotate@",
        "random_rotate": """x = heap[caps[3]] % 32;
            floor = env["math"]["floor"];
            y = floor(heap[caps[2]] / 2 ^ (13 - (heap[caps[3]] - x) / 32)) % 4294967296 / 2 ^ x;
            z = floor(y % 1 * 4294967296) + floor(y);
            heap[caps[1]] = {z % 256, floor(z / 256) % 256, floor(z / 65536) % 256, floor(z / 16777216) % 256};
            pc = @random_return@""",
        "random_return": 'remove = env["table"]["remove"]; out = {remove(heap[caps[1]])}; pc = nil',
        "decode_entry": "x = args[1]; y = args[2]; pc = heap[caps[1]][y] and @decode_return@ or @decode_init@",
        "decode_init": f"""heap[caps[2]] = {{}}; heap[caps[4]] = y % 35184372088832;
            heap[caps[5]] = y % 255 + 2; heap[caps[1]][y] = "";
            z = {previous}; i = 1; pc = @decode_head@""",
        "decode_head": "pc = (i <= #x) and @decode_body@ or @decode_return@",
        "decode_body": """byte = env["string"]["byte"]; provider = caps[6];
            z = (byte(x, i) + provider() + z) % 256;
            heap[caps[1]][y] = heap[caps[1]][y] .. heap[caps[3]][z + 1];
            i = i + 1; pc = @decode_head@""",
        "decode_return": "out = {y}; pc = nil",
    }
    return fixture(
        blocks, constants=[encrypted(data, seed, mul45, add45, mul8, previous)], seed=layout
    )
