"""Small, authored test programs. No obfuscator output or user code is bundled."""

import lzma
import struct

from luraph_deobfuscator.profiles.buffer_v1 import KEY


def varint(value):
    if value < 0:
        value += 2**53
    result = bytearray()
    while value >= 128:
        result.append((value & 127) | 128)
        value >>= 7
    result.append(value)
    return bytes(result)


def encrypt(data):
    return bytes(value ^ KEY[index % 8] for index, value in enumerate(data))


def cipher_string(value, seed=17):
    data = bytearray((1, seed))
    for byte in value:
        seed = (seed * 249 + 119) % 256
        data.append(byte ^ seed ^ 33)
    return bytes(data)


def constant(value):
    if isinstance(value, bool):
        return bytes((138 if value else 23,))
    if isinstance(value, (int, float)):
        return bytes((41,)) + struct.pack("<d", -value)
    if isinstance(value, str):
        value = value.encode("utf8")
    data = cipher_string(value)
    return bytes((116,)) + varint(len(data)) + data


def instruction(opcode, *, t=0, r=0, n=0, R=None, h=None, d=None, child=None):
    packed = [t * 8, r * 8, n * 8]
    for field, value in ((0, d), (1, R), (2, h)):
        if value is not None:
            packed[field] = value * 8 + 1
    if child is not None:
        packed[2] = child * 8 + 3
    return b"".join(varint(value) for value in (opcode, *packed))


def prototype(*instructions, registers=8, captures=()):
    header = varint(registers) + varint(0) + varint(len(captures))
    header += b"".join(varint(source * 4 + mode) for source, mode in captures)
    return header + struct.pack("<I", 0) + varint(len(instructions) + 6169) + b"".join(instructions)


def payload(constants, *prototypes, root=1):
    data = varint(len(constants) + 83908) + b"\x01"
    data += b"".join(constant(value) for value in constants)
    data += varint(len(prototypes) + 61504) + b"".join(prototypes) + varint(root)
    return encrypt(data)


def greeting(message="hello"):
    return payload(
        [message],
        prototype(
            instruction(66, n=1),
            instruction(140, n=2, R=1),
            instruction(23, r=1),
            instruction(58),
        ),
    )


def value_capture(mode=1):
    return payload(
        ["before", "after"],
        prototype(
            instruction(140, n=1, R=1),
            instruction(180, t=2, child=2),
            instruction(140, n=1, R=2),
            instruction(95, r=2),
        ),
        prototype(
            instruction(5, r=1, t=0),
            instruction(95, r=1),
            captures=[(1, mode)],
        ),
    )


def encode85(data):
    data += bytes(-len(data) % 4)
    result = bytearray()
    for offset in range(0, len(data), 4):
        value = int.from_bytes(data[offset : offset + 4], "little")
        if value == 0:
            result.extend(b"z")
            continue
        digits = bytearray(5)
        for index in range(4, -1, -1):
            value, digit = divmod(value, 85)
            digits[index] = digit + 33
        result.extend(digits)
    return bytes(result)


def compressed(data):
    return lzma.compress(
        data,
        format=lzma.FORMAT_RAW,
        filters=[
            {
                "id": lzma.FILTER_LZMA1,
                "dict_size": 1 << 20,
                "lc": 3,
                "lp": 0,
                "pb": 0,
            }
        ],
    )


def wrapper(vm=b"return function() end", data=b"synthetic payload"):
    blocks = [b"LPH!" + encode85(compressed(value)) for value in (vm, data)]
    return b"--!strict\nreturn [====[" + blocks[0] + b"]====], [====[" + blocks[1] + b"]====]\n"
