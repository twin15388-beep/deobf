import json
import struct
import unittest

from luraph_deobfuscator.api import HEADER, read_program, recover
from luraph_deobfuscator.errors import DeobfuscationError
from luraph_deobfuscator.normalize import lua_equal, truth
from luraph_deobfuscator.profiles.buffer_v1 import Reader, decode_string, read_payload
from luraph_deobfuscator.source import restore_multireturn

from .fixtures import (
    cipher_string,
    encrypt,
    greeting,
    instruction,
    payload,
    prototype,
    varint,
    wrapper,
)


class RecoveryTests(unittest.TestCase):
    def test_reads_changed_input(self):
        first = json.loads(recover(greeting(), emit="ir", raw_payload=True))
        second = json.loads(recover(greeting("changed"), emit="ir", raw_payload=True))
        self.assertEqual(first["constants"], ["hello"])
        self.assertEqual(second["constants"], ["changed"])
        self.assertNotEqual(first["functions"], second["functions"])

    def test_emits_real_lua51_header(self):
        self.assertTrue(recover(greeting(), emit="lua51", raw_payload=True).startswith(HEADER))

    def test_fingerprint_rejection(self):
        with self.assertRaisesRegex(DeobfuscationError, "fingerprint"):
            read_program(wrapper())

    def test_all_numeric_encodings(self):
        data = varint(83908 + 9) + b"\0"
        values = [
            (-123, 24, "i"),
            (1.5, 41, "d"),
            (65535, 42, "H"),
            (4294967295, 64, "I"),
            (128, 65, "B"),
            (-32768, 77, "h"),
            (255, 95, "B"),
            (1.25, 114, "f"),
            (-9876543210, 139, "q"),
        ]
        for value, tag, fmt in values:
            data += bytes((tag,)) + struct.pack("<" + fmt, value)
        self.assertEqual(
            Reader(encrypt(data)).constants(),
            [-123, 1.5, 65535, 4294967295, -128, -32768, 255, 1.25, -9876543210],
        )

    def test_encrypted_constants_and_binary_strings(self):
        values = [False, True, 0, -42.5, "héllo", b"\xff\0\x80"]
        program = read_payload(payload(values, prototype(instruction(58))))
        self.assertEqual(program.constants[:5], values[:5])
        self.assertEqual(program.constants[5].encode("utf8", "surrogateescape"), values[5])

    def test_string_cipher(self):
        data = bytes(range(256))
        self.assertEqual(decode_string(cipher_string(data)), data)
        self.assertEqual(decode_string(b"\0literal"), b"literal")
        for value in (b"", b"\x01"):
            with self.assertRaises(DeobfuscationError):
                decode_string(value)

    def test_signed_varints_and_rejection(self):
        for value in (-123, 0, 123, 2**51):
            self.assertEqual(Reader(encrypt(varint(value))).signed(), value)
        for value in (b"\x80" * 9, b"\x80\0", varint(2**53 + 1)):
            with self.assertRaises(DeobfuscationError):
                Reader(encrypt(value)).varint()

    def test_truncated_and_trailing_payload(self):
        data = greeting()
        for invalid in (data[:5], data[:-1], data + b"\0"):
            with self.assertRaises(DeobfuscationError):
                read_payload(invalid)

    def test_expansion_budget(self):
        reader = Reader(b"")
        for _ in range(10):
            reader.account(100000)
        with self.assertRaisesRegex(DeobfuscationError, "expansion limit"):
            reader.account(1)

    def test_invalid_root_and_constant_reference(self):
        for value in (
            payload([], prototype(instruction(58)), root=2),
            payload([], prototype(instruction(140, n=1, R=1))),
        ):
            with self.assertRaises(DeobfuscationError):
                read_payload(value)

    def test_unsupported_instruction_and_invalid_target(self):
        for ins in (instruction(2), instruction(69, n=999), instruction(110, n=2**40)):
            with self.assertRaises(DeobfuscationError):
                recover(payload([], prototype(ins, instruction(58))), emit="ir", raw_payload=True)

    def test_constant_truthy_branch_skips_unreachable_opcode(self):
        data = payload(
            [0],
            prototype(
                instruction(140, n=1, R=1),
                instruction(31, r=1, t=3),
                instruction(2),
                instruction(58),
            ),
        )
        result = json.loads(recover(data, emit="ir", raw_payload=True))
        self.assertEqual(len(result["functions"][0]["instructions"]), 2)

    def test_recursive_prototype_graph_fails(self):
        data = payload([], prototype(instruction(180, t=1, child=1), instruction(58)))
        with self.assertRaisesRegex(DeobfuscationError, "Recursive"):
            recover(data, emit="lua51", raw_payload=True)

    def test_open_call_overlap_with_reference_capture_is_rejected(self):
        data = payload(
            ["stale"],
            prototype(
                instruction(140, n=3, R=1),
                instruction(180, t=2, child=2),
                instruction(74, n=2, r=1, t=0),
                instruction(95, r=2),
            ),
            prototype(instruction(5, r=1, t=0), instruction(95, r=1), captures=[(3, 0)]),
        )
        with self.assertRaisesRegex(DeobfuscationError, "overlaps reference captures"):
            recover(data, emit="lua51", raw_payload=True)

    def test_open_retained_call_boundary_is_rejected(self):
        data = payload(
            [],
            prototype(
                instruction(110, n=2),
                instruction(74, n=1, r=0, t=2),
                instruction(95, r=2),
            ),
        )
        with self.assertRaisesRegex(DeobfuscationError, "retained boundary"):
            recover(data, emit="lua51", raw_payload=True)

    def test_source_rejects_fixed_three_result_call(self):
        data = payload(
            [],
            prototype(instruction(110, n=1), instruction(74, n=1, r=1, t=4), instruction(58)),
        )
        with self.assertRaisesRegex(DeobfuscationError, "three or more results"):
            recover(data, raw_payload=True)

    def test_lua_truth_and_equality(self):
        self.assertTrue(truth(0))
        self.assertTrue(truth(""))
        self.assertFalse(truth(False))
        self.assertFalse(truth(None))
        self.assertFalse(lua_equal(False, 0))
        self.assertTrue(lua_equal(1, 1.0))

    def test_open_result_call_is_packed_and_forwarded(self):
        source = "L1_1, L2_1, L3_1 = producer()\nconsumer(L1_1, L2_1, L3_1)\n"
        result = restore_multireturn(source, 1)
        self.assertIn("table.pack(producer())", result)
        self.assertIn("consumer(table.unpack(returns_1, 1, returns_1.n))", result)
        self.assertTrue(result.startswith("--!strict\n"))

    def test_ambiguous_open_result_is_rejected(self):
        for source, expected in [("return 1\n", 1), ("L1_1, L2_1, L3_1 = producer()\nreturn\n", 1)]:
            with self.assertRaises(DeobfuscationError):
                restore_multireturn(source, expected)
