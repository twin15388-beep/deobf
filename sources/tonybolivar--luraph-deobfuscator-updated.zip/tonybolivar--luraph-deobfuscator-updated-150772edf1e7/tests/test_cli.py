import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from luraph_deobfuscator.cli import write_output
from luraph_deobfuscator.errors import DeobfuscationError

from .fixtures import greeting, wrapper


class CliTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.folder = Path(self.temp.name)
        self.input = self.folder / "example file.lua"
        self.input.write_bytes(greeting())

    def cli(self, *args):
        return subprocess.run(
            [sys.executable, "-m", "luraph_deobfuscator", *map(str, args)],
            capture_output=True,
            timeout=30,
            check=False,
        )

    def test_version_and_profiles(self):
        self.assertIn(b"0.2.0", self.cli("--version").stdout)
        self.assertEqual(json.loads(self.cli("--list-profiles").stdout)[0]["name"], "buffer-v1")

    def test_bare_output_path_and_no_clobber(self):
        args = [self.input, "--raw-payload", "--emit", "ir", "-o"]
        self.assertEqual(self.cli(*args).returncode, 0)
        target = self.folder / "example file.deobfuscated.json"
        self.assertEqual(json.loads(target.read_text())["constants"], ["hello"])
        target.write_text("keep this")
        self.assertEqual(self.cli(*args).returncode, 1)
        self.assertEqual(target.read_text(), "keep this")
        self.assertEqual(self.cli(*args, "--force").returncode, 0)

    def test_custom_output_and_stdout(self):
        result = self.cli(self.input, "--raw-payload", "--emit", "ir")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout)["constants"], ["hello"])
        target = self.folder / "custom.json"
        result = self.cli(self.input, "--raw-payload", "--emit", "ir", "-o", target)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, b"")
        self.assertTrue(target.exists())

    def test_refuses_input_overwrite_even_with_force(self):
        before = self.input.read_bytes()
        result = self.cli(self.input, "--raw-payload", "-o", self.input, "--force")
        self.assertEqual(result.returncode, 1)
        self.assertEqual(self.input.read_bytes(), before)

    def test_refuses_hardlink_to_input(self):
        alias = self.folder / "alias.lua"
        os.link(self.input, alias)
        result = self.cli(self.input, "--raw-payload", "-o", alias, "--force")
        self.assertEqual(result.returncode, 1)
        self.assertIn(b"different from the input", result.stderr)

    def test_atomic_write_preserves_existing_file(self):
        with self.assertRaises(DeobfuscationError):
            write_output(self.input, b"replacement")
        self.assertEqual(self.input.read_bytes(), greeting())
        self.assertEqual(list(self.folder.iterdir()), [self.input])

    def test_unpack_and_existing_directory(self):
        self.input.write_bytes(wrapper())
        target = self.folder / "layers"
        result = self.cli(self.input, "--unpack", target)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual((target / "payload.bin").read_bytes(), b"synthetic payload")
        self.assertTrue((target / "vm.luau").read_bytes().startswith(b"--!strict\n"))
        self.assertIsNone(json.loads((target / "manifest.json").read_text())["profile"])
        self.assertEqual(self.cli(self.input, "--unpack", target).returncode, 1)

    def test_usage_and_missing_file_errors(self):
        self.assertEqual(self.cli().returncode, 2)
        self.assertEqual(self.cli(self.input, "--unpack", self.folder, "-o").returncode, 2)
        result = self.cli(self.folder / "missing.lua")
        self.assertEqual(result.returncode, 1)
        self.assertNotIn(b"Traceback", result.stderr)

    def test_failure_does_not_create_output(self):
        target = self.folder / "failure.luau"
        self.input.write_text('--!strict\nprint("plain Lua")\n')
        result = self.cli(self.input, "-o", target)
        self.assertEqual(result.returncode, 1)
        self.assertFalse(target.exists())
