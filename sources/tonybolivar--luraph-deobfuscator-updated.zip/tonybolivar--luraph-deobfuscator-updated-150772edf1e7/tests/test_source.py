import os
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path

from luraph_deobfuscator.api import recover
from luraph_deobfuscator.errors import DeobfuscationError

from .fixtures import instruction as ins
from .fixtures import payload, prototype, value_capture

JAVA = os.environ.get("LURAPH_TEST_JAVA")
if not JAVA:
    home = os.environ.get("JAVA_HOME")
    JAVA = str(Path(home) / "bin" / "java") if home else shutil.which("java")
try:
    HAS_JAVA = bool(
        JAVA
        and subprocess.run(
            [JAVA, "-version"], capture_output=True, check=False, timeout=10
        ).returncode
        == 0
    )
except (OSError, subprocess.TimeoutExpired):
    HAS_JAVA = False

LUA = os.environ.get("LURAPH_TEST_LUA") or shutil.which("lua5.4")
LUNE = os.environ.get("LURAPH_TEST_LUNE")


@unittest.skipUnless(HAS_JAVA, "Java is required for the source integration tests")
class SourceTests(unittest.TestCase):
    def source(self, data):
        return recover(data, raw_payload=True, java=JAVA).decode("utf8")

    def execute(self, data, check):
        source = self.source(data)
        self.assertTrue(source.startswith("--!strict\n"))
        self.assertNotIn("--", source[len("--!strict\n") :])
        if not (LUA or LUNE):
            self.skipTest("Set LURAPH_TEST_LUA (Lua 5.4) or LURAPH_TEST_LUNE for execution tests")
        with tempfile.TemporaryDirectory() as folder:
            script = Path(folder) / "synthetic.luau"
            script.write_text(
                "--!strict\nlocal run = function(...)\n"
                + source[len("--!strict\n") :]
                + "\nend\n"
                + check
                + "\n",
                encoding="utf8",
            )
            command = [LUNE, "run", str(script)] if LUNE else [LUA, str(script)]
            result = subprocess.run(command, capture_output=True, check=False, timeout=10)
            self.assertEqual(result.returncode, 0, result.stderr.decode("utf8", "replace"))

    def test_source_contains_input_constant(self):
        data = payload(["source fixture"], prototype(ins(140, n=1, R=1), ins(95, r=1)))
        self.assertIn('"source fixture"', self.source(data))

    def test_missing_java_is_actionable(self):
        data = value_capture()
        with self.assertRaisesRegex(DeobfuscationError, "Java executable not found"):
            recover(data, raw_payload=True, java="/nonexistent/luraph-test-java")

    def test_value_capture_survives_parent_write(self):
        self.execute(value_capture(1), 'assert(run()() == "before")')

    def test_reference_capture_observes_parent_write(self):
        self.execute(value_capture(0), 'assert(run()() == "after")')

    def test_self_value_capture(self):
        data = payload(
            [],
            prototype(ins(180, t=1, child=2), ins(95, r=1)),
            prototype(ins(5, t=0, r=1), ins(95, r=1), captures=[(1, 1)]),
        )
        self.execute(data, "local f = run()\nassert(f() == f)")

    def test_parent_upvalue_is_forwarded(self):
        data = payload(
            ["nested"],
            prototype(ins(140, n=1, R=1), ins(180, t=2, child=2), ins(95, r=2)),
            prototype(ins(180, t=1, child=3), ins(95, r=1), captures=[(1, 1)]),
            prototype(ins(5, t=0, r=1), ins(95, r=1), captures=[(0, 2)]),
        )
        self.execute(data, 'assert(run()()() == "nested")')

    def test_two_factories_do_not_share_captured_values(self):
        data = payload(
            ["first", "second"],
            prototype(
                ins(140, n=1, R=1),
                ins(180, t=2, child=2),
                ins(140, n=1, R=2),
                ins(180, t=3, child=2),
                ins(204, t=2, n=3),
            ),
            prototype(ins(5, r=1, t=0), ins(95, r=1), captures=[(1, 1)]),
        )
        self.execute(data, 'local a, b = run()\nassert(a() == "first" and b() == "second")')

    def test_parameter_branch_preserves_lua_truthiness(self):
        data = payload(
            ["yes", "no"],
            prototype(
                ins(110, n=1),
                ins(145, t=1, r=4),
                ins(140, n=2, R=1),
                ins(95, r=2),
                ins(140, n=2, R=2),
                ins(95, r=2),
            ),
        )
        self.execute(
            data,
            'assert(run(0) == "yes" and run("") == "yes")\n'
            'assert(run(false) == "no" and run(nil) == "no")',
        )

    def test_binary_strings(self):
        data = payload([b"\xff\0\x80"], prototype(ins(140, n=1, R=1), ins(95, r=1)))
        self.execute(data, "assert(run() == string.char(255, 0, 128))")

    def test_fixed_call_clears_stale_registers(self):
        data = payload(
            ["stale"],
            prototype(
                ins(110, n=1),
                ins(140, n=3, R=1),
                ins(111, n=1),
                ins(95, r=3),
            ),
        )
        self.execute(data, "assert(run(function() end) == nil)")

    def test_fixed_call_clears_captured_tail_before_invocation(self):
        data = payload(
            ["stale"],
            prototype(
                ins(140, n=3, R=1),
                ins(180, t=2, child=2),
                ins(225, t=2),
                ins(95, r=2),
            ),
            prototype(ins(5, r=1, t=0), ins(95, r=1), captures=[(3, 0)]),
        )
        self.execute(data, "assert(run() == nil)")

    def test_general_call_retains_its_boundary_register(self):
        data = payload(
            [],
            prototype(ins(110, n=2), ins(74, n=1, r=2, t=2), ins(95, r=2)),
        )
        self.execute(data, 'assert(run(function() return "result" end, "argument") == "argument")')

    def test_call_clears_shared_argument_after_invocation(self):
        data = payload(
            [],
            prototype(
                ins(110, n=1),
                ins(180, t=2, child=2),
                ins(23, r=1),
                ins(58),
            ),
            prototype(ins(5, r=1, t=0), ins(95, r=1), captures=[(2, 0)]),
        )
        self.execute(
            data,
            "local saved\nrun(function(f) saved = f; assert(f() == f) end)\nassert(saved() == nil)",
        )

    def test_reference_mutation_prevents_constant_branch_pruning(self):
        data = payload(
            [True, False, "updated", "stale"],
            prototype(
                ins(140, n=1, R=1),
                ins(180, t=2, child=2),
                ins(111, n=2),
                ins(31, r=1, t=6),
                ins(140, n=2, R=3),
                ins(95, r=2),
                ins(140, n=2, R=4),
                ins(95, r=2),
            ),
            prototype(ins(85, t=0, h=2), ins(58), captures=[(1, 0)]),
        )
        self.execute(data, 'assert(run() == "updated")')

    def test_open_results_preserve_nil_holes_and_tail(self):
        data = payload(
            [],
            prototype(
                ins(110, n=2),
                ins(24, r=3, n=2),
                ins(24, r=2, n=1),
                ins(74, n=3, r=1, t=0),
                ins(122, r=2),
                ins(95, r=2),
            ),
        )
        self.execute(
            data,
            'local values = {[1]="first", [33]="last"}\n'
            "local result = run(table.pack, function() return table.unpack(values, 1, 33) end)\n"
            'assert(result.n == 33 and result[1] == "first" and result[2] == nil '
            'and result[33] == "last")',
        )

    def test_open_table_constructor_preserves_prefix(self):
        data = payload(
            ["prefix"],
            prototype(
                ins(110, n=1),
                ins(24, r=3, n=1),
                ins(106, t=1),
                ins(140, n=2, R=1),
                ins(74, n=3, r=1, t=0),
                ins(19, t=1, r=0),
                ins(95, r=1),
            ),
        )
        self.execute(
            data,
            'local result = run(function() return "first", nil, "last" end)\n'
            'assert(result[1] == "prefix" and result[2] == "first" '
            'and result[3] == nil and result[4] == "last")',
        )
