import unittest
from unittest.mock import patch

from luraph_deobfuscator.errors import DeobfuscationError
from luraph_deobfuscator.unpack import decode85, decompress, long_strings, unpack

from .fixtures import compressed, encode85, wrapper


class UnpackTests(unittest.TestCase):
    def test_little_endian_words_and_zero_abbreviation(self):
        data = bytes(range(256)) + b"\0" * 4
        self.assertEqual(decode85(encode85(data)), data)
        self.assertEqual(decode85(b"z"), b"\0" * 4)

    def test_invalid_base85(self):
        for data in (b"abcd", b"!!!!! ", b"~~~~~", b"uuuuu"):
            with self.subTest(data=data), self.assertRaises(DeobfuscationError):
                decode85(data)

    def test_skip_comments_and_quoted_strings(self):
        source = b"""-- [=[LPH!decoy]=]
"[=[LPH!decoy]=]" --[[ [=[LPH!decoy]=] ]]
'escaped\\\' [=[LPH!decoy]=]' [==[real]==]"""
        self.assertEqual(list(long_strings(source)), [b"real"])

    def test_only_one_initial_line_break_is_ignored(self):
        self.assertEqual(
            list(long_strings(b"[[\r\n\ntext]][[\n\rtext]][[\rtext]]")),
            [b"\ntext", b"text", b"text"],
        )

    def test_unterminated_strings(self):
        for source in (b"[=[abc", b'"abc', b"--[[abc"):
            with self.subTest(source=source), self.assertRaises(DeobfuscationError):
                list(long_strings(source))

    def test_extracts_two_layers(self):
        self.assertEqual(unpack(wrapper()), (b"return function() end", b"synthetic payload"))

    def test_rejects_missing_or_ambiguous_layers(self):
        for source in (b"print(1)", wrapper() + b" [=[LPH!extra]=]"):
            with self.assertRaises(DeobfuscationError):
                unpack(source)

    def test_input_size_limit(self):
        with patch("luraph_deobfuscator.unpack.MAX_INPUT", 10):
            with self.assertRaisesRegex(DeobfuscationError, "Input exceeds"):
                unpack(wrapper())

    def test_lzma_padding_and_truncation(self):
        data = compressed(b"hello")
        self.assertEqual(decompress(data + b"\0" * 3), b"hello")
        for invalid in (data[:-2], data + b"\0" * 4, b"corrupted"):
            with self.assertRaises(DeobfuscationError):
                decompress(invalid)

    def test_decompression_output_limit(self):
        with patch("luraph_deobfuscator.unpack.MAX_DECODED", 64):
            with self.assertRaisesRegex(DeobfuscationError, "Decompressed block exceeds"):
                decompress(compressed(b"a" * 1024))
