import json
import os
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from luraph_deobfuscator.api import detect_format, recover
from luraph_deobfuscator.errors import DeobfuscationError
from luraph_deobfuscator.wearedevs import layers
from luraph_deobfuscator.wearedevs.constants import decode_constants
from luraph_deobfuscator.wearedevs.syntax import parse

from .wearedevs_fixtures import cipher_fixture, fixture, quoted

LUA = os.environ.get("LURAPH_TEST_LUA") or shutil.which("lua5.4")
LUNE = os.environ.get("LURAPH_TEST_LUNE")


class WeAreDevsTests(unittest.TestCase):
    def execute(self, source, assertions):
        recovered = recover(source).decode()
        self.assertTrue(recovered.startswith("--!strict\n"))
        parse(recovered.encode())
        if not (LUA or LUNE):
            self.skipTest("Set LURAPH_TEST_LUA or LURAPH_TEST_LUNE for behavior tests")
        for version in (source.decode(), recovered):
            with tempfile.TemporaryDirectory() as temp:
                path = Path(temp) / "authored.luau"
                path.write_text(
                    "--!strict\nlocal function run(...)\n"
                    + version.removeprefix("--!strict\n")
                    + "\nend\n"
                    + assertions
                    + "\n"
                )
                result = subprocess.run(
                    [LUNE, "run", str(path)] if LUNE else [LUA, str(path)],
                    capture_output=True,
                    timeout=10,
                    check=False,
                )
                self.assertEqual(result.returncode, 0, result.stderr.decode(errors="replace"))

    def test_constant_prefix_permutations_and_binary_bytes(self):
        values = [b"hello", bytes(range(256)), b"", b"padding!", b"second"]
        blocks = {
            "entry": "out = {"
            + ", ".join(f"C(@constant{i}@)" for i in range(len(values)))
            + "}; pc = nil"
        }
        for seed in range(5):
            source = fixture(blocks, constants=values, seed=seed)
            _, actual = decode_constants(source)
            self.assertEqual(actual, values)
            self.assertIn('"hello"', recover(source).decode())

    def test_arbitrary_dispatch_labels_and_mutated_constants(self):
        for seed in range(5):
            source = fixture(seed=seed, constants=[f"message {seed}".encode()])
            report = json.loads(recover(source, emit="ir"))
            self.assertEqual(report["profile"], "wearedevs-prometheus-v1")
            self.assertTrue(report["functions"][0]["structured"])
            self.assertEqual(report["constants"][0]["text"], f"message {seed}")

    def test_loop_with_nested_branch(self):
        source = fixture(
            {
                "entry": "x = 0; y = 1; pc = @head@",
                "head": "pc = (y <= args[1]) and @choose@ or @done@",
                "choose": "pc = (y % 2 == 0) and @even@ or @odd@",
                "even": "x = x + y; pc = @next@",
                "odd": "x = x - y; pc = @next@",
                "next": "y = y + 1; pc = @head@",
                "done": "out = {x}; pc = nil",
            }
        )
        self.execute(source, "assert(run(0) == 0 and run(4) == 2 and run(5) == -3)")

    def test_nested_loops_and_early_returns(self):
        source = fixture(
            {
                "entry": "x = 0; y = 0; pc = @outer@",
                "outer": "y = y + 1; z = 0; pc = (y <= args[1]) and @inner@ or @done@",
                "inner": "z = z + 1; pc = (z <= y) and @body@ or @outer@",
                "body": "x = x + 1; pc = args[2] and @done@ or @inner@",
                "done": "out = {x}; pc = nil",
            }
        )
        self.execute(source, "assert(run(4) == 10 and run(4, true) == 1 and run(0) == 0)")

    def test_shared_capture_and_separate_factory_calls(self):
        source = fixture(
            {
                "entry": "x = alloc(); heap[x] = args[1]; y = make(@child@, {x}); heap[x] = args[1] + 1; out = {y}; pc = nil",
                "child": "heap[caps[1]] = heap[caps[1]] + 1; out = {heap[caps[1]]}; pc = nil",
            }
        )
        self.execute(
            source, "local a, b = run(1), run(10)\nassert(a() == 3 and a() == 4 and b() == 12)"
        )

    def test_multi_result_assignments_and_parenthesized_calls(self):
        source = fixture(
            {"entry": "x = args[1]; a, b, c = x(); y = (x()); out = {a, b, c, y}; pc = nil"}
        )
        self.execute(
            source,
            'local a,b,c,d = run(function() return "a",nil,"c" end)\nassert(a == "a" and b == nil and c == "c" and d == "a")',
        )

    def test_nil_holes_and_open_call_arguments(self):
        source = fixture({"entry": "x = args[1]; y = args[2]; out = {x(y())}; pc = nil"})
        self.execute(
            source,
            'local t = run(table.pack, function() return "a",nil,"c" end)\nassert(t.n == 3 and t[2] == nil and t[3] == "c")',
        )

    def test_branch_uses_second_call_result(self):
        source = fixture(
            {
                "entry": "x = args[1]; a, b = x(); pc = b and @yes@ or @no@",
                "yes": "out = {true}; pc = nil",
                "no": "out = {false}; pc = nil",
            }
        )
        self.execute(
            source,
            "assert(run(function() return 1,true end))\nassert(not run(function() return 1,false end))",
        )

    def test_alias_of_dispatch_helper_is_rejected(self):
        source = fixture({"entry": "x = make; out = {x}; pc = nil"})
        with self.assertRaisesRegex(DeobfuscationError, "Aliased or reassigned"):
            recover(source)

    def test_folded_logical_call_still_returns_one_value(self):
        source = fixture({"entry": "x = args[1]; out = {true and x()}; pc = nil"})
        self.execute(
            source, 'local a,b = run(function() return "a","b" end)\nassert(a == "a" and b == nil)'
        )

    def test_cipher_arguments_from_application_are_not_assumed(self):
        source = cipher_fixture().replace(b"912345678", b"(args[1] or 912345678)")
        report = json.loads(recover(source, emit="ir"))
        self.assertEqual(report["decoded_strings"], [])

    def test_generated_names_do_not_shadow_input_globals(self):
        source = fixture({"entry": "out = {local_1, environment, recovered_1}; pc = nil"})
        result = recover(source).decode()
        self.assertIn("local_1, environment, recovered_1", result)
        self.assertIn("recovered_2", result)

    def test_multi_exit_loop_falls_back_without_losing_behavior(self):
        source = fixture(
            {
                "entry": "x = 0; pc = @head@",
                "head": "x = x + 1; pc = (x > args[1]) and @done@ or @choose@",
                "choose": "pc = (x == args[2]) and @early@ or @head@",
                "early": "out = {x + 100}; pc = nil",
                "done": "out = {x}; pc = nil",
            }
        )
        report = json.loads(recover(source, emit="ir"))
        self.assertFalse(report["functions"][0]["structured"])
        self.execute(source, "assert(run(5,3) == 103 and run(5,8) == 6)")

    def test_truthiness_and_side_effect_count(self):
        source = fixture(
            {
                "entry": "x = args[1]; y = x(); pc = y and @yes@ or @no@",
                "yes": "out = {true}; pc = nil",
                "no": "out = {false}; pc = nil",
            }
        )
        self.execute(
            source,
            "local count = 0\nassert(run(function() count = count + 1; return 0 end))\nassert(count == 1 and not run(function() return false end))",
        )

    def test_cipher_is_input_driven(self):
        for seed, keys, text in [
            (912345678, (5, 123456789, 3, 97), b"authored-one"),
            (173019988765, (13, 501789453, 5, 12), b"different\x00\xffvalue"),
        ]:
            source = cipher_fixture(
                text, seed=seed, mul45=keys[0], add45=keys[1], mul8=keys[2], previous=keys[3]
            )
            report = json.loads(recover(source, emit="ir"))
            self.assertEqual([s["bytes_hex"] for s in report["decoded_strings"]], [text.hex()])
            self.execute(source, f"assert(run() == {quoted(text)})")

    def test_no_supported_cipher_is_reported(self):
        report = json.loads(recover(fixture(), emit="ir"))
        self.assertEqual(report["decoded_strings"], [])
        self.assertIn("No supported cipher", report["string_status"])

    def test_unresolved_successor_is_rejected(self):
        with self.assertRaisesRegex(DeobfuscationError, "Unresolved VM successor"):
            recover(fixture({"entry": "pc = args[1]"}))

    def test_opaque_exit_has_runtime_guard(self):
        source = fixture({"entry": 'out = {1}; pc = env["authored_absent_exit"]'})
        self.assertIn("Unsupported truthy VM exit global", recover(source).decode())
        self.execute(source, "assert(run() == 1)")

    def test_external_constant_prefix_calls_are_unavailable(self):
        source = fixture().replace(b"local data =", b'os.execute("authored-noop"); local data =', 1)
        with self.assertRaisesRegex(DeobfuscationError, "unavailable value"):
            recover(source)

    def test_mutating_accessor_is_rejected(self):
        source = fixture().replace(b"return data[index -", b"data[1] = nil; return data[index -", 1)
        with self.assertRaisesRegex(DeobfuscationError, "dynamic constant accessor"):
            recover(source)

    def test_infinite_prefix_is_bounded(self):
        source = fixture().replace(b"local data =", b"while true do end; local data =", 1)
        with self.assertRaisesRegex(DeobfuscationError, "instruction limit"):
            recover(source)

    def test_unknown_and_oversized_inputs(self):
        for source in (b"invalid ?", b"a" * (1024 * 1024 + 1), b"return function() end"):
            with self.assertRaises(DeobfuscationError):
                recover(source)

    def test_layers_and_cli_formats(self):
        source = fixture()
        self.assertEqual(detect_format(source), "wearedevs")
        self.assertEqual(set(layers(source)), {"vm.luau", "constants.json", "manifest.json"})
        self.assertEqual(recover(source), recover(source, input_format="wearedevs"))
        with self.assertRaisesRegex(DeobfuscationError, "Lua 5.1"):
            recover(source, emit="lua51")
        with self.assertRaisesRegex(DeobfuscationError, "Luraph-only"):
            recover(source, raw_payload=True, input_format="wearedevs")
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "fixture.lua"
            path.write_bytes(source)
            result = subprocess.run(
                [sys.executable, "-m", "luraph_deobfuscator", str(path), "-o"],
                capture_output=True,
                timeout=30,
                check=False,
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(path.with_suffix(".deobfuscated.luau").read_bytes(), recover(source))
