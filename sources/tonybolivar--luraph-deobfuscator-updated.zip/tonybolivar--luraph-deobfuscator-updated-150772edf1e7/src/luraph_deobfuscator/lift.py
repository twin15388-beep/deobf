import collections
import json
import re

from .errors import DeobfuscationError
from .normalize import HANDLERS, UNKNOWN, B, Normalizer, Q, same


def reg(n):
    return ("reg", n)


def up(n):
    return ("up", n)


def const(v):
    return ("const", v)


def glob(n):
    return ("global", n)


def expr(v):
    return v if isinstance(v, tuple) else const(v)


def index(obj, key):
    return ("index", expr(obj), expr(key))


MICROS = {
    6,
    157,
    131,
    201,
    230,
    173,
    40,
    165,
    77,
    223,
    195,
    202,
    128,
    109,
    92,
    38,
    39,
    59,
    208,
    224,
    132,
    167,
    243,
    29,
    144,
    124,
    81,
    196,
    127,
    221,
    241,
    170,
    177,
    210,
    121,
    136,
    114,
    164,
    192,
    211,
    203,
    193,
    240,
    12,
    166,
    61,
    20,
    45,
    206,
    26,
    0,
    212,
    112,
    244,
    57,
    3,
    8,
    35,
    54,
    76,
    107,
    51,
}


class Lifter(Normalizer):
    def read(self, obj, key, state):
        if obj == Q:
            return reg(key)
        if obj == B:
            return up(key)
        return index(obj, key)

    def write(self, obj, key, val, state, pc):
        if obj == Q:
            self.effects.append(("assign", reg(key), expr(val)))
        else:
            self.effects.append(("assign", index(obj, key), expr(val)))

    def micro_transfer(self, pc, state):
        op = self.arrays[1][pc]
        r, t, n = [self.arrays[f].get(pc) for f in (3, 10, 5)]
        s = dict(state)
        self.effects = []
        if op in MICROS:
            z, w, V, m = [s.get(k) for k in ("z", "w", "V", "m")]
            if op in (12, 166):
                s["V"] = glob("UDim2" if op == 12 else "game")
                self.write(z, w, s["V"], s, pc)
            elif op == 203:
                s["z"] = Q
                s["w"] = t
                s["V"] = glob("Instance")
            elif op == 193:
                s["w"] = r
                s["V"] = glob("Enum")
            elif op == 240:
                s["V"] = glob("Color3")
            elif op == 61:
                s["w"] = n
                s["V"] = glob("warn")
            elif op == 20:
                s["z"] = Q
                s["w"] = n
                s["V"] = ("newtable",)
            elif op == 51:
                s["z"] = Q
                s["w"] = n
                s["V"] = glob("utf8")
            elif op == 244:
                s["z"] = up(t)
                s["w"] = t
            elif op in (0, 212):
                s["V"] = ("invoke", expr(V), [expr(m)] if op == 0 else [])
                self.write(z, w, s["V"], s, pc)
            else:
                s, _ = super().transfer(pc, s)
        return {k: v for k, v in s.items() if isinstance(k, str)}, self.effects

    def lift(self):
        base = Normalizer(self.program, self.index).run()
        self.arrays = base.arrays
        self.edges = base.edges
        self.params = max(
            (self.arrays[5][pc] for pc in self.edges if self.arrays[1][pc] == 110), default=0
        )
        incoming = {1: {}}
        queue = collections.deque([1])
        effects = {}
        steps = 0
        while queue:
            steps += 1
            if steps > 100000:
                raise DeobfuscationError("Expression analysis did not converge")
            pc = queue.popleft()
            out, effects[pc] = self.micro_transfer(pc, incoming[pc])
            for dst in self.edges[pc]:
                if dst not in incoming:
                    incoming[dst] = dict(out)
                    queue.append(dst)
                else:
                    prev = incoming[dst]
                    merged = {
                        k: prev.get(k) if same(prev.get(k), out.get(k)) else UNKNOWN
                        for k in prev.keys() | out.keys()
                    }
                    if merged != prev:
                        incoming[dst] = merged
                        queue.append(dst)
        actions = {}
        for pc in incoming:
            op = self.arrays[1][pc]
            r, t, n, R, h, d = [self.arrays[f].get(pc) for f in (3, 10, 5, 4, 9, 7)]
            a = []

            def put(dest, value, actions=a):
                actions.append(("assign", reg(dest), value))

            if op in MICROS:
                a = effects[pc]
            elif op in (69, 25, 110):
                pass
            elif op == 24:
                put(r, reg(n))
            elif op == 140:
                put(n, const(R))
            elif op == 34:
                put(r, index(reg(t), h))
            elif op == 214:
                put(r, index(reg(n), reg(t)))
            elif op == 191:
                a = [("self", r, t, const(h))]
            elif op in (72, 158):
                a = [("assign", index(reg(r), d), const(h) if op == 72 else reg(n))]
            elif op == 178:
                a = [("assign", index(reg(t), reg(r)), reg(n))]
            elif op in (5, 80):
                put(r if op == 5 else t, up(t if op == 5 else n))
            elif op in (207, 85):
                a = [("assign", up(r if op == 207 else t), reg(n) if op == 207 else const(h))]
            elif op == 97:
                a = [("assign", index(up(t), h), reg(r))]
            elif op == 238:
                put(t, index(up(n), R))
            elif op in (187, 106):
                put(n if op == 187 else t, ("newtable",))
            elif op == 52:
                put(n, const(None))
            elif op == 180:
                a = [("closure", t, h[1])]
            elif op in (
                248,
                250,
                251,
                252,
                253,
                254,
                255,
                198,
                225,
                86,
                74,
                122,
                111,
                23,
                213,
                96,
                48,
            ):
                spec = {
                    248: (t, 2, 1),
                    198: (t, 1, 1),
                    225: (t, 0, 1),
                    86: (r, t - 1, 1),
                    74: (n, r - 1, t - 1),
                    122: (r, -1, 1),
                    111: (n, 0, 0),
                    23: (r, 1, 0),
                    213: (t, 2, 0),
                    96: (n, r - 1, 0),
                    48: (n, -1, 0),
                }.get(op, (t, 2, 1))
                a = [("call", *spec)]
            elif op == 58:
                a = [("return", 1, 0)]
            elif op == 95:
                a = [("return", r, 1)]
            elif op == 204:
                a = [("return", t, n - 1)]
            elif op == 249:
                for target in range(n, t + 1):
                    put(target, const(None))
            elif op in (50, 19):
                base_, count, offset = (r, t, n) if op == 50 else (t, -1, r)
                a = [("setlist", base_, count, offset)]
            elif op in (31, 145, 65, 184):
                cond = {
                    31: reg(r),
                    145: ("not", reg(t)),
                    65: ("not", ("binary", "<", const(h), reg(r))),
                    184: ("binary", "~=", reg(t), reg(n)),
                }[op]
                dst = {31: t, 145: r, 65: t, 184: r}[op] + 1
                a = [("branch", cond, dst, pc + 1)]
            elif op in (235, 168, 105, 245, 242):
                dest, oper, b, c = {
                    235: (t, "+", reg(r), const(h)),
                    168: (t, "%", reg(n), const(R)),
                    105: (r, "..", const(h), reg(t)),
                    245: (n, "..", reg(t), const(R)),
                    242: (r, "==", reg(t), const(h)),
                }[op]
                put(dest, ("binary", oper, b, c))
            elif op == 82:
                put(r, ("length", reg(t)))
            else:
                handler = HANDLERS.get(str(op), "unsupported opcode")
                match = re.fullmatch(r"\(?q\)?\[([rnt])\[Q\]\] = (\w+(?:\.\w+)?)", handler)
                if not match:
                    raise ValueError((self.index, pc, op, handler))
                name = {
                    "v.Ky": "math",
                    "v.uy": "string",
                    "v.By": "utf8",
                    "v.iy": "bit32",
                    "v.Dy": "setmetatable",
                }.get(match[2], match[2])
                put({"r": r, "n": n, "t": t}[match[1]], glob(name))
            if a and a[-1][0] == "branch" and len(self.edges[pc]) == 1:
                a.pop()
            actions[pc] = a

        def resolve(pc):
            seen = set()
            while not actions.get(pc):
                if pc in seen:
                    raise DeobfuscationError("Empty control-flow cycle")
                seen.add(pc)
                dest = self.edges[pc]
                if len(dest) != 1:
                    raise DeobfuscationError("Unresolved control flow")
                pc = dest[0]
            return pc

        entry = resolve(1)
        clean = {}
        for pc, a in actions.items():
            if not a:
                continue
            successors = self.edges[pc]
            if a[-1][0] == "branch":
                kind, cond, yes, no = a[-1]
                a[-1] = (kind, cond, resolve(yes), resolve(no))
                successors = [no, yes]
            clean[pc] = {
                "actions": a,
                "next": [resolve(x) for x in successors],
                "line": self.arrays[8].get(pc, 0),
            }
        ordered = []
        seen = set()

        def visit(pc):
            if pc in seen:
                return
            seen.add(pc)
            for dst in reversed(clean[pc]["next"]):
                visit(dst)
            ordered.append(pc)

        visit(entry)
        ordered.reverse()
        self.instructions = {pc: clean[pc] for pc in ordered}
        self.entry = entry
        return self


def show(e):
    k = e[0]
    if k == "reg":
        return f"r{e[1]}"
    if k == "up":
        return f"up{e[1]}"
    if k == "global":
        return e[1]
    if k == "const":
        return json.dumps(e[1], ensure_ascii=False) if e[1] is not None else "nil"
    if k == "index":
        return show(e[1]) + "[" + show(e[2]) + "]"
    if k == "binary":
        return "(" + show(e[2]) + " " + e[1] + " " + show(e[3]) + ")"
    if k == "not":
        return "not " + show(e[1])
    if k == "length":
        return "#" + show(e[1])
    if k == "newtable":
        return "{}"
    return str(e)


def listing(lift):
    rows = [f"function {lift.index}({lift.params} parameters); upvalues {lift.upvalues}"]
    order = list(lift.instructions)
    for ix, (pc, item) in enumerate(lift.instructions.items()):
        for a in item["actions"]:
            k = a[0]
            if k == "assign":
                s = show(a[1]) + " = " + show(a[2])
            elif k == "self":
                s = f"r{a[1] + 1} = r{a[2]}; r{a[1]} = r{a[2]}[{show(a[3])}]"
            elif k == "closure":
                s = f"r{a[1]} = function_{a[2]}"
            elif k == "call":
                base, argc, retc = a[1:]
                args = (
                    ", ".join(f"r{r}" for r in range(base + 1, base + argc + 1))
                    if argc >= 0
                    else f"r{base + 1}..TOP"
                )
                lhs = (
                    ", ".join(f"r{r}" for r in range(base, base + retc))
                    if retc >= 0
                    else f"r{base}..TOP"
                )
                s = (lhs + " = " if lhs else "") + f"r{base}({args})"
            elif k == "branch":
                s = f"if {show(a[1])} then goto {a[2]} else goto {a[3]}"
            elif k == "return":
                s = "return"
            else:
                s = str(a)
            rows.append(f"{pc:4}  {s}")
        if len(item["next"]) == 1 and (ix + 1 == len(order) or item["next"][0] != order[ix + 1]):
            rows.append(f"      goto {item['next'][0]}")
    return "\n".join(rows) + "\n"
