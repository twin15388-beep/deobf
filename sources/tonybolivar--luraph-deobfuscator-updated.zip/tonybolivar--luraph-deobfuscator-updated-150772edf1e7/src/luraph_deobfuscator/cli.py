import argparse
import hashlib
import json
import os
import shutil
import sys
import tempfile
from pathlib import Path

from . import __version__
from .api import PROFILES, detect_format, recover
from .errors import DeobfuscationError
from .unpack import MAX_INPUT, unpack

EXTENSIONS = {"luau": ".luau", "lua51": ".luac", "ir": ".json"}


def write_output(target, data, force=False):
    target = Path(target)
    fd, temporary = tempfile.mkstemp(prefix="." + target.name + ".", dir=target.parent)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(data)
        if force:
            os.replace(temporary, target)
        else:
            try:
                os.link(temporary, target)
            except FileExistsError as exc:
                raise DeobfuscationError(
                    f"Output already exists: {target}; use --force to replace it"
                ) from exc
    finally:
        Path(temporary).unlink(missing_ok=True)


def write_layers(source, directory, input_format="auto"):
    directory = Path(directory)
    if directory.exists():
        raise DeobfuscationError("Unpack directory already exists; choose a new directory")
    directory.mkdir()
    try:
        if detect_format(source, input_format) == "wearedevs":
            from .wearedevs import layers

            for name, data in layers(source).items():
                write_output(directory / name, data)
            return
        vm, payload = unpack(source)
        write_output(directory / "vm.luau", b"--!strict\n" + vm)
        write_output(directory / "payload.bin", payload)
        manifest = {
            "source_sha256": hashlib.sha256(source).hexdigest(),
            "vm_sha256": hashlib.sha256(vm).hexdigest(),
            "payload_sha256": hashlib.sha256(payload).hexdigest(),
            "vm_bytes": len(vm),
            "payload_bytes": len(payload),
            "profile": next((p.NAME for p in PROFILES if p.matches(vm, payload)), None),
        }
        write_output(directory / "manifest.json", (json.dumps(manifest, indent=2) + "\n").encode())
    except BaseException:
        shutil.rmtree(directory)
        raise


def parser():
    result = argparse.ArgumentParser(
        prog="luraph-obfuscator",
        description="Recover supported Luraph and WeAreDevs/Prometheus code without a Lua runtime.",
    )
    result.add_argument("input", nargs="?", type=Path, help="obfuscated Lua file")
    result.add_argument(
        "-o",
        "--output",
        nargs="?",
        const="",
        metavar="PATH",
        help="write a file; bare -o uses INPUT.deobfuscated.EXT (default: stdout)",
    )
    result.add_argument(
        "--emit", choices=EXTENSIONS, default="luau", help="output format (default: luau)"
    )
    result.add_argument(
        "--format",
        choices=("auto", "luraph", "wearedevs"),
        default="auto",
        help="input format (default: auto)",
    )
    result.add_argument(
        "--unpack", type=Path, metavar="DIR", help="extract the outer layers only; no Java required"
    )
    result.add_argument(
        "--raw-payload",
        action="store_true",
        help="read a buffer-v1 encrypted payload directly, without its wrapper/bootstrap",
    )
    result.add_argument("--java", metavar="PATH", help="Java executable for Luraph source output")
    result.add_argument("--force", action="store_true", help="replace an existing output file")
    result.add_argument(
        "--list-profiles", action="store_true", help="show supported format fingerprints"
    )
    result.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    return result


def main(argv=None):
    command = parser()
    args = command.parse_args(argv)
    if args.list_profiles:
        print(
            json.dumps(
                [
                    {
                        "name": p.NAME,
                        "vm_sha256": p.VM_SHA256,
                        "bootstrap_sha256": p.BOOTSTRAP_SHA256,
                        "payload_offset": p.PAYLOAD_OFFSET,
                    }
                    for p in PROFILES
                ]
                + [
                    {
                        "name": "wearedevs-prometheus-v1",
                        "match": "AST structure",
                        "outputs": ["luau", "ir"],
                    }
                ],
                indent=2,
            )
        )
        return 0
    if args.input is None:
        command.error("an input file is required")
    if args.unpack and (
        args.output is not None or args.raw_payload or args.emit != "luau" or args.force
    ):
        command.error("--unpack cannot be combined with -o, --raw-payload, --emit, or --force")
    try:
        with args.input.open("rb") as stream:
            source = stream.read(MAX_INPUT + 1)
        if len(source) > MAX_INPUT:
            raise DeobfuscationError("Input exceeds 8 MiB")
        if args.unpack:
            write_layers(source, args.unpack, args.format)
            print(f"Wrote layers to {args.unpack}", file=sys.stderr)
            return 0
        target = None
        if args.output is not None:
            target = (
                Path(args.output)
                if args.output
                else args.input.with_name(args.input.stem + ".deobfuscated" + EXTENSIONS[args.emit])
            )
            if target.resolve() == args.input.resolve() or (
                target.exists() and target.samefile(args.input)
            ):
                raise DeobfuscationError("Output must be different from the input file")
            if target.exists() and not args.force:
                raise DeobfuscationError(
                    f"Output already exists: {target}; use --force to replace it"
                )
        data = recover(
            source,
            emit=args.emit,
            java=args.java,
            raw_payload=args.raw_payload,
            input_format=args.format,
        )
        if target is not None:
            write_output(target, data, force=args.force)
            print(f"Wrote {target}", file=sys.stderr)
        else:
            sys.stdout.buffer.write(data)
        return 0
    except BrokenPipeError:
        return 0
    except (OSError, DeobfuscationError) as exc:
        print(f"{command.prog}: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
