"""Small, conservative Lua AST utilities shared by the Prometheus passes."""

import math
import operator
from textwrap import indent

from luaparser import ast
from luaparser import astnodes as n
from luaparser.printers import LuaOutputVisitor

from ..errors import DeobfuscationError

MAX_SOURCE = 1024 * 1024
ARITHMETIC = {
    n.AddOp: operator.add,
    n.SubOp: operator.sub,
    n.MultOp: operator.mul,
    n.FloatDivOp: operator.truediv,
    n.ModOp: operator.mod,
    n.ExpoOp: operator.pow,
}


def children(node):
    for key, value in vars(node).items():
        if not key.startswith("_") and key != "comments":
            yield key, value


def walk(node):
    if isinstance(node, list):
        for item in node:
            yield from walk(item)
    elif isinstance(node, n.Node):
        yield node
        for _, value in children(node):
            yield from walk(value)


def transform(node, callback):
    if isinstance(node, list):
        return [transform(item, callback) for item in node]
    if isinstance(node, n.Node):
        for key, value in list(children(node)):
            setattr(node, key, transform(value, callback))
        node.comments = []
        return callback(node)
    return node


def quote(value):
    return (
        '"'
        + "".join(chr(c) if 32 <= c < 127 and c not in (34, 92) else f"\\{c:03d}" for c in value)
        + '"'
    )


def literal(value):
    if value is None:
        return n.Nil()
    if isinstance(value, bool):
        return n.TrueExpr() if value else n.FalseExpr()
    if isinstance(value, bytes):
        return n.String(value, quote(value)[1:-1], n.StringDelimiter.DOUBLE_QUOTE)
    if isinstance(value, (float, int)) and math.isfinite(value):
        return n.Number(value)
    raise DeobfuscationError("Non-literal constant in WeAreDevs layer")


def is_literal(node):
    return isinstance(node, (n.Number, n.String, n.Nil, n.TrueExpr, n.FalseExpr))


def value(node):
    if isinstance(node, n.Number):
        return node.n
    if isinstance(node, n.String):
        return node.s
    if isinstance(node, (n.TrueExpr, n.FalseExpr)):
        return isinstance(node, n.TrueExpr)
    if isinstance(node, n.Nil):
        return None
    raise DeobfuscationError("Expected a literal")


def truth(value):
    return value is not None and value is not False


def fold(node):
    if isinstance(node, n.Block):
        node.body = [stmt for stmt in node.body if not isinstance(stmt, n.SemiColon)]
    if isinstance(node, n.Fornum) and type(node.step) in (int, float):
        node.step = literal(node.step)
    if isinstance(node, n.Index) and node.notation == n.IndexNotation.DOT:
        node.idx = literal(node.idx.id.encode())
        node.notation = n.IndexNotation.SQUARE
    if isinstance(node, n.Field) and isinstance(node.key, n.Name) and not node.between_brackets:
        node.key = literal(node.key.id.encode())
        node.between_brackets = True
    if type(node) in ARITHMETIC and all(isinstance(x, n.Number) for x in (node.left, node.right)):
        try:
            result = ARITHMETIC[type(node)](float(node.left.n), float(node.right.n))
            if isinstance(result, float) and math.isfinite(result):
                return literal(result)
        except (ValueError, OverflowError, ZeroDivisionError):
            pass
    if isinstance(node, n.UMinusOp) and isinstance(node.operand, n.Number):
        return literal(-float(node.operand.n))
    if isinstance(node, n.ULNotOp) and is_literal(node.operand):
        return literal(not truth(value(node.operand)))
    if isinstance(node, (n.AndLoOp, n.OrLoOp)) and is_literal(node.left):
        take_right = truth(value(node.left)) == isinstance(node, n.AndLoOp)
        result = node.right if take_right else node.left
        if isinstance(result, (n.Call, n.Invoke, n.Dots)):
            result.wrapped = True
        return result
    return node


class Printer(LuaOutputVisitor):
    def do_visit(self, node):
        if isinstance(node, n.String):
            return quote(node.s)
        if isinstance(node, n.Number):
            val = float(node.n)
            if not math.isfinite(val):
                raise DeobfuscationError("Non-finite numeric literal")
            if val == 0 and math.copysign(1, val) < 0:
                return "-0.0"
            return str(int(val)) if val.is_integer() and abs(val) < 2**53 else repr(val)
        if isinstance(node, n.Block):
            self._level += 1
            lines = [self.do_visit(item) for item in node.body]
            output = "\n".join(
                line + (";" if isinstance(item, (n.Assign, n.Call, n.Invoke)) else "")
                for item, line in zip(node.body, lines, strict=True)
            )
            output = indent(output, " " * (self._indent_size if self._level > 1 else 0))
            self._level -= 1
            return output
        if isinstance(node, (n.BinaryOp, n.UnaryOp)):
            return "(" + self.visit(node) + ")"
        if isinstance(node, n.Call):
            callee = self.do_visit(node.func)
            if not isinstance(node.func, (n.Name, n.Index, n.Call, n.Invoke)):
                callee = "(" + callee + ")"
            result = callee + "(" + self.do_visit(node.args) + ")"
            return "(" + result + ")" if node.wrapped else result
        if isinstance(node, n.Index):
            receiver = self.do_visit(node.value)
            if not isinstance(node.value, (n.Name, n.Index, n.Call, n.Invoke)):
                receiver = "(" + receiver + ")"
            return receiver + "[" + self.do_visit(node.idx) + "]"
        if (
            isinstance(node, n.Table)
            and len(node.fields) <= 6
            and not any(isinstance(x, n.AnonymousFunction) for x in walk(node))
        ):
            return "{" + ", ".join(self.do_visit(f) for f in node.fields) + "}"
        return super().do_visit(node)


def render(node):
    return Printer(indent_size=4).do_visit(node)


def parse(source):
    if len(source) > MAX_SOURCE:
        raise DeobfuscationError("WeAreDevs source exceeds 1 MiB")
    try:
        tree = ast.parse(source.decode("utf8"))
        if sum(1 for _ in walk(tree)) > 100_000:
            raise DeobfuscationError("WeAreDevs AST exceeds 100,000 nodes")
        return transform(tree, fold)
    except (ast.SyntaxException, UnicodeError, RecursionError) as exc:
        raise DeobfuscationError("Unsupported or excessively nested WeAreDevs Lua syntax") from exc


class Bindings:
    """Assign stable names to locals before substituting constants across scopes."""

    def __init__(self):
        self.next_id = 0
        self.reserved = None

    def declare(self, node, scope):
        if isinstance(node, (n.Dots, n.Varargs)):
            return
        self.next_id += 1
        while f"local_{self.next_id}" in self.reserved:
            self.next_id += 1
        original = node.id
        node.id = f"local_{self.next_id}"
        scope[original] = node.id

    def expr(self, node, scope):
        if isinstance(node, list):
            for item in node:
                self.expr(item, scope)
        elif isinstance(node, n.Name):
            node.id = scope.get(node.id, node.id)
        elif isinstance(node, n.AnonymousFunction):
            inner = dict(scope)
            for arg in node.args:
                self.declare(arg, inner)
            self.block(node.body, inner)
        elif isinstance(node, n.Node):
            for _, item in children(node):
                self.expr(item, scope)

    def block(self, block, scope):
        if self.reserved is None:
            self.reserved = {x.id for x in walk(block) if isinstance(x, n.Name)}
        for stmt in block.body:
            if isinstance(stmt, n.LocalAssign):
                self.expr(stmt.values, scope)
                for target in stmt.targets:
                    self.declare(target, scope)
            elif isinstance(stmt, n.LocalFunction):
                self.declare(stmt.name, scope)
                inner = dict(scope)
                for arg in stmt.args:
                    self.declare(arg, inner)
                self.block(stmt.body, inner)
            elif isinstance(stmt, (n.If, n.ElseIf)):
                self.expr(stmt.test, scope)
                self.block(stmt.body, dict(scope))
                if isinstance(stmt.orelse, n.ElseIf):
                    self.block(n.Block([stmt.orelse]), dict(scope))
                elif stmt.orelse:
                    self.block(stmt.orelse, dict(scope))
            elif isinstance(stmt, (n.While, n.Repeat, n.Do)):
                inner = dict(scope)
                if isinstance(stmt, n.While):
                    self.expr(stmt.test, scope)
                self.block(stmt.body, inner)
                if isinstance(stmt, n.Repeat):
                    self.expr(stmt.test, inner)
            elif isinstance(stmt, (n.Fornum, n.Forin)):
                inner = dict(scope)
                if isinstance(stmt, n.Fornum):
                    self.expr([stmt.start, stmt.stop, stmt.step], scope)
                    self.declare(stmt.target, inner)
                else:
                    self.expr(stmt.iter, scope)
                    for target in stmt.targets:
                        self.declare(target, inner)
                self.block(stmt.body, inner)
            elif isinstance(stmt, (n.Assign, n.Call, n.Invoke, n.Return, n.Break, n.SemiColon)):
                self.expr(stmt, scope)
            else:
                raise DeobfuscationError(f"Unsupported WeAreDevs statement: {type(stmt).__name__}")
        return block
