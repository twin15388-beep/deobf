"""Evaluate constant-table initialization in a capability-free, bounded interpreter.

This interpreter has no loader, filesystem, network, process, or host object access.
It is used only for the statements before the returned VM, never its entry point.
"""

import math
from dataclasses import dataclass

from ..errors import DeobfuscationError
from .syntax import (
    ARITHMETIC,
    Bindings,
    is_literal,
    literal,
    n,
    parse,
    transform,
    truth,
    value,
    walk,
)

LIMIT = 1_000_000


class Table:
    def __init__(self, values=()):
        self.items = {}
        for i, val in enumerate(values, 1):
            self.set(i, val)

    def key(self, key):
        if key is None or isinstance(key, float) and math.isnan(key):
            raise DeobfuscationError("Invalid constant table key")
        return (
            bool
            if isinstance(key, bool)
            else float
            if isinstance(key, (int, float))
            else type(key),
            key,
        )

    def get(self, key):
        return self.items.get(self.key(key))

    def set(self, key, val):
        key = self.key(key)
        if val is None:
            self.items.pop(key, None)
        else:
            self.items[key] = val
        if len(self.items) > 65_536:
            raise DeobfuscationError("Constant table size limit exceeded")

    def __len__(self):
        size = 0
        while self.items.get((float, size + 1)) is not None:
            size += 1
        if any(kind is float and key > size and key == int(key) for kind, key in self.items):
            raise DeobfuscationError("Length of sparse constant tables is unsupported")
        return size


class Scope(dict):
    def __init__(self, parent=None):
        super().__init__()
        self.parent = parent

    def lookup(self, name):
        if name in self:
            return self[name]
        if self.parent is not None:
            return self.parent.lookup(name)
        raise DeobfuscationError(f"Constant layer requires unavailable value: {name}")

    def assign(self, name, val):
        if name in self:
            self[name] = val
        elif self.parent is not None:
            self.parent.assign(name, val)
        else:
            raise DeobfuscationError("Constant layer tried to assign a global")


@dataclass
class Builtin:
    name: str


@dataclass
class Closure:
    node: object
    scope: Scope


class Returned(Exception):
    def __init__(self, values):
        self.values = values


class Broken(Exception):
    pass


class Evaluator:
    def __init__(self):
        self.steps = 0
        self.depth = 0
        self.bytes_allocated = 0
        self.scope = Scope()
        for name in ("type", "ipairs"):
            self.scope[name] = Builtin(name)
        for library, names in {
            "table": ("concat", "insert"),
            "string": ("len", "char", "sub"),
            "math": ("floor",),
        }.items():
            tab = self.scope[library] = Table()
            for name in names:
                tab.set(name.encode(), Builtin(f"{library}.{name}"))

    def tick(self):
        self.steps += 1
        if self.steps > LIMIT:
            raise DeobfuscationError("Constant evaluation exceeded its instruction limit")

    def allocate_bytes(self, data):
        self.bytes_allocated += len(data)
        if self.bytes_allocated > 16 * 1024 * 1024:
            raise DeobfuscationError("Constant byte allocation exceeds 16 MiB")
        return data

    def values(self, expressions, scope):
        result = []
        for i, expr in enumerate(expressions):
            if i == len(expressions) - 1 and isinstance(expr, n.Call) and not expr.wrapped:
                result.extend(self.call(self.expr(expr.func, scope), self.values(expr.args, scope)))
            else:
                result.append(self.expr(expr, scope))
        return result

    def known(self, value):
        return value

    def condition(self, value):
        return truth(self.known(value))

    def expr(self, node, scope):
        self.tick()
        if is_literal(node):
            return value(node)
        if isinstance(node, n.Name):
            return scope.lookup(node.id)
        if isinstance(node, n.Index):
            table = self.expr(node.value, scope)
            if not isinstance(table, Table):
                raise DeobfuscationError("Constant layer indexed a non-table")
            return table.get(self.expr(node.idx, scope))
        if isinstance(node, n.Table):
            tab, index = Table(), 1
            for i, field in enumerate(node.fields):
                if field.key is None and i == len(node.fields) - 1:
                    for val in self.values([field.value], scope):
                        tab.set(index, val)
                        index += 1
                    break
                key = self.expr(field.key, scope) if field.key else index
                tab.set(key, self.expr(field.value, scope))
                index += field.key is None
            return tab
        if isinstance(node, n.AnonymousFunction):
            return Closure(node, scope)
        if isinstance(node, (n.AndLoOp, n.OrLoOp)):
            left = self.expr(node.left, scope)
            if self.condition(left) == isinstance(node, n.AndLoOp):
                return self.expr(node.right, scope)
            return left
        if isinstance(node, n.BinaryOp):
            left, right = (
                self.known(self.expr(node.left, scope)),
                self.known(self.expr(node.right, scope)),
            )
            if type(node) in ARITHMETIC:
                if type(left) not in (int, float) or type(right) not in (int, float):
                    raise DeobfuscationError("Non-numeric constant arithmetic")
                result = ARITHMETIC[type(node)](float(left), float(right))
                if not isinstance(result, (float, int)) or not math.isfinite(result):
                    raise DeobfuscationError("Invalid constant arithmetic")
                return result
            if isinstance(node, (n.EqToOp, n.NotEqToOp)):
                result = type(left) is type(right) and left == right
                if type(left) in (int, float) and type(right) in (int, float):
                    result = left == right
                return not result if isinstance(node, n.NotEqToOp) else result
            if isinstance(node, n.LessThanOp):
                return left < right
            if isinstance(node, n.LessOrEqThanOp):
                return left <= right
            if isinstance(node, n.GreaterThanOp):
                return left > right
            if isinstance(node, n.GreaterOrEqThanOp):
                return left >= right
            if isinstance(node, n.Concat) and isinstance(left, bytes) and isinstance(right, bytes):
                if len(left) + len(right) <= LIMIT:
                    return self.allocate_bytes(left + right)
        if isinstance(node, n.UnaryOp):
            val = self.known(self.expr(node.operand, scope))
            if isinstance(node, n.ULengthOP) and isinstance(val, (bytes, Table)):
                return len(val)
            if isinstance(node, n.ULNotOp):
                return not truth(val)
            if isinstance(node, n.UMinusOp) and type(val) in (int, float):
                return -float(val)
        if isinstance(node, n.Call):
            result = self.call(self.expr(node.func, scope), self.values(node.args, scope))
            return result[0] if result else None
        raise DeobfuscationError(f"Unsupported constant expression: {type(node).__name__}")

    def builtin(self, name, args):
        if name == "type":
            val = args[0]
            return (
                b"nil"
                if val is None
                else b"boolean"
                if isinstance(val, bool)
                else b"string"
                if isinstance(val, bytes)
                else b"number"
                if isinstance(val, (float, int))
                else b"table"
                if isinstance(val, Table)
                else b"function"
            )
        if name == "math.floor":
            if len(args) != 1 or type(args[0]) not in (int, float):
                raise DeobfuscationError("Invalid constant math.floor argument")
            return math.floor(args[0])
        if name == "string.len":
            if len(args) != 1 or not isinstance(args[0], bytes):
                raise DeobfuscationError("Invalid constant string.len argument")
            return len(args[0])
        if name == "string.char":
            if any(type(x) not in (int, float) or x != int(x) or not 0 <= x <= 255 for x in args):
                raise DeobfuscationError("Invalid byte in string.char")
            return self.allocate_bytes(bytes(int(x) for x in args))
        if name == "string.sub":
            if (
                len(args) not in (2, 3)
                or not isinstance(args[0], bytes)
                or any(type(x) not in (int, float) for x in args[1:])
            ):
                raise DeobfuscationError("Invalid constant string.sub arguments")
            data, start = args[:2]
            end = args[2] if len(args) == 3 else -1
            start = int(start if start >= 0 else len(data) + start + 1)
            end = int(end if end >= 0 else len(data) + end + 1)
            return self.allocate_bytes(data[max(1, start) - 1 : max(0, end)])
        if name == "table.insert":
            if len(args) not in (2, 3) or not isinstance(args[0], Table):
                raise DeobfuscationError("Invalid constant table.insert arguments")
            tab, val = args[0], args[-1]
            at = int(args[1]) if len(args) == 3 else len(tab) + 1
            if not 1 <= at <= len(tab) + 1:
                raise DeobfuscationError("Invalid constant table insertion")
            for i in range(len(tab), at - 1, -1):
                self.tick()
                tab.set(i + 1, tab.get(i))
            tab.set(at, val)
            return None
        if name == "table.concat":
            if len(args) not in (1, 2) or not isinstance(args[0], Table):
                raise DeobfuscationError("Unsupported constant table.concat arguments")
            tab = args[0]
            sep = args[1] if len(args) > 1 else b""
            parts = [tab.get(i) for i in range(1, len(tab) + 1)]
            if sum(len(x) for x in parts) + len(sep) * len(parts) > LIMIT:
                raise DeobfuscationError("Constant string size limit exceeded")
            return self.allocate_bytes(sep.join(parts))
        raise DeobfuscationError(f"Unavailable constant operation: {name}")

    def call(self, function, args):
        self.tick()
        if isinstance(function, Builtin):
            return [self.builtin(function.name, args)]
        if not isinstance(function, Closure) or self.depth >= 32:
            raise DeobfuscationError("Unsupported or recursive constant function")
        scope = Scope(function.scope)
        for i, arg in enumerate(function.node.args):
            if not isinstance(arg, n.Name):
                raise DeobfuscationError("Varargs in constant function")
            scope[arg.id] = args[i] if i < len(args) else None
        self.depth += 1
        try:
            self.block(function.node.body, scope)
        except Returned as ret:
            return ret.values
        finally:
            self.depth -= 1
        return []

    def block(self, block, scope):
        for stmt in block.body:
            self.tick()
            if isinstance(stmt, n.LocalFunction):
                scope[stmt.name.id] = Closure(stmt, scope)
            elif isinstance(stmt, n.Assign):
                targets = []
                for target in stmt.targets:
                    if isinstance(target, n.Name):
                        targets.append((None, target.id))
                    elif isinstance(target, n.Index) and not isinstance(stmt, n.LocalAssign):
                        targets.append(
                            (self.expr(target.value, scope), self.expr(target.idx, scope))
                        )
                    else:
                        raise DeobfuscationError("Unsupported constant assignment")
                values = self.values(stmt.values, scope)
                for i, (table, key) in enumerate(targets):
                    val = values[i] if i < len(values) else None
                    if isinstance(stmt, n.LocalAssign):
                        scope[key] = val
                    elif isinstance(table, Table):
                        table.set(key, val)
                    elif table is None:
                        scope.assign(key, val)
                    else:
                        raise DeobfuscationError("Constant layer assigned to a non-table")
            elif isinstance(stmt, n.Do):
                self.block(stmt.body, Scope(scope))
            elif isinstance(stmt, (n.If, n.ElseIf)):
                if self.condition(self.expr(stmt.test, scope)):
                    self.block(stmt.body, Scope(scope))
                elif isinstance(stmt.orelse, n.ElseIf):
                    self.block(n.Block([stmt.orelse]), Scope(scope))
                elif stmt.orelse:
                    self.block(stmt.orelse, Scope(scope))
            elif isinstance(stmt, n.While):
                try:
                    while self.condition(self.expr(stmt.test, scope)):
                        self.block(stmt.body, Scope(scope))
                except Broken:
                    pass
            elif isinstance(stmt, n.Fornum):
                start, stop = self.expr(stmt.start, scope), self.expr(stmt.stop, scope)
                step = self.expr(stmt.step, scope) if stmt.step else 1
                if any(type(x) not in (int, float) for x in (start, stop, step)):
                    raise DeobfuscationError("Invalid numeric loop in constant layer")
                if step == 0:
                    raise DeobfuscationError("Zero loop step in constant layer")
                try:
                    while start <= stop if step > 0 else start >= stop:
                        self.tick()
                        inner = Scope(scope)
                        inner[stmt.target.id] = start
                        self.block(stmt.body, inner)
                        start += step
                except Broken:
                    pass
            elif isinstance(stmt, n.Forin):
                if len(stmt.iter) != 1 or not isinstance(stmt.iter[0], n.Call):
                    raise DeobfuscationError("Unsupported constant iterator")
                call = stmt.iter[0]
                iterator = self.expr(call.func, scope)
                if (
                    not isinstance(iterator, Builtin)
                    or iterator.name != "ipairs"
                    or len(call.args) != 1
                ):
                    raise DeobfuscationError("Only ipairs is supported in constant layers")
                tab = self.expr(call.args[0], scope)
                try:
                    for index in range(1, len(tab) + 1):
                        self.tick()
                        inner = Scope(scope)
                        for i, target in enumerate(stmt.targets):
                            inner[target.id] = (index, tab.get(index))[i] if i < 2 else None
                        self.block(stmt.body, inner)
                except Broken:
                    pass
            elif isinstance(stmt, n.Call):
                self.expr(stmt, scope)
            elif isinstance(stmt, n.Break):
                raise Broken()
            elif isinstance(stmt, n.Return):
                raise Returned(self.values(stmt.values, scope))
            elif not isinstance(stmt, n.SemiColon):
                raise DeobfuscationError(f"Unsupported constant statement: {type(stmt).__name__}")


def pure_accessor(function):
    if not isinstance(function, Closure) or len(function.node.args) != 1:
        return False
    statements = function.node.body.body
    if len(statements) != 1 or not isinstance(statements[0], n.Return):
        return False
    values = statements[0].values
    if len(values) != 1 or not isinstance(values[0], n.Index):
        return False
    index = values[0]
    if not isinstance(index.value, n.Name):
        return False
    if not isinstance(function.scope.lookup(index.value.id), Table):
        return False
    parameter = function.node.args[0]
    return isinstance(parameter, n.Name) and all(
        isinstance(x, n.Number)
        or isinstance(x, n.Name)
        and x.id == parameter.id
        or type(x) in ARITHMETIC
        or isinstance(x, n.UMinusOp)
        for x in walk(index.idx)
    )


def decode_constants(source):
    tree = parse(source)
    Bindings().block(tree.body, {})
    body = tree.body.body
    if len(body) != 1 or not isinstance(body[0], n.Return) or len(body[0].values) != 1:
        raise DeobfuscationError("Expected the WeAreDevs returned-function wrapper")
    call = body[0].values[0]
    if not isinstance(call, n.Call) or not isinstance(call.func, n.AnonymousFunction):
        raise DeobfuscationError("Expected the WeAreDevs returned-function wrapper")
    outer = call.func.body.body
    if len(outer) < 2 or not isinstance(outer[-1], n.Return):
        raise DeobfuscationError("WeAreDevs constant prefix is missing")
    evaluator = Evaluator()
    evaluator.block(n.Block(outer[:-1]), evaluator.scope)
    constants = []

    def replace(node):
        if (
            isinstance(node, n.Call)
            and isinstance(node.func, n.Name)
            and node.func.id in evaluator.scope
        ):
            function = evaluator.scope[node.func.id]
            if not pure_accessor(function) or not all(is_literal(arg) for arg in node.args):
                raise DeobfuscationError("Unsupported dynamic constant accessor")
            result = evaluator.call(function, [value(arg) for arg in node.args])
            if len(result) != 1:
                raise DeobfuscationError("Constant accessor must return one value")
            constants.append(result[0])
            return literal(result[0])
        return node

    core = transform(outer[-1], replace)
    prefix_names = {name for name in evaluator.scope if name.startswith("local_")}
    if any(isinstance(x, n.Name) and x.id in prefix_names for x in walk(core)):
        raise DeobfuscationError("Constant layer has unresolved references")
    call.func.body.body = [core]
    return tree, constants
