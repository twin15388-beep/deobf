"""Static recovery for the supported WeAreDevs/Prometheus wrapper family."""

import hashlib
import json

from ..errors import DeobfuscationError
from .constants import decode_constants
from .strings import decode_strings
from .syntax import n, render, transform, walk
from .vm import VM

NAME = "wearedevs-prometheus-v1"


def constant_record(value):
    if isinstance(value, bytes):
        return {"bytes_hex": value.hex(), "text": value.decode("utf8", errors="backslashreplace")}
    return value


def friendly_names(vm):
    suggestions = dict(
        zip(
            [arg.id for arg in vm.wrapper.args[:7]],
            [
                "environment",
                "unpack_values",
                "new_proxy",
                "set_metatable",
                "get_metatable",
                "select_values",
                "input_arguments",
            ],
            strict=True,
        )
    )
    suggestions.update(
        {vm.pc: "state", vm.args: "arguments", vm.captures: "captures", vm.proxy: "capture_guard"}
    )
    reserved = {node.id for node in walk(vm.tree) if isinstance(node, n.Name)}
    mapping = {}
    for original, candidate in suggestions.items():
        while candidate in reserved:
            candidate += "_"
        reserved.add(candidate)
        mapping[original] = candidate

    def rename(node):
        if isinstance(node, n.Name) and node.id in mapping:
            node.id = mapping[node.id]
        return node

    transform(vm.tree, rename)


def layers(source):
    try:
        tree, constants = decode_constants(source)
        data = ("--!strict\n" + render(tree) + "\n").encode()
        return {
            "vm.luau": data,
            "constants.json": (
                json.dumps([constant_record(x) for x in constants], indent=2) + "\n"
            ).encode(),
            "manifest.json": (
                json.dumps(
                    {
                        "format": "wearedevs",
                        "stage": "constant-prefix",
                        "source_sha256": hashlib.sha256(source).hexdigest(),
                        "vm_sha256": hashlib.sha256(data).hexdigest(),
                        "constant_accesses": len(constants),
                    },
                    indent=2,
                )
                + "\n"
            ).encode(),
        }
    except (
        AssertionError,
        AttributeError,
        KeyError,
        IndexError,
        TypeError,
        ValueError,
        RecursionError,
        OverflowError,
        ZeroDivisionError,
    ) as exc:
        raise DeobfuscationError("Unsupported WeAreDevs constant prefix") from exc


def recover(source, *, emit="luau"):
    if emit not in ("luau", "ir"):
        raise DeobfuscationError(
            "WeAreDevs supports --emit luau or --emit ir; Lua 5.1 bytecode output is Luraph-only"
        )
    try:
        tree, constants = decode_constants(source)
        vm = VM(tree)
        strings, string_status = decode_strings(vm)
        functions = vm.recover()
        if emit == "ir":
            return (
                json.dumps(
                    {
                        "profile": NAME,
                        "source_sha256": hashlib.sha256(source).hexdigest(),
                        "constants": [constant_record(x) for x in constants],
                        "decoded_strings": strings,
                        "string_status": string_status,
                        "functions": functions,
                        "blocks": [
                            {
                                "index": b.index,
                                "successors": list(b.edges),
                                "labels": list(b.targets),
                                "exit_global": constant_record(b.exit_key),
                                "instructions": [render(stmt) for stmt in b.statements],
                            }
                            for b in vm.blocks
                        ],
                        "limitations": [
                            "Generated names; original names and comments are unavailable",
                            "Tamper checks remain and may react to changed source lines or stack frames",
                            "Truthy opaque exit globals are unsupported and guarded in source",
                            "Decoded cache reads use the recognized cipher initializer; calls and RNG effects remain",
                        ],
                    },
                    indent=2,
                    allow_nan=False,
                )
                + "\n"
            ).encode()
        friendly_names(vm)
        result = ("--!strict\n" + render(tree) + "\n").encode()
        if len(result) > 8 * 1024 * 1024:
            raise DeobfuscationError("WeAreDevs output exceeds 8 MiB")
        return result
    except (
        AssertionError,
        AttributeError,
        KeyError,
        IndexError,
        TypeError,
        ValueError,
        RecursionError,
        OverflowError,
        ZeroDivisionError,
    ) as exc:
        raise DeobfuscationError("Unsupported WeAreDevs/Prometheus structure") from exc
