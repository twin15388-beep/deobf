"""Recover functions and control-flow edges from a Prometheus numeric dispatcher."""

import copy
from dataclasses import dataclass

from ..errors import DeobfuscationError
from .syntax import fold, is_literal, literal, n, render, transform, truth, value, walk

UNKNOWN = frozenset({("true", None), ("false", None)})
END = -1


def require(condition, message):
    if not condition:
        raise DeobfuscationError(message)


def names(node):
    return {x.id for x in walk(node) if isinstance(x, n.Name)}


def constant_pass(statements):
    known = {}
    output = []
    for original in statements:
        stmt = copy.deepcopy(original)

        def substitute(node):
            if isinstance(node, n.Name) and node.id in known:
                return copy.deepcopy(known[node.id])
            return fold(node)

        if isinstance(stmt, n.Assign):
            require(
                not any(
                    isinstance(x, (n.AnonymousFunction, n.Function)) for x in walk(stmt.values)
                ),
                "Nested function in VM instruction block",
            )
            stmt.values = transform(stmt.values, substitute)
            for target in stmt.targets:
                if isinstance(target, n.Index):
                    target.value = transform(target.value, substitute)
                    target.idx = transform(target.idx, substitute)
            for i, target in enumerate(stmt.targets):
                if isinstance(target, n.Name):
                    known.pop(target.id, None)
                    if (
                        i >= len(stmt.values)
                        and stmt.values
                        and isinstance(stmt.values[-1], (n.Call, n.Invoke, n.Dots))
                        and not stmt.values[-1].wrapped
                    ):
                        continue
                    rhs = stmt.values[i] if i < len(stmt.values) else n.Nil()
                    if is_literal(rhs):
                        known[target.id] = rhs
        elif isinstance(stmt, n.Call):
            stmt = transform(stmt, substitute)
        else:
            raise DeobfuscationError("Unsupported statement inside WeAreDevs VM block")
        output.append(stmt)
    return output


def possible(node, state):
    if is_literal(node):
        val = value(node)
        if type(val) in (int, float):
            return frozenset({("number", val)})
        return frozenset({("true" if truth(val) else "false", None)})
    if isinstance(node, n.Name):
        return state.get(node.id, UNKNOWN)
    if isinstance(node, (n.AndLoOp, n.OrLoOp)):
        left, right = possible(node.left, state), possible(node.right, state)
        result = set()
        for tag, val in left:
            if (tag != "false") == isinstance(node, n.AndLoOp):
                result.update(right)
            else:
                result.add((tag, val))
        require(len(result) <= 8, "Too many possible VM successors")
        return frozenset(result)
    return UNKNOWN


@dataclass
class Block:
    index: int
    lower: float
    upper: float
    statements: list
    edges: tuple = ()
    targets: tuple = ()
    exit_key: bytes | None = None


class VM:
    def __init__(self, tree):
        self.tree = tree
        self.output_nodes = 0
        candidates = [
            x
            for x in walk(tree)
            if isinstance(x, n.Call)
            and isinstance(x.func, n.AnonymousFunction)
            and len(x.func.args) >= 7
        ]
        require(len(candidates) == 1, "Expected one Prometheus VM wrapper")
        self.wrapper_call = candidates[0]
        self.wrapper = self.wrapper_call.func
        require(len(self.wrapper.body.body) == 2, "Unsupported VM initialization")
        self.initialization, self.bootstrap = self.wrapper.body.body
        init = self.initialization
        require(
            type(init) is n.Assign and len(init.targets) == len(init.values),
            "Unsupported VM helpers",
        )
        functions = {
            target.id: rhs
            for target, rhs in zip(init.targets, init.values, strict=True)
            if isinstance(target, n.Name) and isinstance(rhs, n.AnonymousFunction)
        }
        dispatchers = [
            (name, fn)
            for name, fn in functions.items()
            if len(fn.args) == 4
            and len(fn.body.body) == 4
            and isinstance(fn.body.body[0], n.LocalAssign)
            and isinstance(fn.body.body[1], n.While)
        ]
        require(len(dispatchers) == 1, "Unsupported numeric dispatcher")
        self.dispatch_name, self.dispatch = dispatchers[0]
        self.pc, self.args, self.captures, self.proxy = [arg.id for arg in self.dispatch.args]
        self.env = self.wrapper.args[0].id
        self.locals = self.dispatch.body.body[0].targets
        require(
            not self.dispatch.body.body[0].values,
            "Initialized dispatcher registers are unsupported",
        )
        self.epilogue = self.dispatch.body.body[2:]
        touch, ret = self.epilogue
        require(
            type(touch) is n.Assign
            and len(touch.values) == 1
            and len(touch.targets) == 1
            and isinstance(touch.values[0], n.ULengthOP)
            and isinstance(touch.values[0].operand, n.Name)
            and touch.values[0].operand.id == self.proxy
            and isinstance(touch.targets[0], n.Name)
            and touch.targets[0].id == self.pc
            and isinstance(ret, n.Return)
            and len(ret.values) == 1
            and isinstance(ret.values[0], n.Call)
            and isinstance(ret.values[0].func, n.Name)
            and ret.values[0].func.id == self.wrapper.args[1].id,
            "Unsupported VM return epilogue",
        )
        loop = self.dispatch.body.body[1]
        require(
            isinstance(loop.test, n.Name) and loop.test.id == self.pc,
            "Unsupported VM loop condition",
        )
        self.blocks = []
        self.split(loop.body, float("-inf"), float("inf"))
        require(0 < len(self.blocks) <= 4096, "VM block count limit exceeded")
        for block in self.blocks:
            self.edges(block)
        self.factories = {}
        for name, function in functions.items():
            if name != self.dispatch_name and self.dispatch_name in names(function):
                self.factories[name] = self.factory(function)
        require(self.factories, "No supported VM closure factories")
        self.entries = {}
        reserved = names(tree)
        next_name = 1
        for node in walk(tree):
            if (
                isinstance(node, n.Call)
                and isinstance(node.func, n.Name)
                and node.func.id in self.factories
            ):
                require(
                    len(node.args) == 2
                    and isinstance(node.args[0], n.Number)
                    and isinstance(node.args[1], n.Table),
                    "Dynamic VM entry or capture list",
                )
                label = self.label(node.args[0].n)
                key = (node.func.id, label)
                if key not in self.entries:
                    while f"recovered_{next_name}" in reserved:
                        next_name += 1
                    self.entries[key] = f"recovered_{next_name}"
                    next_name += 1
        require(len(self.entries) <= 256, "VM function count limit exceeded")
        protected = set(self.factories) | {self.dispatch_name}
        allowed = {id(x) for x in [*self.wrapper.args, *init.targets]}
        for function in self.factories.values():
            thunk = function.body.body[1].values[0]
            allowed.add(id(thunk.body.body[0].values[0].func))
        for node in walk(tree):
            if (
                isinstance(node, n.Call)
                and isinstance(node.func, n.Name)
                and node.func.id in self.factories
            ):
                allowed.add(id(node.func))
        require(
            not any(
                isinstance(node, n.Name) and node.id in protected and id(node) not in allowed
                for node in walk(tree)
            ),
            "Aliased or reassigned VM helpers are unsupported",
        )

    @staticmethod
    def label(val):
        require(
            type(val) in (int, float) and 0 <= val < 2**24 and int(val) == val, "Invalid VM label"
        )
        return int(val)

    def lookup(self, label):
        for block in self.blocks:
            if block.lower <= label < block.upper:
                return block.index
        raise DeobfuscationError("VM label is outside the dispatcher")

    def split(self, body, lower, upper):
        if len(body.body) == 1 and isinstance(body.body[0], n.If):
            branch = body.body[0]
            test = branch.test
            require(
                isinstance(test, n.LessThanOp)
                and isinstance(test.left, n.Name)
                and test.left.id == self.pc
                and isinstance(test.right, n.Number)
                and isinstance(branch.orelse, n.Block),
                "Unsupported dispatcher split",
            )
            threshold = test.right.n
            require(lower < threshold < upper, "Unordered dispatcher thresholds")
            self.split(branch.body, lower, threshold)
            self.split(branch.orelse, threshold, upper)
        else:
            self.blocks.append(Block(len(self.blocks), lower, upper, constant_pass(body.body)))

    def edges(self, block):
        state = {}
        final_rhs = None
        for stmt in block.statements:
            if isinstance(stmt, n.Assign):
                values = [possible(x, state) for x in stmt.values]
                tail = (
                    UNKNOWN
                    if stmt.values
                    and isinstance(stmt.values[-1], (n.Call, n.Invoke, n.Dots))
                    and not stmt.values[-1].wrapped
                    else frozenset({("false", None)})
                )
                for i, target in enumerate(stmt.targets):
                    if isinstance(target, n.Name):
                        state[target.id] = values[i] if i < len(values) else tail
                        if target.id == self.pc:
                            require(i < len(stmt.values), "Missing VM position assignment")
                            final_rhs = stmt.values[i]
        require(final_rhs is not None, "VM block does not assign its next position")
        if (
            isinstance(final_rhs, n.Index)
            and isinstance(final_rhs.value, n.Name)
            and final_rhs.value.id == self.env
        ):
            require(isinstance(final_rhs.idx, n.String), "Dynamic VM exit global")
            block.exit_key = final_rhs.idx.s
            block.edges = ()
            return
        vals = state[self.pc]
        require(
            all(tag == "number" or tag == "false" for tag, _ in vals), "Unresolved VM successor"
        )
        targets = sorted(self.label(val) for tag, val in vals if tag == "number")
        if any(tag == "false" for tag, _ in vals):
            require(not targets, "Mixed return and branch VM position")
        require(len(targets) <= 2, "Unsupported multiway VM branch")
        block.targets = tuple(targets)
        block.edges = tuple(self.lookup(target) for target in targets)

    def factory(self, function):
        require(
            len(function.args) == 2 and len(function.body.body) == 3, "Unsupported closure factory"
        )
        retain, closure, result = function.body.body
        require(
            isinstance(retain, n.LocalAssign)
            and len(retain.values) == 1
            and isinstance(retain.values[0], n.Call)
            and isinstance(closure, n.LocalAssign)
            and len(closure.values) == 1
            and isinstance(closure.values[0], n.AnonymousFunction)
            and isinstance(result, n.Return),
            "Unsupported closure factory body",
        )
        inner = closure.values[0]
        require(
            len(inner.body.body) == 1 and isinstance(inner.body.body[0], n.Return),
            "Unsupported closure thunk",
        )
        ret = inner.body.body[0].values
        require(
            len(ret) == 1
            and isinstance(ret[0], n.Call)
            and isinstance(ret[0].func, n.Name)
            and ret[0].func.id == self.dispatch_name
            and len(ret[0].args) == 4,
            "Unsupported dispatcher call",
        )
        args = ret[0].args
        require(
            isinstance(args[0], n.Name)
            and args[0].id == function.args[0].id
            and isinstance(args[1], n.Table)
            and isinstance(args[2], n.Name)
            and args[2].id == function.args[1].id
            and isinstance(args[3], n.Name)
            and args[3].id == retain.targets[0].id,
            "Unexpected VM argument mapping",
        )
        require(
            render(result.values) == render(closure.targets), "Unexpected closure factory return"
        )
        require(
            len(retain.values[0].args) == 1
            and isinstance(retain.values[0].args[0], n.Name)
            and retain.values[0].args[0].id == function.args[1].id,
            "Unexpected capture retention",
        )
        require(
            len(args[1].fields) == len(inner.args)
            and all(field.key is None for field in args[1].fields),
            "Unexpected argument table",
        )
        for arg, field in zip(inner.args, args[1].fields, strict=True):
            require(render(arg) == render(field.value), "Reordered closure arguments")
        return function

    def reachable(self, start):
        found, pending = set(), [start]
        while pending:
            at = pending.pop()
            if at not in found:
                found.add(at)
                pending.extend(self.blocks[at].edges)
        return found

    def rewrite_calls(self, node):
        def replace(item):
            if (
                isinstance(item, n.Call)
                and isinstance(item.func, n.Name)
                and item.func.id in self.factories
            ):
                key = (item.func.id, self.label(item.args[0].n))
                item.func = n.Name(self.entries[key])
                item.args = item.args[1:]
            return item

        return transform(node, replace)

    def statements(self, block):
        self.output_nodes += sum(1 for _ in walk(block.statements))
        require(self.output_nodes <= 200_000, "VM output expansion exceeds 200,000 nodes")
        body = copy.deepcopy(block.statements)
        if block.exit_key is not None:
            body.append(
                n.If(
                    n.Name(self.pc),
                    n.Block(
                        [
                            n.Call(
                                n.Name("error"),
                                [literal(b"Unsupported truthy VM exit global: " + block.exit_key)],
                            )
                        ]
                    ),
                    None,
                )
            )
        return body

    def recover(self):
        definitions = []
        reports = []
        for (factory, label), name in self.entries.items():
            original = self.factories[factory]
            capture_arg = original.args[1].id
            retain, closure = copy.deepcopy(original.body.body[:2])
            thunk = closure.values[0]
            table = copy.deepcopy(thunk.body.body[0].values[0].args[1])
            start = self.lookup(label)
            graph = Flow(self, start)
            body = graph.emit()
            thunk.body.body = [
                n.LocalAssign(
                    [n.Name(self.pc), n.Name(self.args), n.Name(self.captures), n.Name(self.proxy)],
                    [literal(label), table, n.Name(capture_arg), copy.deepcopy(retain.targets[0])],
                ),
                n.LocalAssign(copy.deepcopy(self.locals), []),
                *body,
            ]
            definition = n.Assign(
                [n.Name(name)],
                [
                    n.AnonymousFunction(
                        [copy.deepcopy(original.args[1])], n.Block([retain, n.Return([thunk])])
                    )
                ],
            )
            definitions.append(self.rewrite_calls(definition))
            reports.append(
                {
                    "name": name,
                    "entry": label,
                    "parameters": [render(x) for x in thunk.args],
                    "blocks": sorted(graph.nodes),
                    "structured": graph.structured,
                }
            )
        self.wrapper.body.body = [
            n.LocalAssign([n.Name(name) for name in self.entries.values()], []),
            *definitions,
            self.initialization,
            self.rewrite_calls(self.bootstrap),
        ]
        for i, target in enumerate(self.initialization.targets):
            if target.id in self.factories or target.id == self.dispatch_name:
                self.initialization.values[i] = n.Nil()
        return reports


class Flow:
    """Structure reducible regions; retain an explicit state loop for other graphs."""

    def __init__(self, vm, entry):
        self.vm, self.entry = vm, entry
        self.nodes = vm.reachable(entry)
        self.graph = {i: set(vm.blocks[i].edges) for i in self.nodes}
        self.graph[END] = set()
        for edges in self.graph.values():
            if not edges:
                edges.add(END)
        self.graph[END] = set()
        self.predecessors = {i: set() for i in self.nodes}
        for i in self.nodes:
            for j in self.graph[i] - {END}:
                self.predecessors[j].add(i)
        dominators = {i: {i} if i == entry else set(self.nodes) for i in self.nodes}
        for _ in range(len(self.nodes) + 1):
            changed = False
            for i in self.nodes - {entry}:
                merged = {i} | set.intersection(*(dominators[p] for p in self.predecessors[i]))
                changed |= merged != dominators[i]
                dominators[i] = merged
            if not changed:
                break
        self.loops = {}
        for node in self.nodes:
            for header in self.graph[node] & dominators[node]:
                members, pending = {header, node}, [node] if node != header else []
                while pending:
                    at = pending.pop()
                    for parent in self.predecessors[at] - members:
                        members.add(parent)
                        pending.append(parent)
                self.loops.setdefault(header, set()).update(members)
        self.structured = True
        self.emitted = 0

    def exit_statements(self):
        return copy.deepcopy(self.vm.epilogue)

    def emit(self):
        try:
            return self.region(self.nodes, self.entry, None)
        except DeobfuscationError:
            self.structured = False
            return self.state_loop()

    def region(self, members, entry, active):
        nested = {h: group for h, group in self.loops.items() if h != active and group <= members}
        outer = {
            h: group for h, group in nested.items() if not any(group < g for g in nested.values())
        }
        follows = {}
        visible = set(members)
        for header, group in outer.items():
            exits = set.union(*(self.graph[i] for i in group)) - group
            require(len(exits) == 1, "Loop with multiple or no exits")
            follows[header] = next(iter(exits))
            visible -= group - {header}

        def target(dest):
            if dest == active:
                return "again"
            if dest == END:
                return "return"
            if dest not in members:
                return "break"
            return dest

        edges = {}
        for at in visible:
            successors = {follows[at]} if at in outer else self.graph[at]
            edges[at] = {target(x) for x in successors}
        for terminal in ("again", "break", "return"):
            edges[terminal] = {"done"}
        edges["done"] = set()
        all_nodes = set(edges)
        post = {i: {i} if i == "done" else set(all_nodes) for i in all_nodes}
        for _ in range(len(edges) + 1):
            changed = False
            for at in all_nodes - {"done"}:
                require(edges[at] <= all_nodes, "Irreducible loop entry")
                merged = {at} | set.intersection(*(post[x] for x in edges[at]))
                changed |= merged != post[at]
                post[at] = merged
            if not changed:
                break

        def emit_path(at, stop, trail):
            out = []
            while at != stop and at != "done":
                self.emitted += 1
                require(self.emitted < 20_000 and at not in trail, "Control-flow expansion limit")
                trail = trail | {at}
                if at == "again":
                    return out
                if at == "break":
                    return [*out, n.Break()]
                if at == "return":
                    return [*out, *self.exit_statements()]
                if at in outer:
                    body = self.region(outer[at], at, at)
                    out.append(n.While(n.TrueExpr(), n.Block(body)))
                    at = target(follows[at])
                    continue
                block = self.vm.blocks[at]
                out.extend(self.vm.statements(block))
                successors = list(dict.fromkeys(target(x) for x in block.edges)) or ["return"]
                if len(successors) == 1:
                    at = successors[0]
                    continue
                candidates = post[at] - {at}
                require(candidates, "No branch postdominator")
                join = max(candidates, key=lambda x: len(post[x]))
                left = emit_path(successors[0], join, trail)
                right = emit_path(successors[1], join, trail)
                test = n.EqToOp(n.Name(self.vm.pc), literal(block.targets[0]))
                out.append(n.If(test, n.Block(left), n.Block(right)))
                at = join
            return out

        return emit_path(entry, "done", set())

    def state_loop(self):
        branch = None
        for at in sorted(self.nodes, reverse=True):
            block = self.vm.blocks[at]
            body = self.vm.statements(block)
            if not block.edges:
                body.extend(self.exit_statements())
            lower = (
                n.GreaterOrEqThanOp(n.Name(self.vm.pc), literal(block.lower))
                if block.lower != float("-inf")
                else n.TrueExpr()
            )
            upper = (
                n.LessThanOp(n.Name(self.vm.pc), literal(block.upper))
                if block.upper != float("inf")
                else n.TrueExpr()
            )
            test = n.AndLoOp(lower, upper)
            branch = n.If(test, n.Block(body), n.Block([branch]) if branch else None)
        return [n.While(n.TrueExpr(), n.Block([branch]))]
