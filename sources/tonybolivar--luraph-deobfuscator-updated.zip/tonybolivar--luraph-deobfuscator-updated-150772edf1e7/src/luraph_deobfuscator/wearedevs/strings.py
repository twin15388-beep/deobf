"""Inspect a recognized cipher initializer using only bounded, in-memory operations.

Only selected initializer and helper blocks are interpreted. Unsupported calls
end this optional pass. Capture lifetime bookkeeping is modeled without invoking
Lua GC hooks. No Lua runtime or host application APIs are exposed.
"""

import copy
from dataclasses import dataclass

from ..errors import DeobfuscationError
from .constants import Builtin, Evaluator, Scope, Table
from .syntax import is_literal, literal, n, transform, truth, value, walk


class Unavailable:
    pass


UNAVAILABLE = Unavailable()


class Environment(Table):
    def get(self, key):
        return self.items.get(self.key(key), UNAVAILABLE)


class CacheView(Table):
    def __init__(self, cache):
        super().__init__()
        self.cache = cache

    def get(self, key):
        typed = self.key(key)
        return self.items[typed] if typed in self.items else self.cache.get(key)


@dataclass
class Thunk:
    label: int
    captures: Table


@dataclass
class PermutationIndex:
    index: int


def strings_in(node):
    return {x.s for x in walk(node) if isinstance(x, n.String)}


class CipherEvaluator(Evaluator):
    def __init__(self, vm, random_high=False):
        super().__init__()
        self.vm = vm
        self.random_high = random_high
        self.cell = 0
        self.vm_depth = 0
        self.caches = {}
        self.replacements = {}
        self.seeds = {}
        self.ambiguous = set()
        env = Environment()
        for name in ("math", "string", "table"):
            env.set(name.encode(), self.scope[name])
        for name in ("math.random", "string.byte", "table.remove"):
            library, method = name.split(".")
            self.scope[library].set(method.encode(), Builtin(name))
        env.set(b"setmetatable", Builtin("cache_view"))
        self.scope = Scope()
        for arg in vm.wrapper.args:
            self.scope[arg.id] = UNAVAILABLE
        self.scope[vm.env] = env
        self.scope[vm.wrapper.args[1].id] = Builtin("table.unpack")
        self.heaps = []
        for target, rhs in zip(vm.initialization.targets, vm.initialization.values, strict=True):
            if is_literal(rhs):
                self.scope[target.id] = value(rhs)
            elif isinstance(rhs, n.Table) and not rhs.fields:
                tab = self.scope[target.id] = Table()
                self.heaps.append(tab)
            elif target.id in vm.factories:
                self.scope[target.id] = Builtin("factory")
            elif isinstance(rhs, n.AnonymousFunction):
                statements = rhs.body.body
                if not rhs.args and len(statements) == 3 and isinstance(statements[-1], n.Return):
                    self.scope[target.id] = Builtin("allocate")
                elif (
                    len(rhs.args) == 1 and len(statements) == 2 and isinstance(statements[-1], n.If)
                ):
                    self.scope[target.id] = Builtin("release")

    def known(self, value):
        if value is UNAVAILABLE or isinstance(value, PermutationIndex):
            raise DeobfuscationError("Unresolved cipher value")
        return value

    def expr(self, node, scope):
        if isinstance(node, n.Index):
            self.tick()
            tab = self.expr(node.value, scope)
            key = self.expr(node.idx, scope)
            if tab is UNAVAILABLE:
                return UNAVAILABLE
            if not isinstance(tab, Table) or key is UNAVAILABLE:
                raise DeobfuscationError("Unresolved cipher table access")
            result = tab.get(key)
            base = tab.cache if isinstance(tab, CacheView) else tab
            match = self.caches.get((id(base), type(key), key))
            if self.vm_depth == 0 and match is not None and result == match:
                old = self.replacements.get(id(node))
                if old is not None and (old[1] != result or self.seeds[id(node)] != key):
                    self.ambiguous.add(id(node))
                self.replacements[id(node)] = (node, result)
                self.seeds[id(node)] = key
            return result
        if isinstance(node, (n.AndLoOp, n.OrLoOp)):
            self.tick()
            left = self.expr(node.left, scope)
            if left is UNAVAILABLE:
                raise DeobfuscationError("Unresolved cipher branch")
            if self.condition(left) == isinstance(node, n.AndLoOp):
                return self.expr(node.right, scope)
            return left
        return super().expr(node, scope)

    def builtin(self, name, args):
        if any(x is UNAVAILABLE for x in args) and name != "release":
            raise DeobfuscationError("Unresolved cipher argument")
        if any(isinstance(x, PermutationIndex) for x in args) and name != "table.remove":
            raise DeobfuscationError("Randomness outside a cipher permutation is unsupported")
        if name == "allocate":
            self.cell += 1
            if self.cell > 65_536:
                raise DeobfuscationError("Cipher cell limit exceeded")
            return self.cell
        if name == "release":
            return None
        if name == "factory":
            label, captures = args
            if not isinstance(captures, Table):
                raise DeobfuscationError("Unresolved cipher captures")
            return Thunk(self.vm.label(label), captures)
        if name == "math.random":
            if len(args) == 1:
                low, high = 1, args[0]
            else:
                low, high = args
            if not (type(low) in (int, float) and type(high) in (int, float) and low <= high):
                raise DeobfuscationError("Unresolved cipher permutation")
            return PermutationIndex(high if self.random_high else low)
        if name == "table.remove":
            tab = args[0]
            position = args[1] if len(args) == 2 else len(tab)
            at = int(position.index if isinstance(position, PermutationIndex) else position)
            if not isinstance(tab, Table) or not 1 <= at <= len(tab):
                raise DeobfuscationError("Invalid cipher byte pool")
            result = tab.get(at)
            for index in range(at, len(tab) + 1):
                self.tick()
                tab.set(index, tab.get(index + 1))
            return result
        if name == "string.byte":
            data = args[0]
            at = int(args[1]) if len(args) == 2 else 1
            if not isinstance(data, bytes) or not 1 <= at <= len(data):
                raise DeobfuscationError("Invalid cipher string position")
            return data[at - 1]
        if name == "cache_view":
            tab, meta = args
            if not isinstance(tab, Table) or tab.items or not isinstance(meta, Table):
                raise DeobfuscationError("Unsupported cipher metatable")
            cache = meta.get(b"__index")
            if not isinstance(cache, Table) or set(meta.items) != {(bytes, b"__index")}:
                raise DeobfuscationError("Unsupported cipher metatable")
            return CacheView(cache)
        return super().builtin(name, args)

    def call(self, function, args):
        if isinstance(function, Builtin) and function.name == "table.unpack":
            tab = args[0]
            if not isinstance(tab, Table) or len(args) != 1:
                raise DeobfuscationError("Unsupported cipher return")
            return [tab.get(i) for i in range(1, len(tab) + 1)]
        if not isinstance(function, Thunk):
            return super().call(function, args)
        if self.vm_depth >= 8:
            raise DeobfuscationError("Cipher call nesting limit exceeded")
        before = {}
        seed = args[1] if len(args) >= 2 and isinstance(args[0], bytes) else None
        if type(seed) in (int, float):
            for heap in self.heaps:
                for cell in heap.items.values():
                    if isinstance(cell, Table):
                        before[id(cell)] = cell.get(seed)
        self.vm_depth += 1
        try:
            result = self.run(function.label, args, function.captures)
        finally:
            self.vm_depth -= 1
        if type(seed) in (int, float) and result == [seed]:
            for heap in self.heaps:
                for cell in heap.items.values():
                    if isinstance(cell, Table):
                        decoded = cell.get(seed)
                        if (
                            isinstance(decoded, bytes)
                            and len(decoded) == len(args[0])
                            and before.get(id(cell)) != decoded
                        ):
                            self.caches[id(cell), type(seed), seed] = decoded
        return result

    def run(self, label, args=(), captures=None):
        vm = self.vm
        scope = Scope(self.scope)
        initial = UNAVAILABLE if self.vm_depth == 0 else None
        scope.update({x.id: initial for x in vm.locals})
        scope.update(
            {
                vm.pc: label,
                vm.args: UNAVAILABLE if self.vm_depth == 0 else Table(args),
                vm.captures: UNAVAILABLE if self.vm_depth == 0 else captures or Table(),
                vm.proxy: Table(),
            }
        )
        while True:
            self.tick()
            pc = scope[vm.pc]
            if pc is UNAVAILABLE or not truth(pc):
                break
            block = vm.blocks[vm.lookup(vm.label(pc))]
            self.block(n.Block(block.statements), scope)
        ret = vm.epilogue[-1].values
        if len(ret) != 1 or not isinstance(ret[0], n.Call):
            raise DeobfuscationError("Unsupported cipher epilogue")
        return self.call(self.expr(ret[0].func, scope), [self.expr(x, scope) for x in ret[0].args])


def decode_strings(vm):
    # The recognizer is independent of randomized names, labels, and cipher keys.
    # It deliberately skips variants without the familiar cipher initializer.
    starts = [
        b
        for b in vm.blocks
        if {b"math", b"floor", b"random", b"string", b"char", b"table", b"remove"}
        <= strings_in(b.statements)
    ]
    constants = {x.n for b in vm.blocks for x in walk(b.statements) if isinstance(x, n.Number)}
    if not {2**45, 257, 256, 2**32} <= constants or len(starts) != 1:
        return [], "No supported cipher initializer found"
    attempts = []
    for random_high in (False, True):
        evaluator = CipherEvaluator(vm, random_high)
        try:
            start = starts[0]
            evaluator.run(max(0, int(start.lower)) if start.lower != float("-inf") else 0)
        except (
            DeobfuscationError,
            TypeError,
            ValueError,
            KeyError,
            IndexError,
            OverflowError,
            ZeroDivisionError,
        ):
            pass
        attempts.append(evaluator)
    first, second = attempts
    replacements = {
        key: data
        for key, (_, data) in first.replacements.items()
        if key in second.replacements
        and data == second.replacements[key][1]
        and key not in first.ambiguous | second.ambiguous
    }
    records = []
    for block in vm.blocks:
        if any(block.index in vm.reachable(successor) for successor in block.edges):
            continue

        def replace(node, block=block):
            if id(node) in replacements:
                data = replacements[id(node)]
                records.append(
                    {
                        "block": block.index,
                        "seed": first.seeds[id(node)],
                        "bytes_hex": data.hex(),
                        "text": data.decode("utf8", errors="backslashreplace"),
                    }
                )
                return copy.deepcopy(literal(data))
            return node

        block.statements = transform(block.statements, replace)
    return (
        records,
        "Decoded cache reads; cipher calls and initialization remain in source"
        if records
        else "Cipher initializer found, but no literal cache read was resolved",
    )
