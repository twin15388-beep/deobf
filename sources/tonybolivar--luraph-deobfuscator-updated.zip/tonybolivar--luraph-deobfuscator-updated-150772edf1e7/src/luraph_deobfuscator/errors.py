class DeobfuscationError(Exception):
    """Malformed input, unsupported format, or failed recovery."""
