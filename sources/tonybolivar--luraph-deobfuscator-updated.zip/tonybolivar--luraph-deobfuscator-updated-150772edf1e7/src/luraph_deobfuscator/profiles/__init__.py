"""Versioned, fingerprinted VM format readers."""
