"""Reader for the fingerprinted buffer/LZMA VM family.

The bootstrap fingerprint binds the cipher and instruction constants. Only the
payload after that bootstrap varies. No Lua or bootstrap bytecode is executed.
"""

import hashlib
import math
import struct

from ..errors import DeobfuscationError
from ..model import Program, Prototype

NAME = "buffer-v1"
VM_SHA256 = "04ecac2c4be8642443fe760a413bea2fa7c93ad30ee7ebbe1951fc884968c945"
BOOTSTRAP_SHA256 = "9ae85ea24d457ff848fe928e317d70bf31c28c1e74780936ba5f04b9e86280cd"
PAYLOAD_OFFSET = 153060
KEY = bytes.fromhex("de77dab4b95029f8")
ALIASES = {18: 214, 41: 234, 46: 207, 62: 235, 126: 28, 182: 85, 219: 34, 239: 137}
HELPERS = (6, 63, 107, 87, 254, 70, 167, 40)
MAX_ITEMS = 100000


class Reader:
    def __init__(self, data: bytes, key: bytes = KEY):
        if len(key) != 8:
            raise DeobfuscationError("Expected an eight-byte payload key")
        self.data = bytes(b ^ key[i % 8] for i, b in enumerate(data))
        self.pos = 0
        self.work = 0

    def account(self, count):
        self.work += count
        if self.work > 1000000:
            raise DeobfuscationError("Payload item expansion limit exceeded")

    def take(self, count):
        if count < 0 or count > len(self.data) - self.pos:
            raise DeobfuscationError(f"Truncated payload at byte {self.pos}")
        value = self.data[self.pos : self.pos + count]
        self.pos += count
        return value

    def byte(self):
        return self.take(1)[0]

    def number(self, fmt):
        return struct.unpack("<" + fmt, self.take(struct.calcsize("<" + fmt)))[0]

    def varint(self):
        value = 0
        for shift in range(0, 56, 7):
            byte = self.byte()
            value |= (byte & 127) << shift
            if byte < 128:
                if value > 2**53 or (shift and byte == 0):
                    raise DeobfuscationError("Invalid variable-length integer")
                return value
        raise DeobfuscationError("Variable-length integer exceeds eight bytes")

    def signed(self):
        value = self.varint()
        return value - 2**53 if value >= 2**52 else value

    def count(self, value, limit=MAX_ITEMS):
        if not 0 <= value <= limit:
            raise DeobfuscationError(f"Invalid item count: {value}")
        self.account(value)
        return value

    def constants(self):
        count = self.count(self.varint() - 83908)
        encrypted = self.byte() != 0
        values = []
        for _ in range(count):
            tag = self.byte()
            if tag <= 23:
                value = True
            elif tag <= 41:
                value = self.number("d" if tag == 41 else "i")
            elif tag <= 59:
                value = self.number("H")
            elif tag <= 76:
                value = self.number("I") if tag == 64 else -self.byte()
            elif tag <= 94:
                value = self.number("h")
            elif tag <= 114:
                value = self.number("f") if tag == 114 else self.byte()
            elif tag <= 116:
                value = self.take(self.varint())
            elif tag <= 138:
                value = False
            else:
                value = self.number("q")
            if encrypted:
                if isinstance(value, bytes):
                    value = decode_string(value)
                elif isinstance(value, bool):
                    value = not value
                else:
                    value = -value
            if isinstance(value, float) and not math.isfinite(value):
                raise DeobfuscationError("Non-finite constants are not supported")
            if isinstance(value, bytes):
                value = value.decode("utf8", "surrogateescape")
            values.append(value)
        return values

    def prototype(self, index, constants, total):
        registers = self.count(self.varint(), 250)
        flags = self.varint()
        if flags != 0:
            raise DeobfuscationError("Unsupported prototype flags")
        upvalues = []
        for _ in range(self.count(self.varint(), 255)):
            value = self.varint()
            upvalues.append({1: value // 4, 2: value % 4})
        arrays = {field: {} for field in (1, 3, 4, 5, 7, 8, 9, 10)}
        line_index = 1
        for _ in range(self.count(self.number("I"))):
            packed = self.number("I")
            value = packed // 2
            if packed % 2:
                line_index = self.count(self.number("I"))
                line = self.number("I")
                if value > line_index:
                    raise DeobfuscationError("Invalid line table range")
                self.account(line_index - value + 1)
                for pc in range(value, line_index + 1):
                    arrays[8][pc] = line
            else:
                arrays[8][line_index] = value
            line_index += 1
        count = self.count(self.varint() - 6169)
        if not count:
            raise DeobfuscationError("Empty instruction stream")
        for pc in range(1, count + 1):
            opcode, t, r, n = [self.signed() for _ in range(4)]
            if not 0 <= opcode <= 255:
                raise DeobfuscationError("Invalid opcode")
            arrays[1][pc] = opcode
            for packed, field, constant_field in ((t, 10, 7), (r, 3, 4), (n, 5, 9)):
                value, mode = divmod(packed, 8)
                arrays[field][pc] = value
                if mode == 1:
                    if not 1 <= value <= len(constants):
                        raise DeobfuscationError("Constant reference out of range")
                    arrays[constant_field][pc] = constants[value - 1]
                    del arrays[field][pc]
                elif mode == 3:
                    if not 1 <= value <= total:
                        raise DeobfuscationError("Prototype reference out of range")
                    arrays[constant_field][pc] = ("function", value)
                elif mode == 6:
                    arrays[field][pc] = pc + value
                elif mode == 5:
                    arrays[field][pc] = pc - value
                elif mode not in (0, 2, 4, 7):
                    raise DeobfuscationError("Unsupported operand mode")
        return Prototype(index, registers, flags, upvalues, arrays)


def decode_string(data):
    if not data:
        raise DeobfuscationError("Empty encoded string")
    if data[0] == 0:
        return data[1:]
    if len(data) < 2:
        raise DeobfuscationError("Missing string cipher seed")
    seed = data[1]
    result = bytearray()
    for byte in data[2:]:
        seed = (seed * 249 + 119) % 256
        result.append(byte ^ seed ^ 33)
    return bytes(result)


def matches(vm, data):
    return (
        hashlib.sha256(vm).hexdigest() == VM_SHA256
        and hashlib.sha256(data[:PAYLOAD_OFFSET]).hexdigest() == BOOTSTRAP_SHA256
    )


def read_payload(data):
    reader = Reader(data)
    constants = reader.constants()
    count = reader.count(reader.varint() - 61504, 4096)
    prototypes = {index: reader.prototype(index, constants, count) for index in range(1, count + 1)}
    root = reader.varint()
    if root not in prototypes or reader.pos != len(reader.data):
        raise DeobfuscationError("Invalid root or trailing payload data")
    return Program(root, prototypes, constants, NAME, ALIASES, HELPERS)
