from dataclasses import dataclass, field
from typing import Any


@dataclass
class Prototype:
    index: int
    registers: int
    flags: int
    upvalues: list[dict[int, int]]
    arrays: dict[int, dict[int, Any]]


@dataclass
class Program:
    root: int
    prototypes: dict[int, Prototype]
    constants: list[Any]
    profile: str
    aliases: dict[int, int] = field(default_factory=dict)
    helpers: tuple[int, ...] = ()
