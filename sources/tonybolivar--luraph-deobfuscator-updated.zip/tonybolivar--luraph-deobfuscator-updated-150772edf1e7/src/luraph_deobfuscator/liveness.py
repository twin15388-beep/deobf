"""Register liveness for preserving the buffer VM's call cleanup."""

from collections import deque

from .errors import DeobfuscationError
from .normalize import register_range


def registers(expression):
    if not isinstance(expression, (tuple, list)) or not expression:
        return set()
    if expression[0] == "reg":
        return {expression[1]}
    result = set()
    for value in expression[1:]:
        result.update(registers(value))
    return result


def action_access(action, function):
    kind = action[0]
    if kind == "assign":
        target, value = action[1:]
        if target[0] == "reg":
            return registers(value), {target[1]}
        return registers(target) | registers(value), set()
    if kind == "self":
        return {action[2]} | registers(action[3]), {action[1], action[1] + 1}
    if kind == "closure":
        child = function.program.prototypes[action[2]]
        return {d[1] for d in child.upvalues if d[2] in (0, 1)}, {action[1]}
    if kind == "call":
        base, argc, _retc = action[1:]
        end = base + argc if argc >= 0 else function.registers
        return set(register_range(base, end + 1)), set(register_range(base, function.registers + 1))
    if kind == "return":
        base, count = action[1:]
        end = base + count if count >= 0 else function.registers + 1
        return set(register_range(base, end)), set()
    if kind == "setlist":
        base, count = action[1:3]
        end = base + count if count >= 0 else function.registers
        return set(register_range(base, end + 1)), set()
    if kind == "branch":
        return registers(action[1]), set()
    raise DeobfuscationError("Unknown action in register analysis")


def live_after_calls(function):
    instructions = function.instructions
    before = {pc: set() for pc in instructions}
    after = {pc: set() for pc in instructions}
    parents = {pc: set() for pc in instructions}
    accesses = {}
    for pc, item in instructions.items():
        accesses[pc] = [action_access(action, function) for action in item["actions"]]
        for dest in item["next"]:
            parents[dest].add(pc)
    queue = deque(reversed(instructions))
    pending = set(queue)
    steps = 0
    while queue:
        steps += 1
        if steps > 100000:
            raise DeobfuscationError("Register analysis did not converge")
        pc = queue.popleft()
        pending.remove(pc)
        after[pc] = set().union(*(before[dest] for dest in instructions[pc]["next"]))
        live = after[pc].copy()
        for reads, writes in reversed(accesses[pc]):
            live = (live - writes) | reads
        if live != before[pc]:
            before[pc] = live
            for parent in parents[pc] - pending:
                queue.append(parent)
                pending.add(parent)
    return after
