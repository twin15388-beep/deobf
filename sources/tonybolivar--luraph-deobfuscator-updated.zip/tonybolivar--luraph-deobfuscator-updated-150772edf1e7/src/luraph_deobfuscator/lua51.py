import struct
from types import SimpleNamespace

from .errors import DeobfuscationError
from .lift import Lifter
from .liveness import live_after_calls

OP_NAMES = "MOVE LOADK LOADBOOL LOADNIL GETUPVAL GETGLOBAL GETTABLE SETGLOBAL SETUPVAL SETTABLE NEWTABLE SELF ADD SUB MUL DIV MOD POW UNM NOT LEN CONCAT JMP EQ LT LE TEST TESTSET CALL TAILCALL RETURN FORLOOP FORPREP TFORLOOP SETLIST CLOSE CLOSURE VARARG".split()
OPS = {name: i for i, name in enumerate(OP_NAMES)}


def u32(n):
    return struct.pack("<I", n)


def string(s):
    b = s.encode("utf8", "surrogateescape") + b"\0"
    return u32(len(b)) + b


class Chunk:
    def __init__(self, program, index, ancestors=(), budget=None):
        self.budget = budget if budget is not None else {"functions": 0, "instructions": 0}
        self.budget["functions"] += 1
        if self.budget["functions"] > 4096:
            raise DeobfuscationError("Prototype expansion limit exceeded")
        if index in ancestors or len(ancestors) >= 100:
            raise DeobfuscationError("Recursive or excessively nested prototype graph")
        self.program = program
        self.ancestors = (*ancestors, index)
        self.f = Lifter(program, index).lift()
        self.code = []
        self.constants = []
        self.children = []
        self.labels = {}
        self.jumps = []
        self.maxreg = max(
            self.f.registers,
            self.f.params,
            max(self.all_registers(self.f.instructions), default=0) + 1,
        )
        self.temp = self.maxreg

    def all_registers(self, obj):
        if isinstance(obj, dict):
            for x in obj.values():
                yield from self.all_registers(x)
        elif isinstance(obj, (tuple, list)):
            if obj and obj[0] == "reg":
                yield obj[1]
            elif obj and obj[0] == "self":
                yield max(obj[1] + 1, obj[2])
            elif obj and obj[0] == "closure":
                yield obj[1]
            elif obj and obj[0] == "call":
                yield obj[1] + max(obj[2], obj[3], 0)
            elif obj and obj[0] == "return":
                yield obj[1] + max(obj[2] - 1, 0)
            elif obj and obj[0] == "setlist":
                yield obj[1] + max(obj[2], 0)
            else:
                for x in obj:
                    yield from self.all_registers(x)

    def emit(self, name, a=0, b=0, c=0, bx=None):
        self.budget["instructions"] += 1
        if self.budget["instructions"] > 1000000:
            raise DeobfuscationError("Instruction expansion limit exceeded")
        if bx is None:
            if not (0 <= a < 256 and 0 <= b < 512 and 0 <= c < 512):
                raise DeobfuscationError("Instruction operands exceed Lua 5.1 limits")
            word = OPS[name] | int(a) << 6 | int(c) << 14 | int(b) << 23
        else:
            if not (0 <= a < 256 and 0 <= bx < 262144):
                raise DeobfuscationError("Instruction index exceeds Lua 5.1 limits")
            word = OPS[name] | int(a) << 6 | int(bx) << 14
        self.code.append(word)

    def k(self, value):
        for i, old in enumerate(self.constants):
            if type(value) is type(old) and value == old:
                return i
        self.constants.append(value)
        return len(self.constants) - 1

    def scratch(self):
        n = self.temp
        self.temp += 1
        self.maxreg = max(self.maxreg, self.temp)
        return n

    def rk(self, e):
        if e[0] == "reg":
            return e[1] - 1
        if e[0] == "const":
            k = self.k(e[1])
            if k < 256:
                return k + 256
        n = self.scratch()
        self.value(n, e)
        return n

    def value(self, dest, e):
        kind = e[0]
        if kind == "reg":
            if dest != e[1] - 1:
                self.emit("MOVE", dest, e[1] - 1)
        elif kind == "up":
            self.emit("GETUPVAL", dest, e[1])
        elif kind == "const":
            val = e[1]
            if val is None:
                self.emit("LOADNIL", dest, dest)
            elif isinstance(val, bool):
                self.emit("LOADBOOL", dest, int(val))
            else:
                self.emit("LOADK", dest, bx=self.k(val))
        elif kind == "global":
            self.emit("GETGLOBAL", dest, bx=self.k(e[1]))
        elif kind == "newtable":
            self.emit("NEWTABLE", dest)
        elif kind == "index":
            obj = e[1]
            if obj[0] == "reg":
                src = obj[1] - 1
            else:
                src = dest
                self.value(src, obj)
            key = self.rk(e[2])
            self.emit("GETTABLE", dest, src, key)
        elif kind == "binary":
            op, b, c = e[1:]
            if op == "..":
                left = self.scratch()
                right = self.scratch()
                self.value(left, b)
                self.value(right, c)
                self.emit("CONCAT", dest, left, right)
            elif op in ("==", "~=", "<", "<="):
                rb, rc = self.rk(b), self.rk(c)
                self.emit(
                    {"==": "EQ", "~=": "EQ", "<": "LT", "<=": "LE"}[op],
                    0 if op == "~=" else 1,
                    rb,
                    rc,
                )
                self.emit("JMP", bx=131072)
                self.emit("LOADBOOL", dest, 0, 1)
                self.emit("LOADBOOL", dest, 1, 0)
            else:
                self.emit(
                    {"+": "ADD", "-": "SUB", "*": "MUL", "/": "DIV", "%": "MOD"}[op],
                    dest,
                    self.rk(b),
                    self.rk(c),
                )
        elif kind in ("length", "not"):
            src = self.rk(e[1])
            if src >= 256:
                raise DeobfuscationError("Unsupported unary operand")
            self.emit("LEN" if kind == "length" else "NOT", dest, src)
        else:
            raise ValueError(("unsupported expression", self.f.index, e))

    def jump(self, target):
        self.jumps.append((len(self.code), target))
        self.emit("JMP", bx=131071)

    def condition(self, e):
        negate = False
        while e[0] == "not":
            negate = not negate
            e = e[1]
        if e[0] == "reg":
            self.emit("TEST", e[1] - 1, 0, 0 if negate else 1)
        elif e[0] == "binary":
            op = e[1]
            rb, rc = self.rk(e[2]), self.rk(e[3])
            sense = not negate
            if op == "~=":
                sense = not sense
                op = "=="
            self.emit({"==": "EQ", "<": "LT", "<=": "LE"}[op], int(sense), rb, rc)
        else:
            raise ValueError(("condition", e))

    def bind_upvalues(self, child):
        for desc in child.f.upvalues:
            mode, source = desc[2], desc[1]
            if mode == 0:
                if not 1 <= source <= self.f.registers:
                    raise DeobfuscationError("Captured register is out of range")
                self.emit("MOVE", 0, source - 1)
            elif mode in (2, 3):
                if not 0 <= source < len(self.f.upvalues):
                    raise DeobfuscationError("Parent upvalue is out of range")
                self.emit("GETUPVAL", 0, source)
            else:
                raise DeobfuscationError("Unlowered value capture")

    def capture_factory(self, child, destination):
        # A fresh activation gives value captures their own cells. unluac's
        # stripped-debug mode does not preserve temporary-register CLOSE scopes.
        values = list(
            dict.fromkeys(d[1] for d in child.f.upvalues if d[2] == 1 and d[1] != destination)
        )
        refs = [d for d in child.f.upvalues if d[2] != 1]
        wrapper = object.__new__(Chunk)
        wrapper.budget = self.budget
        wrapper.budget["functions"] += 1
        if wrapper.budget["functions"] > 4096:
            raise DeobfuscationError("Prototype expansion limit exceeded")
        wrapper.f = SimpleNamespace(
            index=f"capture-{child.f.index}", params=len(values), upvalues=refs
        )
        wrapper.code = []
        wrapper.constants = []
        wrapper.children = [child]
        wrapper.maxreg = len(values) + 1
        result = len(values)
        wrapper.emit("CLOSURE", result, bx=0)
        ref_index = 0
        for desc in child.f.upvalues:
            if desc[2] == 1:
                source = result if desc[1] == destination else values.index(desc[1])
                wrapper.emit("MOVE", 0, source)
            else:
                wrapper.emit("GETUPVAL", 0, ref_index)
                ref_index += 1
        wrapper.emit("RETURN", result, 2)
        wrapper.emit("RETURN", 0, 1)
        return wrapper, values

    def build(self):
        order = list(self.f.instructions)
        live = live_after_calls(self.f)
        scratchbase = self.maxreg
        for i, pc in enumerate(order):
            self.labels[pc] = len(self.code)
            self.temp = scratchbase
            item = self.f.instructions[pc]
            for a in item["actions"]:
                kind = a[0]
                if kind == "assign":
                    dst, value = a[1:]
                    if dst[0] == "reg":
                        self.value(dst[1] - 1, value)
                    elif dst[0] == "up":
                        src = self.rk(value)
                        if src >= 256:
                            src = self.scratch()
                            self.value(src, value)
                        self.emit("SETUPVAL", src, dst[1])
                    elif dst[0] == "index":
                        obj, key = dst[1:]
                        if obj[0] == "reg":
                            target = obj[1] - 1
                        else:
                            target = self.scratch()
                            self.value(target, obj)
                        self.emit("SETTABLE", target, self.rk(key), self.rk(value))
                    else:
                        raise ValueError(dst)
                elif kind == "self":
                    self.emit("SELF", a[1] - 1, a[2] - 1, self.rk(a[3]))
                elif kind == "call":
                    base, argc, retc = a[1:]
                    captured = self.f.mutable_captures
                    overlap = any(reg > base for reg in captured)
                    retain = self.f.arrays[1][pc] == 74 and retc > 0
                    preserve = retain and base + retc in live[pc]
                    if overlap and (argc < 0 or retc < 0):
                        raise DeobfuscationError(
                            "Open call overlaps reference captures; use --emit ir"
                        )
                    if preserve and argc < 0:
                        raise DeobfuscationError(
                            "Open call reads its retained boundary register; use --emit ir"
                        )
                    if overlap or preserve:
                        target = self.temp
                        for register in range(base, base + argc + 1):
                            self.emit("MOVE", self.scratch(), register - 1)
                        self.maxreg = max(self.maxreg, target + retc)
                        clear_before = captured | ({base + retc} if preserve else set())
                        for register in sorted(clear_before):
                            if register > base + argc:
                                self.emit("LOADNIL", register - 1, register - 1)
                        self.emit("CALL", target, argc + 1, retc + 1)
                        for offset in range(retc):
                            self.emit("MOVE", base + offset - 1, target + offset)
                    else:
                        self.emit("CALL", base - 1, argc + 1, retc + 1)
                    if retc >= 0:
                        for register in sorted(live[pc] | captured):
                            if register >= base + retc + int(retain):
                                self.emit("LOADNIL", register - 1, register - 1)
                elif kind == "return":
                    self.emit("RETURN", a[1] - 1, a[2] + 1)
                elif kind == "closure":
                    child = Chunk(self.program, a[2], self.ancestors, self.budget).build()
                    ci = len(self.children)
                    self.children.append(child)
                    if any(desc[2] == 1 for desc in child.f.upvalues):
                        wrapper, values = self.capture_factory(child, a[1])
                        self.children[ci] = wrapper
                        target = self.scratch()
                        self.emit("CLOSURE", target, bx=ci)
                        self.bind_upvalues(wrapper)
                        for source in values:
                            if not 1 <= source <= self.f.registers:
                                raise DeobfuscationError("Captured register is out of range")
                            self.emit("MOVE", self.scratch(), source - 1)
                        self.emit("CALL", target, len(values) + 1, 2)
                        self.emit("MOVE", a[1] - 1, target)
                    else:
                        self.emit("CLOSURE", a[1] - 1, bx=ci)
                        self.bind_upvalues(child)
                elif kind == "setlist":
                    base, count, offset = a[1:]
                    if count < 0:
                        if offset % 50:
                            raise DeobfuscationError("Unsupported variable-size table constructor")
                        self.emit("SETLIST", base - 1, 0, offset // 50 + 1)
                    else:
                        for j in range(1, count + 1):
                            self.emit(
                                "SETTABLE", base - 1, self.rk(("const", offset + j)), base + j - 1
                            )
                elif kind == "branch":
                    self.condition(a[1])
                    self.jump(a[2])
                    if i + 1 == len(order) or order[i + 1] != a[3]:
                        self.jump(a[3])
                else:
                    raise ValueError(a)
            if item["actions"][-1][0] not in ("branch", "return"):
                if len(item["next"]) != 1:
                    raise DeobfuscationError("Missing instruction successor")
                dest = item["next"][0]
                if i + 1 == len(order) or order[i + 1] != dest:
                    self.jump(dest)
        for address, target in self.jumps:
            offset = self.labels[target] - address - 1
            if not -131071 <= offset <= 131071:
                raise DeobfuscationError("Jump exceeds Lua 5.1 limits")
            self.code[address] = OPS["JMP"] | ((offset + 131071) << 14)
        if not self.code or self.code[-1] != (OPS["RETURN"] | (1 << 23)):
            self.emit("RETURN", 0, 1)
        return self

    def dump(self):
        if self.maxreg > 250:
            raise DeobfuscationError("Recovered function exceeds Lua 5.1 register limit")
        data = string("@recovered-" + str(self.f.index)) + u32(0) * 2
        data += bytes((len(self.f.upvalues), self.f.params, 0, max(2, self.maxreg)))
        data += u32(len(self.code)) + b"".join(u32(x) for x in self.code)
        data += u32(len(self.constants))
        for v in self.constants:
            if v is None:
                data += b"\x00"
            elif isinstance(v, bool):
                data += b"\x01" + bytes((int(v),))
            elif isinstance(v, (int, float)):
                data += b"\x03" + struct.pack("<d", v)
            elif isinstance(v, str):
                data += b"\x04" + string(v)
            else:
                raise ValueError(v)
        data += u32(len(self.children)) + b"".join(c.dump() for c in self.children)
        data += u32(0) * 3
        return data
