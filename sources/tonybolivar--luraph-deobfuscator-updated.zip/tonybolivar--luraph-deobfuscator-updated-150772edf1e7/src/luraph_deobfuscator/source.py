"""Run the pinned bytecode decompiler, then restore checked open-result calls."""

import hashlib
import os
import re
import shutil
import subprocess
import tempfile
from pathlib import Path

from .errors import DeobfuscationError

JAR_SHA256 = "98be0fa84ac73ca66dce2842a2e4512226f4c611b6500dc96415571fc5538fcc"


def restore_multireturn(source, expected):
    lines = source.splitlines()
    pattern = re.compile(r"^(\s*)((?:[LA]\d+_\d+, ){2,}[LA]\d+_\d+) = (.+)$")
    count = 0
    for i in range(len(lines)):
        match = pattern.match(lines[i])
        if not match:
            continue
        space, names, call = match.groups()
        regs = names.split(", ")
        count += 1
        packed = f"returns_{count}"
        unpack = f"table.unpack({packed}, 1, {packed}.n)"
        lines[i] = space + f"local {packed} = table.pack({call})\n" + space + names + " = " + unpack
        suffix = names + ")"
        if i + 1 < len(lines) and lines[i + 1].endswith(suffix):
            lines[i + 1] = lines[i + 1][: -len(suffix)] + unpack + ")"
            continue
        start = i + 1
        while start < len(lines) and not lines[start].endswith(" = " + regs[0]):
            if not re.fullmatch(r"\s*[LA]\d+_\d+\[\d+\] = [LA]\d+_\d+", lines[start]):
                raise DeobfuscationError("Unsupported multi-return consumer; use --emit ir")
            start += 1
        if start >= len(lines):
            raise DeobfuscationError("Missing multi-return consumer")
        row = re.fullmatch(r"\s*([LA]\d+_\d+)\[(\d+)\] = " + regs[0], lines[start])
        if not row:
            raise DeobfuscationError("Unsupported multi-return table assignment")
        table, offset = row.groups()
        offset = int(offset) - 1
        for j, reg in enumerate(regs):
            if (
                start + j >= len(lines)
                or lines[start + j].strip() != f"{table}[{offset + j + 1}] = {reg}"
            ):
                raise DeobfuscationError("Non-contiguous multi-return assignment")
            lines[start + j] = ""
        lines[start] = (
            space
            + f"for returnIndex = 1, {packed}.n do\n"
            + space
            + f"  {table}[{offset} + returnIndex] = {packed}[returnIndex]\n"
            + space
            + "end"
        )
    if count != expected:
        raise DeobfuscationError(
            f"Could not verify all {expected} open-result calls; use --emit ir"
        )
    if re.search(r"(?m)^\s*--", source) or re.search(r"(?m)^\s*(?:goto\s|::)", source):
        raise DeobfuscationError("Decompiler emitted unsupported syntax; use --emit ir")
    return "--!strict\n" + "\n".join(lines) + "\n"


def decompile(bytecode, open_calls, java=None, timeout=30, parameters=0):
    vendor = Path(__file__).parent / "vendor" / "unluac.jar"
    if hashlib.sha256(vendor.read_bytes()).hexdigest() != JAR_SHA256:
        raise DeobfuscationError("Bundled unluac checksum mismatch")
    if java is None:
        java_home = os.environ.get("JAVA_HOME")
        java = str(Path(java_home) / "bin" / "java") if java_home else shutil.which("java")
    if not java:
        raise DeobfuscationError(
            "Java 8+ is required for source output; use --java PATH or --emit ir"
        )
    located = shutil.which(java)
    if not located:
        raise DeobfuscationError("Java executable not found; use --java PATH")
    java = str(Path(located).resolve())
    with tempfile.TemporaryDirectory(prefix="luraph-") as folder:
        path = Path(folder) / "recovered.luac"
        path.write_bytes(bytecode)
        env = dict(os.environ)
        for key in ("JAVA_TOOL_OPTIONS", "_JAVA_OPTIONS", "JDK_JAVA_OPTIONS"):
            env.pop(key, None)
        try:
            result = subprocess.run(
                [java, "-Xmx256m", "-jar", str(vendor), "--nodebug", str(path)],
                capture_output=True,
                timeout=timeout,
                check=False,
                env=env,
                cwd=folder,
            )
        except FileNotFoundError as exc:
            raise DeobfuscationError("Java executable not found; use --java PATH") from exc
        except subprocess.TimeoutExpired as exc:
            raise DeobfuscationError("Source decompiler timed out; use --emit ir") from exc
        if result.returncode != 0:
            raise DeobfuscationError("Source decompilation failed; check Java 8+ or use --emit ir")
        source = restore_multireturn(result.stdout.decode("utf8"), open_calls)
        if parameters:
            names = ", ".join(f"A{index}_1" for index in range(parameters))
            source = "--!strict\nlocal " + names + " = ...\n" + source[len("--!strict\n") :]
        return source
