"""Extract long-string payloads and decode ASCII85/LZMA without evaluating Lua."""

import lzma
import re
import struct

from .errors import DeobfuscationError

MAX_INPUT = 8 * 1024 * 1024
MAX_DECODED = 32 * 1024 * 1024
LONG_OPEN = re.compile(rb"\[(=*)\[")


def long_strings(source):
    pos = 0
    while pos < len(source):
        comment = source.startswith(b"--", pos)
        start = pos + 2 if comment else pos
        match = LONG_OPEN.match(source, start)
        if match:
            end_marker = b"]" + match[1] + b"]"
            end = source.find(end_marker, match.end())
            if end == -1:
                raise DeobfuscationError("Unterminated Lua long string or comment")
            if not comment:
                literal = source[match.end() : end]
                if literal.startswith((b"\r\n", b"\n\r")):
                    literal = literal[2:]
                elif literal.startswith((b"\n", b"\r")):
                    literal = literal[1:]
                yield literal
            pos = end + len(end_marker)
        elif comment:
            end = source.find(b"\n", start)
            pos = len(source) if end < 0 else end + 1
        elif source[pos] in (34, 39):
            quote = source[pos]
            pos += 1
            while pos < len(source) and source[pos] != quote:
                pos += 2 if source[pos] == 92 else 1
            if pos >= len(source):
                raise DeobfuscationError("Unterminated quoted Lua string")
            pos += 1
        else:
            pos += 1


def decode85(data):
    data = data.replace(b"z", b"!!!!!")
    if len(data) % 5:
        raise DeobfuscationError("ASCII85 block length is not a multiple of five")
    result = bytearray()
    for offset in range(0, len(data), 5):
        value = 0
        for byte in data[offset : offset + 5]:
            if not 33 <= byte <= 117:
                raise DeobfuscationError("Invalid ASCII85 character")
            value = value * 85 + byte - 33
        if value > 0xFFFFFFFF:
            raise DeobfuscationError("ASCII85 word overflow")
        result.extend(struct.pack("<I", value))
    return bytes(result)


def decompress(data):
    try:
        decoder = lzma.LZMADecompressor(
            format=lzma.FORMAT_RAW,
            filters=[
                {
                    "id": lzma.FILTER_LZMA1,
                    "dict_size": 64 * 1024 * 1024,
                    "lc": 3,
                    "lp": 0,
                    "pb": 0,
                }
            ],
        )
        output = decoder.decompress(data, max_length=MAX_DECODED + 1)
        if len(output) > MAX_DECODED:
            raise DeobfuscationError("Decompressed block exceeds 32 MiB")
        if not decoder.eof:
            raise DeobfuscationError("Truncated LZMA stream or missing end marker")
        if len(decoder.unused_data) > 3:
            raise DeobfuscationError("Unexpected data after LZMA end marker")
        return output
    except lzma.LZMAError as exc:
        raise DeobfuscationError("Invalid LZMA payload") from exc


def unpack(source):
    if len(source) > MAX_INPUT:
        raise DeobfuscationError("Input exceeds 8 MiB")
    blocks = []
    for literal in long_strings(source):
        if literal.startswith(b"LPH"):
            if len(blocks) == 2:
                raise DeobfuscationError("Ambiguous input: more than two LPH blocks")
            blocks.append(literal)
    if len(blocks) != 2:
        raise DeobfuscationError("Expected two LPH ASCII85 long-string blocks")
    return tuple(decompress(decode85(block[4:])) for block in blocks)
