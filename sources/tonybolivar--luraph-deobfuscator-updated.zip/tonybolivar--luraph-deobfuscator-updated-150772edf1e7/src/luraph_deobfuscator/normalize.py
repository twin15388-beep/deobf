import collections
import json
import re
from pathlib import Path

from .errors import DeobfuscationError

HANDLERS = json.loads((Path(__file__).parent / "profiles" / "globals.json").read_text())
UNKNOWN = ("unknown",)
Q = ("registers",)
B = ("upvalues",)


def same(a, b):
    return type(a) is type(b) and a == b


def lua_equal(a, b):
    if isinstance(a, bool) or isinstance(b, bool):
        return type(a) is type(b) and a == b
    return a == b


def lua_concat(a, b):
    if not all(isinstance(x, (str, int)) and not isinstance(x, bool) for x in (a, b)):
        raise TypeError("Unknown Lua string conversion")
    return str(a) + str(b)


def lua_order(a, b, operation):
    numeric = all(isinstance(x, (int, float)) and not isinstance(x, bool) for x in (a, b))
    if not numeric and not (isinstance(a, str) and isinstance(b, str)):
        raise TypeError("Unknown Lua comparison")
    return operation(a, b)


def scalar(v):
    return not isinstance(v, tuple)


def truth(v):
    return v is not None and v is not False


def register_range(start, stop):
    if not (type(start) is int and type(stop) is int and 1 <= start <= stop <= 251):
        raise DeobfuscationError("Invalid register range")
    return range(start, stop)


class Normalizer:
    def __init__(self, program, index):
        self.program = program
        self.index = index
        p = program.prototypes[index]
        self.params = 0
        self.registers = p.registers
        self.upvalues = p.upvalues
        self.arrays = {field: dict(values) for field, values in p.arrays.items()}
        self.mutable_captures = {
            desc[1]
            for child in self.arrays[9].values()
            if isinstance(child, tuple) and child[0] == "function"
            for desc in program.prototypes[child[1]].upvalues
            if desc[2] == 0
        }
        for pc, op in self.arrays[1].items():
            self.arrays[1][pc] = program.aliases.get(op, op)
        self.patches = {}
        self.changed = False
        self.unresolved = set()

    def read(self, obj, key, state):
        if obj == Q:
            return state.get(key)
        if obj == ("helpers",):
            return (
                ("helper", int(key)) if isinstance(key, (int, float)) and 1 <= key <= 8 else UNKNOWN
            )
        if isinstance(obj, tuple) and obj[0] == "metadata" and scalar(key):
            return self.arrays[obj[1]].get(key)
        return UNKNOWN

    def write(self, obj, key, val, state, pc):
        if obj == Q:
            if scalar(key):
                state[key] = val
            return
        if isinstance(obj, tuple) and obj[0] == "metadata":
            if not scalar(key) or not scalar(val):
                self.unresolved.add(pc)
                return
            field = obj[1]
            prev = self.patches.get((field, key), val)
            if not same(prev, val):
                raise DeobfuscationError("Conflicting instruction patches")
            self.patches[field, key] = val
            if not same(self.arrays[field].get(key), val):
                self.arrays[field][key] = val
                self.changed = True

    def transfer(self, pc, state):
        s = dict(state)
        arr = self.arrays
        op = arr[1][pc]
        r, t, n, R, h, d = [arr[f].get(pc) for f in (3, 10, 5, 4, 9, 7)]
        qr, qt, qn = s.get(r), s.get(t), s.get(n)
        z, w, V, m, micro_index = [s.get(k) for k in ("z", "w", "V", "m", "O")]

        def read(obj, key):
            return self.read(obj, key, s)

        def write(obj, key, val):
            self.write(obj, key, val, s, pc)

        targets = [pc + 1]
        if op == 69:
            targets = [n + 1]
        elif op in (95, 204, 58, 181, 154):
            targets = []
        elif op in (31, 145, 11, 141, 125, 65, 184, 1):
            if op == 31:
                val, dest = qr, t
            elif op == 145:
                val, dest = (not truth(qt) if scalar(qt) else UNKNOWN), r
            else:
                a, b, dest, f = {
                    11: (qt, h, r, lambda a, b: not lua_equal(a, b)),
                    141: (qn, d, r, lambda a, b: lua_equal(a, b)),
                    125: (qn, R, t, lambda a, b: not lua_order(a, b, lambda a, b: a <= b)),
                    65: (h, qr, t, lambda a, b: not lua_order(a, b, lambda a, b: a < b)),
                    184: (qt, qn, r, lambda a, b: not lua_equal(a, b)),
                    1: (qr, qt, n, lambda a, b: not lua_order(a, b, lambda a, b: a <= b)),
                }[op]
                try:
                    val = f(a, b) if scalar(a) and scalar(b) else UNKNOWN
                except (TypeError, ValueError):
                    val = UNKNOWN
            targets = (
                [dest + 1]
                if scalar(val) and truth(val)
                else ([pc + 1] if scalar(val) else [pc + 1, dest + 1])
            )
        elif op in (218, 7):
            targets = [(r if op == 218 else n) + 1]
        elif op in (130, 194):
            targets = [pc + 1, n + 1]
            for i in register_range((t if op == 130 else r), (t if op == 130 else r) + 5):
                s[i] = UNKNOWN
        elif op == 89:
            pass
        elif op == 82:
            s[r] = len(qt.encode("utf8", "surrogateescape")) if isinstance(qt, str) else UNKNOWN
        elif op == 24:
            s[r] = qn
        elif op == 140:
            s[n] = R
        elif op in (106, 187):
            s[t if op == 106 else n] = UNKNOWN
        elif op == 191:
            s[r + 1] = qt
            s[r] = read(qt, h)
        elif op == 34:
            s[r] = read(qt, h)
        elif op == 214:
            s[r] = read(qn, qt)
        elif op == 72:
            write(qr, d, h)
        elif op == 158:
            write(qr, d, qn)
        elif op == 178:
            write(qt, qr, qn)
        elif op == 129:
            write(qr, qn, d)
        elif op in (5, 80, 238):
            s[r if op == 5 else t] = UNKNOWN
        elif op in (207, 85, 97, 50, 19, 120):
            pass
        elif op == 180:
            s[t] = h
        elif op == 27:
            s[t] = ("metadata", 3)
        elif op == 147:
            s[r] = ("metadata", 10)
        elif op == 220:
            s[t] = ("metadata", 5)
        elif op == 91:
            s[n] = ("metadata", 1)
        elif op == 137:
            s[n] = ("helpers",) if t == 4 else UNKNOWN
        elif op == 110:
            for i in register_range(1, n + 1):
                s[i] = UNKNOWN
        elif op == 229:
            for i in register_range(r, r + t):
                s[i] = UNKNOWN
        elif op == 52:
            s[n] = None
        elif op == 249:
            for i in register_range(n, t + 1):
                s[i] = None
        elif op in (248, 250, 251, 252, 253, 254, 255, 198, 225, 86, 74, 122, 111, 23, 213, 96, 48):
            base, argc, retc = {
                198: (t, 1, 1),
                225: (t, 0, 1),
                86: (r, t - 1, 1),
                74: (n, r - 1, t - 1),
                122: (r, -1, 1),
                111: (n, 0, 0),
                23: (r, 1, 0),
                213: (t, 2, 0),
                96: (n, r - 1, 0),
                48: (n, -1, 0),
            }.get(op, (t, 2, 1))
            fn = s.get(base)
            result = (
                self.program.helpers[fn[1] - 1]
                if isinstance(fn, tuple) and fn[0] == "helper"
                else UNKNOWN
            )
            if argc >= 0:
                for i in [i for i in s if isinstance(i, (int, float)) and i > base + argc]:
                    s[i] = None
            if result == UNKNOWN:
                for i in self.mutable_captures:
                    s[i] = UNKNOWN
            boundary = base + retc + (1 if op == 74 and retc > 0 else 0)
            if retc >= 0:
                for i in [i for i in s if isinstance(i, (int, float)) and i >= boundary]:
                    s[i] = None
            for i in register_range(
                base, base + (retc if retc >= 0 else self.registers - base + 1)
            ):
                s[i] = result if i == base else UNKNOWN
            s["P"] = boundary - 1 if retc >= 0 else UNKNOWN
        elif op in (235, 199, 176, 168, 169, 174, 139, 237, 185, 105, 232, 245, 100, 10, 242, 209):
            dst, a, b, f = {
                235: (t, qr, h, lambda a, b: a + b),
                199: (r, qt, qn, lambda a, b: a - b),
                176: (n, qr, d, lambda a, b: a - b),
                168: (t, qn, R, lambda a, b: a % b),
                169: (r, qn, qt, lambda a, b: a % b),
                174: (t, qn, R, lambda a, b: a // b),
                139: (t, qn, qr, lambda a, b: a * b),
                237: (r, qt, qn, lambda a, b: a / b),
                185: (t, qr, h, lambda a, b: int(a) ^ int(b)),
                105: (r, h, qt, lua_concat),
                232: (r, qn, qt, lua_concat),
                245: (n, qt, R, lua_concat),
                100: (n, qr, qt, lambda a, b: lua_equal(a, b)),
                10: (t, qr, qn, lambda a, b: not lua_equal(a, b)),
                242: (r, qt, h, lambda a, b: lua_equal(a, b)),
                209: (t, qn, qr, lambda a, b: lua_order(a, b, lambda a, b: a >= b)),
            }[op]
            try:
                if op not in (105, 232, 245, 100, 10, 242, 209) and not all(
                    isinstance(x, (int, float)) and not isinstance(x, bool) for x in (a, b)
                ):
                    raise TypeError("Unknown Lua arithmetic")
                s[dst] = f(a, b) if scalar(a) and scalar(b) else UNKNOWN
            except (TypeError, ValueError, ZeroDivisionError):
                s[dst] = UNKNOWN
        elif op in (6, 70):
            s["z"] = None
        elif op in (157, 148):
            s["w"] = None
        elif op in (131, 49):
            s["V"] = None
        elif op in (201, 230):
            s["m"] = None
        elif op == 173:
            s["O"] = None
        elif op in (40, 165):
            s["z"] = Q
        elif op in (22, 77):
            s["z"] = Q
            s["w"] = t
            s["V"] = Q if op == 77 else V
        elif op in (223, 195, 202):
            s["z"] = Q
            s["w"] = n if op == 223 else r
        elif op == 128:
            s["z"] = Q
            s["w"] = n
            s["V"] = R
        elif op == 109:
            s["z"] = n
            s["w"] = t
        elif op == 92:
            if isinstance(z, (int, float)) and isinstance(w, (int, float)):
                for i in register_range(z, w + 1):
                    s[i] = None
            s["V"] = Q
            s["m"] = w
        elif op in (38, 39):
            write(z, w, V)
        elif op in (59, 208):
            s["w"] = r
            s["V"] = Q
            s["m"] = n if op == 59 else m
        elif op in (224, 132):
            s["V"] = Q
            s["m"] = t
        elif op in (167, 243):
            s["V"] = read(Q, n)
            s["m"] = n
        elif op in (29, 153):
            s["m"] = r
        elif op in (138, 144):
            s["w"] = r
        elif op == 124:
            s["w"] = d
        elif op in (81, 196):
            s["V"] = read(V, m)
        elif op in (127, 221):
            s["m"] = t if op == 127 else r
            s["V"] = read(V, s["m"])
        elif op in (241, 170):
            s["m"] = h
            s["V"] = read(V, h)
            write(z, w, s["V"]) if op == 170 else None
        elif op == 177:
            s["V"] = read(V, m)
            write(z, w, s["V"])
        elif op == 210:
            s["m"] = n
            s["V"] = read(V, n)
            write(z, w, s["V"])
        elif op == 121:
            s["z"] = read(Q, r)
            s["w"] = r
        elif op == 136:
            s["z"] = read(z, w)
        elif op == 114:
            s["w"] = d
            s["V"] = h
            write(z, d, h)
        elif op == 164:
            s["z"] = read(z, w)
            s["w"] = h
            s["V"] = Q
        elif op == 192:
            s["w"] = h
            s["V"] = Q
        elif op == 211:
            s["z"] = Q
            s["w"] = r
            s["V"] = Q
        elif op == 203:
            s["z"] = Q
            s["w"] = t
            s["V"] = UNKNOWN
        elif op == 193:
            s["w"] = r
            s["V"] = UNKNOWN
        elif op == 240:
            s["V"] = UNKNOWN
        elif op in (12, 166):
            s["V"] = UNKNOWN
            write(z, w, UNKNOWN)
        elif op == 61:
            s["w"] = n
            s["V"] = UNKNOWN
        elif op == 20:
            s["z"] = Q
            s["w"] = n
            s["V"] = UNKNOWN
        elif op == 45:
            s["w"] = n
            s["V"] = None
            write(z, n, None)
        elif op == 206:
            s["w"] = s.get("P", UNKNOWN)
        elif op == 26:
            s["m"] = s.get("P", UNKNOWN)
            s["V"] = read(Q, s["m"])
        elif op in (0, 212):
            s["V"] = UNKNOWN
            write(z, w, UNKNOWN)
        elif op == 112:
            s["w"] = r
            s["V"] = B
        elif op == 244:
            s["w"] = t
            s["z"] = UNKNOWN
        elif op == 57:
            s["w"] = read(w, V)
            s["V"] = Q
            s["m"] = n
        elif op == 3:
            write(w, V, m)
        elif op == 8:
            s["V"] = r
        elif op == 35:
            s["V"] = t
            s["m"] = z
            s["O"] = 2
        elif op == 54:
            s["O"] = t
            s["m"] = read(m, t)
            s["V"] = read(V, s["m"])
        elif op == 76:
            s["m"] = read(m, micro_index)
        elif op == 107:
            s["m"] = d
            s["V"] = (
                V * d if isinstance(V, (int, float)) and isinstance(d, (int, float)) else UNKNOWN
            )
        elif op == 51:
            s["z"] = Q
            s["w"] = n
            s["V"] = UNKNOWN
        elif op == 25:
            pass
        else:
            handler = HANDLERS.get(str(op), "unsupported opcode")
            match = re.fullmatch(r"\(?q\)?\[([rnt])\[Q\]\] = (?:\w+(?:\.\w+)?|X\[\d+\])", handler)
            if not match:
                raise ValueError((self.index, pc, op, handler))
            s[{"r": r, "n": n, "t": t}[match[1]]] = UNKNOWN
        if any(type(x) is not int or x not in arr[1] for x in targets):
            raise DeobfuscationError("Invalid control-flow target")
        return s, targets

    def run(self):
        for _iteration in range(12):
            self.changed = False
            self.unresolved = set()
            incoming = {1: {i: UNKNOWN for i in range(1, self.params + 1)}}
            queue = collections.deque([1])
            edges = {}
            steps = 0
            while queue:
                pc = queue.popleft()
                steps += 1
                if steps >= 100000:
                    raise DeobfuscationError("Analysis did not converge")
                out, targets = self.transfer(pc, incoming[pc])
                edges[pc] = targets
                for target in targets:
                    if target not in incoming:
                        incoming[target] = dict(out)
                        queue.append(target)
                    else:
                        prev = incoming[target]
                        merged = {
                            key: prev.get(key) if same(prev.get(key), out.get(key)) else UNKNOWN
                            for key in prev.keys() | out.keys()
                        }
                        if merged != prev:
                            incoming[target] = merged
                            queue.append(target)
            if not self.changed:
                if self.unresolved:
                    raise DeobfuscationError("Unresolved instruction patches")
                self.incoming = incoming
                self.edges = edges
                return self
        raise ValueError(("patches failed to converge", self.index))

    def export(self):
        return {
            "index": self.index,
            "params": self.params,
            "registers": self.registers,
            "upvalues": self.upvalues,
            "arrays": self.arrays,
            "patches": [[f, pc, v] for (f, pc), v in self.patches.items()],
            "reachable": sorted(self.incoming),
            "edges": self.edges,
            "unresolved_patches": sorted(self.unresolved),
        }
