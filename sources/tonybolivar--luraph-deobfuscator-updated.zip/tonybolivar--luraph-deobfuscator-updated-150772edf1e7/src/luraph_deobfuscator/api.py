"""Input-driven recovery API. All Lua payloads are handled as data."""

import json
import re

from .errors import DeobfuscationError
from .lift import Lifter
from .lua51 import OPS, Chunk
from .profiles import buffer_v1
from .source import decompile
from .unpack import unpack

PROFILES = (buffer_v1,)
HEADER = b"\x1bLua\x51\x00\x01\x04\x04\x04\x08\x00"


def read_program(source, *, raw_payload=False):
    if raw_payload:
        return buffer_v1.read_payload(source)
    vm, payload = unpack(source)
    for profile in PROFILES:
        if profile.matches(vm, payload):
            return profile.read_payload(payload[profile.PAYLOAD_OFFSET :])
    raise DeobfuscationError(
        "Unsupported VM/bootstrap fingerprint; use --unpack DIR to inspect the layers"
    )


def chunk_open_calls(chunk):
    return sum((word & 63) == OPS["CALL"] and (word >> 14) & 511 == 0 for word in chunk.code) + sum(
        chunk_open_calls(child) for child in chunk.children
    )


def check_source_calls(chunk):
    if any(word & 63 == OPS["CALL"] and (word >> 14) & 511 >= 4 for word in chunk.code):
        raise DeobfuscationError(
            "Fixed calls with three or more results require --emit ir or --emit lua51"
        )
    for child in chunk.children:
        check_source_calls(child)


def detect_format(source, input_format="auto", raw_payload=False):
    if input_format not in ("auto", "luraph", "wearedevs"):
        raise DeobfuscationError("Unknown input format")
    if raw_payload:
        if input_format == "wearedevs":
            raise DeobfuscationError("--raw-payload is Luraph-only")
        return "luraph"
    if input_format != "auto":
        return input_format
    if b"wearedevs.net/obfuscator" in source[:1024]:
        return "wearedevs"
    return "luraph" if re.search(rb"\[=*\[LPH", source) else "wearedevs"


def recover(source, *, emit="luau", java=None, raw_payload=False, input_format="auto"):
    if detect_format(source, input_format, raw_payload) == "wearedevs":
        from .wearedevs import recover as recover_wearedevs

        return recover_wearedevs(source, emit=emit)
    try:
        program = read_program(source, raw_payload=raw_payload)
        if emit == "ir":
            functions = []
            for index in program.prototypes:
                function = Lifter(program, index).lift()
                functions.append(
                    {
                        "index": index,
                        "parameters": function.params,
                        "registers": function.registers,
                        "upvalues": function.upvalues,
                        "entry": function.entry,
                        "instructions": function.instructions,
                    }
                )
            return (
                json.dumps(
                    {
                        "profile": program.profile,
                        "root": program.root,
                        "constants": program.constants,
                        "functions": functions,
                    },
                    indent=2,
                    ensure_ascii=True,
                    allow_nan=False,
                )
                + "\n"
            ).encode()
        if emit not in ("luau", "lua51"):
            raise DeobfuscationError("Unknown output format")
        chunk = Chunk(program, program.root).build()
        bytecode = HEADER + chunk.dump()
        if emit == "lua51":
            return bytecode
        check_source_calls(chunk)
        return decompile(
            bytecode, chunk_open_calls(chunk), java=java, parameters=chunk.f.params
        ).encode("utf8")
    except (
        AssertionError,
        KeyError,
        IndexError,
        TypeError,
        ValueError,
        RecursionError,
        OverflowError,
    ) as exc:
        raise DeobfuscationError(
            "Unsupported instruction or control-flow pattern in this payload"
        ) from exc
