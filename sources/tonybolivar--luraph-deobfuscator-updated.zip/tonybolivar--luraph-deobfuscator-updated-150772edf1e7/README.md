# luraph-deobfuscator-updated

A CLI for supported Luraph and WeAreDevs/Prometheus scripts. It unpacks constant layers, recovers functions and control flow, and exposes supported encrypted strings. It does not load the input in a Lua runtime or contact embedded URLs.

Some Roblox exploiters and cybercriminals use Luraph obfuscation to hide exploit logic and malicious behavior from developers. In my case, I found code configured to send the player's Roblox username, the game name, the place ID, and an execution timestamp to a Discord webhook.

Thankfully, agentic programming made deobfuscating this custom buffer format relatively straightforward. Here's the tool.

Enjoy.

Requires Python 3.10+. Luraph source output also needs Java 8+; the pinned unluac JAR is included. WeAreDevs recovery needs no Java.

```sh
pip install git+https://github.com/tonybolivar/luraph-deobfuscator-updated.git@v0.2.0
luraph-obfuscator foo.lua -o
luraph-obfuscator foo.lua -o recovered.luau
wearedevs-deobfuscator foo.lua -o
```

The commands detect the input format automatically. Bare `-o` writes `foo.deobfuscated.luau`. Without `-o`, output goes to stdout. `luraph-deobfuscator` is another alias. Existing files require `--force`.

```sh
luraph-obfuscator foo.lua --emit ir -o recovered.json
luraph-obfuscator foo.lua --emit lua51 -o recovered.luac
luraph-obfuscator foo.lua --unpack layers
luraph-obfuscator foo.lua --format wearedevs --emit ir -o report.json
```

Alpha release. Supports one fingerprinted Luraph buffer VM and one family of WeAreDevs/Prometheus wrappers. Other variants need more work. Original names and comments are unavailable. WeAreDevs tamper checks remain and can react to changed source lines or stack frames. `--emit lua51` is Luraph-only. See [format support](docs/formats.md).

Independent MIT project, inspired by [PhoenixZeng/LuraphDeobfuscator](https://github.com/PhoenixZeng/LuraphDeobfuscator). Uses [luaparser](https://github.com/boolangery/py-lua-parser) and bundles [unluac](https://sourceforge.net/projects/unluac/). See [credits and licenses](THIRD_PARTY.md).
