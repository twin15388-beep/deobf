# Contributing

Use Python 3.10+ and Java 8+. Install from this checkout and run the tests:

```sh
python -m pip install -e .
python -m unittest discover -v
```

Source execution tests also need Lua 5.4 on `PATH`, or an executable path in
`LURAPH_TEST_LUA` or `LURAPH_TEST_LUNE`. Use `LURAPH_TEST_JAVA` to select Java.
Without those runtimes, the relevant integration tests are skipped.

Keep new Luraph VM formats in `src/luraph_deobfuscator/profiles/`. Bind format-specific
keys and opcode maps to verified fingerprints. Reject unsupported patterns
instead of guessing. Include small fixtures with an expected result, especially
for captures, argument counts, return values, and control flow.

The WeAreDevs AST backend lives in `src/luraph_deobfuscator/wearedevs/`. Keep its
evaluators restricted to in-memory operations and preserve multiple-result and
Lua truthiness rules. Do not add application execution or URL fetching to recovery.

Use authored or appropriately licensed fixtures. Do not commit private samples,
webhook URLs, credentials, recovered third-party applications, or obfuscator
runtime source. Bug reports can include the version, error message, and
`--unpack` manifest without uploading the script itself.

All Luau files must start with `--!strict` and contain no other comments.

```sh
ruff check src tests
ruff format --check src tests
python -m build
```
