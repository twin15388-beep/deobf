# Format support

Version 0.2.0 adds `wearedevs-prometheus-v1` alongside `buffer-v1`. Input detection
is automatic; `--format luraph` or `--format wearedevs` overrides it. All three
CLI names select the same backends. The WeAreDevs backend is described below.

For `buffer-v1`, the decoded VM and the first
153,060 bytes of the second layer must match its SHA-256 fingerprints. Run
`luraph-obfuscator --list-profiles` to see them. The encrypted program after
that bootstrap can vary. The CLI reads its constants, prototypes, instructions,
and root index on each run.

There is no verified Luraph version number for this profile. A different build,
randomized VM, bootstrap, or instruction layout needs another profile.
The older PhoenixZeng project's supported versions do not describe this CLI.

## Recovery steps

1. Find two `LPH` long-string literals while skipping Lua comments and quoted strings.
2. Remove each four-byte prefix. Decode five ASCII85 digits into one little-endian
   32-bit word, including the `z` zero-word abbreviation.
3. Decompress raw LZMA1 streams with `lc=3`, `lp=0`, and `pb=0`.
4. Match the VM and bootstrap fingerprints. Read the encrypted program tail with
   the profile's eight-byte XOR key, numeric tags, string cipher, and varints.
5. Normalize instruction aliases and statically resolvable metadata writes.
   Lift supported operations into a control-flow graph with register expressions.
6. Emit stripped Lua 5.1 bytecode. For source output, run the pinned unluac JAR
   and restore supported open-result calls with `table.pack` and `table.unpack`.

Value captures use closure factories so later register writes cannot change a
captured value. Reference captures retain their shared cells. Source files begin
with `--!strict`; recovered types are not inferred, so a strict type checker can
still report errors.

## Limits

This is an alpha decompiler. It supports the operations exercised by the initial
profile and the synthetic tests, not every opcode in that VM. Unsupported
operations, unresolved metadata writes, ambiguous multi-return patterns, and
unsupported control flow produce errors. Original variable names, comments,
formatting, and source structure are not recoverable.

Source output rejects fixed calls with three or more results. Bytecode and source
output reject open calls overlapping reference captures and open calls that read
the general call opcode's retained boundary register. Use `--emit ir` to inspect these cases.
In the IR, calls follow the profile's register cleanup rules: fixed arguments
clear higher registers before invocation, and fixed results clear higher registers
afterward. Opcode 74 retains one extra boundary register for nonzero fixed results.

Generated Lua 5.1 bytecode is an intermediate artifact. Its globals may require
Roblox or a Luau environment. Source output also requires Luau's `table.pack`
and `table.unpack`. Environment introspection and differences between Lua and
Luau are not covered by the behavior checks. Treat recovered source as material
for review, not proof that the input is harmless or behaviorally identical.

Input is limited to 8 MiB, each decompressed block to 32 MiB, and the payload to
4,096 prototypes. Item expansion, analysis iterations, nesting, registers, and
emitted instructions have additional limits. The Java subprocess has a 256 MiB
heap limit and a 30-second timeout. The Python process does not execute Lua or
make network requests. Source recovery runs the bundled Java decompiler.

`--unpack DIR` only decodes the outer layers and needs no matching VM profile or
Java. Its manifest hashes the exact decoded bytes; `vm.luau` has a `--!strict`
directive prepended. The VM and payload remain obfuscated at this stage.

`--raw-payload` is for format research and synthetic fixtures. It expects the
encrypted program tail with the wrapper and bootstrap already removed. It
skips fingerprint matching and still uses the `buffer-v1` key and instruction
map. It cannot make an unrelated format compatible.

## Validation

The public tests generate their own encrypted fixtures. They check input changes,
numeric and binary constants, parsing limits, control flow, closure captures,
multi-return values, and file output behavior. With Java and Lua 5.4 or Lune,
they also execute the authored fixtures' recovered source.

Before release, recovered source from the initial sample matched ten scenarios
in a mocked environment against the original VM. Those runs visited 38 of its
46 program prototypes. Network calls were mocked. The remaining prototypes,
every possible input, and live Roblox behavior were not verified. The original
sample and recovered application are not included in this repository.

## WeAreDevs / Prometheus

The [WeAreDevs obfuscator page](https://wearedevs.net/obfuscator) identifies
[Prometheus](https://github.com/wcrddn/Prometheus) as its backend. Its frontend
submits source to a server endpoint; the obfuscation engine is not shipped as
browser JavaScript. This CLI uses the public format as a reference and works
offline. It does not depend on or call that endpoint.

`wearedevs-prometheus-v1` recognizes a returned-function constant prefix followed
by a numeric VM dispatcher with closure factories. Matching is structural, so
local names, dispatch labels, constant offsets, table permutations, base64
alphabets, and the tested string cipher keys can vary. This is not a claim of
support for every Prometheus preset or every output from the website.

The backend:

1. Parses Lua with the pinned MIT-licensed `luaparser` dependency and resolves
   local bindings before replacing constants.
2. Evaluates the constant prefix with a restricted Python evaluator. Its allowed
   operations cover literal tables, arithmetic, loops, and selected string/table
   functions. It has no filesystem, network, process, loader, or host-object access.
3. Replaces pure constant accessors, folds numeric expressions, and identifies
   dispatcher blocks, successors, function entries, and capture lists.
4. Inspects the recognized string cipher initializer and helper blocks using the
   same restricted evaluator. It models capture allocation without running GC
   hooks and tests the permutation using low and high removal positions. Matching
   decoded cache reads in acyclic blocks become string literals. Reads depending
   on unavailable application values are skipped. Cipher calls and initialization
   remain in the source, including their runtime RNG effects.
5. Recovers separate functions and structures supported branches and loops.
   Functions with unsupported loop shapes keep an explicit state loop. Shared
   capture tables and the original retention helpers remain intact.

`--emit luau` produces source without Java. `--emit ir` produces JSON containing
constants, decoded strings, function entries, block instructions, successor
labels, and each function's `structured` status. Binary strings include exact
hex bytes alongside display text. The optional cipher pass reports when it could
not resolve a string; that does not prevent VM recovery.

`--unpack DIR` extracts `vm.luau`, `constants.json`, and `manifest.json` after
constant-prefix decoding. Its VM hash includes the strict directive in that file.
It can succeed even when the later VM structure is unsupported. `--raw-payload`
and `--emit lua51` apply only to Luraph.

The generated names are descriptive placeholders. Tamper checks remain, including
intentional errors and infinite loops. Checks that inspect line numbers, error
text, environments, or stack frames can behave differently after transformation.
Opaque exit globals must evaluate to nil or false; source includes a runtime
guard that errors if one is truthy. Use the output for inspection, not as proof
of complete runtime equivalence. The cipher pass is limited to its recognized
initialization pattern and is not a general symbolic interpreter.

WeAreDevs input is limited to 1 MiB and 100,000 AST nodes, with at most 4,096 VM
blocks and 256 recovered functions. Constant evaluation has a one-million-step
budget, a 16 MiB cumulative byte-allocation budget, and bounded call nesting and
table sizes. Generated VM statements have a 200,000-node expansion limit; source
output is capped at 8 MiB. Excessive nesting and unresolved transitions fail
with an error.

Authored fixtures check changing constants and cipher keys, shuffled encodings,
branches, nested loops, state-loop fallbacks, multiple returns, nil holes, shared
captures, input/output handling, and rejection boundaries. Behavior tests compare
the original and recovered authored programs in Lua 5.4 or Lune. The supplied
WeAreDevs sample was inspected statically: it contains 72 dispatcher blocks and
nine function entries, eight of which were structured. Its recovered loader URL
was not contacted. The third-party sample and its application are not bundled.
