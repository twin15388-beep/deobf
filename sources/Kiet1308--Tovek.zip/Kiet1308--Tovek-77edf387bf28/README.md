<h1><picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/assets/brand/tovek-logo-dark.svg">
  <img alt="Tovek" src="docs/assets/brand/tovek-logo.svg" height="64">
</picture></h1>

**A high-readability, high-performance Luau decompiler.** **Tovek V2.6.1**

[**Download V2.6.1 for Windows, Linux or macOS**](https://github.com/Kiet1308/Tovek/releases/tag/v2.6.1) · [What’s new in V2.6.1](https://github.com/Kiet1308/Tovek/releases/tag/v2.6.1) · [All release notes](https://kiet1308.github.io/Tovek/changelog.html)

Builds are published for Windows x86_64, Linux x86_64, Linux aarch64 and macOS on Apple silicon. Each package holds the two programs, `luau-lifter` (CLI) and `web-server` (local HTTP server), plus the licence; the executor client scripts live in this repository. The release tag is `v2.6.1`; Rust package versions are `2.6.1`.

[**💬 Join the Tovek Discord →**](https://discord.gg/phY6VUDSF7)

Tovek is a fork of the [medal](https://github.com/Stefanuk12/medal-decompiler) Luau
decompiler, rebuilt around a single goal: **output you can actually read.** Where most
decompilers hand you a wall of `v1, v2, v3 …` and inlined compiler noise, Tovek
reconstructs names, methods, control flow and idioms so the result reads close to the
source a human would have written — without sacrificing correctness.

AI features are disabled. The current decompiler uses deterministic rules and
does not load or download models or call AI services. AI is not part of this release. Model weights and model caches
stay local and must not be committed or uploaded to GitHub, including release
assets, workflow artifacts or Git LFS.

---

## What's new in V2.5

| | Tovek V2.1.1 | **Tovek V2.5** |
|---|---|---|
| Semantic fuzzing: wrong or missing outputs (2,700 runs) | 198 | **0** |
| Edge-case suite from reported and fuzzed bugs (318 runs) | 264 | **318** |
| Rebuilt helper calls, four real games | 1,630 | **4,260** |
| Anonymous `local` declarations, four real games | 57,700 | **36,949** |
| Scripts that fail to decompile, four real games | 7 | **0** |
| Native builds | Windows, Linux (x86_64) | **+ Linux aarch64, macOS Apple silicon** |

V2.5 fixes the structuring failures, captured-variable and evaluation-order bugs
found in real game dumps, two external reviews and semantic fuzzing; recognises
far more of the helper shapes Luau `-O2` inlines (tuple and local returns, loop
returns, trimmed copies, first-read arguments, constant arguments the compiler
folded away); and names values from events, state, modules, getters and the
helpers that produced them. Scripts Roblox could not compile come out as a
comment holding the compiler's message. New opt-in flags: `--style compact` (if-expressions)
and `--assume-standard-libraries` (spell folded `math.pi`, `Vector3.new`, ...).
See the [V2.5 release notes](https://kiet1308.github.io/Tovek/changelog/v2.5/).

## What's new in V2.1

| | Tovek V2 | **Tovek V2.1** |
|---|---|---|
| Full 3,978-script game, one thread | 20.1 s | **11.5 s** |
| Full game, 16 threads | 1.94 s | **1.13 s** |
| Peak memory, full game at 16 threads | 122 MB | **103 MB** |
| Deep-review behaviour suite | 80 / 199 | **199 / 199** |
| Luau bytecode v14 | Not supported | **Supported** (252 / 252 runtime profiles) |
| Damaged files that abort the process | 104 of 1,500 | **0 of 1,500** |

V2.1 fixes every case found by three code reviews since V2 where decompiled code
could behave differently from the original, validates bytecode before analysis,
and hardens the local HTTP server (shared job slots with a FIFO queue in front,
upload deadline via `TOVEK_UPLOAD_TIMEOUT_SECS`). See the
[V2.1 release notes](https://kiet1308.github.io/Tovek/changelog/v2.1/) for
methodology, examples and output changes.

## What's new in V2

| | v0.9 beta | **Tovek V2** |
|---|---|---|
| Roblox bytecode v12 | Not supported | Native support, including CALLFB |
| Anonymous p/v bindings | 54,058 | 36,826 |
| Lines over 180 characters | 382 | 98 |
| Passing shared runtime profiles | 138 / 198 | 198 / 198 |
| Public parse/recompile profiles | 513 / 513 | 513 / 513 |

Readability counts use the same 3,975 private files parseable in both versions.
The public profiles cover 171 source files at three optimization levels.
See the [release evaluation](https://kiet1308.github.io/Tovek/changelog/v2/#evaluation)
for scope, methodology and remaining regressions.

### Core capabilities

- **Name inference.** Locals and parameters get meaningful names derived from how they're
  used: `:Connect` → `connection`, `:Clone()` → `clone`, `:LoadAnimation` → `track`,
  `Color3.new` → `color`, `Vector3.new` → `vector`, `GetAttribute("Speed")` → `speed`,
  event signatures → `dt` / `input` / `player` / `child`, `tonumber`/`tostring` results,
  and more — falling back to `v*` only when nothing can be inferred soundly.
- **Service & `require` preservation.** `game:GetService(...)` and `require(...)` handles
  are kept as single named locals at the top of the chunk instead of being folded into
  every use site, so the dependency surface of a script is obvious at a glance.
- **OOP recovery.** Method tables defined with an explicit `self` first parameter are
  rendered back with colon-call syntax (`function T:method()`), the way they were written.
- **Reverses the Luau optimizer.** Tovek undoes `-O2` inlining — single-use temporaries,
  inlined expressions, and exploded table constructors are reassembled. Computed React event
  keys, drained `children` fields, callbacks, props and nested child tables are rebuilt from the
  leaves upward into declarative UI trees. Every line a recovered helper call starts on ends with
  `-- inferred equivalent call` (the call's first line when a function or table argument follows):
  Tovek inferred a call that behaves the same, which says nothing about where the source called
  the helper. The helper's definition line states how many such calls the output holds:
  `local function emit(part, n) -- 3 equivalent calls inferred from this helper`.
  Luau keeps a helper's own lines on the code it inlines, so line info tells how many copies of
  each helper a function holds. A small helper (`if c then c:Disconnect() end`, `a + (b - a) * t`)
  is rebuilt in a function only where its exact matches there are exactly those copies, and a call
  claiming a constant argument its copy folded away only where the function holds that helper's
  code at all. A copy Luau folded whole into one constant (`frames(13)` as
  `0.21666666666666667` for `return n / 60`) becomes the call where every use of that constant in
  the function is such a copy and an argument folds back to it bit for bit, by Luau's own constant
  folding rules (never through a library call, which a script may replace). A copy with constant
  arguments folded into its code (`part.Transparency = 0.5` for `fade(part, 0.5)` and `1 - k`) is
  matched by solving for those arguments the same way, where its numbers are the copies' own and
  its matches are exactly the helper's copies in the function. Line info only admits a match,
  never proves one; without it (`-g0`) such code stays as written.
- **Idiomatic cleanup.** Compound assignments, backtick string interpolation (where
  `("...%*"):format(x)` gives one value; a spreading last argument, constructor tail or `return`
  keeps `:format`, as a replaced `string.format` may return more),
  left-associated `and`/`or` (far fewer redundant parentheses), exact numeric literals, dropped
  needless `\'` escapes, and removal of redundant local copies, constant-only branches and
  discarded pure expressions. Roblox constructors retain their calls because global
  bindings can be replaced. Callback fields keep assignment syntax, long identifiers stay intact, and
  function-heavy returned tables recover a named module shape. Oversized truthy-selection
  chains return to `if`/`elseif`, while long left-associated concatenations become a named
  accumulator with `..=` updates instead of a parenthesized one-line wall.
- **Modern bytecode coverage.** Reads Luau serialization **v4–v14**, including v12
  size-delimited prototypes, 64-bit cost metadata, call feedback and `CALLFB`, and the
  v14 `FASTPCALL` fast path for `pcall`/`xpcall`, which decompiles to the same source as
  v9 (`pcall(require, script.Parent.Config)`, not a hoisted `local require2 = require`).
  v12 and v14 are each covered by 252 compiler/runtime profiles and the 513 public
  recompile profiles; v12 also has malformed-input checks and executed wasm32 reader
  tests. v13 double-vector serialization has targeted coverage; v15 and the experimental
  class opcodes (`NEWCLASS`) are unsupported. Runtime-mutated `CMPPROTO` guards are explicitly rejected because their
  prototype-identity predicate cannot be faithfully reconstructed in source. See the
  [v12 validation and limits](https://kiet1308.github.io/Tovek/changelog/v2/#bytecode-v12).
- **Literal and runtime fidelity.** Integer constants retain their signed 64-bit value
  and `i` suffix; recompilation requires Luau's `LuauIntegerType2` feature. Vector
  constants capture the standard `vector.create` function at chunk entry, preserving
  their behavior across later environment changes and O0/O1/O2 recompilation. A
  chunk with no room for that binding (no free register, or a closure already holding
  200 upvalues) spells the constant `vector.create(...)` in place instead, under the
  environment assumption below. The
  Lua 5.1 lifter emits Luau and preserves both `...` and the legacy `arg` table,
  including nil holes and `arg.n`; this compatibility path captures standard `select`
  at chunk entry. These generated helpers require those standard bindings at entry.
- **Validated output.** Public regression fixtures are checked with Luau's own
  parser, compiler and VM. V2 passes all 513 public parse/recompile profiles and
  the expanded suite of 246 runtime profiles. These checks cover the tested
  inputs; they do not prove equivalence for every program.

### Performance

- Cached analysis facts and binding summaries reduce repeated work in large
  functions, while bounded rescans limit control-flow traversal costs.
- **mimalloc** supplies per-thread allocation caches.
- **Parallel** per-function lifting and folder decompilation use rayon.
- **Deterministic, byte-identical output** across thread counts keeps results
  reproducible and easy to compare.
- An optional bounded artifact cache speeds up repeated folder workflows.

### Better tooling

- A native **`decompile-folder`** subcommand that decompiles an entire SynSaveInstance dump
  in parallel.
- A native **`validate-folder`** subcommand that decompiles *and* validates every output
  against Luau's parser in one pass.
- A small **HTTP server** (`web-server`) for the executor → server workflow, plus a
  ready-to-use client script.
- A **Cloudflare Worker** target (`luau-worker`) for serverless deployment.

---

## Output and validation

The [V2 release article](https://kiet1308.github.io/Tovek/changelog/v2/#evaluation)
compares the validated V2 output with v0.9 beta, including readability gains,
runtime checks and remaining regressions. The [UI reconstruction example](https://kiet1308.github.io/Tovek/changelog/v2/#ui-trees)
illustrates how module exports can be reconstructed into a table.

The output keeps the bytecode's behavior under one assumption about the
environment, the one Luau's own import resolution makes: a global path the script
never assigns (`print`, `Vector2.new`) keeps the value it had when the script
loaded. Luau resolves such a path once and reads it again only after code calls
getfenv/setfenv on the script's environment. A script that names getfenv or
setfenv itself is decompiled without the assumption; other scripts are assumed not
to call them on it.

A recovered helper (a function Luau's `-O2` inlined, or code found equal to one)
runs in a call frame of its own where the bytecode ran the code inline, as Luau's
inliner removed that frame. Code of the script that reads frames (`debug.info` of
a caller, or of a function or its name) is never moved into a helper, nor code
calling one that reads past its caller's source (its caller's name, or a frame
above): the caller it sees may become the helper, in the same script. Code in
other scripts is assumed not to inspect this script's frames.

A rebuilt call that names a constant the copy folded away (`fade(part, true)`)
stands only where the copy is larger than the call: a copy reduced to one call
of its own size (`table.clone(t)` for `Copy(t)`) keeps its code. Such a constant
is never inferred where the copy still reads the argument the caller passed (a
function literal capturing it). A helper
stored under its own name (`M.Copy = Copy`) keeps its `local function` beside
that store where its calls are rebuilt, and prints as `function M.Copy`
otherwise. An unnamed function literal capturing nothing that `-O2` inlined
everywhere (`local scramble = function`) comes back as a local function
before its first rebuilt call; without one it stays out, as before. Where
copies of two helpers cover the same statements, the call standing for more
code wins (a helper over another one inlined into it); two standing for the
same code keep it inline.

A function literal that Luau shares (one capturing only top-level locals or
itself) is one closure object at every site `-O2` inlined it to, as all copies
load one constant. Copies left inline whose identity can be seen (stored,
passed, compared or returned) are printed as one binding. Copies that capture
variables the output cannot show to hold one value stay separate literals, and
compare unequal where the bytecode may compare equal. Code holding such a
literal is never rebuilt into a helper call: the call would load the helper's
own constant, one object for every caller, where each calling function's copy
loaded a constant of its own. A literal bound to a local of the helper that is
only ever called (a local recursive function such as `deepCopy`) is the
exception: no code can tell those objects apart. A literal the bytecode makes
anew on every run keeps doing so: where a copy left inline captures a local
holding a constant (an `-O2` copy of `bind("y")`), that local is declared
first and assigned after (`local tag` / `tag = "y"`), since Luau would fold
the constant into the literal and share one closure object. With `-g2` Luau
keeps capturing a local declared with a constant (one new closure per run)
while it folds every read of it into the literal's body; that literal reads
the local again where its body holds the constant (`return tag`), or names it
first where the body holds it nowhere (`local _ = DEBUG`, as for `if DEBUG
then` folded away). The shared constant also caches: the first copy to run
fills it with its captures, and a copy whose captures differ makes a new
closure on every run. Where one copy runs before every other and another
captures a value that can never equal its own (a local bound to a different
function, such as each loop's `local function h` passed to an inlined
`bind(h)`), that copy stays new on every run too.

Bytecode that no source spells is refused rather than approximated: a NAMECALL
method that is no identifier, a FASTCALL whose fallback names another function
than its builtin, a loop prepared for `next` or `ipairs` over another generator,
a NaN constant with a payload `0 / 0` does not make, a global
that is no identifier in a script naming getfenv or setfenv, and output that would
need more locals or registers than Luau allows.

A table keeps its keys and values, and list items stay list items, but not always
its internal layout: a constructor that takes later stores sizes the table
differently. What depends only on the layout can differ, as the language leaves
it open: the order `pairs` and `next` visit keys, `#` of a table with `nil` holes
(any border), and the sign a zero key keeps when a store spelled with the other
sign lands on its slot while the slot holds `nil` (`{[0] = nil}`, then `t[-0] = v`:
the store keeps `[0]` if the slot is still there, and creates `[-0]` if a later key
took the slot or a resize dropped it).

Public regression fixtures, pinned corpus manifests and the CI workflow remain in
this repository. Private bytecode, generated output and internal research reports
stay local. No fresh matched comparison with hosted decompilers is claimed for V2.

---

## Usage

### CLI

Single file (raw Luau bytecode):

```sh
luau-lifter <file.luac>
```

Roblox client bytecode is encoded (`op = op * 203 % 256`); pass `-e` for it:

```sh
luau-lifter <script.lua> -e --script-name "Workspace.Script"
```

Decompile a whole folder of saved-bytecode files in parallel (mirrors the input tree,
renaming `.lua` → `.luau`):

```sh
luau-lifter decompile-folder ./dump ./out          # -e/--key 203 is the default for this mode
```

For repeated folder runs, add `--cache-dir ./tovek-cache`. The optional cache
keys artifacts by the exact binary, bytecode, options and module naming context;
it rebuilds path-specific metadata on each run. Keep the cache outside the input
and output trees. `--cache-max-mib` defaults to 512.

Add `--emit-binding-provenance --compact-annotations` to use short reconstruction
comments while retaining their complete diagnostics and reconstructed-call
locations in sidecars. Default comments remain unchanged. These locations
identify emitted calls; they do not prove original source call sites.

Volt/static-analysis mode writes clean `.lua` source directly and keeps all
upvalue metadata in hidden sidecars. The Volt export manifest is authoritative,
so source fallbacks are copied cleanly and never interpreted as bytecode:

```sh
luau-lifter decompile-folder ./dump ./out \
  --output-extension lua \
  --emit-upvalue-analysis \
  --export-manifest ./dump/.volt-export-manifest.json
```

Analysis output lives under `./out/.tovek-analysis/`. It includes deterministic
static function/site IDs, ordered zero-based VM upvalue slots, one-based ordinals,
`VAL`/`REF`/`UPVAL` capture chains, final emitted names, and decompiled spans. No
IDs, comments, or metadata are inserted into the decompiled source.
Sidecars are content-addressed and hash-bound by the folder manifest, which is
published last. Before that final publication, Tovek atomically publishes
`.tovek-analysis/source-write-provenance.json`, a hidden generation-bound
recovery snapshot. Its schema-v2 `sources` records bind every normalized output
path to the authoritative SHA-256 and byte length committed by that generation;
`generated_source_paths` remains as compatibility metadata. This makes a user
edit after an interrupted generation distinguishable from Tovek-owned bytes,
including writes completed before a later sidecar or manifest failure. It
carries the same `generation_id` as a successful analysis manifest and, for
Volt exports, the authoritative export-manifest SHA-256. A cross-process
output-generation lock prevents overlapping folder runs from mixing source
files and analysis generations.

Decompile **and** validate every output with Luau's own parser:

```sh
luau-lifter validate-folder ./dump ./out
```

Condition normalization is NaN-safe by default. `--assume-no-nan` permits the
more aggressive rewrite `not (a < b)` → `a >= b` when static proof is unavailable;
use it only when inputs cannot be NaN, because the two forms differ for NaN.

`--style compact` writes a scalar select as a Luau if-expression instead of
branch statements (`local mode = if flag then "a" else "b"`), and a
value-exact boolean select as its idiom (`ready and visible`). Conditions and
the chosen arm evaluate in the same order; function and table literals and
expressions longer than one line stay statements. The default style is
unchanged. Available in single-file and folder modes.

`--assume-standard-libraries` writes constants the compiler folded out of a
library as `math.pi`, `math.huge` and `Vector3.new(x, y, z)` instead of
`3.141592653589793`, `1e999` and a `createVector` snapshot. It applies only
when the script never writes those globals and never names getfenv/setfenv,
so the spelling compiles back to the same constant; it still assumes no other
script replaces the libraries in its environment, which the exact default
does not.

A number constant that is exactly `p / q` with `q <= 1000` prints as that
fraction when it reads shorter than its decimal: `task.wait(7 / 60)` instead of
`task.wait(0.11666666666666667)`, `x * (8 / 11)`. Division is correctly
rounded, so the fraction compiles back to the identical constant at every
optimization level, with no library involved; this is the default. A fraction
prints over the denominator its source most likely divided by when its lowest
one is no denominator anyone writes, or the script keeps using a larger one:
`Color3.new(190 / 255, ...)` rather than `38 / 51`, `UDim2.fromScale(1492 / 1920,
814 / 1080)` in a 1920x1080 layout, `28 / 60` beside other sixtieths; unit
fractions (`1 / 30`) stay as they are. Short decimals, integers, vector
components and literal table keys stay as they are, and such numbers are no
longer hoisted into named constants (`WAIT_INTERVAL`).

`--stats-json stats.json` (single-file and folder modes) writes what the
de-inliners did per script: the calls they rebuilt, counted in the final tree
by kind (statement, expression, arithmetic sites), the calls per helper with the
bytecode prototype it was lifted from, and the reasons helpers and sites were
refused. `scripts/scorecard.py --lifter <exe>` uses it to score the research
sample set (lines, rebuilt calls, generated-name share, name recall, token
similarity, line-info census recall).

`--synthesize-arithmetic-loops` enables an experimental presentation of exact
4-8-term arithmetic accumulations as finite loops. It is off by default and
labels generated loops as synthesis: the original source may have contained
a written-out expression. Available in single-file and folder modes.

### Web server + executor

Build and start the decompiler server (binds `http://127.0.0.1:3000/decompile`):

```powershell
.\run-server.ps1            # builds the release binary first if missing
.\run-server.ps1 -Build     # force a fresh release rebuild
```

It accepts `POST /decompile` with a base64-encoded bytecode body and an optional
`X-Script-Name` header (used to name the chunk). Load `decompile.client.luau` in your
executor to hook `getgenv().decompile` and drive SynSaveInstance through it.

#### Raw bytecode and batch endpoints

Two extra routes skip per-script overhead — ideal for dumping a whole game in one shot:

| Route | Body | Response |
| --- | --- | --- |
| `POST /decompile` | base64 bytecode (one script) | `text/plain` source |
| `POST /decompile/raw` | **raw** bytecode (one script, no base64) | `text/plain` source |
| `POST /decompile/batch` | **many** scripts in one request | JSON results array |

The local server runs at most four requests at once across these routes. Later
requests wait in a first-come, first-served queue without their bodies being read,
up to `TOVEK_QUEUE_LIMIT` waiting requests (default 1024) for at most
`TOVEK_QUEUE_TIMEOUT_SECS` (default 120). Only a full queue or an expired wait is
answered with HTTP `503` and `Retry-After: 1`; the bundled client scripts retry it.
Admitted uploads have a **30-second total body-read deadline**;
set `TOVEK_UPLOAD_TIMEOUT_SECS` to a positive integer to change it. An expired
upload receives HTTP `408` with `Connection: close` and releases its slot.
Completed uploads are not subject to this deadline while decompilation runs;
CPU work retains its slot until it finishes, even if the client disconnects.

- **Raw** (`/decompile/raw`): send the bytecode bytes verbatim — no base64 encode/decode.
  Use `Content-Type: application/octet-stream`, the optional `X-Script-Name` header, and an
  optional `X-Encode-Key` header (defaults to `203`).
- **Batch** (`/decompile/batch`): decompile many scripts in one request, in parallel. Two
  encodings, chosen by `Content-Type`:
  - `application/json` — `{ "key": 203, "scripts": [ { "id"?, "script_name"?, "bytecode": "<base64>" } ] }`
  - `application/octet-stream` — the binary **MDB1** framing (raw bytecode, no base64):
    `"MDB1"` magic, `u8` version `1`, `u8` key, two zero bytes, `u32`-LE count, then per entry
    a `u32`-LE-length-prefixed name and a `u32`-LE-length-prefixed bytecode blob (all little-endian).
  - Response: `{ "count", "ok_count", "results": [ { "index", "id"?, "script_name"?, "ok",
    "decompilation"?, "error"? } ] }`, in input order. **One bad script never fails the
    batch** — that item gets `ok:false` + an `error`; only a malformed request framing is a
    `400`.

Load `decompile-batch.client.luau` to pre-walk every script, decompile them all in one batch
(raw by default — flip `USE_RAW` if your executor mangles binary bodies), and drive
SynSaveInstance from the cached results.

---

## Building from source

Tovek uses nightly Rust feature gates and pins a specific toolchain — stable will not build it:

```sh
rustup toolchain install nightly-2026-06-15
cargo +nightly-2026-06-15 build --release --locked -p web-server -p luau-lifter
```

The release profile is tuned for distribution: fat LTO, a single codegen unit, no debug
info, and stripped symbols — maximum runtime speed and the smallest possible binary.
Prebuilt binaries are attached to each [release](https://github.com/Kiet1308/Tovek/releases/latest).

### Worker: build và cấu hình xác thực

Worker cần `worker-build 0.8.7` và chế độ `--panic-unwind` để lỗi của một script
không dừng cả batch. Phiên bản công cụ này gọi `cargo +nightly` khi build lại
std. Kênh nightly mới nhất đã bỏ những feature workspace còn dùng, và rustup không cho đặt tên
`nightly` cho toolchain tự tạo, nên CI dùng một shim `cargo` nhỏ để chuyển
`+nightly` sang toolchain đã ghim (job `worker` trong `.github/workflows/ci.yaml`).
Khi build cục bộ trong shell POSIX, làm tương tự:

```sh
rustup toolchain install nightly-2026-06-15 --component rust-src --target wasm32-unknown-unknown
mkdir -p ~/.cargo-shim
cat > ~/.cargo-shim/cargo <<'SHIM'
#!/usr/bin/env bash
if [ "${1:-}" = "+nightly" ]; then shift; set -- +nightly-2026-06-15 "$@"; fi
exec "${CARGO_HOME:-$HOME/.cargo}/bin/cargo" "$@"
SHIM
chmod +x ~/.cargo-shim/cargo
export PATH="$HOME/.cargo-shim:$PATH"
cargo install worker-build --version 0.8.7 --locked
cd luau-worker
worker-build --release --panic-unwind --no-opt
```

Không dùng bản WASM mặc định `panic=abort`; source Worker sẽ từ chối build cấu
hình này. `--no-opt` giữ nguyên exception handling; profile Worker cũng giữ
metadata mà wasm-bindgen cần. Kiểm tra runtime cục bộ từ thư mục gốc:

```sh
npm install --prefix out/worker-runtime --no-audit --no-fund miniflare@5.20260925.0-alpha
node scripts/check_worker_runtime.mjs luau-worker/build out/worker-runtime
```

Các endpoint đọc `AUTH_SECRET` từ Worker secret binding. Trước khi triển khai,
dùng `wrangler secret put AUTH_SECRET` trong `luau-worker` và nhập một giá trị
mới; không tái sử dụng khóa từng được commit. Thiếu binding trả HTTP 503, sai
khóa trả HTTP 403. Khóa cũ vẫn tồn tại trong lịch sử Git cho tới khi quản trị
viên xử lý; xóa literal khỏi source không tự xoay khóa trên deployment đang chạy.

### Kiểm thử hồi quy của đợt deep review

`scripts/check_deep_review.py` biên dịch fixture bằng Luau 0.736, chạy bytecode
gốc bằng VM, decompile, biên dịch lại và so sánh hành vi. Script bao gồm các
fixture C1–C12 trong `_harness/_bugs`, với cả ba mức tối ưu. Các file `.dec.luau`
cũ đã được bỏ vì không được harness kiểm tra và không còn phản ánh kết quả hiện tại.
Kết quả mới được sinh vào `--work`, kèm bytecode và `result.json` từng ca.

```sh
python scripts/check_deep_review.py --compiler /path/to/luau-compile --vm /path/to/benchmark-vm --lifter target/release/luau-lifter --work out/deep-review
```

### Fuzz có kiểu, đối chiếu với chính bytecode

`scripts/fuzz_roundtrip.py` sinh chương trình ngẫu nhiên từ một grammar có kiểu,
với các nhóm tính năng lấy từ những lớp lỗi các đợt review đã tìm (capture bị
ghi giữa các toán hạng, metamethod, method call, nhiều giá trị trả về, constructor
với key `±0` và `nil`, so sánh NaN, vòng lặp với `break`/`continue`, closure trong
vòng lặp, helper cạnh bản sao inline, thư viện bị che, `debug.info`, áp lực
register). Hai nhóm `capture-factory` và `recursive-arm` rút từ luồng ngẫu nhiên
riêng, nên seed không rút chúng vẫn sinh đúng chương trình cũ: closure gán đè lên
biến đang giữ chính giá trị nó capture (qua factory mà -O2 inline, hoặc làm đối
số gọi ở mọi mức tối ưu), và hàm đệ quy cục bộ trong một nhánh của phép chọn giá
trị. Năm nhóm de-inline rút từ luồng thứ ba theo cùng cách, mỗi nhóm một helper mà
-O2 thật sự inline cạnh code có dạng bản sao của nó: `written-param` (tham số bị
ghi, bản sao ghi vào biến của caller còn được đọc sau `if`, quanh vòng lặp hay
trong điều kiện `while`), `returned-cell` (trả về biến ngoài cho câu lệnh đọc
trạng thái khác trước), `error-level` (`error(msg, level)` trong `pcall`),
`closure-identity` (so sánh `==` closure tạo trong vòng lặp; seed có nhóm này
được biên dịch lại cùng phía -O1 với bytecode, vì DUPCLOSURE chỉ có từ -O1) và
`service-handle` (handle GetService/require qua stub toàn cục). Tham chiếu là
bytecode đã biên dịch, chạy trên benchmark VM; output
được biên dịch lại ở một mức ngẫu nhiên và chạy cùng driver. Bytecode -O0 được
biên dịch lại ở -O0 khi chính chương trình in khác nhau giữa -O0 và mức đã rút
(từ -O1 Luau đọc local truyền vào builtin lúc gọi, nên một đối số sau ghi local
đó chỉ thấy ở -O1); dòng kết quả ghi `source_differs`. `--mutate` sửa
bytecode theo cách chỉ chunk tự tạo mới có (string không phải identifier, NaN
payload): decompiler phải từ chối hoặc giữ nguyên hành vi. Grammar tránh những
gì chính Luau làm khác nhau giữa các mức tối ưu (từ -O1 POWK tính `^ 0.5` bằng
`sqrt`; ở -O2 vòng `for i = -0, 1` được unroll và bắt đầu từ `0`; inliner -O2 bỏ
frame; DUPCLOSURE chỉ dùng chung closure từ -O1, nên mọi hàm in ra là `fn`) và
những gì phụ thuộc layout bảng (thứ tự `pairs`, `#` khi có lỗ `nil`, dấu của key
`0` trên slot đang giữ `nil`). Địa chỉ heap mà một chunk bị sửa in ra (string
`"function"` bị đổi tên) được so như một token. CI chạy 80 seed cố định mỗi lần push;
workflow `Nightly fuzz` chạy một dải seed mới mỗi đêm và giữ chương trình đã rút
gọn của ca lỗi.

```sh
python scripts/fuzz_roundtrip.py --compiler /path/to/luau-compile --vm /path/to/benchmark-vm --lifter target/release/luau-lifter --seeds 500 --mutate --reduce --work out/fuzz --report out/fuzz.json
```

Manifest phân tích batch dùng `corpus_hash_algorithm: ordered-content-sha256-v2`:
băm đường dẫn theo thứ tự cùng SHA-256 của chính dữ liệu mỗi worker đã đọc.
Giá trị này khác thuật toán corpus cũ; chỉ so sánh hash khi cùng tên thuật toán.

---

## Reproducible decompiler benchmark

`scripts/decompiler_benchmark.py` compares local CLI binaries and the optional
[lua.expert API](https://lua.expert/docs) using identical compiler-produced bytes.
It separates bytecode support, recompilation, tested runtime behavior, source
structure and latency. There is no AI judge or combined winner score.

Build the compiler, AST parser and isolated VM from Luau commit
`c2ec0d4e5ca50796ba174a7565298f59aa572268`:

```sh
cmake -S /path/to/luau -B out/luau-build -DCMAKE_BUILD_TYPE=Release
cmake --build out/luau-build --target Luau.Compile.CLI Luau.Ast.CLI --parallel 4
cmake -S scripts/benchmark_vm -B out/benchmark-vm -DCMAKE_BUILD_TYPE=Release -DLUAU_SOURCE_DIR=/path/to/luau
cmake --build out/benchmark-vm --target benchmark-vm --parallel 4
```

Stage the licensed public repositories using `public_source_roundtrip.py
--checkout` (see its `--help`). Then run the stages below, substituting tool paths
and adding `.exe` on Windows as needed:

```sh
python scripts/decompiler_benchmark.py prepare --out out/comparison --vendor out/vendor --compiler out/luau-build/luau-compile --ast out/luau-build/luau-ast --vm out/benchmark-vm/benchmark-vm
python scripts/decompiler_benchmark.py collect --out out/comparison --native tovek-v2=target/release/luau-lifter --native beta-v09=/path/to/beta-v0.9 --online
python scripts/decompiler_benchmark.py evaluate --out out/comparison
python scripts/decompiler_benchmark.py timing --out out/comparison --native tovek-v2=target/release/luau-lifter --native beta-v09=/path/to/beta-v0.9 --online
python scripts/decompiler_benchmark.py report --out out/comparison
```

Open `out/comparison/index.html` to inspect every outcome and compare untouched
outputs against the original source. The frozen plan, binary hashes, HTTP
receipts and raw timing attempts remain beside the report. Collection resumes
from verified responses; use a new directory for a new provider snapshot.

Only `collect --online` and `timing --online` contact lua.expert, at 120 requests
per minute by default. They upload the benchmark's owned fixtures, generated
programs and pinned public sources; private dumps are not part of this corpus.
CI runs offline controls only. Reports and collected outputs stay under ignored
`out/`; no model downloads or AI features are enabled.

The default plan covers 41 development regressions, all 171 selected public
files and 24 fresh generated seeds with alpha-renamed variants, across v9/v12
and optimization/debug profiles. Six capability probes are excluded from quality
scores. Existing fixtures and generator grammar have Tovek development exposure;
fresh seeds are not an independent language-family holdout. Public Roblox modules
receive syntax/structural checks, not full experience execution. Runtime checks
prove only the supplied observations. Profile variants are clustered by original
program/seed for paired uncertainty estimates. API latency includes the network;
CLI latency includes process startup, so their ratio is not engine throughput.

---

## Community

Questions, bug reports, or want to follow development? **[Join the Tovek Discord](https://discord.gg/phY6VUDSF7).**

---

## Credits

Tovek stands on the work of the original **medal** decompiler. All credit for the
foundation goes, in honour and memory, to:

- **Jujhar Singh** (KowalskiFX)
- **Mathias Pedersen** (Costomality)

Keep the Singh and Pedersen families in your prayers. We love you both.

---

## License

MIT — see [LICENSE.txt](LICENSE.txt). © 2024 Jujhar Singh, Mathias Pedersen.
