//! Frozen pre-W5 expression de-inlining; test-only differential oracle.
//! Expression-level de-inliner (proposal §7): reverses Luau `-O2` inlining of a
//! small pure scalar helper whose body was copied into a caller as a
//! *sub-expression* of a larger condition / RValue — the case the
//! statement-region [`crate::deinline`] pass cannot see.
//!
//! Flagship (`DecompiledTest/Client/ChatTipsClient.luau`):
//!
//! ```luau
//! local function isFiniteNumber(p)
//!     return if typeof(p) == "number" and (p == p and p > -math.huge) then p < math.huge else false
//! end
//!
//! -- caller, with isFiniteNumber inlined as an expression under `not (...)`:
//! local v4 = not (if typeof(v2) == "number" and (v2 == v2 and v2 > -math.huge) then v2 < math.huge else false)
//!     and 240 or math.clamp(math.floor(v2 + 0.5), 5, 86400)
//! ```
//!
//! becomes
//!
//! ```luau
//! local v4 = not isFiniteNumber(v2) and 240 or math.clamp(math.floor(v2 + 0.5), 5, 86400)
//! ```
//!
//! # Where this runs, and why it matters
//!
//! This pass MUST run AFTER `reconstruct_conditional_expressions` (so
//! `IfExpression`/`and`/`or` exist) but BEFORE `normalize_conditions`. The latter
//! pushes `not` inward by De Morgan: the call-site copy above, sitting under
//! `not (...)`, would be rewritten into a disjunction
//! (`typeof(v2) ~= "number" or ... or not (v2 < math.huge)`) while the standalone
//! helper body collapses to a conjunction — two structurally unrelated trees an
//! EXACT unifier can never bridge. Run *before* normalization and both the helper
//! body `E` and the embedded copy are the same freshly-reconstructed tree; the
//! `not (...)` wrapper is preserved verbatim by the in-place rewrite, and the
//! later `normalize_conditions` keeps `not isFiniteNumber(v2)` (it cannot De Morgan
//! a call). See `luau-lifter/src/lib.rs`.
//!
//! # Why it is correct (refuse-by-default, like [`crate::deinline`])
//!
//! Replacing an in-place sub-expression `S = E[params := args]` with
//! `helper(args)` is observationally equivalent in Luau when:
//!
//!   * **In place** — the call occupies `S`'s exact evaluation slot, so the
//!     enclosing short-circuit / conditionality (`and`/`or`/`if-expr`) and the
//!     body's own internal short-circuits + side effects are reproduced
//!     identically (guaranteed by the exact structural match). Body purity is NOT
//!     required: `typeof(p)` is a side-effecting call yet is fine, because the
//!     body's effects happen identically either way.
//!   * **Single scalar result** — the helper returns exactly one scalar on every
//!     path (`is_scalar_return_value` on `E`'s root), so `helper(args)` yields one
//!     value in ANY expression slot, including a multi-value tail position.
//!   * **Arg hoist-safety** — `helper(args)` evaluates each argument once, eagerly,
//!     left-to-right, whereas `S` evaluates each parameter occurrence lazily at its
//!     position. The only semantic delta is therefore arg-evaluation timing/count;
//!     it vanishes iff every bound argument is **side-effect-free** (so an arg that
//!     `E` never evaluates on some path, or evaluates several times, is neutral)
//!     AND **value-stable** (reads no local written inside `S` — provably vacuous
//!     here, since an eligible `E` is a closure-free RValue with no statement
//!     writes, but kept as belt-and-suspenders).
//!
//! Everything is matched by the same exact unifier the statement pass uses
//! ([`crate::deinline::unify_rvalue`]): parameters are bind-once holes, callee
//! locals an injective renaming, and globals/literals(NaN-bit-exact)/operators/
//! upvalues must match exactly — NO commutativity, associativity, or De-Morgan.
//!
//! The additional [`arithmetic`] family accepts named bytecode helpers without
//! global/string anchors. It constructs an internal return/selection pattern,
//! admits only parameter/literal arithmetic, checks reference-capture stability,
//! and uses deterministic search budgets. Its separate output marker identifies
//! equivalent-call inference; it does not assert unique original call sites.

use std::mem::Discriminant;

#[path = "reference_arithmetic.rs"]
pub(super) mod arithmetic;

use parking_lot::Mutex;
use rustc_hash::{FxHashMap, FxHashSet};
use triomphe::Arc;

use crate::deinline::{
    Bindings, MatchCtx, anchors_in_rvalue, body_unsafe, canon, each_closure_decl,
    is_scalar_return_value, stmt_rvalues, stmt_rvalues_mut, unify_rvalue,
};
use crate::{Block, Call, Function, LValue, LocalRw, RValue, RcLocal, Statement, Traverse};

type FnPtr = *const Mutex<Function>;

/// Legacy expression-family cost gate — readability only. `E` must carry at least
/// this many "anchors" (globals + string literals + method calls) so a trivial
/// helper like `double(x) = x * 2` (0 anchors) is never replaced. The flagship
/// `isFiniteNumber` body sits at exactly 2 (the `typeof` global + the `"number"`
/// string; `math.huge` folds to a `Number` literal contributing 0), so this floor
/// must NOT be raised.
const ANCHOR_FLOOR: usize = 2;
/// `E` must have at least this many RValue nodes — a second readability floor that
/// rejects single-operator helpers the anchor gate might admit.
const NODE_COUNT_FLOOR: usize = 5;
/// A site is only rewritten when the inlined subtree `S` is at least this many
/// nodes larger than its replacement `helper(args)` — so `f(bigExpr)` non-shrinks
/// are refused.
const NET_SAVING_FLOOR: usize = 4;

/// A pure-scalar helper eligible for expression-level de-inlining.
pub(super) struct ExprTarget {
    /// The `local f` the helper is bound to (the call we emit).
    pub(super) f_local: RcLocal,
    /// Identity of the helper's `Function`, for the self-match / scope guards.
    pub(super) func_ptr: FnPtr,
    /// The canonical body expression `E` (one pure scalar RValue).
    pub(super) expr: RValue,
    /// `E`'s parameter binding-holes (bind-once during unification).
    pub(super) params: FxHashSet<RcLocal>,
    /// Callee-declared locals (always empty for a single-expression body, kept for
    /// the [`MatchCtx`] the shared unifier expects).
    pub(super) locals: FxHashSet<RcLocal>,
    /// Parameters in declaration order, to reconstruct the argument list.
    pub(super) param_order: Vec<RcLocal>,
    /// Additional, bounded proof path for named bytecode arithmetic helpers.
    pub(super) arithmetic: Option<std::rc::Rc<arithmetic::Safety>>,
    pub(super) leading: crate::evaluation_order::LeadingReads,
    pub(super) upvalues: std::rc::Rc<super::FunctionUpvalues>,
    pub(super) captures: std::rc::Rc<crate::deinline_safety::CaptureSafety>,
    pub(super) search: std::rc::Rc<crate::deinline_safety::SearchBudget>,
    pub(super) protect_definition: bool,
}

impl ExprTarget {
    fn ctx(&self) -> MatchCtx<'_> {
        MatchCtx {
            params: &self.params,
            locals: &self.locals,
            captures: None,
            fold: None,
        }
    }
}

pub fn expr_deinline(body: &mut Block) { run(body, false); }

/// Match named scalar helpers before cleanup can consume their only binding
/// into an export property. A committed call keeps that lexical binder alive.
pub fn arithmetic_deinline_early(body: &mut Block) { run(body, true); }

pub(super) fn run(body: &mut Block, arithmetic_only: bool) {
    let mut targets = collect_expr_targets(body);
    if arithmetic_only {
        targets.retain(|t| t.arithmetic.is_some());
        for target in &mut targets { target.protect_definition = true; }
    }
    if targets.is_empty() {
        return;
    }
    // f_local -> target index, so we recognise each helper's declaration during
    // the scan and only activate it for sites in its lexical scope.
    let decl_map: FxHashMap<RcLocal, usize> = targets
        .iter()
        .enumerate()
        .map(|(i, t)| (t.f_local.clone(), i))
        .collect();
    // E-root discriminant -> candidate target indices. An exact unify requires the
    // candidate node to share `E`'s root variant (the root is always a compound
    // expression — a bare param/local/literal root is refused by the cost gate),
    // so this is a sound, false-negative-free prefilter.
    let mut by_root: FxHashMap<Discriminant<RValue>, Vec<usize>> = FxHashMap::default();
    for (i, t) in targets.iter().enumerate() {
        by_root
            .entry(std::mem::discriminant(&t.expr))
            .or_default()
            .push(i);
        if t.arithmetic.is_some() && matches!(t.expr, RValue::IfExpression(_)) {
            by_root
                .entry(std::mem::discriminant(&RValue::Binary(crate::Binary::new(
                    crate::Literal::Nil.into(),
                    crate::Literal::Nil.into(),
                    crate::BinaryOperation::Or,
                ))))
                .or_default()
                .push(i);
        }
    }
    walk_block(&mut body.0, &targets, &by_root, &decl_map, &[], None);
}

// ===================================================================
// Target collection
// ===================================================================

pub(super) fn collect_expr_targets(body: &Block) -> Vec<ExprTarget> {
    // Writes to every local across the whole module, shared with the statement
    // de-inliner. Refcounts cannot establish whether a helper is reassigned: a
    // genuine call or an earlier de-inline also raises them. Refuse a binder
    // with a second write: if
    // `local f = function...end` is later rebound (`f = otherFn`), emitting `f(args)`
    // at a site past the rebind would call the wrong function. A binder that is
    // never rebound is written exactly once (its declaration); any extra write
    // refuses it.
    let captures = std::rc::Rc::new(crate::deinline_safety::CaptureSafety::new(body));
    let upvalues = std::rc::Rc::new(super::function_upvalues(body));
    if !captures.complete() { return Vec::new(); }
    let mut write_counts: FxHashMap<RcLocal, usize> = FxHashMap::default();
    collect_write_counts(&body.0, &mut write_counts);
    let search = std::rc::Rc::new(crate::deinline_safety::SearchBudget::default());
    let arithmetic_safety = std::rc::Rc::new(arithmetic::Safety::new(body));
    let mut arithmetic_targets = 0usize;
    let mut targets = Vec::new();
    each_closure_decl(&body.0, &mut |l, fa| {
        // Refuse a reassigned helper binder (written anywhere beyond its decl).
        if write_counts.get(l).copied().unwrap_or(0) != 1 {
            return;
        }
        let g = fa.lock();
        // Fixed-arity, no goto/label/comment/close/for-init, NO nested closure
        // (identity-matching closures is unsound). P5-A: the `g.name.is_none()`
        // gate is dropped here too — `g.name` is only the bytecode debugname,
        // never consumed by emission (the call uses `f_local`) or the formatter;
        // the ANCHOR_FLOOR/NODE_COUNT_FLOOR cost gates below filter trivial
        // helpers regardless of debugname. Variadic stays refused (unprovable
        // arity in a multi-value slot).
        if g.is_variadic || body_unsafe(&g.body.0) {
            return;
        }
        let leading = super::leading_reads(&g.body.0, &g.parameters, &captures);
        if let Some(expr) = arithmetic::pattern(&g) {
            arithmetic_targets += 1;
            if arithmetic_targets > arithmetic::MAX_TARGETS {
                return;
            }
            crate::call_origins::register_callee(l.stable_id(), g.bytecode_proto_id);
            targets.push(ExprTarget {
                f_local: l.clone(),
                func_ptr: Arc::as_ptr(fa),
                expr,
                params: g.parameters.iter().cloned().collect(),
                locals: FxHashSet::default(),
                param_order: g.parameters.clone(),
                arithmetic: Some(arithmetic_safety.clone()),
                leading: leading.clone(),
                upvalues: upvalues.clone(),
                captures: captures.clone(),
                search: search.clone(),
                // Keep competing helper definitions intact in every phase.
                // Folding one helper into another would erase the ambiguity
                // that must also block reconstruction in their callers.
                protect_definition: true,
            });
            return;
        }
        // The body must canonicalise to EXACTLY `return <one value>`. `canon` folds
        // the guard/early-return duality and drops a trailing void return; a body
        // that still has statement-level branching after that (a multi-leaf
        // if/else diamond — which `value_leaf_shape` would accept) cannot be a
        // single embeddable expression, so refuse it. We do NOT fold such a body
        // ourselves (that would re-derive a slice of the reconstructor and risk
        // building an `E` that diverges from real call sites).
        let shape = crate::deinline_safety::CaptureSafety::new(&g.body);
        if !shape.complete() || shape.nodes() > 2048 { return; }
        let pat = canon(&g.body.0);
        let expr = match pat.as_slice() {
            [Statement::Return(r)] if r.values.len() == 1 => r.values[0].clone(),
            _ => return,
        };
        // Root must yield a single value (not Call/MethodCall/VarArg/Select — those
        // have unprovable arity in a multi-value slot). Nested calls like `typeof`
        // inside `E` are fine; only the ROOT is constrained.
        if !is_scalar_return_value(&expr) {
            return;
        }
        // Recursion guard: a body that reads its own binder would emit a call to
        // itself for one unrolled level. Refuse (sound; rare).
        if expr.values_read().iter().any(|&rl| rl == l) {
            return;
        }
        // Cost gate (specificity + size). Both reject trivial helpers.
        let mut anchors = 0usize;
        anchors_in_rvalue(&expr, &mut anchors);
        if anchors < ANCHOR_FLOOR {
            return;
        }
        if node_count(&expr) < NODE_COUNT_FLOOR {
            return;
        }
        let params: FxHashSet<RcLocal> = g.parameters.iter().cloned().collect();
        let param_order = g.parameters.clone();
        crate::call_origins::register_callee(l.stable_id(), g.bytecode_proto_id);
        targets.push(ExprTarget {
            f_local: l.clone(),
            func_ptr: Arc::as_ptr(fa),
            expr,
            params,
            locals: FxHashSet::default(),
            param_order,
            arithmetic: None,
            leading,
            upvalues: upvalues.clone(),
            captures: captures.clone(),
                search: search.clone(),
                protect_definition: false,
        });
    });
    if targets.len() > 256 { return Vec::new(); }
    // Never silently truncate the ambiguity set: an omitted helper might also
    // match. Budget exhaustion disables the entire new family for this module.
    if arithmetic_targets > arithmetic::MAX_TARGETS {
        targets.retain(|t| t.arithmetic.is_none());
    }
    targets
}

/// Count writes to each local across `stmts`, recursing into nested statement
/// blocks AND closure bodies (a rebind could hide in either). Mirrors the write
/// sites `deinline::collect_written` recognises (assignment LHS, numeric/generic
/// `for` induction locals, `SetList` object) but accumulates counts. Runs once at
/// collection time (cold), not in the matching hot path.
///
/// `pub(crate)` so the statement de-inliner (`crate::deinline::collect_targets`,
/// proposal P4) shares this single source of truth instead of copying it — the
/// `stmt_rvalues` note below is load-bearing and two copies would drift.
pub(crate) fn collect_write_counts(stmts: &[Statement], out: &mut FxHashMap<RcLocal, usize>) {
    for s in stmts {
        match s {
            Statement::Assign(a) => {
                for lhs in &a.left {
                    if let LValue::Local(x) = lhs {
                        *out.entry(x.clone()).or_default() += 1;
                    }
                }
            }
            Statement::NumericFor(nf) => {
                *out.entry(nf.counter.clone()).or_default() += 1;
                collect_write_counts(&nf.block.lock().0, out);
            }
            Statement::GenericFor(gf) => {
                for x in &gf.res_locals {
                    *out.entry(x.clone()).or_default() += 1;
                }
                collect_write_counts(&gf.block.lock().0, out);
            }
            Statement::SetList(sl) => {
                *out.entry(sl.object_local.clone()).or_default() += 1;
            }
            Statement::If(f) => {
                collect_write_counts(&f.then_block.lock().0, out);
                collect_write_counts(&f.else_block.lock().0, out);
            }
            Statement::While(w) => collect_write_counts(&w.block.lock().0, out),
            Statement::Repeat(r) => collect_write_counts(&r.block.lock().0, out),
            _ => {}
        }
        // Use `stmt_rvalues` (not the `Traverse::rvalues` accessor): for an
        // `Assign` the latter exposes only `right`, omitting LHS `Index` operands,
        // whereas `collect_written` — which this mirrors — also visits them. A
        // closure rebinding the helper hidden in an LHS index operand
        // (`t[(function() f = g end)()] = x`) must still be counted, so the
        // reassignment-refusal gate cannot be silently bypassed.
        for rv in stmt_rvalues(s) {
            write_counts_in_closures(rv, out);
        }
    }
}

pub(crate) fn write_counts_in_closures(rv: &RValue, out: &mut FxHashMap<RcLocal, usize>) {
    if let RValue::Closure(c) = rv {
        collect_write_counts(&c.function.0.lock().body.0, out);
        return;
    }
    for child in rv.rvalues() {
        write_counts_in_closures(child, out);
    }
}

// ===================================================================
// Traversal: two-phase scope walk mirroring `deinline::deinline_block`
// ===================================================================

fn walk_block(
    stmts: &mut Vec<Statement>,
    targets: &[ExprTarget],
    by_root: &FxHashMap<Discriminant<RValue>, Vec<usize>>,
    decl_map: &FxHashMap<RcLocal, usize>,
    outer_active: &[usize],
    current_func: Option<FnPtr>,
) {
    // Phase 1: recurse into nested statement blocks and closure bodies. A child
    // only sees targets whose declaration lexically precedes it, so `active` grows
    // as each declaration in THIS block is passed.
    {
        let mut active: Vec<usize> = outer_active.to_vec();
        for s in stmts.iter_mut() {
            match s {
                Statement::If(f) => {
                    walk_block(
                        &mut f.then_block.lock().0,
                        targets,
                        by_root,
                        decl_map,
                        &active,
                        current_func,
                    );
                    walk_block(
                        &mut f.else_block.lock().0,
                        targets,
                        by_root,
                        decl_map,
                        &active,
                        current_func,
                    );
                }
                Statement::While(w) => walk_block(
                    &mut w.block.lock().0,
                    targets,
                    by_root,
                    decl_map,
                    &active,
                    current_func,
                ),
                Statement::Repeat(r) => walk_block(
                    &mut r.block.lock().0,
                    targets,
                    by_root,
                    decl_map,
                    &active,
                    current_func,
                ),
                Statement::NumericFor(nf) => walk_block(
                    &mut nf.block.lock().0,
                    targets,
                    by_root,
                    decl_map,
                    &active,
                    current_func,
                ),
                Statement::GenericFor(gf) => walk_block(
                    &mut gf.block.lock().0,
                    targets,
                    by_root,
                    decl_map,
                    &active,
                    current_func,
                ),
                _ => {}
            }
            for rv in stmt_rvalues_mut(s) {
                recurse_into_closures(rv, targets, by_root, decl_map, &active);
            }
            if let Some(idx) = target_decl_index(s, decl_map, targets) {
                active.push(idx);
            }
        }
    }

    // Phase 2: scan this block left to right, matching each statement's own
    // expressions, activating each target after its declaration.
    let mut active: Vec<usize> = outer_active.to_vec();
    let mut index = 0;
    while index < stmts.len() {
        // A bounded terminal scalar region has no live continuation. Normalize
        // its lets/guard returns before comparing with named helper patterns.
        if try_rewrite_region(&mut stmts[index..], targets, &active, current_func) {
            stmts.truncate(index + 1);
            break;
        }
        try_rewrite_select(stmts, index, targets, &active, current_func);
        let s = &mut stmts[index];
        index += 1;
        // Skip the per-statement rvalue scan (and its allocation) entirely until a
        // helper is in scope.
        if !active.is_empty() {
            for rv in stmt_rvalues_mut(s) {
                try_rewrite(rv, targets, by_root, &active, current_func);
            }
        }
        if let Some(idx) = target_decl_index(s, decl_map, targets) {
            active.push(idx);
        }
    }
}

/// Descend `rv` to find closures, running the full walk on each closure body with
/// `current_func` set to that closure (so a helper never matches inside its own
/// body) and the current `active` set (targets in scope at the closure's site are
/// visible inside it as upvalues).
fn recurse_into_closures(
    rv: &mut RValue,
    targets: &[ExprTarget],
    by_root: &FxHashMap<Discriminant<RValue>, Vec<usize>>,
    decl_map: &FxHashMap<RcLocal, usize>,
    active: &[usize],
) {
    if let RValue::Closure(c) = rv {
        let fp = Arc::as_ptr(&c.function.0);
        walk_block(
            &mut c.function.0.lock().body.0,
            targets,
            by_root,
            decl_map,
            active,
            Some(fp),
        );
        return;
    }
    for child in rv.rvalues_mut() {
        recurse_into_closures(child, targets, by_root, decl_map, active);
    }
}

/// If `s` is the declaration `local f = function ... end` of one of our targets,
/// returns that target's index (scope activation, mirroring
/// `deinline::target_decl_index`).
fn target_decl_index(
    s: &Statement,
    decl_map: &FxHashMap<RcLocal, usize>,
    targets: &[ExprTarget],
) -> Option<usize> {
    if let Statement::Assign(a) = s
        && a.prefix
        && a.left.len() == 1
        && a.right.len() == 1
        && let LValue::Local(l) = &a.left[0]
        && let RValue::Closure(c) = &a.right[0]
        && let Some(&idx) = decl_map.get(l)
        && Arc::as_ptr(&c.function.0) == targets[idx].func_ptr
    {
        return Some(idx);
    }
    None
}

// ===================================================================
// Matching + rewrite (outermost-first)
// ===================================================================

fn try_rewrite_select(
    stmts: &mut Vec<Statement>, index: usize, targets: &[ExprTarget], active: &[usize],
    current_func: Option<FnPtr>,
) {
    if active.is_empty() || current_func.is_some_and(|p| targets.iter().any(|t| t.func_ptr == p)) { return; }
    let [Statement::Assign(decl), Statement::If(_)] = &stmts[index..stmts.len().min(index + 2)] else { return; };
    if !decl.prefix || decl.parallel || decl.left.len() != 1 { return; }
    let LValue::Local(result) = &decl.left[0] else { return; };
    let result = result.clone();
    // The result binding is retained, including debug identity. Captured cells
    // refuse because moving the nil initialization inside a call is observable.
    if !targets[active[0]].captures.uncaptured(&result) { return; }
    let candidate = vec![stmts[index].clone(), stmts[index + 1].clone(), crate::Return::new(vec![result.clone().into()]).into()];
    let Some(value) = arithmetic::region(&candidate, &targets[active[0]].captures) else { return; };
    let mut pick = super::Pick::default();
    let ordered = crate::reconstruction_search::prioritize(active, current_func.map(|p| p as usize), |i| targets[i].func_ptr as usize);
    for idx in ordered {
        let target = &targets[idx];
        let Some(safety) = &target.arithmetic else { continue; };
        if !safety.spend_attempt() { return; }
        if let Some(found) = try_match(target, &value, current_func) {
            pick.offer(idx, found);
            if pick.settled() { return; }
        }
    }
    let Some((idx, args)) = pick.take() else { return; };
    let target = &targets[idx];
    let call = Call::new(target.f_local.clone().into(), args).reconstructed(crate::call_origins::Kind::ArithmeticDeinline);
    // One result, declared the way the lifter declares any `local r = f()`, so
    // later temp inlining can place it where the value is used.
    let value = RValue::Select(crate::Select::Call(call));
    stmts.splice(index..index + 2, [crate::Assign { node_origin: Default::default(), left: vec![result.into()], right: vec![value], prefix: true, parallel: false, compound: false}.into()]);
}

fn try_rewrite_region(
    stmts: &mut [Statement],
    targets: &[ExprTarget],
    active: &[usize],
    current_func: Option<FnPtr>,
) -> bool {
    if active.is_empty() || stmts.len() > 8 || matches!(stmts, [Statement::Return(_)]) { return false; }
    if current_func.is_some_and(|ptr| targets.iter().any(|t| t.func_ptr == ptr)) { return false; }
    let Some(value) = arithmetic::region(stmts, &targets[active[0]].captures) else { return false; };
    let mut declared = FxHashSet::default();
    crate::deinline::collect_declared_locals(stmts, &mut declared);
    let mut pick = super::Pick::default();
    for &idx in active {
        let target = &targets[idx];
        let Some(safety) = &target.arithmetic else { continue; };
        if current_func == Some(target.func_ptr) { continue; }
        if !safety.spend_attempt() { return false; }
        if declared.iter().any(|l| l.has_source_binding() || !target.captures.uncaptured(l)) { continue; }
        if let Some(found) = try_match(target, &value, current_func) {
            pick.offer(idx, found);
            if pick.settled() { return false; }
        }
    }
    let Some((idx, args)) = pick.take() else { return false; };
    let target = &targets[idx];
    let call = Call::new(target.f_local.clone().into(), args)
        .reconstructed(crate::call_origins::Kind::ArithmeticDeinline);
    stmts[0] = crate::Return::new(vec![call.into()]).into();
    true
}

fn try_rewrite(
    rv: &mut RValue,
    targets: &[ExprTarget],
    by_root: &FxHashMap<Discriminant<RValue>, Vec<usize>>,
    active: &[usize],
    current_func: Option<FnPtr>,
) {
    // No helper is in lexical scope here, so no node in this subtree can match
    // (`active` is monotone-nondecreasing down the descent, and `try_match` only
    // considers `active` targets). Prune the whole subtree — this skips the entire
    // pre-declaration region of every block. Mirrors the statement pass's
    // `if active.is_empty()` guard in `deinline::try_match_at`.
    if active.is_empty() || current_func.is_some_and(|ptr| targets.iter().any(|t| t.protect_definition && t.func_ptr == ptr)) {
        return;
    }
    // Outermost-first: try to match the WHOLE node before descending, so the
    // largest equivalent subtree is collapsed into one call.
    if let Some(cands) = by_root.get(&std::mem::discriminant(&*rv)) {
        let mut pick = super::Pick::default();
        let mut ambiguous = false;
        let ordered = crate::reconstruction_search::prioritize(cands, current_func.map(|p| p as usize), |i| targets[i].func_ptr as usize);
        for &idx in &ordered {
            if !active.contains(&idx) {
                continue; // helper not yet in lexical scope here
            }
            let t = &targets[idx];
            if current_func == Some(t.func_ptr) {
                continue; // never match a helper against its own body
            }
            if !t.search.spend(2048) { ambiguous = true; break; }
            if let Some(safety) = &t.arithmetic {
                if !safety.spend_attempt() {
                    ambiguous = true;
                    break;
                }
            }
            if let Some(found) = try_match(t, rv, current_func) {
                pick.offer(idx, found);
                if pick.settled() {
                    break;
                }
            }
        }
        if !ambiguous {
            if let Some((idx, args)) = pick.take() {
                let t = &targets[idx];
                let call = Call::new(RValue::Local(t.f_local.clone()), args).reconstructed(
                    if t.arithmetic.is_some() { crate::call_origins::Kind::ArithmeticDeinline }
                    else { crate::call_origins::Kind::ExpressionDeinline });
                *rv = RValue::Call(call);
                // Do NOT descend into the freshly-emitted args (idempotence +
                // largest-match): the call root is never a pattern (scalar-root gate
                // excludes Call), and the args are already-final caller expressions.
                return;
            }
        }
    }
    // No unambiguous match here — descend into children (a smaller subtree, or a
    // sibling, may still match). Closures yield no children here (handled in the
    // phase-1 closure recursion), so we never re-enter a closure body.
    for child in rv.rvalues_mut() {
        try_rewrite(child, targets, by_root, active, current_func);
    }
}

/// Attempt to unify target `t`'s body `E` against the candidate subtree `rv` and,
/// if it matches under all gates, return the reconstructed argument list.
fn try_match(t: &ExprTarget, rv: &RValue, current_func: Option<FnPtr>) -> Option<(Vec<RValue>, super::Hoist)> {
    let mut b = Bindings::default();
    let matched = if t.arithmetic.is_some() {
        arithmetic::unify(&t.ctx(), &t.expr, rv, &mut b)
    } else {
        unify_rvalue(&t.ctx(), &t.expr, rv, &mut b).is_ok()
    };
    if !matched {
        return None;
    }
    // Every parameter must have bound to an argument (an unread parameter cannot be
    // reconstructed) — refuse otherwise.
    let mut args = Vec::with_capacity(t.param_order.len());
    for p in &t.param_order {
        match b.params.get(p) {
            Some(e) => args.push(e.clone()),
            None => return None,
        }
    }
    // Arg hoist-safety. Turning `S = E[params := args]` back into `helper(args)`
    // evaluates each argument ONCE, EAGERLY, before the body, whereas `S` evaluates
    // each parameter occurrence lazily at its position. For the rewrite to be
    // observationally equivalent each bound argument must be hoist-safe, which means
    // more than merely side-effect-free:
    //   * TOTAL — it must not be able to RAISE. A pure-looking `a + b`, `a .. b`,
    //     `-x` or `#t` is `has_side_effects() == false` (the crate only propagates
    //     effects from operands) yet can throw a type/metamethod error. If such an
    //     arg binds to a parameter `E` evaluates only on SOME path (an `IfExpression`
    //     branch, or the right operand of `and`/`or` — the very shapes this pass
    //     targets), eager evaluation would raise an error the inlined original never
    //     raised.
    //   * IDENTITY-STABLE — a `{}` / `{...}` constructor is effect-free but yields a
    //     FRESH reference per evaluation, so a parameter used twice (`p == p`) would
    //     flip from two distinct tables to one shared reference.
    // Literals and non-reference-captured locals are total, identity-stable
    // snapshots. A call/metamethod in this expression may mutate a referenced
    // cell despite there being no syntactic assignment in the expression.
    let hoist = super::hoist(&t.expr, &t.param_order, &args, |a| {
        t.captures.stable(a) && t.arithmetic.as_ref().is_none_or(|safety| safety.stable(a))
    }, |arg| {
        matches!(arg, RValue::Local(local) if current_func
            .and_then(|function| t.upvalues.get(&(function as usize)))
            .is_none_or(|ids| !ids.contains(&local.stable_id())))
    }, &t.leading)?;
    // Cost: the replacement must be a net node saving against the specialised
    // subtree `S` (rejects `f(bigExpr)` non-shrinks). Computed only on a real match.
    let s_nodes = node_count(rv);
    let args_nodes: usize = args.iter().map(node_count).sum();
    let call_nodes = if t.arithmetic.is_some() { 2 } else { 1 };
    if s_nodes < call_nodes + args_nodes + NET_SAVING_FLOOR {
        return None;
    }
    Some((args.into_iter().map(crate::untruncated).collect(), hoist))
}

/// Number of RValue nodes in `rv`. Single post-order recursion via the `Traverse`
/// child accessor (each node visited once → O(n)); a `Closure` exposes no child
/// rvalues, so its body is not counted.
fn node_count(rv: &RValue) -> usize {
    1 + rv.rvalues().iter().map(|c| node_count(c)).sum::<usize>()
}
