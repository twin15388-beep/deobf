//! Semantics-preserving fallback for CFGs whose source-shaped region proof
//! cannot be established.
//!
//! The normal structurer emits source-level conditionals and loops only after
//! proving region ownership and every exit transfer. Irreducible graphs and
//! unproven VM protocols cannot pass that boundary by guessing a jump target.
//!
//! This module is a fail-closed fallback: it translates the *original,
//! post-SSA* CFG into a local state machine.  Every CFG edge becomes an explicit
//! state transition, so no edge is discarded and no source-level goto/label is
//! needed.  Generic-for VM markers are deliberately rejected here until the
//! CFG preserves VM prep-kind and edge-sensitive write metadata.  Treating
//! `FORGPREP` as an identity assignment is not equivalent for tables, `__iter`,
//! `__call`, or unsupported values, and treating `FORGLOOP` as a plain call can
//! get hidden-control exhaustion semantics wrong.  Returning `None` keeps this
//! fallback fail-closed instead of emitting plausible but incorrect Luau.

use ast::{
    Assign, Binary, BinaryOperation, Block, Continue, Global, If, LValue, Literal, Local, LocalRw,
    RValue, RcLocal, Statement, Traverse, Upvalue, While,
};
use cfg::{block::BlockEdge, function::Function};
use itertools::Either;
use petgraph::{stable_graph::NodeIndex, visit::EdgeRef};
use rustc_hash::{FxHashMap, FxHashSet};

/// Purpose of a local synthesized by the certified CFG fallback.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum SyntheticRole {
    ProgramCounter,
    DispatchSignal,
    DispatchExit,
}

#[derive(Clone, Debug)]
pub struct SyntheticLocal {
    pub local: RcLocal,
    pub role: SyntheticRole,
}

/// A fallback block together with identity-based metadata for every synthetic
/// control local it introduced.  Policies can inspect this without relying on
/// generated names such as `controlFlowState`.
#[derive(Debug)]
pub struct CertifiedFallback {
    pub block: Block,
    pub synthetic_locals: Vec<SyntheticLocal>,
}

/// Lower a post-SSA CFG to a valid Luau state machine.
///
/// `None` means that the CFG contains a construct for which this conservative
/// fallback does not yet have a proven lowering.  Callers must retain their
/// existing fail-closed behaviour in that case; this function never emits a
/// partial program.
pub fn lift(function: Function) -> Option<Block> {
    let locals_to_ignore = function
        .parameters
        .iter()
        .cloned()
        .collect::<FxHashSet<_>>();
    lift_with_ignored_locals(function, &locals_to_ignore)
}

/// Build a fallback state machine while preserving the lexical scope of
/// locals that are live across dispatcher iterations.
///
/// A `continue` in the generated dispatcher starts a new iteration of the
/// enclosing `while`.  Lua locals declared inside that loop are consequently
/// re-created (and reset to `nil`) on every transition.  Any value that flows
/// from one CFG state to another must therefore be declared outside the loop.
/// The normal local-declaration pass does not know that our synthetic loop is a
/// dispatcher, so we seed declarations here for exactly those values.  The
/// caller supplies parameters and upvalues in `locals_to_ignore`; declaring one
/// of those would shadow the function's actual inputs and change semantics.
pub fn lift_with_ignored_locals(
    function: Function,
    locals_to_ignore: &FxHashSet<RcLocal>,
) -> Option<Block> {
    lift_certified_with_ignored_locals(function, locals_to_ignore).map(|result| result.block)
}

pub fn lift_certified_with_ignored_locals(
    function: Function,
    locals_to_ignore: &FxHashSet<RcLocal>,
) -> Option<CertifiedFallback> {
    let entry = *function.entry().as_ref()?;
    let nodes = reachable_nodes(&function, entry);
    if nodes.is_empty() {
        return None;
    }

    // The dispatcher only has a proven lowering for the flat, post-SSA CFG
    // statements above.  A prestructured statement with an embedded block is
    // opaque to the CFG edge/liveness analysis below: `If::values_read` and
    // `Traverse` intentionally expose only the condition, while the nested
    // body can contain writes or reference captures.  Lowering such a block
    // as an ordinary state statement can therefore reset a captured local on
    // the next dispatcher iteration.  Reject it until nested-block effects
    // have a dedicated scope-aware analysis.
    if nodes.iter().any(|&node| {
        function.block(node).is_some_and(|block| {
            block.iter().any(statement_has_embedded_block)
        })
    }) {
        return None;
    }

    // Break/continue statements are source-level control transfers whose
    // target is an enclosing loop.  The synthetic dispatcher introduces a
    // different loop, so copying one of these statements into a state would
    // break or continue the dispatcher itself instead of the original loop.
    // Post-SSA CFG input normally represents these transfers as edges; reject
    // any pre-existing marker rather than guessing its ownership.
    if nodes.iter().any(|&node| {
        function.block(node).is_some_and(|block| {
            block.iter().any(|statement| {
                matches!(statement, Statement::Break(_) | Statement::Continue(_))
            })
        })
    }) {
        return None;
    }

    // A GenericForInit/GenericForNext pair is still a low-level VM protocol,
    // not a source-level iterator expression.  The current Function IR does
    // not retain the FORGPREP variant/AUX metadata needed to distinguish the
    // table fast path, `__iter`, `__call`, and callable-generator paths, nor
    // the path-specific result writes on exhaustion.  Refuse every reachable
    // marker until that provenance is available; callers then produce the
    // explicit unsupported-structuring sentinel rather than wrong source.
    if nodes.iter().any(|&node| {
        function
            .block(node)
            .is_some_and(crate::region::block_contains_unlowered_control)
            || function.edges(node).any(|edge| {
                edge.weight()
                    .arguments
                    .iter()
                    .any(|(_, value)| crate::region::rvalue_contains_unlowered_control(value))
            })
    }) {
        return None;
    }

    let states: FxHashMap<NodeIndex, usize> = nodes
        .iter()
        .enumerate()
        .map(|(state, &node)| (node, state))
        .collect();
    let state_local = fresh_synthetic_local(&function, "controlFlowState");

    let mut plans = Vec::with_capacity(nodes.len());
    let mut state_facts = Vec::with_capacity(nodes.len());
    let mut state_successors = Vec::with_capacity(nodes.len());
    for &node in &nodes {
        let statements = function.block(node)?.clone().0;
        let edges = function
            .edges(node)
            .map(|edge| (edge.target(), edge.weight().clone()))
            .collect::<Vec<_>>();
        state_successors.push(edges.iter().map(|(target, _)| *target).collect());
        state_facts.push(analyze_state(&statements, &edges));

        let body = lower_block(statements, &edges, &states, &state_local)?;
        plans.push(body);
    }

    // Build the dispatch ladder backwards so every branch has a structurally
    // valid else block.  Each state body ends in `continue`, `break`, or
    // `return`; the fallback never relies on accidental fall-through.
    let mut dispatch = Block(vec![Statement::Break(ast::Break {}).into()]);
    for (state, body) in plans.into_iter().enumerate().rev() {
        let condition = Binary::new(
            state_local.clone().into(),
            Literal::Number(state as f64).into(),
            BinaryOperation::Equal,
        )
        .into();
        dispatch = Block(vec![If::new(condition, body, dispatch).into()]);
    }

    let entry_state = *states.get(&entry)?;
    let mut root = Block::default();

    // Seed declarations before the synthetic `while`.  Keep ordering stable so
    // generated output remains deterministic regardless of hash iteration
    // order.  Locals that are initialized before every read remain scoped by
    // `LocalDeclarer`, preserving the readable output of the normal pipeline.
    let persistent_locals =
        persistent_locals(&state_facts, &state_successors, &states, locals_to_ignore);
    // A local captured by reference can represent a fresh per-iteration Lua
    // cell.  Hoisting that binding outside the synthetic dispatcher would make
    // closures from different iterations share one cell, changing observable
    // behaviour.  We do not have enough lexical-scope information in a flat
    // post-SSA CFG to split such cells soundly, so reject this one shape rather
    // than emit code with a plausible but incorrect capture lifetime.  By-value
    // captures are snapshots and remain safe to hoist; parameters/upvalues are
    // excluded from `persistent_locals` by the caller.
    if contains_ref_capture(
        &function,
        &nodes,
        &state_facts,
        &state_successors,
        &states,
        &persistent_locals,
        locals_to_ignore,
    ) {
        return None;
    }
    if !persistent_locals.is_empty() {
        let mut declaration = Assign::new(
            persistent_locals.into_iter().map(LValue::Local).collect(),
            Vec::new(),
        );
        declaration.prefix = true;
        root.push(declaration.into());
    }
    root.push(
        Assign::new(vec![LValue::Local(state_local.clone())], vec![
            Literal::Number(entry_state as f64).into(),
        ])
        .into(),
    );
    root.push(While::new(Literal::Boolean(true).into(), dispatch).into());
    Some(CertifiedFallback {
        block: root,
        synthetic_locals: vec![SyntheticLocal {
            local: state_local,
            role: SyntheticRole::ProgramCounter,
        }],
    })
}

fn statement_has_embedded_block(statement: &Statement) -> bool {
    match statement {
        // An empty If is the CFG conditional terminator and is safe: its real
        // branches are represented by BlockEdges.  A non-empty branch is an
        // already-structured subgraph whose effects are not visible to the
        // fallback's flat-state analysis.
        Statement::If(if_statement) => {
            !if_statement.then_block.lock().is_empty()
                || !if_statement.else_block.lock().is_empty()
        }
        // These statements always own an embedded body.  They are not emitted
        // by the post-SSA CFG fallback input and must not be treated as opaque
        // state statements until their nested effects are analyzed.
        Statement::While(_)
        | Statement::Repeat(_)
        | Statement::NumericFor(_)
        | Statement::GenericFor(_) => true,
        _ => false,
    }
}

fn fresh_synthetic_local(function: &Function, base: &str) -> RcLocal {
    let mut used_names = FxHashSet::default();
    let mut seen_closures = FxHashSet::default();
    let mut incomplete_closure = false;

    for local in &function.parameters {
        remember_local_name(local, &mut used_names);
    }
    for (node, block) in function.blocks() {
        remember_names_in_block(
            block,
            &mut used_names,
            &mut seen_closures,
            &mut incomplete_closure,
        );
        for edge in function.edges(node) {
            for (destination, value) in &edge.weight().arguments {
                remember_local_name(destination, &mut used_names);
                remember_globals_in_rvalue(
                    value,
                    &mut used_names,
                    &mut seen_closures,
                    &mut incomplete_closure,
                );
            }
        }
    }

    if incomplete_closure {
        // A child function may still be decompiled on another worker.  Its
        // eventual body can introduce a global whose name is unavailable now;
        // leave the synthetic binding unnamed so the pre-naming AST remains
        // independent of that scheduling race.  The normal naming pass will
        // assign a readable collision-free name once all child bodies exist.
        return RcLocal::default();
    }

    let mut candidate = base.to_string();
    let mut suffix = 0usize;
    while used_names.contains(&candidate) {
        suffix += 1;
        candidate = format!("{base}_{suffix}");
    }
    RcLocal::new(Local::new(Some(candidate)))
}

fn remember_names_in_block(
    block: &Block,
    used_names: &mut FxHashSet<String>,
    seen_closures: &mut FxHashSet<usize>,
    incomplete_closure: &mut bool,
) {
    for statement in block.iter() {
        for local in statement.values() {
            remember_local_name(local, used_names);
        }
        if let Statement::Close(close) = statement {
            // `Close` intentionally has an empty LocalRw summary because it
            // only closes cells, but its locals still occupy source names.
            for local in &close.locals {
                remember_local_name(local, used_names);
            }
        }
        let mut statement_copy = statement.clone();
        let _: Option<()> = statement_copy.traverse_values(&mut |_, value| -> Option<()> {
            match value {
                Either::Left(LValue::Global(global))
                | Either::Right(RValue::Global(global)) => {
                    remember_global_name(global, used_names)
                }
                Either::Right(RValue::Closure(closure)) => {
                    remember_closure_names(
                        closure,
                        used_names,
                        seen_closures,
                        incomplete_closure,
                    )
                }
                _ => {}
            }
            None
        });
        match statement {
            Statement::If(node) => {
                remember_names_in_block(
                    &node.then_block.lock(),
                    used_names,
                    seen_closures,
                    incomplete_closure,
                );
                remember_names_in_block(
                    &node.else_block.lock(),
                    used_names,
                    seen_closures,
                    incomplete_closure,
                );
            }
            Statement::While(node) => {
                remember_names_in_block(
                    &node.block.lock(),
                    used_names,
                    seen_closures,
                    incomplete_closure,
                )
            }
            Statement::Repeat(node) => {
                remember_names_in_block(
                    &node.block.lock(),
                    used_names,
                    seen_closures,
                    incomplete_closure,
                )
            }
            Statement::NumericFor(node) => {
                remember_local_name(&node.counter, used_names);
                remember_names_in_block(
                    &node.block.lock(),
                    used_names,
                    seen_closures,
                    incomplete_closure,
                );
            }
            Statement::GenericFor(node) => {
                for local in &node.res_locals {
                    remember_local_name(local, used_names);
                }
                remember_names_in_block(
                    &node.block.lock(),
                    used_names,
                    seen_closures,
                    incomplete_closure,
                );
            }
            _ => {}
        }
    }
}

fn remember_closure_names(
    closure: &ast::Closure,
    used_names: &mut FxHashSet<String>,
    seen_closures: &mut FxHashSet<usize>,
    incomplete_closure: &mut bool,
) {
    let identity = closure.function.0.as_ptr() as usize;
    if !seen_closures.insert(identity) {
        return;
    }
    let (parameters, body) = {
        let function = closure.function.lock();
        (function.parameters.clone(), function.body.clone())
    };
    for parameter in &parameters {
        remember_local_name(parameter, used_names);
    }
    if body.is_empty() {
        *incomplete_closure = true;
    } else {
        remember_names_in_block(&body, used_names, seen_closures, incomplete_closure);
    }
}

fn remember_local_name(local: &RcLocal, used_names: &mut FxHashSet<String>) {
    if let Some(name) = local.0.0.lock().0.clone() {
        used_names.insert(name);
    }
}

fn remember_global_name(global: &Global, used_names: &mut FxHashSet<String>) {
    if let Ok(name) = std::str::from_utf8(&global.0) {
        used_names.insert(name.to_string());
    }
}

fn remember_globals_in_rvalue(
    value: &RValue,
    used_names: &mut FxHashSet<String>,
    seen_closures: &mut FxHashSet<usize>,
    incomplete_closure: &mut bool,
) {
    if let RValue::Local(local) = value {
        remember_local_name(local, used_names);
    }
    if let RValue::Global(global) = value {
        remember_global_name(global, used_names);
    }
    if let RValue::Closure(closure) = value {
        remember_closure_names(closure, used_names, seen_closures, incomplete_closure);
    }
    value.traverse_rvalues_ref(&mut |nested| {
        match nested {
            RValue::Local(local) => remember_local_name(local, used_names),
            RValue::Global(global) => remember_global_name(global, used_names),
            RValue::Closure(closure) => {
                remember_closure_names(closure, used_names, seen_closures, incomplete_closure)
            }
            _ => {}
        }
    });
}

fn remember_ref_captures_in_rvalue(value: &RValue, captured_ref: &mut FxHashSet<RcLocal>) {
    // `traverse_rvalues` visits nested expressions but deliberately does not
    // call the visitor for the root value, so inspect the root explicitly.
    if let RValue::Closure(closure) = value {
        for upvalue in &closure.upvalues {
            if let Upvalue::Ref(local) = upvalue {
                captured_ref.insert(local.clone());
            }
        }
    }
    let mut remember = |value: &RValue| {
        if let RValue::Closure(closure) = value {
            for upvalue in &closure.upvalues {
                if let Upvalue::Ref(local) = upvalue {
                    captured_ref.insert(local.clone());
                }
            }
        }
    };
    value.traverse_rvalues_ref(&mut remember);
}

fn contains_ref_capture(
    function: &Function,
    nodes: &[NodeIndex],
    facts: &[StateFacts],
    successors: &[Vec<NodeIndex>],
    states: &FxHashMap<NodeIndex, usize>,
    persistent_locals: &[RcLocal],
    locals_to_ignore: &FxHashSet<RcLocal>,
) -> bool {
    if facts.iter().all(|state| state.captured_ref.iter()
        .all(|local| locals_to_ignore.contains(local))) {
        return false;
    }
    // Build the set of local values carried by each outgoing edge.  The
    // destination (`param`) is a write that does not appear in a source
    // statement, while RHS reads can be hidden by a same-state definition in
    // `StateFacts`; both must participate in the ambiguity check below.
    let edge_values = nodes
        .iter()
        .map(|&node| {
            function
                .edges(node)
                .flat_map(|edge| {
                    edge.weight().arguments.iter().flat_map(|(param, value)| {
                        std::iter::once(param).chain(value.values_read().into_iter())
                    })
                })
                .cloned()
                .collect::<FxHashSet<_>>()
        })
        .collect::<Vec<_>>();

    let persistent = persistent_locals.iter().collect::<FxHashSet<_>>();
    let cyclic = std::cell::OnceCell::new();
    let local_states = std::cell::OnceCell::new();
    for (capture_state, state) in facts.iter().enumerate() {
        for local in &state.captured_ref {
            // Parameters and already-linked upvalues have function scope, so
            // their cells are not recreated by the synthetic dispatcher.
            if locals_to_ignore.contains(local) {
                continue;
            }
            // Hoisting a reference capture is only safe when its cell is known
            // to live across all dispatcher iterations.  `persistent_locals`
            // is intentionally conservative, but it can miss a capture that
            // is followed solely by a write (the write kills normal liveness).
            // Such a shape is still ambiguous after CLOSEUPVALS was discarded,
            // so fail closed regardless of whether liveness selected it.
            if persistent.contains(local)
                || cyclic.get_or_init(|| cyclic_states(successors, states))[capture_state]
                || edge_values
                    .get(capture_state)
                    .is_some_and(|values| values.contains(local))
                || local_states.get_or_init(|| {
                    let mut index = FxHashMap::default();
                    for (state, facts) in facts.iter().enumerate() {
                        for local in facts.captured_ref.iter().chain(&facts.use_before_def)
                            .chain(&facts.defs).chain(&edge_values[state]) {
                            index.entry(local).and_modify(|owner| {
                                if *owner != Some(state) { *owner = None; }
                            }).or_insert(Some(state));
                        }
                    }
                    index
                }).get(local) == Some(&None)
            {
                return true;
            }
        }
    }
    false
}

/// Compute cyclic-state membership once, rather than searching every
/// captured state's reachable suffix. Two iterative DFS passes compute SCCs;
/// a singleton is cyclic exactly when it has a self edge. Unknown successors
/// are ignored, matching the dispatcher-state reachability contract.
fn cyclic_states(
    successors: &[Vec<NodeIndex>],
    states: &FxHashMap<NodeIndex, usize>,
) -> Vec<bool> {
    let edges: Vec<Vec<usize>> = successors.iter().map(|targets| {
        targets.iter().filter_map(|node| states.get(node).copied()).collect()
    }).collect();
    let mut predecessors = vec![Vec::new(); edges.len()];
    for (source, targets) in edges.iter().enumerate() {
        for &target in targets { predecessors[target].push(source); }
    }
    let mut visited = vec![false; edges.len()];
    let mut order = Vec::with_capacity(edges.len());
    let mut walk = Vec::new();
    for start in 0..edges.len() {
        walk.push((start, false));
        while let Some((node, exiting)) = walk.pop() {
            if exiting {
                order.push(node);
            } else if !visited[node] {
                visited[node] = true;
                walk.push((node, true));
                walk.extend(edges[node].iter().filter(|&&target| !visited[target])
                    .map(|&target| (target, false)));
            }
        }
    }
    visited.fill(false);
    let mut cyclic = vec![false; edges.len()];
    let mut work = Vec::new();
    let mut component = Vec::new();
    for start in order.into_iter().rev() {
        if visited[start] { continue; }
        component.clear();
        work.push(start);
        while let Some(node) = work.pop() {
            if std::mem::replace(&mut visited[node], true) { continue; }
            component.push(node);
            work.extend(predecessors[node].iter().copied());
        }
        if component.len() > 1 || edges[start].contains(&start) {
            for &node in &component { cyclic[node] = true; }
        }
    }
    cyclic
}

fn reachable_nodes(function: &Function, entry: NodeIndex) -> Vec<NodeIndex> {
    let mut seen = FxHashSet::default();
    let mut stack = vec![entry];
    while let Some(node) = stack.pop() {
        if !seen.insert(node) {
            continue;
        }
        stack.extend(function.successor_blocks(node));
    }

    // NodeIndex order is stable for a given CFG and avoids making generated
    // source depend on traversal details of petgraph's adjacency storage.
    let mut nodes = seen.into_iter().collect::<Vec<_>>();
    nodes.sort_by_key(|node| node.index());
    nodes
}

#[derive(Default)]
struct StateFacts {
    /// Locals read before their first write in this state.  The set is
    /// deliberately conservative for complex expressions: `values_read` is
    /// evaluated before the statement's writes, matching parallel assignment
    /// semantics.
    use_before_def: FxHashSet<RcLocal>,
    /// Locals written by the state body.  Edge-copy destinations are not
    /// considered definite here: a conditional predecessor may provide a
    /// value on only one path, so treating them as source-state definitions
    /// would unsafely suppress a required hoist.
    defs: FxHashSet<RcLocal>,
    /// Locals captured by-reference by closures constructed in this state.
    /// Value captures (`Upvalue::Copy`) snapshot their input and do not impose
    /// a cell-lifetime constraint on the dispatcher.
    captured_ref: FxHashSet<RcLocal>,
}

fn analyze_state(statements: &[Statement], edges: &[(NodeIndex, BlockEdge)]) -> StateFacts {
    let mut facts = StateFacts::default();
    for statement in statements {
        for local in statement.values_read() {
            if !facts.defs.contains(local) {
                facts.use_before_def.insert(local.clone());
            }
        }
        facts
            .defs
            .extend(statement.values_written().into_iter().cloned());

        // Traverse all expression positions (including index l-values) while
        // stopping at the child function body. The read-only visitor retains
        // the original AST while collecting captures without a speculative copy.
        statement.traverse_rvalues_ref(&mut |value| {
            if let RValue::Closure(closure) = value {
                for upvalue in &closure.upvalues {
                    if let Upvalue::Ref(local) = upvalue {
                        facts.captured_ref.insert(local.clone());
                    }
                }
            }
        });
    }

    // Edge copies are parallel and execute after the source block.  Reads on
    // their RHS therefore observe the source state's definitions.  Their
    // destinations are intentionally not added to `defs`; with multiple
    // conditional predecessors they are not definitely initialized at target
    // entry, and over-hoisting is safer than allowing a reset local to leak.
    for (_, edge) in edges {
        for (_, value) in &edge.arguments {
            // Closures can be materialized as edge arguments, not only in a
            // source statement.  Their reference captures still need the
            // same dispatcher-cell lifetime proof as statement closures.
            remember_ref_captures_in_rvalue(value, &mut facts.captured_ref);
            for local in value.values_read() {
                if !facts.defs.contains(local) {
                    facts.use_before_def.insert(local.clone());
                }
            }
        }
    }
    facts
}

fn persistent_locals(
    facts: &[StateFacts],
    successors: &[Vec<NodeIndex>],
    states: &FxHashMap<NodeIndex, usize>,
    locals_to_ignore: &FxHashSet<RcLocal>,
) -> Vec<RcLocal> {
    let mut live_in = facts
        .iter()
        .map(|state| state.use_before_def.clone())
        .collect::<Vec<_>>();

    let mut predecessors = vec![Vec::new(); facts.len()];
    for (source, targets) in successors.iter().enumerate() {
        for target in targets {
            if let Some(&state) = states.get(target) {
                predecessors[state].push(source);
            }
        }
    }
    let mut work = std::collections::VecDeque::from_iter((0..facts.len()).rev());
    let mut queued = vec![true; facts.len()];
    let mut live_out = FxHashSet::default();
    while let Some(state) = work.pop_front() {
        queued[state] = false;
        live_out.clear();
        for target in &successors[state] {
            if let Some(&target_state) = states.get(target) {
                live_out.extend(live_in[target_state].iter().cloned());
            }
        }
        let before = live_in[state].len();
        // This transfer is monotone: uses were seeded above, and facts never
        // change. Revisit only predecessors of a state that gains a live local.
        live_in[state].extend(live_out.drain()
            .filter(|local| !facts[state].defs.contains(local)));
        if live_in[state].len() != before {
            for &predecessor in &predecessors[state] {
                if !std::mem::replace(&mut queued[predecessor], true) {
                    work.push_back(predecessor);
                }
            }
        }
    }

    let mut result = live_in
        .into_iter()
        .flatten()
        .filter(|local| !locals_to_ignore.contains(local))
        .collect::<FxHashSet<_>>()
        .into_iter()
        .collect::<Vec<_>>();
    result.sort();
    result
}

#[cfg(test)]
fn contains_ref_capture_reference(
    function: &Function,
    nodes: &[NodeIndex],
    facts: &[StateFacts],
    successors: &[Vec<NodeIndex>],
    states: &FxHashMap<NodeIndex, usize>,
    persistent_locals: &[RcLocal],
    locals_to_ignore: &FxHashSet<RcLocal>,
) -> bool {
    // Build the set of local values carried by each outgoing edge.  The
    // destination (`param`) is a write that does not appear in a source
    // statement, while RHS reads can be hidden by a same-state definition in
    // `StateFacts`; both must participate in the ambiguity check below.
    let edge_values = nodes
        .iter()
        .map(|&node| {
            function
                .edges(node)
                .flat_map(|edge| {
                    edge.weight().arguments.iter().flat_map(|(param, value)| {
                        std::iter::once(param).chain(value.values_read().into_iter())
                    })
                })
                .cloned()
                .collect::<FxHashSet<_>>()
        })
        .collect::<Vec<_>>();

    let persistent = persistent_locals.iter().collect::<FxHashSet<_>>();
    for (capture_state, state) in facts.iter().enumerate() {
        for local in &state.captured_ref {
            // Parameters and already-linked upvalues have function scope, so
            // their cells are not recreated by the synthetic dispatcher.
            if locals_to_ignore.contains(local) {
                continue;
            }
            // Hoisting a reference capture is only safe when its cell is known
            // to live across all dispatcher iterations.  `persistent_locals`
            // is intentionally conservative, but it can miss a capture that
            // is followed solely by a write (the write kills normal liveness).
            // Such a shape is still ambiguous after CLOSEUPVALS was discarded,
            // so fail closed regardless of whether liveness selected it.
            if persistent.contains(local)
                || state_is_cyclic_reference(capture_state, successors, states)
                || edge_values
                    .get(capture_state)
                    .is_some_and(|values| values.contains(local))
                || facts.iter().enumerate().any(|(other_state, other)| {
                    other_state != capture_state
                        && (other.captured_ref.contains(local)
                            || other.use_before_def.contains(local)
                            || other.defs.contains(local)
                            || edge_values
                                .get(other_state)
                                .is_some_and(|values| values.contains(local)))
                })
            {
                return true;
            }
        }
    }
    false
}

/// Return whether re-entering a dispatcher state is possible through one of
/// its outgoing CFG paths.  A reference capture in such a state would create
/// a fresh Lua cell on every dispatcher iteration; without preserved
/// `CLOSEUPVALS` scope metadata the fallback cannot prove that this is the
/// intended lifetime, so the caller must reject it.
#[cfg(test)]
fn state_is_cyclic_reference(
    state: usize,
    successors: &[Vec<NodeIndex>],
    states: &FxHashMap<NodeIndex, usize>,
) -> bool {
    let mut pending = successors
        .get(state)
        .into_iter()
        .flatten()
        .filter_map(|node| states.get(node).copied())
        .collect::<Vec<_>>();
    let mut seen = FxHashSet::default();
    while let Some(candidate) = pending.pop() {
        if candidate == state {
            return true;
        }
        if !seen.insert(candidate) {
            continue;
        }
        pending.extend(
            successors
                .get(candidate)
                .into_iter()
                .flatten()
                .filter_map(|node| states.get(node).copied()),
        );
    }
    false
}

#[cfg(test)]
fn persistent_locals_reference(
    facts: &[StateFacts],
    successors: &[Vec<NodeIndex>],
    states: &FxHashMap<NodeIndex, usize>,
    locals_to_ignore: &FxHashSet<RcLocal>,
) -> Vec<RcLocal> {
    let mut live_in = facts
        .iter()
        .map(|state| state.use_before_def.clone())
        .collect::<Vec<_>>();

    // The graph is finite and each update only adds locals to a set, so this
    // monotone fixed point terminates after at most |states|*|locals| inserts.
    loop {
        let mut changed = false;
        for state in (0..facts.len()).rev() {
            let mut live_out = FxHashSet::default();
            for target in &successors[state] {
                let Some(&target_state) = states.get(target) else {
                    continue;
                };
                live_out.extend(live_in[target_state].iter().cloned());
            }

            let mut next = facts[state].use_before_def.clone();
            next.extend(
                live_out
                    .into_iter()
                    .filter(|local| !facts[state].defs.contains(local)),
            );
            if next != live_in[state] {
                live_in[state] = next;
                changed = true;
            }
        }
        if !changed {
            break;
        }
    }

    let mut result = live_in
        .into_iter()
        .flatten()
        .filter(|local| !locals_to_ignore.contains(local))
        .collect::<FxHashSet<_>>()
        .into_iter()
        .collect::<Vec<_>>();
    result.sort();
    result
}

fn lower_block(
    mut statements: Vec<Statement>,
    edges: &[(NodeIndex, BlockEdge)],
    states: &FxHashMap<NodeIndex, usize>,
    state_local: &RcLocal,
) -> Option<Block> {
    // The CFG lifter represents a conditional jump as an empty If terminator;
    // its real branches live on the two outgoing BlockEdges.  Refuse to
    // reinterpret a non-empty If here because doing so could execute a nested
    // branch twice.
    if matches!(statements.last(), Some(Statement::If(_))) {
        if edges.len() != 2 {
            return None;
        }
        let condition = {
            let statement = statements.pop()?.into_if().ok()?;
            if !statement.then_block.lock().is_empty() || !statement.else_block.lock().is_empty() {
                return None;
            }
            statement.condition
        };
        let then_edge = edge_of_type(edges, cfg::block::BranchType::Then)?;
        let else_edge = edge_of_type(edges, cfg::block::BranchType::Else)?;
        statements.push(
            If::new(
                condition,
                transition(then_edge, states, state_local)?,
                transition(else_edge, states, state_local)?,
            )
            .into(),
        );
        return Some(statements.into());
    }

    let mut lowered = Vec::with_capacity(statements.len() + 2);
    for statement in statements {
        match statement {
            // Never print low-level protocol markers into source.  The early
            // reachable-node guard normally handles these; retaining the
            // match here makes the helper fail closed even if it is reused
            // independently in the future.
            Statement::GenericForInit(_)
            | Statement::GenericForNext(_)
            | Statement::NumForInit(_)
            | Statement::NumForNext(_)
            | Statement::Goto(_)
            | Statement::Label(_) => return None,
            other => lowered.push(other),
        }
    }

    match edges {
        [] => {
            if !matches!(lowered.last(), Some(Statement::Return(_))) {
                lowered.push(Statement::Break(ast::Break {}).into());
            }
        }
        [edge] if edge.1.branch_type == cfg::block::BranchType::Unconditional => {
            lowered.extend(transition(edge, states, state_local)?.0)
        }
        _ => return None,
    }
    Some(lowered.into())
}

fn edge_of_type(
    edges: &[(NodeIndex, BlockEdge)],
    kind: cfg::block::BranchType,
) -> Option<&(NodeIndex, BlockEdge)> {
    edges.iter().find(|(_, edge)| edge.branch_type == kind)
}

fn transition(
    edge: &(NodeIndex, BlockEdge),
    states: &FxHashMap<NodeIndex, usize>,
    state_local: &RcLocal,
) -> Option<Block> {
    let (target, edge) = edge;
    let state = *states.get(target)?;
    let mut body = Block::default();

    if !edge.arguments.is_empty() {
        let mut assign = Assign::new(
            edge.arguments
                .iter()
                .map(|(local, _)| LValue::Local(local.clone()))
                .collect(),
            edge.arguments
                .iter()
                .map(|(_, value)| value.clone())
                .collect(),
        );
        assign.parallel = true;
        body.push(assign.into());
    }
    body.push(
        Assign::new(vec![LValue::Local(state_local.clone())], vec![
            Literal::Number(state as f64).into(),
        ])
        .into(),
    );
    body.push(Continue {}.into());
    Some(body)
}

#[cfg(test)]
mod tests {
    use super::*;
    use ast::{
        Call, Closure, Function as AstFunction, GenericForInit, GenericForNext, If,
        NumForNext, Upvalue,
    };
    use cfg::block::BlockEdge;
    use parking_lot::Mutex;
    use triomphe::Arc;

    fn local(name: &str) -> RcLocal {
        RcLocal::new(Local::new(Some(name.to_string())))
    }

    fn edge(
        function: &mut Function,
        from: NodeIndex,
        to: NodeIndex,
        branch_type: cfg::block::BranchType,
    ) {
        function
            .graph_mut()
            .add_edge(from, to, BlockEdge::new(branch_type));
    }

    #[test]
    fn indexed_fallback_analyses_match_reference_on_randomized_graphs() {
        for seed in 1..=384u64 {
            let mut random_state = seed;
            let mut random = |limit: usize| {
                random_state = random_state.wrapping_mul(6364136223846793005)
                    .wrapping_add(1442695040888963407);
                ((random_state >> 32) as usize) % limit
            };
            let mut function = Function::new(0);
            let nodes: Vec<_> = (0..2 + random(13)).map(|_| function.new_block()).collect();
            function.set_entry(nodes[0]);
            let states = nodes.iter().copied().enumerate().map(|(index, node)| (node, index)).collect();
            let locals: Vec<_> = (0..8).map(|_| RcLocal::default()).collect();
            let mut facts: Vec<_> = nodes.iter().map(|_| StateFacts::default()).collect();
            let mut successors = vec![Vec::new(); nodes.len()];
            for (index, &node) in nodes.iter().enumerate() {
                for local in &locals {
                    if random(4) == 0 { facts[index].use_before_def.insert(local.clone()); }
                    if random(4) == 0 { facts[index].defs.insert(local.clone()); }
                    if random(5) == 0 { facts[index].captured_ref.insert(local.clone()); }
                }
                for _ in 0..random(4) {
                    let target = nodes[random(nodes.len())];
                    successors[index].push(target);
                    let mut edge = BlockEdge::default();
                    if random(3) == 0 {
                        edge.arguments.push((locals[random(locals.len())].clone(),
                            locals[random(locals.len())].clone().into()));
                    }
                    function.graph_mut().add_edge(node, target, edge);
                }
            }
            let ignored = locals.iter().filter(|_| random(4) == 0).cloned().collect();
            let result = persistent_locals(&facts, &successors, &states, &ignored);
            assert_eq!(result, persistent_locals_reference(&facts, &successors, &states, &ignored),
                "persistent seed={seed}");
            let cyclic = cyclic_states(&successors, &states);
            for (state, &result) in cyclic.iter().enumerate() {
                assert_eq!(result, state_is_cyclic_reference(state, &successors, &states),
                    "cyclic seed={seed}, state={state}");
            }
            // Also test the rejection census without a liveness result so
            // persistent cells cannot hide differences in the remaining proof.
            for persistent in [result.as_slice(), &[]] {
                assert_eq!(contains_ref_capture(&function, &nodes, &facts, &successors,
                    &states, persistent, &ignored),
                    contains_ref_capture_reference(&function, &nodes, &facts, &successors,
                        &states, persistent, &ignored), "capture seed={seed}");
            }
        }
    }

    #[test]
    fn deep_fallback_cycle_analysis_is_iterative_and_marks_only_cycle_members() {
        let nodes: Vec<_> = (0..20_000).map(NodeIndex::new).collect();
        let states = nodes.iter().copied().enumerate().map(|(index, node)| (node, index)).collect();
        let mut successors: Vec<_> = (0..nodes.len()).map(|index| {
            nodes.get(index + 1).copied().into_iter().collect()
        }).collect();
        successors[nodes.len() - 1] = vec![nodes[nodes.len() / 2]];
        let cyclic = cyclic_states(&successors, &states);
        assert!(cyclic[..nodes.len() / 2].iter().all(|&value| !value));
        assert!(cyclic[nodes.len() / 2..].iter().all(|&value| value));
    }

    #[test]
    fn rejects_generic_for_without_vm_protocol_metadata() {
        let mut function = Function::new(0);
        let entry = function.new_block();
        let next = function.new_block();
        let body = function.new_block();
        let exit = function.new_block();
        function.set_entry(entry);

        let generator = local("generator");
        let state = local("state");
        let control = local("control");
        let result = local("result");

        function
            .block_mut(entry)
            .unwrap()
            .push(GenericForInit::new(generator.clone(), state.clone(), control.clone()).into());
        function.block_mut(next).unwrap().push(
            GenericForNext::new(
                vec![result.clone()],
                generator.clone().into(),
                state.clone(),
                control.clone(),
            )
            .into(),
        );
        function
            .block_mut(exit)
            .unwrap()
            .push(ast::Return::new(Vec::new()).into());
        edge(
            &mut function,
            entry,
            next,
            cfg::block::BranchType::Unconditional,
        );
        edge(&mut function, next, body, cfg::block::BranchType::Then);
        edge(&mut function, next, exit, cfg::block::BranchType::Else);
        edge(
            &mut function,
            body,
            next,
            cfg::block::BranchType::Unconditional,
        );

        // The fallback must not pretend that a tuple assignment implements
        // Luau's FORGPREP/FORGLOOP protocol.  Without prep-kind/AUX metadata,
        // emitting a callable iterator would be wrong for plain tables,
        // __iter/__call values, and path-specific exhaustion writes.
        assert!(lift(function).is_none());
    }

    #[test]
    fn reports_synthetic_control_by_local_identity() {
        let mut function = Function::new(0);
        let entry = function.new_block();
        function.set_entry(entry);
        function
            .block_mut(entry)
            .unwrap()
            .push(ast::Return::new(Vec::new()).into());

        let fallback = lift_certified_with_ignored_locals(function, &FxHashSet::default()).unwrap();
        assert_eq!(fallback.synthetic_locals.len(), 1);
        assert_eq!(
            fallback.synthetic_locals[0].role,
            SyntheticRole::ProgramCounter
        );
        let rendered = fallback.block.to_string();
        assert!(rendered.contains("while true do"), "{rendered}");
    }

    #[test]
    fn gives_synthetic_control_a_fresh_source_name() {
        let mut function = Function::new(0);
        let entry = function.new_block();
        function.set_entry(entry);

        let user_local = local("controlFlowState");
        function.block_mut(entry).unwrap().push(
            Assign::new(
                vec![LValue::Local(user_local.clone())],
                vec![Literal::Number(7.0).into()],
            )
            .into(),
        );
        function
            .block_mut(entry)
            .unwrap()
            .push(ast::Return::new(vec![user_local.into()]).into());

        let fallback =
            lift_certified_with_ignored_locals(function, &FxHashSet::default()).unwrap();
        let synthetic = &fallback.synthetic_locals[0].local;
        assert_eq!(synthetic.to_string(), "controlFlowState_1");
        assert_ne!(synthetic.to_string(), "controlFlowState");
        assert!(fallback.block.to_string().contains("controlFlowState_1"));
    }

    #[test]
    fn avoids_synthetic_control_name_used_by_a_global() {
        let mut function = Function::new(0);
        let entry = function.new_block();
        function.set_entry(entry);
        function
            .block_mut(entry)
            .unwrap()
            .push(ast::Return::new(vec![Global::from("controlFlowState").into()]).into());

        let fallback =
            lift_certified_with_ignored_locals(function, &FxHashSet::default()).unwrap();
        assert_eq!(fallback.synthetic_locals[0].local.to_string(), "controlFlowState_1");
        assert!(fallback.block.to_string().contains("controlFlowState_1"));
        assert!(fallback.block.to_string().contains("return controlFlowState"));
    }

    #[test]
    fn avoids_synthetic_control_name_used_by_a_closure_global() {
        let mut function = Function::new(0);
        let entry = function.new_block();
        function.set_entry(entry);

        let closure_function = Arc::new(Mutex::new(AstFunction {
            body: Block(vec![
                ast::Return::new(vec![Global::from("controlFlowState").into()]).into(),
            ]),
            ..AstFunction::default()
        }));
        let callback = local("callback");
        let closure = Closure {
            node_origin: Default::default(),
            function: by_address::ByAddress(closure_function),
            upvalues: Vec::new(),
        };
        function.block_mut(entry).unwrap().push(
            Assign::new(vec![LValue::Local(callback)], vec![RValue::Closure(closure)]).into(),
        );

        let fallback =
            lift_certified_with_ignored_locals(function, &FxHashSet::default()).unwrap();
        assert_eq!(fallback.synthetic_locals[0].local.to_string(), "controlFlowState_1");
        assert!(fallback.block.to_string().contains("controlFlowState_1"));
    }

    #[test]
    fn avoids_synthetic_control_name_used_by_a_nested_closure_global() {
        let mut function = Function::new(0);
        let entry = function.new_block();
        function.set_entry(entry);

        let closure_function = Arc::new(Mutex::new(AstFunction {
            body: Block(vec![
                If::new(
                    Global::from("ready").into(),
                    Block(vec![
                        ast::Return::new(vec![Global::from("controlFlowState").into()]).into(),
                    ]),
                    Block::default(),
                )
                .into(),
            ]),
            ..AstFunction::default()
        }));
        let callback = local("callback");
        let closure = Closure {
            node_origin: Default::default(),
            function: by_address::ByAddress(closure_function),
            upvalues: Vec::new(),
        };
        function.block_mut(entry).unwrap().push(
            Assign::new(vec![LValue::Local(callback)], vec![RValue::Closure(closure)]).into(),
        );

        let fallback =
            lift_certified_with_ignored_locals(function, &FxHashSet::default()).unwrap();
        assert_eq!(fallback.synthetic_locals[0].local.to_string(), "controlFlowState_1");
        assert!(fallback.block.to_string().contains("controlFlowState_1"));
    }

    #[test]
    fn avoids_synthetic_control_name_used_by_an_edge_closure_global() {
        let mut function = Function::new(0);
        let entry = function.new_block();
        let target = function.new_block();
        function.set_entry(entry);

        let closure_function = Arc::new(Mutex::new(AstFunction {
            body: Block(vec![
                ast::Return::new(vec![Global::from("controlFlowState").into()]).into(),
            ]),
            ..AstFunction::default()
        }));
        let callback = local("callback");
        let closure = Closure {
            node_origin: Default::default(),
            function: by_address::ByAddress(closure_function),
            upvalues: Vec::new(),
        };
        function
            .block_mut(target)
            .unwrap()
            .push(ast::Return::default().into());
        function.graph_mut().add_edge(
            entry,
            target,
            BlockEdge {
                branch_type: cfg::block::BranchType::Unconditional,
                arguments: vec![(callback, RValue::Closure(closure))],
            },
        );

        let fallback =
            lift_certified_with_ignored_locals(function, &FxHashSet::default()).unwrap();
        assert_eq!(fallback.synthetic_locals[0].local.to_string(), "controlFlowState_1");
        assert!(fallback.block.to_string().contains("controlFlowState_1"));
    }

    #[test]
    fn avoids_synthetic_control_name_used_by_an_edge_local() {
        let mut function = Function::new(0);
        let entry = function.new_block();
        let target = function.new_block();
        function.set_entry(entry);

        let source = local("controlFlowState");
        let sink = local("sink");
        function
            .block_mut(target)
            .unwrap()
            .push(ast::Return::new(vec![sink.clone().into()]).into());
        function.graph_mut().add_edge(
            entry,
            target,
            BlockEdge {
                branch_type: cfg::block::BranchType::Unconditional,
                arguments: vec![(sink, RValue::Local(source))],
            },
        );

        let fallback =
            lift_certified_with_ignored_locals(function, &FxHashSet::default()).unwrap();
        assert_eq!(fallback.synthetic_locals[0].local.to_string(), "controlFlowState_1");
        assert!(fallback.block.to_string().contains("sink = controlFlowState"));
    }

    #[test]
    fn avoids_synthetic_control_name_used_by_close_local() {
        let mut function = Function::new(0);
        let entry = function.new_block();
        function.set_entry(entry);
        let close_local = local("controlFlowState");
        function.block_mut(entry).unwrap().extend([
            Statement::Close(ast::Close {
                locals: vec![close_local],
            })
            .into(),
            ast::Return::default().into(),
        ]);

        let fallback =
            lift_certified_with_ignored_locals(function, &FxHashSet::default()).unwrap();
        assert_eq!(fallback.synthetic_locals[0].local.to_string(), "controlFlowState_1");
        assert!(fallback.block.to_string().contains("__close_uv(controlFlowState)"));
    }

    #[test]
    fn leaves_control_name_unnamed_when_a_closure_body_is_not_ready() {
        let mut function = Function::new(0);
        let entry = function.new_block();
        function.set_entry(entry);

        let child = Arc::new(Mutex::new(AstFunction::default()));
        let callback = local("callback");
        let closure = Closure {
            node_origin: Default::default(),
            function: by_address::ByAddress(child.clone()),
            upvalues: Vec::new(),
        };
        function.block_mut(entry).unwrap().push(
            Assign::new(vec![LValue::Local(callback)], vec![RValue::Closure(closure)]).into(),
        );

        let fallback =
            lift_certified_with_ignored_locals(function, &FxHashSet::default()).unwrap();
        let synthetic_name = fallback.synthetic_locals[0].local.to_string();
        assert!(
            synthetic_name.starts_with("UNNAMED_"),
            "an incomplete child must not influence the synthetic name: {synthetic_name}"
        );

        // Simulate the child worker filling its AST after the parent fallback
        // has already been built.  The pre-naming fallback remains collision
        // free because its control local has no user-visible spelling.
        child.lock().body.push(
            ast::Return::new(vec![Global::from("controlFlowState").into()]).into(),
        );
        assert_ne!(synthetic_name, "controlFlowState");
        assert!(fallback.block.to_string().contains("controlFlowState"));
    }

    #[test]
    fn predeclares_values_crossing_dispatcher_iterations() {
        let mut function = Function::new(0);
        let entry = function.new_block();
        let use_state = function.new_block();
        function.set_entry(entry);

        let value = local("value");
        let sink = local("sink");
        function.block_mut(entry).unwrap().push(
            Assign::new(vec![LValue::Local(value.clone())], vec![
                Literal::Number(1.0).into(),
            ])
            .into(),
        );
        function
            .block_mut(use_state)
            .unwrap()
            .push(Assign::new(vec![LValue::Local(sink)], vec![value.clone().into()]).into());
        edge(
            &mut function,
            entry,
            use_state,
            cfg::block::BranchType::Unconditional,
        );

        let output = lift(function).unwrap().to_string();
        let declaration = output.find("local value").expect("missing declaration");
        let dispatcher = output.find("while true do").expect("missing dispatcher");
        assert!(declaration < dispatcher, "{output}");
        assert!(!output[dispatcher..].contains("local value"), "{output}");
    }

    #[test]
    fn predeclares_values_reused_by_a_self_loop() {
        let mut function = Function::new(0);
        let loop_node = function.new_block();
        function.set_entry(loop_node);

        let value = local("value");
        function.block_mut(loop_node).unwrap().push(
            Assign::new(vec![LValue::Local(value.clone())], vec![
                Binary::new(
                    value.clone().into(),
                    Literal::Number(1.0).into(),
                    BinaryOperation::Add,
                )
                .into(),
            ])
            .into(),
        );
        edge(
            &mut function,
            loop_node,
            loop_node,
            cfg::block::BranchType::Unconditional,
        );

        let output = lift(function).unwrap().to_string();
        let declaration = output.find("local value").expect("missing declaration");
        let dispatcher = output.find("while true do").expect("missing dispatcher");
        assert!(declaration < dispatcher, "{output}");
        assert!(!output[dispatcher..].contains("local value"), "{output}");
    }

    #[test]
    fn predeclares_values_across_a_multi_state_cycle() {
        let mut function = Function::new(0);
        let producer = function.new_block();
        let consumer = function.new_block();
        function.set_entry(producer);

        let value = local("value");
        let sink = local("sink");
        function.block_mut(producer).unwrap().push(
            Assign::new(vec![LValue::Local(value.clone())], vec![
                Literal::Number(1.0).into(),
            ])
            .into(),
        );
        function
            .block_mut(consumer)
            .unwrap()
            .push(Assign::new(vec![LValue::Local(sink)], vec![value.clone().into()]).into());
        edge(
            &mut function,
            producer,
            consumer,
            cfg::block::BranchType::Unconditional,
        );
        edge(
            &mut function,
            consumer,
            producer,
            cfg::block::BranchType::Unconditional,
        );

        let output = lift(function).unwrap().to_string();
        let declaration = output.find("local value").expect("missing declaration");
        let dispatcher = output.find("while true do").expect("missing dispatcher");
        assert!(declaration < dispatcher, "{output}");
        assert!(!output[dispatcher..].contains("local value"), "{output}");
    }

    #[test]
    fn does_not_shadow_ignored_function_inputs() {
        let mut function = Function::new(0);
        let entry = function.new_block();
        let use_state = function.new_block();
        function.set_entry(entry);

        let parameter = local("parameter");
        function.parameters.push(parameter.clone());
        function.block_mut(entry).unwrap().push(
            Assign::new(vec![LValue::Local(local("unused"))], vec![
                Literal::Number(1.0).into(),
            ])
            .into(),
        );
        function
            .block_mut(use_state)
            .unwrap()
            .push(ast::Return::new(vec![parameter.clone().into()]).into());
        edge(
            &mut function,
            entry,
            use_state,
            cfg::block::BranchType::Unconditional,
        );

        let mut ignored = FxHashSet::default();
        ignored.insert(parameter.clone());
        let output = lift_with_ignored_locals(function, &ignored).unwrap();
        assert!(
            !matches!(
                output.first(),
                Some(Statement::Assign(assign))
                    if assign.prefix
                        && assign.left.iter().any(|left| {
                            matches!(left, LValue::Local(local) if local == &parameter)
                        })
            ),
            "function parameters must not be redeclared:\n{output}"
        );
    }

    #[test]
    fn refuses_unlowered_numeric_loop_markers() {
        let mut function = Function::new(0);
        let entry = function.new_block();
        function.set_entry(entry);
        let counter = local("counter");
        function.block_mut(entry).unwrap().push(
            NumForNext::new(
                counter,
                Literal::Number(1.0).into(),
                Literal::Number(1.0).into(),
            )
            .into(),
        );
        assert!(lift(function).is_none());
    }

    #[test]
    fn refuses_loop_markers_hidden_in_edge_closure() {
        let mut function = Function::new(0);
        let entry = function.new_block();
        let exit = function.new_block();
        function.set_entry(entry);

        let callback = local("callback");
        let generator = local("generator");
        let state = local("state");
        let control = local("control");
        let value = local("value");
        let mut for_init = GenericForInit::new(generator.clone(), state.clone(), control.clone());
        for_init.0.right = vec![RValue::Global(Global::from("items"))];
        let child = AstFunction {
            body: Block::from(vec![
                for_init.into(),
                GenericForNext::new(vec![value], generator.into(), state, control).into(),
            ]),
            ..Default::default()
        };
        let closure = RValue::Closure(Closure {
            node_origin: Default::default(),
            function: by_address::ByAddress(Arc::new(Mutex::new(child))),
            upvalues: Vec::new(),
        });
        function
            .block_mut(exit)
            .unwrap()
            .push(ast::Return::new(Vec::new()).into());
        function.graph_mut().add_edge(
            entry,
            exit,
            BlockEdge {
                branch_type: cfg::block::BranchType::Unconditional,
                arguments: vec![(callback, closure)],
            },
        );

        assert!(
            lift_certified_with_ignored_locals(function, &FxHashSet::default()).is_none(),
            "fallback must reject markers nested in edge closures"
        );
    }

    #[test]
    fn refuses_prestructured_nested_blocks_until_scope_analysis() {
        let mut function = Function::new(0);
        let entry = function.new_block();
        function.set_entry(entry);

        let captured = local("captured");
        let callback = local("callback");
        let closure = Closure {
            node_origin: Default::default(),
            function: by_address::ByAddress(Arc::new(Mutex::new(AstFunction::default()))),
            upvalues: vec![Upvalue::Ref(captured)],
        };
        let nested = If::new(
            Literal::Boolean(true).into(),
            Block(vec![
                Assign::new(vec![LValue::Local(callback)], vec![RValue::Closure(closure)])
                    .into(),
            ]),
            Block::default(),
        );
        function.block_mut(entry).unwrap().push(nested.into());

        // `If` bodies are not visible to the flat CFG liveness/capture pass.
        // Keep the fallback certified by refusing this prestructured shape
        // until nested-block scope effects have a dedicated analysis.
        assert!(lift(function).is_none());
    }

    #[test]
    fn refuses_ref_capture_that_would_cross_dispatcher_iterations() {
        let mut function = Function::new(0);
        let capture = function.new_block();
        let write = function.new_block();
        function.set_entry(capture);

        let captured = local("captured");
        let callback = local("callback");
        let closure = Closure {
            node_origin: Default::default(),
            function: by_address::ByAddress(Arc::new(Mutex::new(AstFunction::default()))),
            upvalues: vec![Upvalue::Ref(captured.clone())],
        };
        function.block_mut(capture).unwrap().push(
            Assign::new(vec![LValue::Local(callback)], vec![RValue::Closure(
                closure,
            )])
            .into(),
        );
        function.block_mut(write).unwrap().push(
            Assign::new(vec![LValue::Local(captured.clone())], vec![
                Literal::Number(1.0).into(),
            ])
            .into(),
        );
        edge(
            &mut function,
            capture,
            write,
            cfg::block::BranchType::Unconditional,
        );
        edge(
            &mut function,
            write,
            capture,
            cfg::block::BranchType::Unconditional,
        );

        assert!(
            lift(function).is_none(),
            "fallback must fail closed when a Ref capture would be hoisted"
        );
    }

    #[test]
    fn allows_ref_capture_of_function_input() {
        let mut function = Function::new(0);
        let capture = function.new_block();
        let use_input = function.new_block();
        function.set_entry(capture);

        let parameter = local("parameter");
        let callback = local("callback");
        function.parameters.push(parameter.clone());
        let closure = Closure {
            node_origin: Default::default(),
            function: by_address::ByAddress(Arc::new(Mutex::new(AstFunction::default()))),
            upvalues: vec![Upvalue::Ref(parameter.clone())],
        };
        function.block_mut(capture).unwrap().push(
            Assign::new(vec![LValue::Local(callback)], vec![RValue::Closure(
                closure,
            )])
            .into(),
        );
        function
            .block_mut(use_input)
            .unwrap()
            .push(ast::Return::new(vec![parameter.clone().into()]).into());
        edge(
            &mut function,
            capture,
            use_input,
            cfg::block::BranchType::Unconditional,
        );
        edge(
            &mut function,
            use_input,
            capture,
            cfg::block::BranchType::Unconditional,
        );

        let ignored = [parameter].into_iter().collect();
        assert!(
            lift_with_ignored_locals(function, &ignored).is_some(),
            "function-scoped inputs must remain valid capture cells"
        );
    }

    #[test]
    fn refuses_ref_capture_followed_by_cross_state_write_even_when_liveness_kills_read() {
        // The capture reads `captured` only after this state's assignment, so a
        // plain use-before-def liveness scan would not hoist it.  A subsequent
        // state writes the same local; after CLOSEUPVALS metadata has been
        // discarded, either sharing or splitting that cell is possible.  The
        // fallback must therefore reject the shape rather than silently pick
        // one closure lifetime.
        let mut function = Function::new(0);
        let capture = function.new_block();
        let write = function.new_block();
        function.set_entry(capture);

        let captured = local("captured");
        let callback = local("callback");
        function.block_mut(capture).unwrap().extend([
            Assign::new(vec![LValue::Local(captured.clone())], vec![
                Literal::Number(0.0).into(),
            ])
            .into(),
            Assign::new(vec![LValue::Local(callback)], vec![RValue::Closure(
                Closure {
                    node_origin: Default::default(),
                    function: by_address::ByAddress(Arc::new(Mutex::new(AstFunction::default()))),
                    upvalues: vec![Upvalue::Ref(captured.clone())],
                },
            )])
            .into(),
        ]);
        function.block_mut(write).unwrap().push(
            Assign::new(vec![LValue::Local(captured)], vec![
                Literal::Number(1.0).into(),
            ])
            .into(),
        );
        edge(
            &mut function,
            capture,
            write,
            cfg::block::BranchType::Unconditional,
        );
        edge(
            &mut function,
            write,
            capture,
            cfg::block::BranchType::Unconditional,
        );

        assert!(
            lift(function).is_none(),
            "cross-state writes after a Ref capture are ambiguous without Close metadata"
        );
    }

    #[test]
    fn refuses_ref_capture_in_reentered_state() {
        // The local is assigned and captured in the same state, so ordinary
        // use-before-def liveness sees no value crossing a state boundary.
        // A self-loop nevertheless re-enters that state on every dispatcher
        // iteration, recreating the captured cell and changing closure
        // behaviour.  Without preserved CLOSEUPVALS scope metadata this shape
        // must fail closed.
        let mut function = Function::new(0);
        let state = function.new_block();
        let exit = function.new_block();
        function.set_entry(state);

        let captured = local("captured");
        let callback = local("callback");
        let closure = Closure {
            node_origin: Default::default(),
            function: by_address::ByAddress(Arc::new(Mutex::new(AstFunction {
                body: Block::from(vec![
                    ast::Return::new(vec![captured.clone().into()]).into(),
                ]),
                ..Default::default()
            }))),
            upvalues: vec![Upvalue::Ref(captured.clone())],
        };
        function.block_mut(state).unwrap().extend([
            Assign::new(
                vec![LValue::Local(captured.clone())],
                vec![RValue::Call(Call::new(Global::from("nextValue").into(), vec![]))],
            )
            .into(),
            Assign::new(
                vec![LValue::Local(callback.clone())],
                vec![RValue::Closure(closure)],
            )
            .into(),
            Statement::Call(Call::new(Global::from("save").into(), vec![callback.into()])).into(),
            If::new(
                RValue::Call(Call::new(Global::from("again").into(), vec![])),
                Block::default(),
                Block::default(),
            )
            .into(),
        ]);
        function
            .block_mut(exit)
            .unwrap()
            .push(ast::Return::new(Vec::new()).into());
        edge(
            &mut function,
            state,
            state,
            cfg::block::BranchType::Then,
        );
        edge(
            &mut function,
            state,
            exit,
            cfg::block::BranchType::Else,
        );

        assert!(
            lift(function).is_none(),
            "fallback must reject Ref captures in states that can be re-entered"
        );
    }

    #[test]
    fn refuses_ref_capture_carried_by_edge_argument() {
        // A closure may be created by an SSA edge transfer rather than by a
        // statement in the source block. The transferred closure still
        // captures the local cell, and the next dispatcher state writes that
        // local. Missing the edge expression in capture analysis would emit
        // a fallback that recreates the cell on each iteration.
        let mut function = Function::new(0);
        let capture = function.new_block();
        let write = function.new_block();
        function.set_entry(capture);

        let captured = local("captured");
        let callback = local("callback");
        let closure = Closure {
            node_origin: Default::default(),
            function: by_address::ByAddress(Arc::new(Mutex::new(AstFunction::default()))),
            upvalues: vec![Upvalue::Ref(captured.clone())],
        };
        function.block_mut(write).unwrap().push(
            Assign::new(
                vec![LValue::Local(captured.clone())],
                vec![Literal::Number(1.0).into()],
            )
            .into(),
        );
        function.graph_mut().add_edge(
            capture,
            write,
            BlockEdge {
                branch_type: cfg::block::BranchType::Unconditional,
                arguments: vec![(callback, RValue::Closure(closure))],
            },
        );
        edge(
            &mut function,
            write,
            capture,
            cfg::block::BranchType::Unconditional,
        );

        assert!(
            lift(function).is_none(),
            "fallback must inspect reference captures in edge arguments"
        );
    }

    #[test]
    fn refuses_preexisting_loop_control_markers() {
        let mut function = Function::new(0);
        let entry = function.new_block();
        function.set_entry(entry);
        function
            .block_mut(entry)
            .unwrap()
            .push(Statement::Continue(ast::Continue {}).into());

        assert!(
            lift(function).is_none(),
            "fallback cannot infer the owner of a pre-existing Continue"
        );
    }
}
