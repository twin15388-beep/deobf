#!/usr/bin/env node
//
// Strips the Luraph v14.7 outer envelope off a protected Lua file.
//
//   node lph-unwrap.js protected.lua out/
//
// Writes out/protected.lua.stage1.bin (the VM interpreter, plain Lua source) and
// out/protected.lua.stage2.bin (the VM's bytecode for the original script).
//
// Both decoders below are transcribed from the loader that ships in the clear at the
// top of every protected file. See docs/envelope.md for the derivation.

const fs = require('fs');
const path = require('path');

// Stage 1: base85. Luraph writes a 4-byte magic ("LPH" + one variable byte) that the
// loader drops with string.sub(s, 5). 'z' is a zero-run standing in for "!!!!!".
// Digits are big-endian within the group; the resulting word is packed LITTLE-endian
// (string.pack("<I4", n)), which is the part that trips people up.
function base85(str) {
  const s = str.slice(4).replace(/z/g, '!!!!!');
  const groups = Math.floor(s.length / 5);
  const out = Buffer.alloc(groups * 4);

  for (let i = 0, o = 0; i < groups; i++, o += 4) {
    const p = i * 5;
    const n = (s.charCodeAt(p + 4) - 33)
            + (s.charCodeAt(p + 3) - 33) * 85
            + (s.charCodeAt(p + 2) - 33) * 7225
            + (s.charCodeAt(p + 1) - 33) * 614125
            + (s.charCodeAt(p) - 33) * 52200625;
    out.writeUInt32LE(n >>> 0, o);
  }

  const rem = s.length % 5;
  if (rem) {
    // gsub("....." ) only matches whole groups, so a short tail would have been left
    // verbatim in the loader's output too. Shouldn't happen on real files.
    console.error(`  warning: ${rem} trailing base85 chars ignored`);
  }
  return out;
}

// Stage 2: raw LZMA1. No props byte, no size field: lc=3, lp=0, pb=0 are baked into
// the loader (literal context is prevByte>>5, and posState is always `pos & 0`).
// Range/code are kept as doubles because `code << 8` overflows 32-bit JS bitwise ops.
function lzma(buf) {
  let pos = 0;
  const next = () => (pos < buf.length ? buf[pos++] : 0);

  let range = 0xFFFFFFFF;
  let code = 0;
  for (let i = 0; i < 5; i++) code = code * 256 + next();   // first byte is always 0

  const normalize = () => {
    if (Math.floor(range / 0x1000000) === 0) {
      range *= 256;
      code = code * 256 + next();
    }
  };

  const directBits = (n) => {
    let v = 0;
    for (let i = 0; i < n; i++) {
      range = Math.floor(range / 2);
      v *= 2;
      if (code >= range) { code -= range; v += 1; }
      normalize();
    }
    return v;
  };

  const bit = (probs, i) => {
    let p = probs[i];
    const bound = Math.floor(range / 2048) * p;
    let b;
    if (code < bound) { range = bound; p += (2048 - p) >> 5; b = 0; }
    else { range -= bound; code -= bound; p -= p >> 5; b = 1; }
    probs[i] = p;
    normalize();
    return b;
  };

  const tree = (probs, offset, nbits) => {
    let i = 1;
    for (let n = 0; n < nbits; n++) i = i * 2 + bit(probs, i);
    return i - offset;
  };

  const treeReverse = (probs, nbits, offset) => {
    let v = 0, i = 1;
    for (let n = 0; n < nbits; n++) {
      const b = bit(probs, offset + i);
      i = (i << 1) | b;
      v += b * 2 ** n;
    }
    return v;
  };

  const probArr = (n) => new Array(n).fill(1024);              // kBitModelTotal / 2
  const probArr2 = (a, b) => Array.from({ length: a }, () => probArr(b));
  const lenCoder = () => [1024, 1024, probArr2(1, 8), probArr2(1, 8), probArr(256)];

  const lit = probArr2(8, 0x300);
  const isMatch = probArr2(12, 1);
  const isRep = probArr(12);
  const isRepG0 = probArr(12);
  const isRepG1 = probArr(12);
  const isRepG2 = probArr(12);
  const isRep0Long = probArr2(12, 1);
  const posSlot = probArr2(4, 64);
  const specPos = probArr(115);
  const align = probArr(16);
  const lenC = lenCoder();
  const repLenC = lenCoder();

  const decodeLen = (lc) => {
    if (bit(lc, 0) === 0) return tree(lc[2][0], 8, 3);
    if (bit(lc, 1) === 0) return 8 + tree(lc[3][0], 8, 3);
    return tree(lc[4], 256, 8) + 16;
  };

  // dictionary is the whole output; out[0] is a sentinel so out[outPos] is "prev byte"
  const out = [0];
  let outPos = 0;
  let state = 0;
  const nextStateLit = [0, 0, 0, 0, 1, 2, 3, 4, 5, 6, 4, 5];
  let rep0 = 0, rep1 = 0, rep2 = 0, rep3 = 0;

  const matchedLiteral = (matchByte, probs) => {
    let i = 1;
    for (let k = 7; k >= 0; k--) {
      const mb = (matchByte >> k) & 1;
      const b = bit(probs, i + mb * 256 + 256);
      i = i * 2 + b;
      if (mb !== b) {
        while (i < 0x100) i = i * 2 + bit(probs, i);
        break;
      }
    }
    return i & 0xFF;
  };

  while (pos <= buf.length) {
    if (bit(isMatch[state], 0) === 0) {
      const probs = lit[out[outPos] >> 5];
      outPos++;
      out[outPos] = state < 7
        ? tree(probs, 256, 8)
        : matchedLiteral(out[outPos - rep0 - 1], probs);
      state = nextStateLit[state];
      continue;
    }

    let len;
    if (bit(isRep, state) !== 0) {
      if (bit(isRepG0, state) === 0) {
        if (bit(isRep0Long[state], 0) === 0) {
          state = state < 7 ? 9 : 11;
          len = 1;                                   // short rep
        }
      } else {
        let dist;
        if (bit(isRepG1, state) === 0) dist = rep1;
        else {
          if (bit(isRepG2, state) === 0) dist = rep2;
          else { dist = rep3; rep3 = rep2; }
          rep2 = rep1;
        }
        rep1 = rep0;
        rep0 = dist;
      }
      if (len === undefined) {
        state = state < 7 ? 8 : 11;
        len = 2 + decodeLen(repLenC);
      }
    } else {
      rep3 = rep2; rep2 = rep1; rep1 = rep0;
      len = 2 + decodeLen(lenC);

      const lenToPos = Math.min(len - 2, 3);
      const slot = tree(posSlot[lenToPos], 64, 6);
      rep0 = slot;
      if (slot >= 4) {
        const nDirect = (slot >> 1) - 1;
        rep0 = (2 | (slot & 1)) * 2 ** nDirect;
        if (slot < 14) {
          rep0 += treeReverse(specPos, nDirect, rep0 - slot);
        } else {
          rep0 += directBits(nDirect - 4) * 16 + treeReverse(align, 4, 0);
          if (rep0 === 0xFFFFFFFF) break;            // end marker
        }
      }
      state = state < 7 ? 7 : 10;
      if (rep0 >= outPos) throw new Error('lzma: distance past start of output');
    }

    const end = outPos + len;
    for (let i = outPos + 1; i <= end; i++) out[i] = out[i - rep0 - 1];
    outPos = end;
  }

  return Buffer.from(out.slice(1, outPos + 1));
}

function main() {
  const [file, outDir] = process.argv.slice(2);
  if (!file || !outDir) {
    console.error('usage: node lph-unwrap.js <protected.lua> <outdir>');
    process.exit(1);
  }
  fs.mkdirSync(outDir, { recursive: true });

  const src = fs.readFileSync(file, 'latin1');
  // The loader holds its two payloads in long-bracket literals of matching level.
  const literals = [...src.matchAll(/\[(=+)\[([\s\S]*?)\]\1\]/g)].map((m) => m[2]);

  if (literals.length !== 2) {
    console.error(`${file}: expected 2 long-bracket literals, found ${literals.length}`);
    if (!literals.length) process.exit(1);
  }

  const names = ['stage1', 'stage2'];
  literals.forEach((lit, i) => {
    const packed = base85(lit);
    const plain = lzma(packed);
    const dest = path.join(outDir, `${path.basename(file)}.${names[i] || 'stage' + (i + 1)}.bin`);
    fs.writeFileSync(dest, plain);
    console.log(
      `${names[i] || i}: magic=${JSON.stringify(lit.slice(0, 4))} ` +
      `b85=${lit.length}ch -> ${packed.length}B -> lzma ${plain.length}B  ${dest}`
    );
  });
}

main();
