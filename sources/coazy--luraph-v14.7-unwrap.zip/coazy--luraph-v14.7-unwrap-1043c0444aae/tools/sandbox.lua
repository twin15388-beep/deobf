-- Runs an unwrapped Luraph VM under a synthetic _ENV and dumps everything it decrypts.
--
--   lua sandbox.lua <dir> <name>[,<name>...]
--
-- <name> refers to the pair <dir>/<name>.stage1.bin + <dir>/<name>.stage2.bin produced
-- by lph-unwrap.js. Multiple names run in order in ONE shared environment, which matters
-- when an early chunk installs globals that later chunks need.
--
-- Two things do the actual work:
--   * the fake native surface, which keeps execution alive long enough for the VM to
--     decrypt its constants on demand, and
--   * the closure walk at the end, which reads every string the VM materialised out of
--     its upvalues via debug.getupvalue.
--
-- io / os.execute / package / require are never handed to the guest. HTTP is logged and
-- dropped. Treat that as the minimum, not as a real sandbox: bytecode passed to load()
-- can escape a Lua "sandbox", so run untrusted samples in a VM or container.

local realIO, realOS, realDebug = io, os, debug
local dir, names = ...
if not dir then
  print('usage: lua sandbox.lua <dir> <name>[,<name>...]')
  return
end
names = names or 'main.lua'

local targets = {}
for n in names:gmatch('[^,]+') do targets[#targets + 1] = n end

local function readFile(p)
  local f = assert(realIO.open(p, 'rb'))
  local d = f:read('a')
  f:close()
  return d
end

local log = assert(realIO.open(dir .. '/sandbox.log', 'w'))
local function LOG(...)
  local parts = {}
  for i = 1, select('#', ...) do parts[i] = tostring((select(i, ...))) end
  log:write(table.concat(parts, ' '), '\n')
end

local function quote(s)
  s = s:gsub('[\r\n\t\\"]', { ['\r'] = '\\r', ['\n'] = '\\n', ['\t'] = '\\t',
                              ['\\'] = '\\\\', ['"'] = '\\"' })
  return '"' .. (s:gsub('[%z\1-\31\127-\255]', function(c)
    return ('\\x%02X'):format(c:byte())
  end)) .. '"'
end

local show
show = function(v, depth)
  depth = depth or 0
  local t = type(v)
  if t == 'string' then return quote(v) end
  if t == 'function' then return '<fn>' end
  if t ~= 'table' then return tostring(v) end
  local mt = realDebug.getmetatable(v)
  if mt and mt.__stubname then return '<' .. mt.__stubname .. '>' end
  if depth > 3 then return '{...}' end
  local n, out = 0, {}
  for k, vv in next, v do
    n = n + 1
    if n > 14 then out[#out + 1] = '...' break end
    out[#out + 1] = tostring(k) .. '=' .. show(vv, depth + 1)
  end
  return '{' .. table.concat(out, ',') .. '}'
end

local function showArgs(...)
  local out = {}
  for i = 1, select('#', ...) do out[i] = show((select(i, ...))) end
  return table.concat(out, ', ')
end

-- Strings the VM builds pass through the string library on their way out, so wrapping it
-- catches constants the closure walk might miss.
local seen = {}
local function catch(s)
  if type(s) == 'string' and #s >= 2 and #s <= 2048 then seen[s] = true end
end

local strlib = {}
for k, v in pairs(string) do
  if type(v) == 'function' then
    strlib[k] = function(...)
      local first = (select(1, ...))
      if type(first) == 'string' then catch(first) end
      local r = table.pack(pcall(v, ...))
      if not r[1] then return v(...) end          -- let the real error surface
      for i = 2, r.n do if type(r[i]) == 'string' then catch(r[i]) end end
      return table.unpack(r, 2, r.n)
    end
  else
    strlib[k] = v
  end
end

local tablib = {}
for k, v in pairs(table) do tablib[k] = v end
tablib.concat = function(...)
  local r = table.concat(...)
  catch(r)
  return r
end

local env = {}
local threads = {}
local calls, callLog = {}, {}
local function record(name, line)
  calls[name] = (calls[name] or 0) + 1
  if #callLog < 80000 then callLog[#callLog + 1] = line end
end

-- A stub that is callable AND indexable. Returning a bare function breaks on
-- `SomeGlobal.field`; returning a bare table breaks on `SomeGlobal()`. Scripts do both.
local stubs = {}
local function stub(name)
  if stubs[name] then return stubs[name] end
  local t = {}
  setmetatable(t, {
    __stubname = name,
    __call = function(_, ...)
      record(name, ('%s(%s)'):format(name, showArgs(...)))
      LOG(('[call] %s(%s)'):format(name, showArgs(...)))
      if name:find('Wait') then coroutine.yield() end
      return nil
    end,
    __index = function(_, k) return stub(name .. '.' .. tostring(k)) end,
    __newindex = function(_, k, v)
      LOG(('[set] %s.%s = %s'):format(name, tostring(k), show(v)))
    end,
    __tostring = function() return name end,
    __len = function() return 0 end,
    __concat = function(a, b)
      return (type(a) == 'string' and a or tostring(a)) ..
             (type(b) == 'string' and b or tostring(b))
    end,
    __add = function() return 0 end, __sub = function() return 0 end,
    __mul = function() return 0 end, __div = function() return 0 end,
    __mod = function() return 0 end, __unm = function() return 0 end,
    __idiv = function() return 0 end, __pow = function() return 0 end,
    __eq = function() return false end,
    __lt = function() return false end, __le = function() return false end,
  })
  stubs[name] = t
  return t
end

local function native(name, ret)
  return function(...)
    local line = ('%s(%s)'):format(name, showArgs(...))
    record(name, line)
    LOG('[native] ' .. line)
    if name == 'Wait' or name == 'Citizen.Wait' then coroutine.yield() end
    if ret ~= nil then
      if type(ret) == 'function' then return ret(...) end
      return ret
    end
    return nil
  end
end

env.string, env.table, env.math = strlib, tablib, math
env.select, env.type, env.pairs, env.ipairs, env.next = select, type, pairs, ipairs, next
env.tostring, env.tonumber = tostring, tonumber
env.setmetatable, env.getmetatable = setmetatable, getmetatable
env.rawset, env.rawget, env.rawequal, env.rawlen = rawset, rawget, rawequal, rawlen
env.pcall, env.xpcall, env.error, env.assert = pcall, xpcall, error, assert
env.unpack, env.coroutine, env._VERSION = table.unpack, coroutine, _VERSION
env.collectgarbage = function() return 0 end
env.os = { time = realOS.time, clock = realOS.clock, date = realOS.date,
           getenv = function() return nil end }

-- Luraph reads debug.getinfo fields ("linedefined", "short_src", "currentline", ...) for
-- its own error paths, so this has to answer rather than be absent.
env.debug = {
  getinfo = function(...) return realDebug.getinfo(...) end,
  traceback = realDebug.traceback,
  sethook = function() end, gethook = function() end,
  getlocal = function() return nil end, getupvalue = function() return nil end,
}

-- Anything the VM load()s is a layer we haven't seen yet: keep it.
local nested = 0
env.load = function(chunk, name, mode, e)
  nested = nested + 1
  if type(chunk) == 'string' then
    LOG(('[load #%d] name=%s len=%d head=%s')
      :format(nested, tostring(name), #chunk, quote(chunk:sub(1, 140))))
    local f = realIO.open(('%s/nested_%d.bin'):format(dir, nested), 'wb')
    if f then f:write(chunk) f:close() end
  end
  return load(chunk, name, mode, e or env)
end
env.loadstring = env.load

-- Natives whose return VALUE steers control flow have to be concrete; the rest can be
-- stubs. Getting this set wrong is the usual reason a run dies in the first few steps.
local concrete = {
  GetGameTimer = function() return 1000 end,
  GetNetworkTime = function() return 1000 end,
  PlayerPedId = function() return 1 end,
  PlayerId = function() return 0 end,
  GetPlayerServerId = function() return 1 end,
  GetPlayerName = function() return 'Player' end,
  GetCurrentResourceName = function() return 'sample' end,
  IsDuplicityVersion = function() return false end,      -- flip to true for server chunks
  GetGameName = function() return 'fivem' end,
  GetNumResources = function() return 1 end,
  GetResourceByFindIndex = function() return 'sample' end,
  GetResourceState = function() return 'started' end,
  GetResourcePath = function() return '/resources/sample' end,
  GetConvar = function(_, d) return d or '' end,
  GetConvarInt = function(_, d) return d or 0 end,
  GetPlayers = function() return { '1' } end,
  GetActivePlayers = function() return { 0 } end,
  GetNumPlayerIndices = function() return 1 end,
  GetPlayerIdentifiers = function() return { 'license:0000', 'ip:127.0.0.1' } end,
  GetHashKey = function() return 0 end,
  DoesEntityExist = function() return true end,
  GetPlayerPed = function() return 1 end,
  GetEntityHealth = function() return 200 end,
  GetEntityMaxHealth = function() return 200 end,
  GetEntityModel = function() return 0 end,
  GetEntityCoords = function() return env.vector3(0, 0, 0) end,
  LoadResourceFile = function() return nil end,
  SaveResourceFile = function() return true end,
  GetResourceMetadata = function() return nil end,
  GetNumResourceMetadata = function() return 0 end,
  GetInvokingResource = function() return nil end,
}
for n, f in pairs(concrete) do env[n] = native(n, f) end

for _, n in ipairs({
  'RegisterNetEvent', 'AddEventHandler', 'RemoveEventHandler', 'TriggerEvent',
  'TriggerServerEvent', 'TriggerClientEvent', 'TriggerLatentServerEvent',
  'TriggerLatentClientEvent', 'TriggerServerEventInternal', 'TriggerClientEventInternal',
  'TriggerEventInternal', 'TriggerLatentServerEventInternal', 'RegisterCommand',
  'ExecuteCommand', 'SendNUIMessage', 'RegisterNUICallback', 'SetNuiFocus', 'DropPlayer',
  'SetConvar', 'SetConvarReplicated', 'CancelEvent', 'WasEventCanceled', 'Wait',
  'SetStateBagValue', 'GetStateBagValue', 'AddStateBagChangeHandler', 'RegisterKeyMapping',
  'AddTextEntry', 'StartResource', 'StopResource', 'ProfilerEnterScope', 'ProfilerExitScope',
}) do env[n] = native(n) end

-- Captured, never sent. Call the callback back with a failure so retry paths get exercised.
env.PerformHttpRequest = function(url, cb, method, data, headers)
  record('PerformHttpRequest', ('PerformHttpRequest(%s)'):format(show(url)))
  LOG(('[http] %s %s\n       headers=%s\n       body=%s')
    :format(tostring(method or 'GET'), tostring(url), show(headers), show(data)))
  catch(tostring(url))
  if type(cb) == 'function' then pcall(cb, 0, '', {}) end
end

env.Citizen = setmetatable({
  CreateThread = function(fn)
    LOG('[CreateThread]')
    threads[#threads + 1] = coroutine.create(fn)
  end,
  CreateThreadNow = function(fn) threads[#threads + 1] = coroutine.create(fn) end,
  Wait = native('Citizen.Wait'),
  SetTimeout = function(ms, fn)
    LOG('[SetTimeout] ' .. tostring(ms))
    threads[#threads + 1] = coroutine.create(fn)
  end,
  InvokeNative = function(hash, ...)
    local h = type(hash) == 'number' and ('0x%X'):format(hash) or tostring(hash)
    record('InvokeNative ' .. h, ('InvokeNative(%s, %s)'):format(h, showArgs(...)))
    LOG(('[InvokeNative] %s(%s)'):format(h, showArgs(...)))
    return nil
  end,
  Trace = function(...) LOG('[Trace] ' .. showArgs(...)) end,
}, { __index = function(_, k) return native('Citizen.' .. tostring(k)) end })

env.CreateThread, env.SetTimeout = env.Citizen.CreateThread, env.Citizen.SetTimeout
env.print = function(...) LOG('[print] ' .. showArgs(...)) end
env.vector3 = function(x, y, z)
  return setmetatable({ x = x or 0, y = y or 0, z = z or 0 }, {
    __sub = function() return env.vector3(0, 0, 0) end,
    __add = function() return env.vector3(0, 0, 0) end,
    __len = function() return 0 end,
    __tostring = function() return 'vec3' end,
  })
end
env.vector2, env.vector4 = env.vector3, env.vector3
env.msgpack = { pack = function() return '' end, unpack = function(v) return v end,
                pack_args = function() return '' end }
env.json = {
  encode = function(v) local s = show(v) catch(s) return s end,
  decode = function(s) catch(tostring(s)) return {} end,
}
env.exports = setmetatable({}, {
  __index = function() return setmetatable({}, {
    __index = function() return function() end end }) end,
  __newindex = function(_, k) LOG('[export] ' .. tostring(k)) end,
})

-- State bags are a common place for a script to block on a server handshake. Answering
-- with a plausible string instead of nil is often what gets a run past its init loop.
env.GlobalState = setmetatable({}, {
  __index = function(_, k)
    LOG('[GlobalState read] ' .. tostring(k))
    return 'placeholder'
  end,
  __newindex = function(t, k, v)
    LOG(('[GlobalState write] %s = %s'):format(tostring(k), show(v)))
    catch(tostring(k))
    rawset(t, k, v)
  end,
})
env.LocalPlayer = { state = setmetatable({}, { __index = function() return nil end }) }
env.Player = function() return { state = {} } end
env.Entity = function() return { state = {} } end
env._G = env

setmetatable(env, {
  __index = function(t, k)
    LOG('[unstubbed global] ' .. tostring(k))
    local s = stub(tostring(k))
    rawset(t, k, s)
    return s
  end,
  __newindex = function(t, k, v)
    LOG(('[global write] %s = %s'):format(tostring(k), show(v)))
    rawset(t, k, v)
  end,
})

local function run(tag)
  LOG('\n===== ' .. tag .. ' =====')
  local vmSource = readFile(('%s/%s.stage1.bin'):format(dir, tag))
  local payload = readFile(('%s/%s.stage2.bin'):format(dir, tag))

  local factory = load(vmSource, '@lph_' .. tag, 't', env)
  if not factory then LOG('could not load stage1') return nil end

  local ok, entry = pcall(factory, payload)
  LOG(('[%s] factory ok=%s -> %s'):format(tag, tostring(ok), show(entry)))
  if not ok then LOG(('[%s] %s'):format(tag, tostring(entry))) return nil end
  if type(entry) ~= 'function' then return entry end

  local co = coroutine.create(entry)
  for step = 1, 500 do
    local r = { coroutine.resume(co) }
    if not r[1] then LOG(('[%s] step %d: %s'):format(tag, step, tostring(r[2]))) end
    if coroutine.status(co) == 'dead' then break end
  end

  -- Threads registered during init only reach their interesting code after a few Waits.
  for pass = 1, 120 do
    local alive = false
    for i, th in ipairs(threads) do
      if coroutine.status(th) == 'suspended' then
        alive = true
        local r = { coroutine.resume(th) }
        if not r[1] then
          LOG(('[%s] thread %d pass %d: %s'):format(tag, i, pass, tostring(r[2])))
        end
      end
    end
    if not alive then break end
  end
  return entry
end

local entries = {}
for _, t in ipairs(targets) do entries[#entries + 1] = run(t) end

-- The VM caches decrypted constants in tables held by its closures, so reading upvalues
-- transitively recovers them without knowing anything about the opcode format.
local pool, visited, nObjects = {}, {}, 0
local walk
walk = function(v, depth)
  if depth > 16 then return end
  local t = type(v)
  if t == 'string' then
    if #v >= 2 and #v <= 2048 then pool[v] = true end
    return
  end
  if t == 'table' then
    if visited[v] then return end
    visited[v] = true
    nObjects = nObjects + 1
    if nObjects > 600000 then return end
    local mt = realDebug.getmetatable(v)
    if mt and mt.__stubname then return end          -- our own stubs, not sample data
    for k, vv in next, v do walk(k, depth + 1) walk(vv, depth + 1) end
    if mt then walk(mt, depth + 1) end
    return
  end
  if t == 'function' then
    if visited[v] then return end
    visited[v] = true
    for i = 1, 255 do
      local n, uv = realDebug.getupvalue(v, i)
      if not n then break end
      walk(uv, depth + 1)
    end
  end
end

for _, e in ipairs(entries) do walk(e, 0) end
walk(threads, 0)
walk(env, 0)
for s in pairs(seen) do pool[s] = true end

local printable, binary = {}, {}
for s in pairs(pool) do
  if s:find('^[\32-\126]+$') then printable[#printable + 1] = s
  else binary[#binary + 1] = s end
end
table.sort(printable)
table.sort(binary)

local function dump(name, lines)
  local f = assert(realIO.open(dir .. '/' .. name, 'wb'))
  for _, l in ipairs(lines) do f:write(l, '\n') end
  f:close()
end

dump('strings.txt', printable)
dump('calls.txt', callLog)
local hex = {}
for i, b in ipairs(binary) do
  hex[i] = (b:gsub('.', function(c) return ('%02X'):format(c:byte()) end))
end
dump('strings-binary.txt', hex)

LOG('\n===== call counts =====')
local keys = {}
for k in pairs(calls) do keys[#keys + 1] = k end
table.sort(keys)
for _, k in ipairs(keys) do LOG(('  %-56s %d'):format(k, calls[k])) end
log:close()

print(('strings=%d binary=%d calls=%d kinds=%d objects=%d')
  :format(#printable, #binary, #callLog, #keys, nObjects))
