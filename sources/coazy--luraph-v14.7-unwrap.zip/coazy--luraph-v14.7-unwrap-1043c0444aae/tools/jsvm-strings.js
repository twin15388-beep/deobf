#!/usr/bin/env node
//
// Pulls constants out of a JS file protected with the vmm_* / vmH_* VM obfuscator
// (the one that keeps its function bytecode in base64 string literals).
//
//   node jsvm-strings.js protected.js out.txt
//
// The bytecode is a length-prefixed constant table followed by instructions. The
// constants are NOT encrypted, so a printable-run scan over the decoded bytes recovers
// property names, string literals and error messages verbatim. Combined with the
// exports(...) calls left in the clear, that is usually enough to reconstruct what each
// exported function does without touching the interpreter.

const fs = require('fs');

const file = process.argv[2];
const out = process.argv[3];
if (!file) {
  console.error('usage: node jsvm-strings.js <protected.js> [out.txt]');
  process.exit(1);
}

const src = fs.readFileSync(file, 'latin1');

// Bytecode blobs are long single-quoted base64 literals. 40 chars is a low enough floor
// to catch small functions without dragging in ordinary strings.
const blobs = [...src.matchAll(/'([A-Za-z0-9+/]{40,}={0,2})'/g)].map((m) => m[1]);

const strings = new Set();
for (const b64 of blobs) {
  let buf;
  try {
    buf = Buffer.from(b64, 'base64');
  } catch {
    continue;
  }
  for (const run of buf.toString('latin1').match(/[\x20-\x7e]{4,}/g) || []) {
    strings.add(run);
  }
}

// Export names are emitted as plain exports('name', ...) calls.
const exported = [...src.matchAll(/exports\('([A-Za-z0-9_$]+)'/g)].map((m) => m[1]);

const list = [...strings].sort();
console.log(`blobs=${blobs.length} strings=${list.length} exports=${exported.length}`);

if (exported.length) {
  console.log('\nexports:');
  [...new Set(exported)].sort().forEach((e) => console.log('  ' + e));
}

// Node/browser builtins worth calling out, since they tell you the real capability set.
const notable = list.filter((s) =>
  /^(require|process|child_process|fs|crypto|net|http|https|dns|os|path|vm|eval|Function|WebSocket|XMLHttpRequest|fetch)$/.test(s) ||
  /readFile|writeFile|unlink|exec|spawn|createHmac|createCipher|randomBytes|timingSafeEqual|digest|connect|listen/.test(s) ||
  /^https?:\/\//.test(s)
);
if (notable.length) {
  console.log('\nnotable identifiers:');
  [...new Set(notable)].sort().forEach((s) => console.log('  ' + JSON.stringify(s)));
}

if (out) {
  fs.writeFileSync(out, list.join('\n'));
  console.log(`\nwrote ${out}`);
}
