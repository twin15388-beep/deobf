# The outer envelope

Every file protected with v14.7 that I looked at has the same shape:

```lua
-- This file was protected using Luraph Obfuscator v14.7 [https://lura.ph/]

return(function()local j,u,n,f,T,E,M,a,L,Q,W,t,X,V=string.char,tostring,{},string.sub,
string.gsub,assert,pcall,type,string.byte,setmetatable,load,5,string.rep,string.pack
...
local f,T=n([=[LPH&V]7Sp...]=]),n([=[LPH$...]=])
...
local j=n(f);f=n(T);n,T=M(W,j,"Luraph"..X(" ",4),nil)
E(n and T and a(T)=='function',"Luraph decompression error: "..u(T)..
  " (does your environment support load/loadstring?)")
return T(f);end)()(...);
```

The whole loader is in the clear, which makes this layer straightforward. Read it top to
bottom and it tells you exactly what it does. Two payloads, two passes over each.

Note the local names are shuffled per file, so don't pattern-match on them. In the sample
above `f = string.sub`, `T = string.gsub`, `W = load`, `M = pcall`, `V = string.pack`. In
another file the same roles land on different letters.

## Pass 1: base85

```lua
n = function(A)
  A = f(A, t)                       -- string.sub(A, 5): drop the 4-byte magic
  A = T(A, "z", "!!!!!")            -- 'z' is a zero-run
  return T(A, ".....", setmetatable({}, {__index = function(cache, grp)
    local a, b, c, d, e = L(grp, 1, 5)
    local n = (e - 33)
            + (d - 33) * 85
            + (c - 33) * 7225
            + (b - 33) * 614125
            + (a - 33) * 52200625
    local packed = V("<I4", n)
    cache[grp] = packed
    return packed
  end}))
end
```

Three things matter here:

1. **The magic is 4 bytes and gets dropped.** I saw `LPH&`, `LPH-`, `LPH:`, `LPH#`,
   `LPH/`, `LPH$` across six payloads, so only treat `LPH` as fixed.
2. **Digits are big-endian inside the group, but the word is packed little-endian.**
   `string.pack("<I4", n)`. This is the step people get wrong; if your output looks like
   valid-length garbage that never decompresses, byte order is why.
3. `gsub` with pattern `"....."` only replaces whole 5-char groups. A 1–4 char tail would
   be copied through verbatim rather than decoded. Real payloads are group-aligned, but
   it's worth asserting on.

Using a memoised `__index` table as the gsub replacement is just a speed trick — repeated
groups are decoded once. It has no effect on output.

## Pass 2: raw LZMA1

`n` is then reassigned to a hand-rolled LZMA decoder. It's a faithful LZMA1 range coder,
recognisable from the constants:

- `A = 0xFFFFFFFF` initial range, 5 bytes read for the range-coder init (first is always 0)
- `(A >> 11) * z` — `kNumBitModelTotalBits = 11`
- `z + ((2048 - z) >> 5)` / `z - (z >> 5)` — `kBitModelTotal = 2048`, `kNumMoveBits = 5`
- probability arrays initialised to `1024` = `kBitModelTotal / 2`
- state transition table `{[0]=0,0,0,0,1,2,3,4,5,6,4,5}` — `UpdateState_Literal`
- `k(8, 0x300)` literal coder, indexed by `prevByte >> 5` → **lc = 3**
- `local V = (D & 0)` for posState → **pb = 0**, and lp = 0
- `k(4, 64)` posSlot, `Y(115)` specPos, `Y(16)` align
- `if J == 0xFFFFFFFF then return P == 2 end` — end-of-stream marker

There is **no props byte and no uncompressed-size field**. If you want to hand the stream
to an off-the-shelf LZMA library instead of reimplementing, synthesise a header:
props = `(pb * 5 + lp) * 9 + lc` = `3`, then a dictionary size, then
`0xFFFFFFFFFFFFFFFF` for unknown size.

The dictionary is the entire output buffer (`G[t] = G[t - J - 1]` with no window bound),
and `G[0] = 0` is a sentinel so index 1 is the first real byte.

If you reimplement in JavaScript, keep `range` and `code` as doubles. `code << 8` exceeds
32 bits and JS bitwise operators will silently truncate it. Same for the distance
computation `(2 | (slot & 1)) << nDirect`, which reaches `3 << 30`.

Output is assembled in 7997-byte chunks:

```lua
for L = 1, R, 7997 do
  local Q = math.min(L + 7996, R)
  S = S .. j(N(G, L, Q))          -- string.char(table.unpack(...))
end
```

That's just staying under `LUAI_MAXCSTACK` for `table.unpack`, nothing meaningful.

## What you get

```
literal 1 -> the VM interpreter, as plain loadable Lua source
literal 2 -> the VM's bytecode for the original script
```

and the loader finishes with `load(interpreter, "Luraph    ")(bytecode)`.

Sizes from one real resource, for scale:

| file | on disk | interpreter | bytecode |
|---|---|---|---|
| a | 295 KB | 43,812 B | 398,982 B |
| b | 62 KB | 39,130 B | 60,116 B |
| c | 276 KB | 41,411 B | 393,021 B |
| d | 230 KB | 41,759 B | 307,813 B |

The interpreter is roughly the same size every time — it's boilerplate. The bytecode is
where your script went.

## Decoy checks

Before defining the decoder, the loader runs this:

```lua
n = {38640, {0x1B,0x4C,0x75,0x61,0x50}, u(W)}
for A, P in next, n do
  local Z = {M(W, A % 2 == 0 and j(N(P)) or P, nil, nil)}
  if Z[1] and M(Z[2]) ~= not Z[3] then t = 5 end
end
```

`{0x1B,0x4C,0x75,0x61,0x50}` is `"\27LuaP"`, and it's feeding those through `pcall(load, ...)`.
`t` is already 5, and every branch sets it to 5 again, so this is inert. It exists to make
you think binary-chunk support is being probed. Ignore it.

Later there's also:

```lua
M(W, Q({}, {__tostring = function() G = nil end}), nil, nil)
```

`pcall(load, <table with __tostring>)`. `load` rejects a table argument before any
metamethod fires, so `G` is never cleared. Also inert.
