# The interpreter layer

Once the envelope is off, literal 1 is real Lua that `load()` accepts. It is not pleasant
to read, but everything about it is visible. What follows is what the protection actually
consists of, and what turned out to be decoration.

## Shape

One table literal with roughly 150 short methods, returned and immediately closed over:

```lua
local q = ...                    -- q is the bytecode string
return({
  c  = function(b,b,L) L=nil; b=nil; return L,b end,
  J1 = function(b,b,L,u) u=L[12](b); return u end,
  U  = string.sub,
  ...
}):J()
```

`:J()` builds and returns the entry function. Note `local q = ...` — the bytecode arrives
as a vararg, so the interpreter closes over it and every proto reader slices out of it.

## Real obfuscation

**Control flow flattening.** Straight-line code is rewritten as a dispatch over a state
variable, with the state values chosen so the loop bounds look meaningful:

```lua
for t = 69, 340, 62 do
  if t > 69.0 and t < 193.0 then b:h1(o, C)
  elseif t > 193.0 then ... break
  else if t < 255.0 and t > 131.0 then o[7]=A; o[6]=L; o[8]=j
  else if not(t < 131.0) then else o[1] = u end end end
end
```

The step values and comparisons are constructed so only one branch is reachable per
iteration. Both `for ... do if <state> then` and `repeat ... until false` with a sentinel
comparison (`if Z ~= 20482 then else break end`) are used.

**Integer state compared as float.** Every state test is written `if c > 35.0 then`, not
`if c > 35 then`. Cheap, and it breaks naive integer-literal matching.

**Opaque predicates, memoised.** The bulk of the source volume is this:

```lua
L = 55 + ((b.C[2] << u[13529] <= b.C[7] and u[15211] or u[14896]) & b.C[2]
     < b.C[7] and u[6606] or u[15211])
u[6244] = L
```

with the guard `if not(not u[6244]) then L = u[6244] else <compute> end`. `u` is a sparse
table of constants and `b.C` a small fixed array, so each of these folds to one integer on
first execution and is cached. They carry no data dependency on the program. You can
ignore them wholesale — do not try to evaluate them.

**Deliberate identifier shadowing.** This is the one that will actually cost you time:

```lua
local V, A, P = 0, 0xFFFFFFFF, #t
local Z = function() V = V + 1; return L(t, V, V) end   -- L is string.byte here
local L = 0                                             -- L is now the range coder's code
local function t(w) ... end                             -- t was the input string
local function L(A, Z, G) ... end                       -- L is now a bittree decoder
local A = 0                                             -- A is now the LZMA state
local function Z(G, h, z) ... end                       -- Z was the byte reader
```

Six rebindings of four names in one scope. Closures created before each rebinding keep the
earlier binding, which is load-bearing, not accidental. Read declaration order carefully or
you will mis-transcribe it.

**Escape-assembled strings.** Metamethod and format names are built so grep misses them:

```lua
I  = '\u{005F}\95\z \u{006E}ewind\z  ex'     -- __newindex
S  = '\x5F_i\u{6E}dex'                        -- __index
     '\x3Cf'                                  -- <f
     '<i\u{34}'                               -- <i4
     "<\z i\z 8"                              -- <i8
```

`\z` swallows following whitespace, so the padding between fragments vanishes at parse
time. Search for the decoded forms, not the literals.

**Stdlib aliased once.** Near the end of the table:

```lua
U = string.sub,  l = string.byte,  b = string.char,
k = string.unpack,  zx = string.unpack,  xx = table.move,
O = table.unpack,  T = table.unpack
```

Grepping for `string.` finds these and nothing else. Track the aliases.

## The bytecode format

Instruction and operand fields are LEB128 varints. The reader is a plain
`until (c & 128) == 0` loop, wrapped in the usual flattening:

```lua
q = function(b, L, u, A)
  repeat
    local c
    for v = 123, 511, 119 do
      if v == 480 then if L[21] ~= L[4] then else return -2, A, u, (b:A()) end break
      elseif v == 242 then
      else if v == 361 then c = L[19]() else ... end end
    end
    u = u | ((c & 127) << A)
    A = A + 7
  until (c & 128) == 0
  do return -2, A, u, (b:e(u)) end
end
```

The string-constant reader is unencrypted — it slices straight out of the payload:

```lua
A[31] = function()
  local n = A[26]()            -- varint length
  A[13] = A[13] + n            -- advance the cursor
  return A[18](q, A[13] - n, A[13] - 1)    -- string.sub(bytecode, from, to)
end
```

So **v14.7 does not encrypt string constants at the VM layer**. If the strings in your
sample still look like ciphertext, that's the protected application encrypting its own
data, which is a separate problem.

In the payload prologue the constant table is tagged:

| tag | payload |
|---|---|
| `0x36` | `<leb128 len> <bytes>` — string |
| `0x64` | `<f32 le>` — number |
| `0x6b` | `<u8>` — small int |
| `0xd5` | `<leb128>` — int |

Only the prologue parses cleanly this way. A naive tag scan over the whole blob produces
mostly false positives, because `0x36` occurs constantly in the instruction stream. Per-proto
constant tables are reached through a dedup layer:

```lua
f1 = function(b, L, u, A)
  for c = 1, L do
    local L = u[26]()          -- constant id
    if u[11][L] then A[c] = u[11][L]   -- already materialised
    else b:q1(c, u, L, A) end          -- parse a new one
  end
end
```

## The interpreter is a register machine

This is the useful finding. The dispatch is a binary search over one variable — 56 distinct
opcode constants in the range 4–240 in the sample I measured — and the handlers are
completely legible:

```lua
a == 186  ->  w[Z[I]] = w[j[I]] & w[i[I]]              -- BAND
a == 197  ->  w[Z[I]] = w[j[I]][g[I]]                  -- GETFIELD
a == 203  ->  w[Z[I]] = w[j[I]] - w[i[I]]              -- SUB
a == 216  ->  w[Z[I]] = w[i[I]] / C[I]                 -- DIV  (rhs from constants)
a == 218  ->  w[Z[I]] = w[i[I]] <= C[I]                -- LE
a == 220  ->  S = j[I]; z = 0
a == 228  ->  w[j[I]] = w[Z[I]] >= g[I]                -- GE
a == 234  ->  w[c](table.unpack(w, c + 1, Q))          -- CALL
a == 240  ->  w[j[I]] = A[6][Z[I]]                     -- load proto/closure
a == 184  ->  if not(w[i[I]] < C[I]) then I = Z[I] end  -- LT + branch
a == 182  ->  if not(not w[Z[I]]) then else I = j[I] end -- TEST + branch
```

The naming maps to:

- `w` — register file
- `I` — instruction pointer
- `Q` — top of frame (used by CALL / SETLIST / register clearing)
- `i`, `j`, `Z` — operand arrays (register indices)
- `C`, `G`, `g` — operand arrays sourcing the constant table
- `v` — upvalue array
- `A` — VM context (`A[3]` = `table.unpack`, `A[15]` = `next`, `A[6]` = protos)

The important structural point: **operands are pre-decoded into parallel arrays indexed by
instruction number**, not bit-packed into a word. `Q1` is the decode loop that fills them:

```lua
for w = 1, g do
  ...
  if Q == 6 then ... else L[w] = c[16][h] end
  elseif Q == 5 then b:s1(h, j, w)
  elseif Q == 7 then j[w] = w + h        -- relative -> absolute jump target
  else if Q == 2 then j[w] = w - h
  ...
end
```

Two consequences worth knowing:

1. Jump targets are **resolved to absolute instruction indices at load time** (`j[w] = w + h`),
   so you don't have to reimplement relative offsets.
2. Because the decoded program lives in ordinary Lua tables, you can recover all of it at
   runtime without parsing the bytecode at all — see
   [instrumentation.md](instrumentation.md). Walking closures on one real sample turned up
   1,733 dense integer arrays clustering into 313 same-length groups, i.e. 313 function
   protos with their operand arrays intact.

## What this does and doesn't get you

A full instruction-level **disassembly** is reachable: map the 56 opcodes from the handler
bodies, grab the operand arrays, resolve constants, print. It's work but there is no
research risk in it.

**Original source is not recoverable, by construction.** Luraph compiles the script to this
bytecode; local names, comments, and formatting are discarded and are not present anywhere
in the artifact. Anything past disassembly means writing a decompiler — control-flow
structuring back into `if`/`while`/`for`, expression re-nesting from register traffic,
invented local names. You'd get machine-generated Lua that behaves the same, not the file
the author wrote.

For most practical purposes (auditing what a resource does, what it talks to, what it
collects) the instrumentation route answers the question faster and more reliably than
either.
