# Recovering behaviour by running the VM

Since the interpreter is plain Lua after unwrapping, the fastest way to find out what a
protected script does is to run it under a fake environment and watch. This gets you
further in an afternoon than a partial devirtualizer does in a week.

The mechanism is Lua 5.4's fourth argument to `load`:

```lua
local factory = load(interpreterSource, '@vm', 't', env)
local entry = factory(bytecode)
```

Everything the guest can reach now comes from `env`. Give it the stdlib it needs, stub the
host API, and log.

## Getting execution to survive

Most of the effort is keeping the script alive long enough to be interesting. Four things
mattered:

**Stubs must be callable *and* indexable.** Return a bare function and `SomeGlobal.field`
throws; return a bare table and `SomeGlobal()` throws. Scripts do both, and once a decrypted
name reaches an unstubbed global you get
`attempt to index a function value (field '?')` with no name in the message, because the
name came from a constant rather than the source. Use one object with `__call`, `__index`,
`__concat`, `__len`, `__tostring` and arithmetic metamethods.

**Return types steer control flow.** A native that returns a number where the script
expects one is worth more than ten stubs. `GetGameTimer`, `PlayerPedId`, `DoesEntityExist`,
`GetEntityHealth` and friends need plausible concrete values or the script takes a branch
you didn't want. Getting this set wrong is the usual reason a run dies in the first handful
of steps.

**Coroutines need driving.** `Citizen.CreateThread(fn)` bodies are where the real logic is,
and they only get there after several `Wait()` calls. Collect them as coroutines, then
resume in rounds until none are suspended:

```lua
for pass = 1, 120 do
  local alive = false
  for _, th in ipairs(threads) do
    if coroutine.status(th) == 'suspended' then
      alive = true
      coroutine.resume(th)
    end
  end
  if not alive then break end
end
```

**Watch for handshake spin-loops.** This is the one that cost me the most time. A script
sat in `while not GlobalState[someKey] do Wait(10) end` waiting on a value its server
normally replicates. Returning `nil` from the state bag meant it never initialised. Answering
with any plausible string took recovered strings on that sample from 306 to 1,743. If your
trace is an endless repeat of two log lines, you are in one of these.

`debug.getinfo` also has to answer rather than be absent — the interpreter reads
`linedefined`, `short_src`, `currentline`, `namewhat`, `isvararg`, `nparams` for its own
error paths. Forward it to the real one.

## Reading out the constants

The interpreter caches materialised constants in tables held by its closures, so you can
recover them without understanding the opcode format at all. Walk the entry function's
upvalues transitively:

```lua
local seen = {}
local function walk(v, depth)
  if depth > 16 then return end
  local t = type(v)
  if t == 'string' then collect(v)
  elseif t == 'table' then
    if seen[v] then return end
    seen[v] = true
    for k, vv in next, v do walk(k, depth+1) walk(vv, depth+1) end
    local mt = debug.getmetatable(v)
    if mt then walk(mt, depth+1) end
  elseif t == 'function' then
    if seen[v] then return end
    seen[v] = true
    for i = 1, 255 do
      local n, uv = debug.getupvalue(v, i)
      if not n then break end
      walk(uv, depth+1)
    end
  end
end
```

Skip your own stub objects during the walk (tag them with a metafield) or you'll drown in
your own scaffolding.

Wrapping the `string` library as a second capture point is worth it — every function, first
argument in and all string results out. Constants that were only touched on a path the walk
didn't reach still show up there. Same for `table.concat`.

Two caveats:

- **Decryption is on-demand.** You only recover constants on paths that actually executed.
  Deeper execution means more strings; there is no shortcut that dumps them all.
- Non-printable results are not necessarily VM-encrypted. In one sample ~2,300 binary
  strings turned out to be the *application's* own encrypted data, not Luraph's — v14.7
  stores its string constants in the clear (see [vm-layer.md](vm-layer.md)).

## Reading out the program

Because operands are pre-decoded into parallel per-instruction arrays, the same walk
recovers the decoded program. Collect dense integer-keyed tables instead of strings and
group them by element count: each proto contributes several arrays of identical length, one
of which holds opcodes in the handler's value range.

On one 399 KB bytecode blob that produced 1,733 arrays in 313 same-length groups. Jump
targets are already absolute, because the loader resolves them (`j[w] = w + h`).

This is the input a disassembler wants, and it costs nothing beyond the walk you already
wrote.

## Containment

`load` on a *binary* chunk can escape anything you build out of `_ENV`, so this is not a
security boundary. What I did as the floor:

- never put `io`, `os.execute`, `package`, `require`, `dofile` or `loadfile` in `env`
- pass through only `os.time`, `os.clock`, `os.date`
- wrap `load` so nested chunks are written to disk and inspected, not silently run
- stub HTTP so requests are logged and dropped, then invoke the callback with a failure so
  retry paths still get exercised

For genuinely untrusted samples, run the whole thing in a throwaway VM or container. A
`_ENV` swap keeps an honest script from reaching the host; it does not stop one that is
trying to.

One practical note: log to a file and cap it. A script that retries a network call on a
short timer will produce gigabytes overnight. Mine hit 17 MB in about 90 seconds before I
noticed it was looping on a dashboard retry.
