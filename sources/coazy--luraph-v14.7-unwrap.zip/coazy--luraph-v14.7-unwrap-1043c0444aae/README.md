# Luraph v14.7 — notes and tooling

Notes from taking apart the Luraph Obfuscator v14.7 protection layer on some FiveM Lua
resources, plus the scripts I used. Written down because the public tooling I could find
targets the older v14.4.x / `initv4` family and none of it handles 14.7.

Scope, up front: **this unwraps the envelope and gets you the interpreter and the bytecode.
It does not give you the original source back.** See [what's not here](#whats-not-here).

## Layers

```
protected.lua
 └─ base85 envelope            (loader is in the clear)
     └─ raw LZMA1              (lc=3 lp=0 pb=0, no props byte, no size field)
         ├─ literal 1 -> VM interpreter, plain loadable Lua (~40 KB)
         └─ literal 2 -> VM bytecode for your script (60 KB – 400 KB)
```

Full derivation in [docs/envelope.md](docs/envelope.md).

## Usage

Needs Node 18+ and Lua 5.4.

```sh
# strip the envelope
node tools/lph-unwrap.js protected.lua out/
# -> out/protected.lua.stage1.bin   the interpreter, readable Lua
# -> out/protected.lua.stage2.bin   the bytecode

# run the interpreter under a fake host and dump what it decrypts
lua tools/sandbox.lua out/ protected.lua
# -> out/strings.txt   printable constants recovered
# -> out/calls.txt     host API calls with arguments
# -> out/sandbox.log   full trace
```

Chunks that install globals for later chunks have to run in the same environment, in load
order:

```sh
lua tools/sandbox.lua out/ include.lua,main.lua
```

For JS protected with the `vmm_*` VM obfuscator, the bytecode is base64 and its constants
are **not** encrypted, so this is usually enough to reconstruct each export:

```sh
node tools/jsvm-strings.js protected.js out.txt
```

## Docs

| | |
|---|---|
| [envelope.md](docs/envelope.md) | base85 + LZMA1 spec, byte order, the inert decoy checks |
| [vm-layer.md](docs/vm-layer.md) | anti-analysis techniques, bytecode encoding, opcode semantics |
| [instrumentation.md](docs/instrumentation.md) | running the VM under a fake `_ENV`, recovering constants and the decoded program |

## Notes worth skipping to

**Byte order in the base85 pass.** Digits are big-endian within each 5-char group, but the
resulting word is packed *little*-endian (`string.pack("<I4", n)`). If your output is
plausible-length garbage that never decompresses, this is why.

**The LZMA stream has no header.** Parameters are baked into the loader. To use an existing
library rather than reimplementing, synthesise props = `(pb*5 + lp)*9 + lc` = `3`, a
dictionary size, then `0xFFFFFFFFFFFFFFFF` for unknown size.

**Keep range/code as doubles if you reimplement in JS.** `code << 8` overflows 32 bits and
JS bitwise operators truncate it silently. Same for `(2 | (slot & 1)) << nDirect`, which
reaches `3 << 30`.

**v14.7 does not encrypt string constants.** The reader slices straight out of the payload
(`string.sub(bytecode, from, to)`). If strings in your sample still look encrypted, that's
the application encrypting its own data, which is a different problem.

**The interpreter is a register machine with pre-decoded operands.** Handlers read
`w[Z[I]] = w[j[I]] - w[i[I]]` and similar — operands live in parallel arrays indexed by
instruction number, not bit-packed. Jump targets are resolved to absolute indices at load
time. 56 opcodes in the range 4–240 on the sample I measured.

**You can read the decoded program out of live tables.** Because of the above, walking the
entry closure's upvalues recovers instructions and operands without parsing bytecode at all.
One 399 KB blob gave up 1,733 dense integer arrays in 313 same-length groups — 313 protos
with operands intact.

**Most of the source volume is inert.** Opaque predicates like
`-1835367654 + (((u[13529]==u[14976] and u[13529] or u[1164]) >= u[6244] ...) >> u[22229])`
fold to one integer on first execution and are memoised. They have no data dependency on the
program. Don't try to evaluate them.

**Watch for shadowed identifiers.** The interpreter rebinds names inside a single scope —
`L` is `string.byte`, then the range coder's `code`, then a bittree decoder — and closures
built before each rebinding keep the earlier one. It's deliberate and it will make you
mis-transcribe things.

## What's not here

No lifter, no decompiler. Getting from bytecode to readable Lua means mapping the opcode set,
building an IR, then structuring control flow and re-nesting expressions. The disassembly
half has no research risk in it and is a reasonable next step. The decompiler half is real
work.

And even a perfect decompiler doesn't return the original file. Local names, comments and
formatting are discarded at protect time and are not in the artifact. You'd get
machine-generated Lua that behaves the same way.

If you only need to know what a resource *does* — what it calls, what it sends, what it
collects — the instrumentation route answers that faster and more reliably than either.

## Licence

MIT, see [LICENSE](LICENSE). Interoperability and security-review work on code you are
entitled to analyse. Don't use it to redistribute someone else's software.
