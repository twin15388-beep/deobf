# Changelog

## 0.1.0

Initial release.

- Lua 5.1/5.2 lexer, recursive-descent parser, AST, and formatting unparser
  (parse ⇄ unparse verified as a fixed point over a grammar corpus).
- Reversal passes: `unwrap` (WrapInFunction), `anti_tamper`, `constant_fold`
  (NumbersToExpressions / strcat SplitStrings), `encrypt_strings` (full
  keystream port), `constant_array` (rotation + base64, alphabet-aware),
  `proxify_locals` (partial), `dead_code`, `cleanup`, `rename`.
- `Vmify` handling:
  - `vm_lift` — symbolic register execution + upvalue/closure reconstruction +
    dominator-based control-flow structuring → readable Lua.
  - `devirtualize` — dispatcher de-flattening fallback.
- CLI (`unprom`, `python -m unprom`, `python unprom.py`) with `--devirt`,
  `--rename`, `--passes`, `--skip`, `--verbose`.
- Verified end to end against a real ~76-block wearedevs.net-obfuscated sample
  (`ConstantArray(base64) + EncryptStrings + Vmify`).
