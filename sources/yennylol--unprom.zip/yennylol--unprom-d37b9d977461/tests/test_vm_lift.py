"""VM lifter checks against hand-compiled Vmify fixtures."""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from unprom.parser import parse                       # noqa: E402
from unprom.unparser import unparse                   # noqa: E402
from unprom.pipeline import Pipeline, PassContext     # noqa: E402
from unprom.passes import vm_lift                     # noqa: E402

FIX = os.path.join(os.path.dirname(__file__), "fixtures")
_res = []


def check(name, cond, detail=""):
    _res.append((name, bool(cond)))
    print(f"{'PASS' if cond else 'FAIL':5} {name}" + (f"   >>> {detail}" if not cond else ""))


def lift(fixture):
    src = open(os.path.join(FIX, fixture), encoding="utf-8").read()
    ch = parse(src)
    ctx = PassContext(options={"devirt": "on"})
    ch = vm_lift.run(ch, ctx)
    return unparse(ch), ctx


def norm(s):
    return " ".join(s.split())


def test_hello():
    out, ctx = lift("vm_hello.lua")
    check("hello lifted", ctx.stats.get("vm_lifted") == 1, "; ".join(ctx.notes))
    check("hello body", norm(out) == 'print("hello") return 42', out)


def test_ifelse():
    out, ctx = lift("vm_ifelse.lua")
    n = norm(out)
    check("ifelse lifted", ctx.stats.get("vm_lifted") == 1)
    check("ifelse has function+if", "function(a1)" in n
          and "if a1 > 5 then" in n and 'return "big"' in n
          and 'return "small"' in n, out)
    check("ifelse re-parses", parse(out) is not None)


def test_while():
    out, ctx = lift("vm_while.lua")
    n = norm(out)
    check("while lifted", ctx.stats.get("vm_lifted") == 1)
    check("while recovered", "while c1 < a1 do" in n and "c1 = c1 + 1" in n
          and "return c1" in n, out)
    check("while re-parses", parse(out) is not None)


def test_while_full_pipeline_merges_decl():
    src = open(os.path.join(FIX, "vm_while.lua"), encoding="utf-8").read()
    out, ctx = Pipeline().run(src)
    check("pipeline merges local decl", "local c1 = 0" in " ".join(out.split()), out)


def test_real_wearedevs_mm2():
    """A real script from wearedevs.net's obfuscator v1.0.0 (a Prometheus
    fork): ConstantArray(base64) + EncryptStrings + Vmify, ~76 VM blocks.

    The fixture is user-supplied and git-ignored (see tests/fixtures/README.md);
    this test is skipped when it is absent so the suite stays green on a fresh
    clone."""
    path = os.path.join(FIX, "real_wearedevs_mm2.lua")
    if not os.path.exists(path):
        print("SKIP  test_real_wearedevs_mm2 (fixture not present)")
        return
    src = open(path, encoding="utf-8").read()
    out, ctx = Pipeline().run(src)
    check("real: vm lifted", ctx.stats.get("vm_lifted") == 1, "; ".join(ctx.notes[-3:]))
    check("real: output re-parses", _reparses(out), out[:200])
    n = norm(out)
    check("real: globals resolved", "string" in n and "math" in n
          and "pcall(" in n)
    check("real: payload visible",
          "queue_on_teleport" in n and "_G[" in n, out[-400:])
    # upvalue-table indexing still leaks where cell recognition misses (known
    # limitation) - this is a regression guard, not an aspiration
    check("real: upvalue-table leakage bounded",
          n.count("t[") <= 260, f"t[ count = {n.count('t[')}")
    check("real: no leftover factory calls",
          not any(f"{c}(" in n and f"{c}(11" in n for c in "FUyIKj"))


def _reparses(s):
    try:
        parse(s)
        return True
    except Exception:  # noqa: BLE001
        return False


def test_non_vm_untouched():
    src = "local a = 1\nlocal function f(x) return x + a end\nreturn f(2)\n"
    baseline = unparse(parse(src))
    ch = parse(src)
    ctx = PassContext(options={"devirt": "on"})
    ch = vm_lift.run(ch, ctx)
    check("non-VM code untouched", unparse(ch) == baseline
          and "vm_lifted" not in ctx.stats, unparse(ch))


if __name__ == "__main__":
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            print(f"== {name} ==")
            try:
                fn()
            except Exception as exc:  # noqa: BLE001
                check(name + " (crash)", False, repr(exc))
    bad = [r for r in _res if not r[1]]
    print(f"\n{len(_res)} checks, {len(bad)} failed")
    sys.exit(1 if bad else 0)
