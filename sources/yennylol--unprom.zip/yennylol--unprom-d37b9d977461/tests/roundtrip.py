"""parse -> unparse -> re-parse fixed-point check over corpus/.

Guarantees the front end and back end agree: every corpus file must parse,
unparse, re-parse, and produce byte-identical output the second time round.
"""

from __future__ import annotations

import glob
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from unprom.parser import parse        # noqa: E402
from unprom.unparser import unparse    # noqa: E402


def check(path):
    src = open(path, "r", encoding="utf-8", errors="replace").read()
    try:
        a1 = parse(src)
    except Exception as e:  # noqa: BLE001
        return "PARSE-FAIL", repr(e)
    try:
        out1 = unparse(a1)
    except Exception as e:  # noqa: BLE001
        return "UNPARSE-FAIL", repr(e)
    try:
        a2 = parse(out1)
    except Exception as e:  # noqa: BLE001
        return "REPARSE-FAIL", repr(e)
    if unparse(a2) != out1:
        return "NOT-STABLE", "second emit differs"
    return "OK", f"{len(out1)} bytes"


def main() -> int:
    targets = sys.argv[1:] or glob.glob(
        os.path.join(os.path.dirname(__file__), "..", "corpus", "*.lua"))
    fails = 0
    for t in sorted(targets):
        status, detail = check(t)
        fails += status != "OK"
        print(f"{status:14} {os.path.basename(t):32} {detail}")
    print(f"\n{len(targets)} files, {fails} failures")
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
