"""Run every test module in this folder. Exit non-zero if any fails."""
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
MODULES = ["roundtrip.py", "test_passes.py", "test_vm_lift.py", "test_e2e.py"]


def main() -> int:
    rc = 0
    for m in MODULES:
        print("\n" + "=" * 70)
        print(f"RUN {m}")
        print("=" * 70)
        p = subprocess.run([sys.executable, os.path.join(HERE, m)])
        rc |= p.returncode
    print("\n" + ("ALL GREEN" if rc == 0 else "SOME TESTS FAILED"))
    return rc


if __name__ == "__main__":
    sys.exit(main())
