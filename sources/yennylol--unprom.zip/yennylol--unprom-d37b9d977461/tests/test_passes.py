import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from unprom.parser import parse                       # noqa: E402
from unprom.unparser import unparse                   # noqa: E402
from unprom.pipeline import Pipeline, PassContext     # noqa: E402
from unprom.prng import encrypt, decrypt              # noqa: E402
from unprom.passes import constant_fold, wrap_in_function, anti_tamper  # noqa: E402
from unprom.passes import encrypt_strings, constant_array, devirtualize  # noqa: E402

FIX = os.path.join(os.path.dirname(__file__), "fixtures")
_results = []


def check(name, cond, detail=""):
    _results.append((name, bool(cond), detail))
    print(f"{'PASS' if cond else 'FAIL':5} {name}  {detail}")


def one_pass(fn, src):
    chunk = parse(src)
    ctx = PassContext()
    chunk = fn(chunk, ctx) or chunk
    return unparse(chunk), ctx


# --------------------------------------------------------------------------
def test_prng_roundtrip():
    consts = (41, 24691, 2, 173)
    for seed in (1, 2, 999983, 35184372088831):
        for text in ("hello world", "print", "", "\x00\xff\x10abc", "A" * 50):
            enc = encrypt(text, seed, *consts)
            dec = decrypt(enc, seed, *consts)
            check(f"prng roundtrip seed={seed} len={len(text)}", dec == text,
                  repr(dec[:20]))


def test_constant_fold():
    src = "local x = (2 + 3) * 4 - 1\nlocal s = 'a' .. 'b' .. 'c'\n" \
          "return x, s, not not not true, (1 == 1) and 'y' or 'n'\n"
    out, ctx = one_pass(constant_fold.run, src)
    check("fold arithmetic -> 19", "= 19" in out, out.strip())
    check("fold concat -> 'abc'", '"abc"' in out, out.strip())
    check("fold not chain -> false", "false" in out, out.strip())
    check("fold ternary -> 'y'", '"y"' in out and '"n"' not in out, out.strip())


def test_wrap_in_function():
    src = "return (function(...) local a = 1 return a + 41 end)(...)\n"
    out, ctx = one_pass(wrap_in_function.run, src)
    check("unwrap removes wrapper", out.strip().startswith("local a = 1"),
          out.strip())
    check("unwrap counted", ctx.stats.get("wrap_layers_removed") == 1)

    src2 = "return (function(...) return (function(...) return 5 end)(...) end)(...)\n"
    out2, ctx2 = one_pass(wrap_in_function.run, src2)
    check("unwrap nested x2", ctx2.stats.get("wrap_layers_removed") == 2, out2.strip())


def test_anti_tamper():
    src = ("do local valid = true\n"
           "  local x = debug and debug.sethook\n"
           "  repeat until valid\n"
           "  error('Tamper Detected!')\n"
           "end\n"
           "print('real code')\n")
    out, ctx = one_pass(anti_tamper.run, src)
    check("anti_tamper drops block", "valid" not in out and "real code" in out,
          out.strip())


def test_encrypt_strings():
    tmpl = open(os.path.join(FIX, "encrypt_strings_template.lua"),
                encoding="utf-8").read()
    mul45, add45, mul8, key8 = 41, 24691, 2, 173
    seeds = [111, 222, 333]
    secrets = ["print", "Hello, Prometheus!", "http://example.com/path"]
    body_lines = []
    for i, (txt, seed) in enumerate(zip(secrets, seeds)):
        enc = encrypt(txt, seed, mul45, add45, mul8, key8)
        esc = enc.encode("latin-1").decode("unicode_escape") if False else _luaescape(enc)
        body_lines.append(f'local v{i} = S[D("{esc}", {seed})]')
    body_lines.append("return v0, v1, v2")
    src = (tmpl.replace("__MUL45__", str(mul45)).replace("__ADD45__", str(add45))
           .replace("__MUL8__", str(mul8)).replace("__KEY8__", str(key8))
           .replace("__BODY__", "\n".join(body_lines)))
    out, ctx = one_pass(encrypt_strings.run, src)
    for txt in secrets:
        check(f"decrypt recovers {txt!r}", txt in out, "")
    check("decrypt count == 3", ctx.stats.get("strings_decrypted") == 3, "")
    check("prelude removed", "setmetatable" not in out and "35184372088832" not in out,
          out.strip()[:120])


def _luaescape(s: str) -> str:
    out = []
    for ch in s:
        o = ord(ch)
        if ch == '"':
            out.append('\\"')
        elif ch == "\\":
            out.append("\\\\")
        elif 32 <= o < 127:
            out.append(ch)
        else:
            out.append("\\%03d" % o)
    return "".join(out)


def test_constant_array():
    # local wrapper disabled, base64 disabled (Encoding="none"): array holds raw
    # strings, wrapper returns ARR[a - OFFSET], one rotation applied.
    src = (
        'local ARR = {"charlie", "alpha", "bravo"}\n'
        'for i, v in ipairs({{1, 3}, {1, 1}, {2, 3}}) do\n'
        '  while v[1] < v[2] do\n'
        '    ARR[v[1]], ARR[v[2]], v[1], v[2] = ARR[v[2]], ARR[v[1]], v[1] + 1, v[2] - 1\n'
        '  end\n'
        'end\n'
        'local function W(a) return ARR[a - 1000] end\n'
        'return W(1001), W(1002), W(1003)\n'
    )
    out, ctx = one_pass(constant_array.run, src)
    check("constant_array inlines values",
          all(s in out for s in ('"alpha"', '"bravo"', '"charlie"')), out.strip())
    check("constant_array drops ARR decl", "ARR" not in out, out.strip())


def test_devirtualize_deflatten():
    src = open(os.path.join(FIX, "vm_container.lua"), encoding="utf-8").read()
    out, ctx = one_pass(devirtualize.run, src)
    check("vm container detected", ctx.stats.get("vm_containers_deflattened") == 1,
          "; ".join(ctx.notes))
    check("flat dispatch emitted",
          "pos == 0" in out and "pos == 1" in out and "pos == 2" in out
          and "pos == 3" in out, out)
    check("search-tree bounds gone", "pos < 700" not in out and "pos < 300" not in out,
          out)
    check("transition 500 -> index 1", "pos = 1" in out, out)
    check("transition (reg1 and 2 or 3)", "reg1 and 2 or 3" in out, out)
    check("entry remapped to 1", "(500, {})" not in out and "(1, {})" in out, out)
    # must still re-parse
    reparsed = parse(out)
    check("devirt output re-parses", reparsed is not None)


def _prom_b64encode(s: str, alphabet: str) -> str:
    """Faithful port of ConstantArray.encode (base64 branch)."""
    bits = "".join(f"{b:08b}" for b in s.encode("latin-1")) + "0000"
    out = []
    i = 0
    while i < len(bits):
        grp = bits[i:i + 6]
        i += 6
        if len(grp) < 6:
            continue
        out.append(alphabet[int(grp, 2)])
    pad = ("", "==", "=")[len(s) % 3]
    return "".join(out) + pad


def test_constant_array_base64():
    from unprom.passes.constant_array import _b64decode
    alphabet = ("QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiop"
                "asdfghjklzxcvbnm0123456789+/")
    assert len(alphabet) == 64
    for txt in ["alpha", "bravo", "charlie", "x", "print!!", "a longer string here"]:
        enc = _prom_b64encode(txt, alphabet)
        dec = _b64decode(enc, alphabet)
        check(f"b64 roundtrip {txt!r}", dec == txt, repr(dec))

    lookup_entries = ", ".join(f'["{c}"] = {i}' for i, c in enumerate(alphabet))
    strs = ["hello", "world", "lua"]
    arr = ", ".join(f'"{_prom_b64encode(s, alphabet)}"' for s in strs)
    src = (
        f"local ARR = {{{arr}}}\n"
        f"local function W(a) return ARR[a + 5] end\n"
        "do\n"
        f"  local lookup = {{{lookup_entries}}}\n"
        "  for i = 1, #ARR do\n"
        "    local data = ARR[i]\n"
        "    if type(data) == 'string' then\n"
        "      local v = 0 % 65536\n"       # carry the 65536 marker
        "      ARR[i] = data\n"
        "    end\n"
        "  end\n"
        "end\n"
        "return W(-4), W(-3), W(-2)\n"
    )
    out, ctx = one_pass(constant_array.run, src)
    check("b64 array decoded+inlined",
          all(f'"{s}"' in out for s in strs), out.strip())


def test_full_pipeline_smoke():
    src = "return (function(...) local x = 1 + (2 + 3) return x end)(...)\n"
    text, ctx = Pipeline().run(src)
    check("pipeline smoke", "= 6" in text or "6" in text, text.strip())


if __name__ == "__main__":
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            print(f"\n== {name} ==")
            try:
                fn()
            except Exception as exc:  # noqa: BLE001
                check(name + " (crashed)", False, repr(exc))
    failed = [r for r in _results if not r[1]]
    print(f"\n{len(_results)} checks, {len(failed)} failed")
    sys.exit(1 if failed else 0)
