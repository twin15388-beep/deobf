"""End-to-end: build a Prometheus-style obfuscated script from parts, then run
the full pipeline and check the payload is recovered."""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from unprom.pipeline import Pipeline           # noqa: E402
from unprom.parser import parse                # noqa: E402
from unprom.prng import encrypt                # noqa: E402

FIX = os.path.join(os.path.dirname(__file__), "fixtures")
_res = []


def check(name, cond, detail=""):
    _res.append((name, bool(cond)))
    print(f"{'PASS' if cond else 'FAIL':5} {name}   {detail if not cond else ''}")


def _lua_str(s: str) -> str:
    o = []
    for ch in s:
        c = ord(ch)
        if ch == '"':
            o.append('\\"')
        elif ch == "\\":
            o.append("\\\\")
        elif 32 <= c < 127:
            o.append(ch)
        else:
            o.append("\\%03d" % c)
    return '"' + "".join(o) + '"'


def build_obfuscated() -> str:
    tmpl = open(os.path.join(FIX, "encrypt_strings_template.lua"), encoding="utf-8").read()
    m45, a45, m8, k8 = 41, 24691, 2, 173
    parts = {
        "Hello, ": 101,
        "world!": 202,
        "print": 303,
    }
    decl = []
    for i, (txt, seed) in enumerate(parts.items()):
        enc = encrypt(txt, seed, m45, a45, m8, k8)
        decl.append(f'local s{i} = S[D({_lua_str(enc)}, {seed})]')
    # numbers-to-expressions style payload; strings via the decrypt table
    body = "\n".join(decl) + "\n" + (
        "local answer = (40 + 2) - (0 + 0)\n"
        "local fn = _G[s2]\n"
        "fn(s0 .. s1)\n"
        "return answer\n"
    )
    prelude = (tmpl.replace("__MUL45__", str(m45)).replace("__ADD45__", str(a45))
               .replace("__MUL8__", str(m8)).replace("__KEY8__", str(k8))
               .replace("__BODY__", body))
    # wrap twice
    wrapped = f"return (function(...) {prelude}\n end)(...)"
    wrapped = f"return (function(...) {wrapped}\n end)(...)"
    return wrapped


def test_e2e_recovers_payload():
    obf = build_obfuscated()
    parse(obf)  # sanity: fixture is valid Lua
    text, ctx = Pipeline(options={"rename": "auto"}).run(obf)
    print("\n----- deobfuscated -----\n" + text + "\n------------------------")
    check("wrapper layers removed", ctx.stats.get("wrap_layers_removed") == 2,
          str(ctx.stats))
    check("strings decrypted", ctx.stats.get("strings_decrypted") == 3, str(ctx.stats))
    check("recovers 'Hello, '", "Hello, " in text)
    check("recovers 'world!'", "world!" in text)
    check("recovers 'print'", '"print"' in text)
    check("folds 40+2 -> 42", "42" in text and "40 + 2" not in text)
    check("no decryptor residue", "35184372088832" not in text
          and "setmetatable" not in text)
    check("output re-parses", parse(text) is not None)


if __name__ == "__main__":
    for n, f in sorted(globals().items()):
        if n.startswith("test_") and callable(f):
            print(f"== {n} ==")
            try:
                f()
            except Exception as exc:  # noqa: BLE001
                check(n + " (crash)", False, repr(exc))
    bad = [r for r in _res if not r[1]]
    print(f"\n{len(_res)} checks, {len(bad)} failed")
    sys.exit(1 if bad else 0)
