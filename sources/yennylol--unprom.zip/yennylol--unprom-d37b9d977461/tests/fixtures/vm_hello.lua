-- Hand-compiled the way Prometheus' Vmify would emit  `print("hello") return 42`:
-- container C(pos,args,upvals,gc), balanced search tree over block ids
-- 1000 / 3000 / 7000, register locals r0..r2, ENV global lookups, ret table.
return (function(env, unpack, newproxy, setmetatable, getmetatable, select, arg, C)
	C = function(pos, args, upvals, gc)
		local ret, r0, r1, r2
		while pos do
			if pos < 5000 then
				if pos < 2500 then
					r0 = "print"
					r0 = env[r0]
					r1 = "hello"
					r2 = r0(r1)
					r2 = nil
					pos = 7000
				else
					r0 = 42
					ret = { r0 }
					r0 = nil
					pos = env["qwertyuiopas"]
				end
			else
				pos = 3000
			end
		end
		pos = #gc
		return unpack(ret)
	end
	return (function(p, u)
		return (function(...)
			return C(p, { ... }, u, nil)
		end)
	end)(1000, {})(unpack(arg))
end)(getfenv and getfenv() or _ENV, unpack or table.unpack, newproxy, setmetatable, getmetatable, select, { ... })
