-- Hand-compiled Vmify of:
--   local function classify(n)
--     if n > 5 then return "big" end
--     return "small"
--   end
--   classify(10)
-- Blocks: TOP=1000, classify-entry=4000, then=6000, final=8000
return (function(env, unpack, newproxy, setmetatable, getmetatable, select, arg,
		C, mkcl, UPV, RC, allocupv, cuid, upf, gcf, freeupv)
	C, mkcl, UPV, RC, allocupv, cuid, upf, gcf, freeupv =
		function(pos, args, upvals, gc)
			local ret, r0, r1, r2, r3
			while pos do
				if pos < 5000 then
					if pos < 2500 then
						r0 = mkcl(4000, {})
						r1 = r0(10)
						r1 = nil
						r0 = nil
						pos = env["zzexitaaa12"]
						ret = {}
					else
						r1 = args[1]
						r2 = r1 > 5
						pos = (r2 and 6000 or 8000)
					end
				else
					if pos < 7000 then
						ret = { "big" }
						pos = env["zzexitbbb34"]
					else
						ret = { "small" }
						pos = env["zzexitccc56"]
					end
				end
			end
			pos = #gc
			return unpack(ret)
		end,
		function(p, u) return (function(...) return C(p, { ... }, u, nil) end) end,
		{}, {},
		function() cuid = cuid + 1 RC[cuid] = 1 return cuid end,
		0,
		function(e) return e end,
		function(s) end,
		function(a) end
	return mkcl(1000, {})(unpack(arg))
end)(getfenv and getfenv() or _ENV, unpack or table.unpack, newproxy, setmetatable,
	getmetatable, select, { ... })
