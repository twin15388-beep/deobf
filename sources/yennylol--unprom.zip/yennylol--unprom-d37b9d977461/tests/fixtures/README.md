# Test fixtures

| file | what it is |
|------|------------|
| `encrypt_strings_template.lua` | the `EncryptStrings` prelude template, filled in by `test_passes.py` |
| `vm_hello.lua` / `vm_ifelse.lua` / `vm_while.lua` / `vm_container.lua` | hand-compiled miniature `Vmify` outputs that mirror `compiler.lua` codegen |
| `real_wearedevs_mm2.lua` | **not committed** — a real obfuscated script |

## Adding a real sample

`tests/test_vm_lift.py::test_real_wearedevs_mm2` runs the full pipeline against
`real_wearedevs_mm2.lua` and asserts the key recoveries. That file is
**git-ignored** because real samples tend to carry identifiers / tokens. Drop
any Prometheus- or wearedevs-obfuscated `.lua` in as `real_wearedevs_mm2.lua`
and the test activates; without it the test is skipped.
