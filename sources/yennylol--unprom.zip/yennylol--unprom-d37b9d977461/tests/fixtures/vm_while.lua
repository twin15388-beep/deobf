-- Hand-compiled Vmify of:
--   local function count(n)
--     local i = 0
--     while i < n do i = i + 1 end
--     return i
--   end
--   count(3)
-- Blocks: TOP=1000 CE=3000 CHECK=5000 INNER=7000 FINAL=9000
return (function(env, unpack, newproxy, setmetatable, getmetatable, select, arg,
		C, mkcl, UPV, RC, allocupv, cuid, upf, gcf, freeupv)
	C, mkcl, UPV, RC, allocupv, cuid, upf, gcf, freeupv =
		function(pos, args, upvals, gc)
			local ret, t0, t1, c0, c1, c2
			while pos do
				if pos < 6000 then
					if pos < 4000 then
						if pos < 2000 then
							t0 = mkcl(3000, {})
							t1 = t0(3)
							t1 = nil
							t0 = nil
							pos = env["zexittop110"]
							ret = {}
						else
							c0 = args[1]
							c1 = 0
							pos = 5000
						end
					else
						c2 = c1 < c0
						pos = (c2 and 7000 or 9000)
					end
				else
					if pos < 8000 then
						c1 = c1 + 1
						pos = 5000
					else
						ret = { c1 }
						pos = env["zexitfin990"]
					end
				end
			end
			pos = #gc
			return unpack(ret)
		end,
		function(p, u) return (function(...) return C(p, { ... }, u, nil) end) end,
		{}, {}, function() cuid = cuid + 1 RC[cuid] = 1 return cuid end, 0,
		function(e) return e end, function(s) end, function(a) end
	return mkcl(1000, {})(unpack(arg))
end)(getfenv and getfenv() or _ENV, unpack or table.unpack, newproxy, setmetatable,
	getmetatable, select, { ... })
