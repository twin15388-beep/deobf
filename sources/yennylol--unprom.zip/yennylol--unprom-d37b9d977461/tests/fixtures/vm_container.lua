-- Hand-built miniature of a Prometheus Vmify container: a balanced binary
-- search tree over four shuffled block ids (100, 500, 900, 1300) with a flat
-- register set.  Exercises the dispatch de-flattener.
return (function(unpack, arg)
	local C
	C = function(pos, args, upvals, gc)
		local ret, reg1, reg2
		while pos do
			if pos < 700 then
				if pos < 300 then
					reg1 = 5
					pos = 500
				else
					pos = (reg1 and 900 or 1300)
				end
			else
				if pos < 1100 then
					ret = { reg1 }
					pos = nil
				else
					reg2 = 7
					pos = 100
				end
			end
		end
		pos = #gc
		return unpack(ret)
	end
	return (function(p, u)
		return (function(...)
			return C(p, { ... }, u, nil)
		end)
	end)(500, {})(unpack(arg))
end)(unpack, { ... })
