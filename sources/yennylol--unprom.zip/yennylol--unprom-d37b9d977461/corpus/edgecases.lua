-- Parser edge cases: call/index chains, parenthesised prefixes, string calls,
-- table calls, ambiguous statement boundaries, trailing semicolons.

local m = { fn = function() return { x = 10 } end }

local a = m.fn().x
local b = ("literal"):upper()
local c = ({ 1, 2, 3 })[2]
local d = m["fn"]()["x"]

print "string call"
print { "table", "call" }
print("normal")("chained")

local e = (function() return 1, 2, 3 end)()
local f = { (function() return 1, 2, 3 end)() }

;(function() end)()

local g = 1;
local h = 2;

local neg = - - -1
local nn = not not true
local pw = 2 ^ 2 ^ 3
local cc = "a" .. "b" .. "c" .. 1 .. 2

return a, b, c, d, e, f, g, h, neg, nn, pw, cc
