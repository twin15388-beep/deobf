-- A small realistic program: a stack, a tokenizer-ish loop, string work.

local Stack = {}
Stack.__index = Stack

function Stack.new()
  return setmetatable({ items = {}, size = 0 }, Stack)
end

function Stack:push(v)
  self.size = self.size + 1
  self.items[self.size] = v
end

function Stack:pop()
  if self.size == 0 then
    return nil
  end
  local v = self.items[self.size]
  self.items[self.size] = nil
  self.size = self.size - 1
  return v
end

local function split(str, sep)
  local out = {}
  local pattern = "([^" .. sep .. "]+)"
  for piece in string.gmatch(str, pattern) do
    out[#out + 1] = piece
  end
  return out
end

local function evalRPN(expr)
  local s = Stack.new()
  local ops = {
    ["+"] = function(x, y) return x + y end,
    ["-"] = function(x, y) return x - y end,
    ["*"] = function(x, y) return x * y end,
    ["/"] = function(x, y) return x / y end,
  }
  for _, tok in ipairs(split(expr, " ")) do
    local fn = ops[tok]
    if fn then
      local b = s:pop()
      local a = s:pop()
      s:push(fn(a, b))
    else
      s:push(tonumber(tok))
    end
  end
  return s:pop()
end

print(evalRPN("3 4 + 2 *"))
return evalRPN("10 2 / 3 -")
