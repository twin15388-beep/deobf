-- Grammar coverage: literals, operators, precedence, comments.
-- Used by tests/roundtrip.py to check parse -> unparse is a fixed point.

local a = 1 + 2 * 3 - 4 / 2 ^ 2 % 3
local b = -a + #"hello" .. tostring(a)
local c = a == b and "eq" or (a < b and "lt" or "gt")
local d = not (a ~= b) or a >= b and a <= b

local hex = 0xFF + 0x1p4
local float = 3.14159e2
local long = [[
multi
line ]] .. [==[ nested ]] bracket ]==]

local t = {
  1, 2, 3;
  name = "value",
  ["key with spaces"] = true,
  [1 + 1] = "computed",
  nested = { deep = { deeper = {} } },
}

local s1 = "double \"quotes\" and \n\t escapes \65\066\067"
local s2 = 'single \'quotes\' too'

return a, b, c, d, hex, float, long, t, s1, s2
