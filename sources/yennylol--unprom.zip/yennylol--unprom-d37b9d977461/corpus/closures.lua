-- Grammar coverage: closures, upvalues, varargs, multiple assignment.

local function counter(start)
  local n = start or 0
  return function()
    n = n + 1
    return n
  end, function()
    return n
  end
end

local inc, get = counter(10)
inc()
inc()

local function sum(...)
  local total, count = 0, select("#", ...)
  for i = 1, count do
    total = total + (select(i, ...))
  end
  return total, count
end

local a, b, c = sum(1, 2, 3, 4)
local pack = { sum(5, 6, 7) }

local memo = setmetatable({}, {
  __index = function(tbl, k)
    local v = k * k
    rawset(tbl, k, v)
    return v
  end,
})

return get(), a, b, c, pack, memo[9], (function(...) return ... end)(1, 2)
