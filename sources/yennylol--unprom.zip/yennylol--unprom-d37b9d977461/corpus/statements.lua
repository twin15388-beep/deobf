-- Grammar coverage: every statement form.

local x = 0

do
  local scoped = 1
  x = x + scoped
end

while x < 10 do
  x = x + 1
  if x == 5 then
    x = x + 1
  elseif x == 7 then
    break
  else
    x = x - 0
  end
end

repeat
  x = x - 1
until x <= 0

for i = 1, 10, 2 do
  x = x + i
end

for k, v in pairs({ a = 1, b = 2 }) do
  x = x + v
end

local function fact(n)
  if n <= 1 then
    return 1
  end
  return n * fact(n - 1)
end

local obj = {}
function obj.method(self, a, b)
  return a + b
end
function obj:colonMethod(a)
  return self.method(self, a, a)
end

::top::
x = x + 1
if x < 3 then
  goto top
end

return fact(5), obj:colonMethod(2), x
