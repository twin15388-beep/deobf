# Contributing

Thanks for looking. This is a small, dependency-free codebase — easy to hack on.

## Setup

```bash
git clone https://github.com/OWNER/unprom
cd unprom
python tests/run_all.py      # should print ALL GREEN
```

No install needed to develop. `pip install -e .` if you want the `unprom`
console script.

## Layout

See the "Project layout" section of the [README](README.md). In short:

- `unprom/{lexer,parser,ast_nodes,unparser}.py` — the front/back end. Changes
  here must keep `tests/roundtrip.py` a fixed point.
- `unprom/passes/*.py` — one module per technique, each exposing
  `run(chunk, ctx) -> chunk`. Register new passes in `unprom/pipeline.py`.
- `unprom/vm.py` + `unprom/passes/{devirtualize,vm_lift}.py` — the `Vmify`
  handling.

## Adding a pass

1. Create `unprom/passes/yourpass.py` with `def run(chunk, ctx): ...`.
2. Add it to `_load_passes()` and `DEFAULT_PASSES` in `unprom/pipeline.py`.
3. Add a fixture + checks in `tests/test_passes.py`.
4. A pass must **fail safe**: if it can't confidently reverse something, leave
   the tree untouched and `ctx.note(...)` why. The pipeline swallows exceptions,
   but silent corruption is worse than a no-op.

## Tests

- `python tests/run_all.py` runs everything.
- New behaviour needs a test. Hand-compiled VM fixtures live in
  `tests/fixtures/vm_*.lua` and mirror `compiler.lua` codegen.
- Real obfuscated samples are the most valuable thing you can contribute a
  test around — see `tests/fixtures/README.md`. Scrub identifiers/tokens first;
  `real_*.lua` is git-ignored.

## Style

- Standard library only. Keep it that way.
- `from __future__ import annotations` at the top of every module.
- Match the surrounding code; `ruff check .` is advisory (config in
  `pyproject.toml`).
