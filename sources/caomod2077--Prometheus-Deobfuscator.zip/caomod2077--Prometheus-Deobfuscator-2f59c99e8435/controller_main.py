import sys
import json
import os
from datetime import datetime

def make_console_safe(text_value):
    output_encoding = sys.stdout.encoding or 'utf-8'
    return str(text_value).encode(output_encoding, errors='replace').decode(output_encoding, errors='replace')

def main():
    if len(sys.argv) < 2:
        print("Usage: python controller_main.py <lua_file> [--mode=<mode>] [--output=<file>] [--deobf-output=<file>] [--pipeline-dir=<dir>]")
        print("Available modes: strings, patterns, execute, deobfuscate, pipeline, full")
        sys.exit(1)
    
    target_file = sys.argv[1]
    selected_mode = "full"
    output_target = None
    deobf_output_target = None
    pipeline_output_dir = None
    
    for argument in sys.argv[2:]:
        if argument.startswith("--mode="):
            selected_mode = argument.split("=")[1]
        elif argument.startswith("--output="):
            output_target = argument.split("=")[1]
        elif argument.startswith("--deobf-output="):
            deobf_output_target = argument.split("=")[1]
        elif argument.startswith("--pipeline-dir="):
            pipeline_output_dir = argument.split("=")[1]
    
    try:
        from deobfuscator_core import Deobfuscator
        from pattern_scanner import PatternScanner
        from execution_engine import ExecutionEngine
    except ImportError as import_error:
        print(f"Import Error: {import_error}")
        print("Required files: deobfuscator_core.py, pattern_scanner.py, execution_engine.py")
        sys.exit(1)
    
    print(f"Target: {target_file}")
    print(f"Mode: {selected_mode}")
    print("-" * 50)
    
    analysis_results = {
        'target_file': target_file,
        'analysis_timestamp': datetime.now().isoformat(),
        'selected_mode': selected_mode
    }
    
    string_processor = None

    if selected_mode in ["strings", "deobfuscate", "pipeline", "full"]:
        print("\n[String Analysis]")
        string_processor = Deobfuscator()
        string_analysis = string_processor.analyze_script(target_file)
        analysis_results['string_analysis'] = string_analysis
        
        if 'decrypted_strings' in string_analysis:
            string_count = len(string_analysis['decrypted_strings'])
            print(f"  Decrypted strings: {string_count}")
            if string_analysis.get('lookup_function_name'):
                print(f"  Lookup function: {string_analysis['lookup_function_name']} (offset {string_analysis.get('lookup_offset')})")
            for index, string_value in enumerate(string_analysis['decrypted_strings'][:5]):
                preview_text = string_value[:40] + "..." if len(string_value) > 40 else string_value
                print(f"    {index+1}. {make_console_safe(preview_text)}")
            if string_analysis.get('warnings'):
                for warning_message in string_analysis['warnings']:
                    print(f"  Warning: {make_console_safe(warning_message)}")
    
    if selected_mode in ["patterns", "full"]:
        print("\n[Pattern Scan]")
        pattern_scanner = PatternScanner()
        pattern_analysis = pattern_scanner.analyze_target_file(target_file)
        analysis_results['pattern_analysis'] = pattern_analysis
        
        if 'detection_data' in pattern_analysis:
            score_value = pattern_analysis.get('total_score_value', 0)
            risk_level = pattern_analysis.get('risk_assessment', 'Unknown')
            print(f"  Detection Score: {score_value}")
            print(f"  Risk Level: {risk_level}")
            
            detection_items = pattern_analysis.get('detection_data', {})
            for pattern_name, detection_info in list(detection_items.items())[:5]:
                print(f"    {pattern_name}: {detection_info['match_count']} occurrences")
    
    if selected_mode in ["execute", "full"]:
        print("\n[Execution]")
        execution_engine = ExecutionEngine(max_time=10)
        execution_analysis = execution_engine.process_script_file(target_file)
        analysis_results['execution_analysis'] = execution_analysis
        
        exec_details = execution_analysis.get('execution_details', {})
        print(f"  Success: {exec_details.get('successful', False)}")
        print(f"  Duration: {exec_details.get('duration', 0):.3f}s")
        
        if exec_details.get('output_text'):
            output_preview = exec_details['output_text'][:200]
            if len(exec_details['output_text']) > 200:
                output_preview += "..."
            print(f"  Output: {make_console_safe(output_preview)}")

        if exec_details.get('error_text'):
            print(f"  Error: {make_console_safe(exec_details['error_text'].strip())}")

    if selected_mode in ["deobfuscate", "full"]:
        output_processor = Deobfuscator()

        print("\n[Source Output]")
        if not deobf_output_target:
            base_name, _ = os.path.splitext(target_file)
            deobf_output_target = f"{base_name}.deobf.lua"

        deobf_result = output_processor.write_deobfuscated_output(target_file, deobf_output_target)
        analysis_results['deobfuscation_output'] = {
            'output_file': deobf_result.get('output_file'),
            'warning_count': len(deobf_result.get('warnings', []))
        }

        print(f"  Output file: {deobf_result.get('output_file')}")
        if deobf_result.get('warnings'):
            for warning_message in deobf_result['warnings']:
                print(f"  Warning: {make_console_safe(warning_message)}")

    if selected_mode in ["pipeline", "full"]:
        pipeline_processor = Deobfuscator()

        print("\n[Pipeline Output]")
        pipeline_result = pipeline_processor.write_pipeline_outputs(target_file, pipeline_output_dir)
        analysis_results['pipeline_output'] = {
            'output_dir': pipeline_result.get('output_dir'),
            'written_files': pipeline_result.get('written_files', {}),
            'warning_count': len(pipeline_result.get('warnings', []))
        }

        print(f"  Output dir: {pipeline_result.get('output_dir')}")
        for stage_data in pipeline_result.get('stages', []):
            stage_path = pipeline_result.get('written_files', {}).get(stage_data['key'])
            stage_state = "skipped" if stage_data.get('skipped') else "ok"
            print(f"  {stage_data['filename']}: {stage_state}")
            if stage_path:
                print(f"    {stage_path}")
            for warning_message in stage_data.get('warnings', []):
                print(f"    Warning: {make_console_safe(warning_message)}")
    
    print("\n" + "=" * 50)
    print("Analysis Completed")
    
    if output_target:
        with open(output_target, 'w', encoding='utf-8') as f:
            json.dump(analysis_results, f, indent=2, ensure_ascii=False)
        print(f"\nResults saved to: {output_target}")

if __name__ == "__main__":
    main()
