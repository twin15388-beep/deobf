import ast
import base64
import os
import re
import subprocess
from collections import Counter, deque


class Deobfuscator:
    def __init__(self):
        self.decrypted_data = {}
        self.decryption_keys = {}

    def process_base64(self, encoded_data):
        try:
            missing_padding = len(encoded_data) % 4
            if missing_padding:
                encoded_data += '=' * (4 - missing_padding)
            return base64.b64decode(encoded_data).decode('utf-8', errors='ignore')
        except Exception:
            return encoded_data

    def process_hex_data(self, hex_data):
        try:
            if hex_data.startswith('0x'):
                hex_data = hex_data[2:]
            hex_data = re.sub(r'[^0-9A-Fa-f]', '', hex_data)
            if len(hex_data) % 2 != 0:
                hex_data = '0' + hex_data
            return bytes.fromhex(hex_data).decode('utf-8', errors='ignore')
        except Exception:
            return hex_data

    def process_octal_data(self, escaped_data):
        # Lua numeric escapes use decimal byte values, not octal.
        return self.process_string_escapes(escaped_data)

    def apply_xor_cipher(self, input_data, cipher_key):
        try:
            output_chars = []
            key_bytes = str(cipher_key).encode() if not isinstance(cipher_key, bytes) else cipher_key

            for index, char_val in enumerate(input_data):
                key_val = key_bytes[index % len(key_bytes)]
                if isinstance(char_val, str):
                    output_chars.append(chr(ord(char_val) ^ key_val))
                else:
                    output_chars.append(chr(char_val ^ key_val))
            return ''.join(output_chars)
        except Exception:
            return input_data

    def process_string_escapes(self, raw_string):
        escape_replacements = {
            'n': '\n',
            'r': '\r',
            't': '\t',
            '"': '"',
            "'": "'",
            '\\': '\\',
            'a': '\a',
            'b': '\b',
            'f': '\f',
            'v': '\v'
        }

        processed_chars = []
        current_index = 0

        while current_index < len(raw_string):
            current_char = raw_string[current_index]

            if current_char != '\\':
                processed_chars.append(current_char)
                current_index += 1
                continue

            if current_index + 1 >= len(raw_string):
                processed_chars.append('\\')
                break

            next_char = raw_string[current_index + 1]

            if next_char in escape_replacements:
                processed_chars.append(escape_replacements[next_char])
                current_index += 2
                continue

            if next_char == 'x' and current_index + 3 < len(raw_string):
                hex_value = raw_string[current_index + 2:current_index + 4]
                if re.fullmatch(r'[0-9A-Fa-f]{2}', hex_value):
                    processed_chars.append(chr(int(hex_value, 16)))
                    current_index += 4
                    continue

            if next_char.isdigit():
                digit_index = current_index + 1
                digit_buffer = []

                while digit_index < len(raw_string) and raw_string[digit_index].isdigit() and len(digit_buffer) < 3:
                    digit_buffer.append(raw_string[digit_index])
                    digit_index += 1

                processed_chars.append(chr(int(''.join(digit_buffer), 10)))
                current_index = digit_index
                continue

            processed_chars.append(next_char)
            current_index += 2

        return ''.join(processed_chars)

    def _is_string_literal(self, token):
        return len(token) >= 2 and token[0] == token[-1] and token[0] in ('"', "'")

    def _parse_lua_string_literal(self, token):
        return self.process_string_escapes(token[1:-1])

    def _find_matching_delimiter(self, text_content, start_index, open_char='{', close_char='}'):
        depth_level = 0
        in_string = None
        is_escaped = False

        for char_index in range(start_index, len(text_content)):
            current_char = text_content[char_index]

            if in_string:
                if is_escaped:
                    is_escaped = False
                elif current_char == '\\':
                    is_escaped = True
                elif current_char == in_string:
                    in_string = None
                continue

            if current_char in ('"', "'"):
                in_string = current_char
            elif current_char == open_char:
                depth_level += 1
            elif current_char == close_char:
                depth_level -= 1
                if depth_level == 0:
                    return char_index

        return -1

    def _split_top_level_items(self, text_content):
        item_buffer = []
        split_items = []
        paren_depth = 0
        brace_depth = 0
        bracket_depth = 0
        in_string = None
        is_escaped = False

        for current_char in text_content:
            if in_string:
                item_buffer.append(current_char)
                if is_escaped:
                    is_escaped = False
                elif current_char == '\\':
                    is_escaped = True
                elif current_char == in_string:
                    in_string = None
                continue

            if current_char in ('"', "'"):
                in_string = current_char
                item_buffer.append(current_char)
                continue

            if current_char == '(':
                paren_depth += 1
            elif current_char == ')':
                paren_depth -= 1
            elif current_char == '{':
                brace_depth += 1
            elif current_char == '}':
                brace_depth -= 1
            elif current_char == '[':
                bracket_depth += 1
            elif current_char == ']':
                bracket_depth -= 1
            elif current_char in ',;' and paren_depth == 0 and brace_depth == 0 and bracket_depth == 0:
                completed_item = ''.join(item_buffer).strip()
                if completed_item:
                    split_items.append(completed_item)
                item_buffer = []
                continue

            item_buffer.append(current_char)

        completed_item = ''.join(item_buffer).strip()
        if completed_item:
            split_items.append(completed_item)

        return split_items

    def _find_top_level_assignment(self, item_text):
        paren_depth = 0
        brace_depth = 0
        bracket_depth = 0
        in_string = None
        is_escaped = False

        for char_index, current_char in enumerate(item_text):
            if in_string:
                if is_escaped:
                    is_escaped = False
                elif current_char == '\\':
                    is_escaped = True
                elif current_char == in_string:
                    in_string = None
                continue

            if current_char in ('"', "'"):
                in_string = current_char
            elif current_char == '(':
                paren_depth += 1
            elif current_char == ')':
                paren_depth -= 1
            elif current_char == '{':
                brace_depth += 1
            elif current_char == '}':
                brace_depth -= 1
            elif current_char == '[':
                bracket_depth += 1
            elif current_char == ']':
                bracket_depth -= 1
            elif current_char == '=' and paren_depth == 0 and brace_depth == 0 and bracket_depth == 0:
                return char_index

        return -1

    def _safe_evaluate_expression(self, expression_text):
        normalized_expression = expression_text.replace('^', '**').strip()

        if not re.fullmatch(r'[\d\s+\-*/%()]+', normalized_expression):
            raise ValueError(f"Unsupported expression: {expression_text}")

        parsed_expression = ast.parse(normalized_expression, mode='eval')
        allowed_nodes = (
            ast.Expression,
            ast.BinOp,
            ast.UnaryOp,
            ast.Add,
            ast.Sub,
            ast.Mult,
            ast.Div,
            ast.FloorDiv,
            ast.Mod,
            ast.Pow,
            ast.USub,
            ast.UAdd,
            ast.Constant
        )

        for current_node in ast.walk(parsed_expression):
            if not isinstance(current_node, allowed_nodes):
                raise ValueError(f"Unsupported AST node: {type(current_node).__name__}")
            if isinstance(current_node, ast.Constant) and not isinstance(current_node.value, (int, float)):
                raise ValueError("Only numeric constants are allowed")

        return int(eval(compile(parsed_expression, '<lua-expression>', 'eval'), {'__builtins__': {}}, {}))

    def _extract_named_table(self, script_content, table_name):
        match_object = re.search(rf'local\s+{re.escape(table_name)}\s*=\s*\{{', script_content)
        if not match_object:
            return None

        brace_start = script_content.find('{', match_object.start())
        brace_end = self._find_matching_delimiter(script_content, brace_start)
        if brace_start == -1 or brace_end == -1:
            return None

        return {
            'name': table_name,
            'body': script_content[brace_start + 1:brace_end],
            'statement_start': match_object.start(),
            'brace_start': brace_start,
            'brace_end': brace_end
        }

    def _extract_string_table(self, script_content, table_name='B'):
        table_info = self._extract_named_table(script_content, table_name)
        if not table_info:
            return None

        elements = []
        for item_text in self._split_top_level_items(table_info['body']):
            if self._is_string_literal(item_text):
                elements.append(self._parse_lua_string_literal(item_text))

        if not elements:
            return None

        table_info['elements'] = elements
        return table_info

    def _extract_primary_string_table(self, script_content, preferred_name=None):
        if preferred_name:
            preferred_table = self._extract_string_table(script_content, preferred_name)
            if preferred_table:
                return preferred_table

        candidate_tables = []

        for table_match in re.finditer(r'local\s+(\w+)\s*=\s*\{', script_content):
            table_name = table_match.group(1)
            table_info = self._extract_string_table(script_content, table_name)
            if table_info:
                candidate_tables.append(table_info)

        if not candidate_tables:
            return None

        return max(candidate_tables, key=lambda current_table: len(current_table['elements']))

    def locate_data_tables(self, script_content):
        found_tables = []

        for table_match in re.finditer(r'local\s+(\w+)\s*=\s*\{', script_content):
            table_name = table_match.group(1)
            brace_start = script_content.find('{', table_match.start())
            brace_end = self._find_matching_delimiter(script_content, brace_start)

            if brace_start == -1 or brace_end == -1:
                continue

            table_items = self._split_top_level_items(script_content[brace_start + 1:brace_end])
            string_elements = []

            for item_text in table_items:
                if self._is_string_literal(item_text):
                    string_elements.append(self._parse_lua_string_literal(item_text))

            if string_elements:
                found_tables.append({
                    'name': table_name,
                    'elements': string_elements
                })

        return found_tables

    def find_encryption_functions(self, script_content):
        function_patterns = [
            r'function\s+(\w+)\s*\([^)]*\)\s*local\s+.*string\.char',
            r'local\s+function\s+(\w+)\s*\([^)]*\)\s*.*bit32\.',
            r'(\w+)\s*=\s*function\s*\([^)]*\)\s*.*table\.concat'
        ]

        encryption_functions = []

        for pattern in function_patterns:
            matches = re.finditer(pattern, script_content, re.DOTALL)
            for match in matches:
                if match.group(1):
                    function_start = match.start()
                    function_end = script_content.find('end', function_start)
                    if function_end != -1:
                        function_body = script_content[function_start:function_end + 3]
                        encryption_functions.append({
                            'name': match.group(1),
                            'body': function_body
                        })

        return encryption_functions

    def extract_cipher_mapping(self, script_content):
        for table_match in re.finditer(r'local\s+(\w+)\s*=\s*\{', script_content):
            table_name = table_match.group(1)
            table_info = self._extract_named_table(script_content[table_match.start():], table_name)
            if not table_info:
                continue

            absolute_start = table_match.start() + table_info['statement_start']
            brace_start = table_match.start() + table_info['brace_start']
            brace_end = table_match.start() + table_info['brace_end']
            body_text = script_content[brace_start + 1:brace_end]

            mapping_data = {}

            for item_text in self._split_top_level_items(body_text):
                assignment_index = self._find_top_level_assignment(item_text)
                if assignment_index == -1:
                    continue

                key_text = item_text[:assignment_index].strip()
                value_text = item_text[assignment_index + 1:].strip()

                if key_text.startswith('[') and key_text.endswith(']'):
                    inner_key = key_text[1:-1].strip()
                    if not self._is_string_literal(inner_key):
                        continue
                    mapping_key = self._parse_lua_string_literal(inner_key)
                elif re.fullmatch(r'[A-Za-z_]\w*', key_text):
                    mapping_key = key_text
                else:
                    continue

                try:
                    mapping_value = self._safe_evaluate_expression(value_text)
                except Exception:
                    continue

                mapping_data[mapping_key] = mapping_value

            if len(mapping_data) > 30:
                return mapping_data

        return {}

    def _extract_lookup_function(self, script_content):
        lookup_match = re.search(
            r'local\s+function\s+(\w+)\s*\(\s*(\w+)\s*\)\s*'
            r'return\s+(\w+)\[\s*\2\s*([+-])\s*(.*?)\s*\]\s*;?\s*end',
            script_content,
            re.DOTALL
        )

        if not lookup_match:
            return None

        try:
            offset_value = self._safe_evaluate_expression(lookup_match.group(5))
        except Exception:
            offset_value = None

        index_delta = None
        if offset_value is not None:
            if lookup_match.group(4) == '+':
                index_delta = offset_value
            else:
                index_delta = -offset_value

        return {
            'name': lookup_match.group(1),
            'parameter_name': lookup_match.group(2),
            'table_name': lookup_match.group(3),
            'operator': lookup_match.group(4),
            'offset_expression': lookup_match.group(5).strip(),
            'offset_value': offset_value
            ,
            'index_delta': index_delta
        }

    def _find_runtime_block_start(self, script_content):
        return_matches = list(
            re.finditer(r'return\s*\(\s*function\s*\(', script_content)
        )
        if not return_matches:
            return -1
        if len(return_matches) >= 2:
            return return_matches[1].start()
        return return_matches[0].start()

    def _extract_reversal_ranges(self, script_content):
        range_loop_match = re.search(r'for\s+\w+\s*,\s*\w+\s+in\s+ipairs\s*\(', script_content)
        if not range_loop_match:
            return []

        brace_start = script_content.find('{', range_loop_match.end())
        brace_end = self._find_matching_delimiter(script_content, brace_start)

        if brace_start == -1 or brace_end == -1:
            return []

        range_items = []
        outer_items = self._split_top_level_items(script_content[brace_start + 1:brace_end])

        for item_text in outer_items:
            item_text = item_text.strip()
            if not (item_text.startswith('{') and item_text.endswith('}')):
                continue

            inner_values = self._split_top_level_items(item_text[1:-1])
            if len(inner_values) != 2:
                continue

            try:
                start_index = self._safe_evaluate_expression(inner_values[0])
                end_index = self._safe_evaluate_expression(inner_values[1])
            except Exception:
                continue

            range_items.append((start_index, end_index))

        return range_items

    def _apply_reversal_ranges(self, element_list, reversal_ranges):
        reordered_elements = list(element_list)

        for start_index, end_index in reversal_ranges:
            left_index = max(start_index - 1, 0)
            right_index = min(end_index - 1, len(reordered_elements) - 1)

            while left_index < right_index:
                reordered_elements[left_index], reordered_elements[right_index] = (
                    reordered_elements[right_index],
                    reordered_elements[left_index]
                )
                left_index += 1
                right_index -= 1

        return reordered_elements

    def reconstruct_string_bytes(self, encrypted_string, cipher_map):
        if not isinstance(encrypted_string, str):
            return b''

        if not cipher_map:
            return encrypted_string.encode('utf-8', errors='ignore')

        byte_buffer = bytearray()
        accumulator = 0
        position_counter = 0

        for current_char in encrypted_string:
            if current_char in cipher_map:
                accumulator = (accumulator << 6) | cipher_map[current_char]
                position_counter += 1

                if position_counter == 4:
                    byte_buffer.append((accumulator >> 16) & 0xFF)
                    byte_buffer.append((accumulator >> 8) & 0xFF)
                    byte_buffer.append(accumulator & 0xFF)
                    accumulator = 0
                    position_counter = 0
            elif current_char == '=':
                if position_counter == 3:
                    byte_buffer.append((accumulator >> 10) & 0xFF)
                    byte_buffer.append((accumulator >> 2) & 0xFF)
                elif position_counter == 2:
                    byte_buffer.append((accumulator >> 4) & 0xFF)
                break

        return bytes(byte_buffer)

    def reconstruct_strings(self, encrypted_strings, cipher_map):
        reconstructed = []

        for encrypted_string in encrypted_strings:
            decoded_bytes = self.reconstruct_string_bytes(encrypted_string, cipher_map)
            reconstructed.append(decoded_bytes.decode('utf-8', errors='replace'))

        return reconstructed

    def _format_lua_string(self, string_value):
        if isinstance(string_value, bytes):
            raw_bytes = string_value
        else:
            raw_bytes = str(string_value).encode('utf-8', errors='replace')

        output_parts = ['"']

        for current_byte in raw_bytes:
            if current_byte == 92:
                output_parts.append('\\\\')
            elif current_byte == 34:
                output_parts.append('\\"')
            elif current_byte == 10:
                output_parts.append('\\n')
            elif current_byte == 13:
                output_parts.append('\\r')
            elif current_byte == 9:
                output_parts.append('\\t')
            elif 32 <= current_byte <= 126:
                output_parts.append(chr(current_byte))
            else:
                output_parts.append(f'\\{current_byte:03d}')

        output_parts.append('"')
        return ''.join(output_parts)

    def _normalize_lua_string_literals(self, script_content):
        output_parts = []
        current_index = 0

        while current_index < len(script_content):
            current_char = script_content[current_index]

            if script_content.startswith('--', current_index):
                long_comment_end = self._consume_long_bracket(script_content, current_index + 2)
                if long_comment_end is not None:
                    output_parts.append(script_content[current_index:long_comment_end])
                    current_index = long_comment_end
                    continue

                line_end = script_content.find('\n', current_index)
                if line_end == -1:
                    line_end = len(script_content)
                output_parts.append(script_content[current_index:line_end])
                current_index = line_end
                continue

            long_string_end = self._consume_long_bracket(script_content, current_index)
            if long_string_end is not None:
                output_parts.append(script_content[current_index:long_string_end])
                current_index = long_string_end
                continue

            if current_char in ('"', "'"):
                string_start = current_index
                current_index += 1
                is_escaped = False

                while current_index < len(script_content):
                    current_char = script_content[current_index]
                    if is_escaped:
                        is_escaped = False
                    elif current_char == '\\':
                        is_escaped = True
                    elif current_char == script_content[string_start]:
                        current_index += 1
                        break
                    current_index += 1

                raw_token = script_content[string_start:current_index]
                try:
                    output_parts.append(self._format_lua_string(self._parse_lua_string_literal(raw_token)))
                except Exception:
                    output_parts.append(raw_token)
                continue

            output_parts.append(current_char)
            current_index += 1

        return ''.join(output_parts)

    def _apply_constant_array_decryption(self, script_content):
        lookup_function = self._extract_lookup_function(script_content)
        preferred_table_name = lookup_function['table_name'] if lookup_function else None
        string_table = self._extract_primary_string_table(script_content, preferred_table_name)
        cipher_mapping = self.extract_cipher_mapping(script_content)
        reversal_ranges = self._extract_reversal_ranges(script_content)
        warnings = []
        decoded_string_bytes = []
        decoded_strings = []
        deobfuscated_source = script_content

        if string_table:
            reordered_elements = self._apply_reversal_ranges(string_table['elements'], reversal_ranges)
            decoded_string_bytes = [
                self.reconstruct_string_bytes(current_string, cipher_mapping)
                for current_string in reordered_elements
            ]
            decoded_strings = [
                current_bytes.decode('utf-8', errors='replace')
                for current_bytes in decoded_string_bytes
            ]

            main_logic_index = self._find_runtime_block_start(script_content)
            rewrite_source = script_content[main_logic_index:] if main_logic_index != -1 else script_content

            if lookup_function and lookup_function.get('index_delta') is not None:
                inlined_source = self._inline_lookup_calls(
                    rewrite_source,
                    lookup_function,
                    decoded_string_bytes
                )

                if f"{lookup_function['name']}(" not in inlined_source and main_logic_index != -1:
                    deobfuscated_source = inlined_source
                else:
                    replacement_block = self._build_static_lookup_block(
                        lookup_function['table_name'],
                        lookup_function['name'],
                        lookup_function['parameter_name'],
                        lookup_function['index_delta'],
                        decoded_string_bytes
                    )
                    prefix_source = (
                        ''
                        if main_logic_index != -1
                        else ''
                    )
                    deobfuscated_source = prefix_source + replacement_block + inlined_source
            else:
                if not lookup_function:
                    warnings.append('Bước 2: Không phát hiện accessor function của constant array, giữ nguyên phần lookup')
                elif lookup_function.get('index_delta') is None:
                    warnings.append('Bước 2: Không tính được offset của accessor function, giữ nguyên phần lookup')
        else:
            warnings.append('Bước 2: Không phát hiện constant array trung tâm, bỏ qua')

        try:
            deobfuscated_source = self._simplify_numeric_lines(deobfuscated_source)
        except Exception as simplify_error:
            warnings.append(f'Bước 2: Numeric simplifier skipped: {simplify_error}')

        try:
            deobfuscated_source = self._beautify_lua_source(deobfuscated_source)
        except Exception as formatter_error:
            warnings.append(f'Bước 2: Formatter skipped: {formatter_error}')

        return {
            'output': deobfuscated_source,
            'decoded_string_bytes': decoded_string_bytes,
            'decoded_strings': decoded_strings,
            'cipher_mapping_size': len(cipher_mapping),
            'lookup_function': lookup_function,
            'reversal_ranges': reversal_ranges,
            'warnings': warnings
        }

    def _rewrite_lua_identifiers(self, script_content, rename_map):
        if not rename_map:
            return script_content

        keywords = {
            'and', 'break', 'do', 'else', 'elseif', 'end', 'false', 'for',
            'function', 'goto', 'if', 'in', 'local', 'nil', 'not', 'or',
            'repeat', 'return', 'then', 'true', 'until', 'while'
        }
        output_parts = []
        current_index = 0

        while current_index < len(script_content):
            current_char = script_content[current_index]

            if script_content.startswith('--', current_index):
                long_comment_end = self._consume_long_bracket(script_content, current_index + 2)
                if long_comment_end is not None:
                    output_parts.append(script_content[current_index:long_comment_end])
                    current_index = long_comment_end
                    continue

                line_end = script_content.find('\n', current_index)
                if line_end == -1:
                    line_end = len(script_content)
                output_parts.append(script_content[current_index:line_end])
                current_index = line_end
                continue

            long_string_end = self._consume_long_bracket(script_content, current_index)
            if long_string_end is not None:
                output_parts.append(script_content[current_index:long_string_end])
                current_index = long_string_end
                continue

            if current_char in ('"', "'"):
                string_start = current_index
                current_index += 1
                is_escaped = False

                while current_index < len(script_content):
                    current_char = script_content[current_index]
                    if is_escaped:
                        is_escaped = False
                    elif current_char == '\\':
                        is_escaped = True
                    elif current_char == script_content[string_start]:
                        current_index += 1
                        break
                    current_index += 1

                output_parts.append(script_content[string_start:current_index])
                continue

            if current_char.isalpha() or current_char == '_':
                identifier_start = current_index
                current_index += 1
                while current_index < len(script_content):
                    current_char = script_content[current_index]
                    if not (current_char.isalnum() or current_char == '_'):
                        break
                    current_index += 1

                identifier = script_content[identifier_start:current_index]
                if identifier not in keywords and identifier in rename_map:
                    output_parts.append(rename_map[identifier])
                else:
                    output_parts.append(identifier)
                continue

            output_parts.append(current_char)
            current_index += 1

        return ''.join(output_parts)

    def _replace_lua_identifier_tokens(self, text_content, replacement_map):
        if not replacement_map:
            return text_content

        output_parts = []
        current_index = 0

        while current_index < len(text_content):
            current_char = text_content[current_index]

            if text_content.startswith('--', current_index):
                long_comment_end = self._consume_long_bracket(text_content, current_index + 2)
                if long_comment_end is not None:
                    output_parts.append(text_content[current_index:long_comment_end])
                    current_index = long_comment_end
                    continue

                line_end = text_content.find('\n', current_index)
                if line_end == -1:
                    line_end = len(text_content)
                output_parts.append(text_content[current_index:line_end])
                current_index = line_end
                continue

            long_string_end = self._consume_long_bracket(text_content, current_index)
            if long_string_end is not None:
                output_parts.append(text_content[current_index:long_string_end])
                current_index = long_string_end
                continue

            if current_char in ('"', "'"):
                string_start = current_index
                current_index += 1
                is_escaped = False

                while current_index < len(text_content):
                    current_char = text_content[current_index]
                    if is_escaped:
                        is_escaped = False
                    elif current_char == '\\':
                        is_escaped = True
                    elif current_char == text_content[string_start]:
                        current_index += 1
                        break
                    current_index += 1

                output_parts.append(text_content[string_start:current_index])
                continue

            if current_char.isalpha() or current_char == '_':
                identifier_start = current_index
                current_index += 1
                while current_index < len(text_content):
                    current_char = text_content[current_index]
                    if not (current_char.isalnum() or current_char == '_'):
                        break
                    current_index += 1

                identifier_name = text_content[identifier_start:current_index]
                output_parts.append(replacement_map.get(identifier_name, identifier_name))
                continue

            output_parts.append(current_char)
            current_index += 1

        return ''.join(output_parts)

    def _strip_wearedev_banner(self, script_content):
        stripped_source = re.sub(
            r'^\s*--\[\[\s*v[\d.]+\s+https://wearedevs\.net/obfuscator\s*\]\]\s*\n?',
            '',
            script_content,
            count=1,
            flags=re.IGNORECASE
        )
        return stripped_source.lstrip('\ufeff')

    def _rename_prometheus_runtime_aliases(self, script_content):
        rename_map = {}
        runtime_layout = self._extract_prometheus_runtime_layout(script_content)
        outer_function_match = re.search(r'return\s*\(\s*function\(([^)]*)\)', script_content)

        if outer_function_match:
            outer_params = [item.strip() for item in outer_function_match.group(1).split(',') if item.strip()]
            outer_param_names = [
                'env',
                'unpack_fn',
                'newproxy_fn',
                'setmetatable_fn',
                'getmetatable_fn',
                'select_fn',
                'vararg_pack'
            ]
            for index, target_name in enumerate(outer_param_names):
                if index < len(outer_params):
                    rename_map[outer_params[index]] = target_name

        if runtime_layout:
            if runtime_layout.get('cleanup_name'):
                rename_map[runtime_layout['cleanup_name']] = 'runtime_cleanup'
            if runtime_layout.get('slot_counter_name'):
                rename_map[runtime_layout['slot_counter_name']] = 'slot_counter'
            if runtime_layout.get('slot_table_name'):
                rename_map[runtime_layout['slot_table_name']] = 'runtime_slots'
            if runtime_layout.get('free_slot_name'):
                rename_map[runtime_layout['free_slot_name']] = 'free_slot'
            if runtime_layout.get('alloc_slot_name'):
                rename_map[runtime_layout['alloc_slot_name']] = 'alloc_slot'
            if runtime_layout.get('proxy_builder_name'):
                rename_map[runtime_layout['proxy_builder_name']] = 'build_proxy'
            if runtime_layout.get('refcount_table_name'):
                rename_map[runtime_layout['refcount_table_name']] = 'runtime_refcounts'
            if runtime_layout.get('container_name'):
                rename_map[runtime_layout['container_name']] = 'runtime_container'

            creator_index = 0
            for helper_name, arg_spec in runtime_layout.get('creator_args', {}).items():
                if arg_spec == 'vararg':
                    rename_map[helper_name] = 'make_vararg_closure'
                    continue

                creator_index += 1
                rename_map[helper_name] = f'make_closure_{creator_index}'

        sanitized_mapping = {}
        used_targets = set()
        for source_name, target_name in rename_map.items():
            if (
                source_name == target_name
                or not self._is_valid_lua_identifier(source_name)
                or not self._is_valid_lua_identifier(target_name)
                or target_name in used_targets
            ):
                continue
            sanitized_mapping[source_name] = target_name
            used_targets.add(target_name)

        if not sanitized_mapping:
            return script_content

        return self._rewrite_lua_identifiers(script_content, sanitized_mapping)

    def _simplify_obfuscated_conditions(self, script_content):
        simplified_source = script_content
        simplified_source = re.sub(
            r'while\s+not\s*\(\(\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*\*\s*45\s*\)\s*%\s*257\)\s*\*\s*45\s*\)\s*%\s*257\s*~=\s*1\)',
            r'while not (\1 ~= 1)',
            simplified_source
        )
        simplified_source = re.sub(
            r'if\s+not\s*\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*\)\s*then',
            r'if not \1 then',
            simplified_source
        )
        simplified_source = re.sub(
            r'if\s+\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*\)\s*then',
            r'if \1 then',
            simplified_source
        )
        return simplified_source

    def _strip_empty_blocks(self, script_content):
        source_lines = script_content.splitlines()
        output_lines = []
        current_index = 0

        while current_index < len(source_lines):
            stripped_line = source_lines[current_index].strip()
            normalized_line = stripped_line[:-1].rstrip() if stripped_line.endswith(';') else stripped_line

            if re.match(r'^(if\b.*then|while\b.*do|for\b.*do|repeat)$', normalized_line):
                block_end_index = self._find_matching_block_end_line(source_lines, current_index)
                if block_end_index != -1:
                    body_lines = source_lines[current_index + 1:block_end_index]
                    meaningful_lines = [
                        line_text.strip()
                        for line_text in body_lines
                        if line_text.strip()
                    ]
                    if meaningful_lines and all(line_text in {'else'} or line_text.startswith('elseif ') for line_text in meaningful_lines):
                        meaningful_lines = []
                    if not meaningful_lines:
                        current_index = block_end_index + 1
                        continue

            output_lines.append(source_lines[current_index])
            current_index += 1

        normalized_output = '\n'.join(output_lines)
        return normalized_output + ('\n' if script_content.endswith('\n') else '')

    def _remove_unused_literal_assignments(self, script_content):
        identifier_counts = Counter(re.findall(r'\b[A-Za-z_][A-Za-z0-9_]*\b', script_content))
        output_lines = []
        assignment_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*;?\s*$'
        )
        safe_literal_pattern = re.compile(
            r'^(?:-?\d+(?:\.\d+)?|true|false|nil|\{\}|".*"|\'.*\')$'
        )

        for line_text in script_content.splitlines():
            assignment_match = assignment_pattern.match(line_text)
            if assignment_match:
                lhs_name = assignment_match.group(1)
                rhs_text = assignment_match.group(2).strip()
                if identifier_counts.get(lhs_name, 0) == 1 and safe_literal_pattern.fullmatch(rhs_text):
                    continue
            output_lines.append(line_text)

        normalized_output = '\n'.join(output_lines)
        return normalized_output + ('\n' if script_content.endswith('\n') else '')

    def _rename_prometheus_register_locals_for_readability(self, script_content):
        rename_map = {}
        for name_text in set(re.findall(r'\br(\d+)\b', script_content)):
            register_match = re.fullmatch(r'(\d+)', name_text)
            if not register_match:
                continue
            source_name = f"r{register_match.group(1)}"
            rename_map[source_name] = f"{source_name}_local"

        if not rename_map:
            return script_content
        return self._rewrite_lua_identifiers(script_content, rename_map)

    def _compact_simple_multiline_table_literals(self, script_content):
        table_pattern = re.compile(r'\{([^{}]*?)\}', re.DOTALL)

        def replace_table(match_object):
            table_inner = match_object.group(1)
            if '\n' not in table_inner:
                return match_object.group(0)
            if 'function' in table_inner:
                return match_object.group(0)

            parts = [
                part.strip()
                for part in re.split(r'[;\n]+', table_inner)
                if part.strip()
            ]
            if not parts:
                return '{}'
            return '{' + ', '.join(parts) + '}'

        return table_pattern.sub(replace_table, script_content)

    def _rename_common_prometheus_library_aliases(self, script_content):
        rename_candidates = {}
        candidate_positions = {}
        source_targets = {}
        ambiguous_sources = set()
        base_aliases = {}
        lines = script_content.splitlines()
        assignment_pattern = re.compile(r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*$')

        def register_candidate(source_name, target_name, line_index):
            previous_targets = source_targets.setdefault(source_name, set())
            previous_targets.add(target_name)
            if len(previous_targets) > 1:
                ambiguous_sources.add(source_name)
                rename_candidates.pop(source_name, None)
                candidate_positions.pop(source_name, None)
                return
            if source_name in ambiguous_sources:
                return
            rename_candidates[source_name] = target_name
            candidate_positions.setdefault(source_name, line_index)

        for line_index, line_text in enumerate(lines):
            assignment_match = assignment_pattern.match(line_text)
            if assignment_match:
                lhs_name = assignment_match.group(1)
                rhs_text = assignment_match.group(2).strip()
                if rhs_text in {'math', 'table', 'string'}:
                    base_aliases[lhs_name] = rhs_text
                elif re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', rhs_text):
                    base_aliases[lhs_name] = base_aliases.get(rhs_text, rhs_text if rhs_text in {'math', 'table', 'string'} else None)
                else:
                    base_aliases.pop(lhs_name, None)

            floor_match = re.match(r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*math\.floor\s*$', line_text)
            if floor_match:
                register_candidate(floor_match.group(1), 'floor_fn', line_index)
                continue

            floor_alias_match = re.match(
                r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\.floor\s*$',
                line_text
            )
            if floor_alias_match and base_aliases.get(floor_alias_match.group(2)) == 'math':
                register_candidate(floor_alias_match.group(1), 'floor_fn', line_index)
                continue

            random_match = re.match(r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*math\.random\s*$', line_text)
            if random_match:
                register_candidate(random_match.group(1), 'random_fn', line_index)
                continue

            random_alias_match = re.match(
                r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\.random\s*$',
                line_text
            )
            if random_alias_match and base_aliases.get(random_alias_match.group(2)) == 'math':
                register_candidate(random_alias_match.group(1), 'random_fn', line_index)
                continue

            remove_match = re.match(r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*table\.remove\s*$', line_text)
            if remove_match:
                register_candidate(remove_match.group(1), 'remove_fn', line_index)
                continue

            remove_alias_match = re.match(
                r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\.remove\s*$',
                line_text
            )
            if remove_alias_match and base_aliases.get(remove_alias_match.group(2)) == 'table':
                register_candidate(remove_alias_match.group(1), 'remove_fn', line_index)
                continue

            char_match = re.match(r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*string\.char\s*$', line_text)
            if char_match:
                register_candidate(char_match.group(1), 'char_fn', line_index)
                continue

            char_alias_match = re.match(
                r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\.char\s*$',
                line_text
            )
            if char_alias_match and base_aliases.get(char_alias_match.group(2)) == 'string':
                register_candidate(char_alias_match.group(1), 'char_fn', line_index)
                continue

        if not rename_candidates:
            return script_content

        target_counts = Counter(rename_candidates.values())
        filtered_map = {
            source_name: target_name
            for source_name, target_name in rename_candidates.items()
            if target_counts[target_name] == 1
        }
        if not filtered_map:
            return script_content
        return self._rewrite_lua_identifiers(script_content, filtered_map)

    def _semantic_rename_prometheus_domain_symbols(self, script_content):
        lines = script_content.splitlines()
        fn_assign_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*function\(([^)]*)\)\s*$'
        )
        local_fn_pattern = re.compile(
            r'^\s*local\s+function\s+([A-Za-z_][A-Za-z0-9_]*)\(([^)]*)\)\s*$'
        )
        table_stats_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*\{[^{}]*\bkills\b[^{}]*\bdeaths\b[^{}]*\}\s*$'
        )
        call_assign_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\(([^)]*)\)\s*$'
        )
        simple_alias_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\s*$'
        )
        get_service_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*game\s*:\s*GetService\s*\(\s*("(?:(?:\\.)|[^"\\])*"|\'(?:(?:\\.)|[^\'\\])*\')\s*\)\s*$'
        )
        wait_for_child_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*.+?:\s*WaitForChild\s*\(\s*("(?:(?:\\.)|[^"\\])*"|\'(?:(?:\\.)|[^\'\\])*\')\s*\)\s*$'
        )
        instance_new_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*Instance\.new\s*\(\s*("(?:(?:\\.)|[^"\\])*"|\'(?:(?:\\.)|[^\'\\])*\')\s*(?:,.*)?\)\s*$'
        )
        local_player_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*[A-Za-z_][A-Za-z0-9_]*\.LocalPlayer\s*$'
        )

        all_names = set(re.findall(r'\b[A-Za-z_][A-Za-z0-9_]*\b', script_content))
        rename_map = {}
        used_targets = set()
        function_names = set()

        reserved_targets = {
            'floor_fn', 'random_fn', 'remove_fn', 'char_fn', 'next_prng_byte',
            'decode_runtime_string', 'decoded_cache', 'lookup', 'items'
        }

        def allocate_target(base_name):
            if base_name in reserved_targets:
                return None
            if base_name not in all_names and base_name not in used_targets:
                used_targets.add(base_name)
                return base_name
            suffix = 2
            while True:
                candidate = f'{base_name}_{suffix}'
                if candidate not in all_names and candidate not in used_targets:
                    used_targets.add(candidate)
                    return candidate
                suffix += 1

        def register_rename(source_name, target_base):
            if (
                source_name in rename_map
                or source_name in reserved_targets
                or source_name == target_base
                or re.fullmatch(r'(?:env|pc|ret_reg|v\d+)', source_name)
            ):
                return
            target_name = allocate_target(target_base)
            if target_name:
                rename_map[source_name] = target_name

        # 1) Rename obvious stats table variable.
        for line_text in lines:
            table_match = table_stats_pattern.match(line_text.strip())
            if table_match:
                register_rename(table_match.group(1), 'player_stats')

        # 2) Classify functions by semantic behavior.
        index = 0
        while index < len(lines):
            fn_match = fn_assign_pattern.match(lines[index].strip()) or local_fn_pattern.match(lines[index].strip())
            if not fn_match:
                index += 1
                continue
            fn_name = fn_match.group(1)
            function_names.add(fn_name)
            end_index = self._find_matching_block_end_line(lines, index)
            if end_index == -1:
                index += 1
                continue
            body_text = '\n'.join(lines[index:end_index + 1])
            fn_overwritten_later = False
            overwrite_pattern = re.compile(
                rf'^\s*(?:local\s+)?{re.escape(fn_name)}\s*='
            )
            for probe_line in lines[end_index + 1:]:
                if overwrite_pattern.match(probe_line.strip()):
                    fn_overwritten_later = True
                    break

            if not fn_overwritten_later and re.search(r'\.WalkSpeed\b', body_text):
                register_rename(fn_name, 'toggle_speed')
            elif not fn_overwritten_later and re.search(r'\.JumpPower\b', body_text):
                register_rename(fn_name, 'toggle_jump')
            elif (
                not fn_overwritten_later
                and
                'CharacterAdded' in body_text
                and 'WaitForChild' in body_text
                and '"Humanoid"' in body_text
            ):
                register_rename(fn_name, 'get_humanoid')
            elif (
                not fn_overwritten_later
                and
                re.search(r'\.kills\b', body_text)
                and re.search(r'\.deaths\b', body_text)
                and re.search(r'\bscore\b', body_text)
                and re.search(r'\bkd\b', body_text)
            ):
                register_rename(fn_name, 'update_stats')
            elif (
                not fn_overwritten_later
                and
                re.search(r'==\s*0', body_text)
                and re.search(r'\*\s*2', body_text)
                and re.search(r'\*\s*10', body_text)
            ):
                register_rename(fn_name, 'calculate_score')
            elif (
                not fn_overwritten_later
                and
                re.search(r'\*\s*2', body_text)
                and re.search(r'/\s*[A-Za-z_][A-Za-z0-9_]*', body_text)
                and re.search(r'\*\s*10', body_text)
            ):
                register_rename(fn_name, 'calculate_score')
            elif (
                not fn_overwritten_later
                and
                re.search(r'=\s*2\b', body_text)
                and re.search(r'=\s*10\b', body_text)
                and re.search(r'/\s*[A-Za-z_][A-Za-z0-9_]*', body_text)
            ):
                register_rename(fn_name, 'calculate_score')
            elif (
                not fn_overwritten_later
                and
                'MouseButton1Click' in script_content
                and 'print("' in body_text
            ):
                register_rename(fn_name, 'on_print_click')
            elif not fn_overwritten_later and ('task.wait' in body_text or re.search(r'for\s+\w+\s*=\s*1\s*,\s*\d+', body_text)):
                register_rename(fn_name, 'run_background_task')

            index = end_index + 1

        # 3) Rename call results using renamed function names.
        for line_text in lines:
            call_match = call_assign_pattern.match(line_text.strip())
            if not call_match:
                continue
            lhs_name, callee_name, _arg_text = call_match.groups()
            mapped_callee = rename_map.get(callee_name, callee_name)
            if mapped_callee in {'update_stats'}:
                register_rename(lhs_name, 'result_stats')
            elif mapped_callee in {'get_humanoid'}:
                register_rename(lhs_name, 'humanoid')
            elif mapped_callee in {'calculate_score'}:
                register_rename(lhs_name, 'score_value')

        # 3b) Rename obvious stat temporaries from field reads.
        field_read_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*[A-Za-z_][A-Za-z0-9_]*\.(kills|deaths)\s*$'
        )
        for line_text in lines:
            field_match = field_read_pattern.match(line_text.strip())
            if not field_match:
                continue
            lhs_name, field_name = field_match.groups()
            if lhs_name in function_names:
                continue
            if field_name == 'kills':
                register_rename(lhs_name, 'kills_value')
            elif field_name == 'deaths':
                register_rename(lhs_name, 'deaths_value')

        # 4) Roblox-oriented value flow naming.
        for line_text in lines:
            stripped = line_text.strip()
            service_match = get_service_pattern.match(stripped)
            if service_match:
                lhs_name, literal_text = service_match.groups()
                service_name = self._parse_lua_string_literal(literal_text)
                service_label = self._build_prometheus_identifier_component(service_name)
                if service_label:
                    register_rename(lhs_name, f'{service_label}_service')
                continue

            wait_match = wait_for_child_pattern.match(stripped)
            if wait_match:
                lhs_name, literal_text = wait_match.groups()
                child_name = self._parse_lua_string_literal(literal_text)
                child_label = self._build_prometheus_identifier_component(child_name)
                if child_label:
                    register_rename(lhs_name, child_label)
                continue

            instance_match = instance_new_pattern.match(stripped)
            if instance_match:
                lhs_name, literal_text = instance_match.groups()
                class_name = self._parse_lua_string_literal(literal_text)
                class_label = self._build_prometheus_identifier_component(class_name)
                if class_label:
                    register_rename(lhs_name, class_label)
                continue

            local_player_match = local_player_pattern.match(stripped)
            if local_player_match:
                register_rename(local_player_match.group(1), 'local_player')

        # 5) Propagate semantic names through direct aliases.
        for line_text in lines:
            alias_match = simple_alias_pattern.match(line_text.strip())
            if not alias_match:
                continue
            lhs_name, rhs_name = alias_match.groups()
            mapped_rhs = rename_map.get(rhs_name)
            if not mapped_rhs:
                continue
            if lhs_name in rename_map:
                continue
            register_rename(lhs_name, f'{mapped_rhs}_ref')

        if not rename_map:
            return script_content
        return self._rewrite_lua_identifiers(script_content, rename_map)

    def _build_prometheus_identifier_component(self, raw_text):
        if raw_text is None:
            return ''
        snake_text = re.sub(r'([a-z0-9])([A-Z])', r'\1_\2', str(raw_text))
        snake_text = re.sub(r'[^A-Za-z0-9]+', '_', snake_text).strip('_').lower()
        snake_text = re.sub(r'_+', '_', snake_text)
        if not snake_text:
            return ''
        if snake_text[0].isdigit():
            snake_text = f'value_{snake_text}'
        return snake_text

    def _collapse_prometheus_alias_chains(self, script_content):
        lines = script_content.splitlines()
        assign_pattern = re.compile(
            r'^(\s*)(local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*)\s*$'
        )
        any_assign_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*='
        )
        lua_keywords = {
            'and', 'break', 'do', 'else', 'elseif', 'end', 'false', 'for',
            'function', 'goto', 'if', 'in', 'local', 'nil', 'not', 'or',
            'repeat', 'return', 'then', 'true', 'until', 'while'
        }

        changed = True
        rounds = 0
        while changed and rounds < 6:
            changed = False
            rounds += 1
            source_lines = list(lines)
            output_lines = []
            index = 0

            while index < len(source_lines):
                line_text = source_lines[index]
                match_object = assign_pattern.match(line_text)
                if not match_object:
                    output_lines.append(line_text)
                    index += 1
                    continue

                lhs_name = match_object.group(3)
                rhs_text = match_object.group(4)
                if lhs_name == rhs_text:
                    output_lines.append(line_text)
                    index += 1
                    continue
                if rhs_text in lua_keywords:
                    output_lines.append(line_text)
                    index += 1
                    continue
                if re.fullmatch(r'r\d+(?:_local)?', rhs_text):
                    output_lines.append(line_text)
                    index += 1
                    continue

                search_limit = min(len(source_lines), index + 28)
                stop_index = search_limit
                use_indexes = []
                for probe in range(index + 1, search_limit):
                    probe_line = source_lines[probe]
                    reassign_match = any_assign_pattern.match(probe_line)
                    if reassign_match and reassign_match.group(1) == lhs_name:
                        stop_index = probe
                        break
                    if re.search(rf'\b{re.escape(lhs_name)}\b', probe_line):
                        use_indexes.append(probe)

                if not use_indexes or len(use_indexes) > 3:
                    output_lines.append(line_text)
                    index += 1
                    continue

                local_lines = list(source_lines[index + 1:stop_index])
                local_changed = False
                skip_rewrite = False
                for probe in use_indexes:
                    local_idx = probe - (index + 1)
                    if local_idx < 0 or local_idx >= len(local_lines):
                        continue
                    probe_line = local_lines[local_idx]
                    stripped_probe = probe_line.strip()
                    if (
                        stripped_probe.startswith('local ')
                        or stripped_probe.startswith('for ')
                        or stripped_probe.startswith('function ')
                        or re.search(rf'function\s*\([^)]*\b{re.escape(lhs_name)}\b', stripped_probe)
                    ):
                        skip_rewrite = True
                        break
                    rewritten_line = re.sub(
                        rf'\b{re.escape(lhs_name)}\b',
                        rhs_text,
                        probe_line
                    )
                    if rewritten_line != probe_line:
                        local_lines[local_idx] = rewritten_line
                        local_changed = True

                if not local_changed or skip_rewrite:
                    output_lines.append(line_text)
                    index += 1
                    continue

                output_lines.extend(local_lines)
                index = stop_index
                changed = True

            lines = output_lines

        rewritten_text = '\n'.join(lines)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _rename_prometheus_registers_by_role(self, script_content):
        lines = script_content.splitlines()
        assignment_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*$'
        )
        register_pattern = re.compile(r'^r\d+(?:_local)?$')
        string_literal_pattern = re.compile(r'^(?:"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\')$')
        call_pattern = re.compile(r'^([A-Za-z_][A-Za-z0-9_]*(?:[.:][A-Za-z_][A-Za-z0-9_]*)*)\((.*)\)$')
        dotted_pattern = re.compile(r'^([A-Za-z_][A-Za-z0-9_]*)\.([A-Za-z_][A-Za-z0-9_]*)$')
        wait_child_pattern = re.compile(
            r'^[A-Za-z_][A-Za-z0-9_]*:WaitForChild\(\s*("([^"\\]|\\.)*"|\'([^\'\\]|\\.)*\')\s*\)$'
        )
        instance_new_pattern = re.compile(
            r'^Instance\.new\(\s*("([^"\\]|\\.)*"|\'([^\'\\]|\\.)*\')'
        )
        get_service_pattern = re.compile(
            r'^game:GetService\(\s*("([^"\\]|\\.)*"|\'([^\'\\]|\\.)*\')\s*\)$'
        )

        assignment_counts = Counter()
        for line_text in lines:
            match_object = assignment_pattern.match(line_text)
            if match_object:
                assignment_counts[match_object.group(1)] += 1

        existing_names = set(re.findall(r'\b[A-Za-z_][A-Za-z0-9_]*\b', script_content))
        rename_map = {}

        def allocate_name(base_name):
            candidate = base_name
            suffix = 2
            while candidate in existing_names or candidate in rename_map.values():
                candidate = f"{base_name}_{suffix}"
                suffix += 1
            existing_names.add(candidate)
            return candidate

        for line_text in lines:
            match_object = assignment_pattern.match(line_text)
            if not match_object:
                continue
            lhs_name, rhs_text = match_object.groups()
            rhs_text = rhs_text.strip().rstrip(';').strip()
            if not register_pattern.fullmatch(lhs_name):
                continue
            if assignment_counts.get(lhs_name, 0) != 1:
                continue

            base_name = None
            if string_literal_pattern.fullmatch(rhs_text):
                try:
                    decoded_string = self._parse_lua_string_literal(rhs_text)
                except Exception:
                    decoded_string = None
                if decoded_string and re.fullmatch(r'[A-Za-z_][A-Za-z0-9_ ]*', decoded_string) and len(decoded_string) <= 32:
                    label = self._build_prometheus_identifier_component(decoded_string)
                    if label:
                        base_name = f"{label}_name"
            elif rhs_text.endswith('.LocalPlayer'):
                base_name = 'local_player'
            elif rhs_text.endswith('.CharacterAdded'):
                base_name = 'character_added_signal'
            elif rhs_text.endswith('.Character'):
                base_name = 'character_model'
            else:
                wait_match = wait_child_pattern.match(rhs_text)
                if wait_match:
                    literal_token = wait_match.group(1)
                    try:
                        child_name = self._parse_lua_string_literal(literal_token)
                    except Exception:
                        child_name = ''
                    label = self._build_prometheus_identifier_component(child_name)
                    if label:
                        base_name = label

            if base_name is None:
                service_match = get_service_pattern.match(rhs_text)
                if service_match:
                    literal_token = service_match.group(1)
                    try:
                        service_name = self._parse_lua_string_literal(literal_token)
                    except Exception:
                        service_name = ''
                    label = self._build_prometheus_identifier_component(service_name)
                    base_name = f"{label}_service" if label else 'service_obj'

            if base_name is None:
                new_match = instance_new_pattern.match(rhs_text)
                if new_match:
                    literal_token = new_match.group(1)
                    try:
                        class_name = self._parse_lua_string_literal(literal_token)
                    except Exception:
                        class_name = ''
                    label = self._build_prometheus_identifier_component(class_name)
                    base_name = f"{label}_instance" if label else 'instance_obj'

            if base_name is None:
                dotted_match = dotted_pattern.match(rhs_text)
                if dotted_match:
                    member_name = dotted_match.group(2)
                    label = self._build_prometheus_identifier_component(member_name)
                    if label:
                        function_like_names = {
                            'new', 'fromrgb', 'remove', 'char', 'byte', 'len',
                            'gsub', 'gmatch', 'sub', 'concat', 'insert', 'random',
                            'floor', 'wait', 'waitforchild', 'getservice'
                        }
                        suffix = '_fn' if label in function_like_names else '_value'
                        base_name = f"{label}{suffix}"

            if base_name is None:
                call_match = call_pattern.match(rhs_text)
                if call_match:
                    callee_name = call_match.group(1).split(':')[-1].split('.')[-1]
                    label = self._build_prometheus_identifier_component(callee_name)
                    if label and not re.fullmatch(r'r\d+(?:_local)?', label):
                        if label in {'decode_runtime_string', 'next_prng_byte'}:
                            base_name = f"{label}_result"
                        else:
                            base_name = f"{label}_result"

            if base_name is None:
                continue
            if not self._is_valid_lua_identifier(base_name):
                continue
            if base_name == lhs_name:
                continue
            rename_map[lhs_name] = allocate_name(base_name)

        if not rename_map:
            return script_content
        return self._rewrite_lua_identifiers(script_content, rename_map)

    def _remove_prometheus_noop_lines(self, script_content):
        output_lines = []
        noop_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*\1\s*;?\s*$'
        )

        for line_text in script_content.splitlines():
            if noop_pattern.match(line_text):
                continue
            output_lines.append(line_text)

        normalized_output = '\n'.join(output_lines)
        return normalized_output + ('\n' if script_content.endswith('\n') else '')

    def _inline_short_lived_prometheus_identifier_aliases(self, script_content):
        lines = script_content.splitlines()
        assign_pattern = re.compile(
            r'^(\s*)(local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\s*$'
        )
        any_assign_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*='
        )

        rewritten_lines = list(lines)
        remove_indices = set()

        for index, line_text in enumerate(lines):
            alias_match = assign_pattern.match(line_text)
            if not alias_match:
                continue
            indent_text, _local_kw, lhs_name, rhs_name = alias_match.groups()
            if indent_text:
                continue
            if lhs_name == rhs_name:
                continue
            if lhs_name in {'pc', 'env'} or rhs_name in {'pc', 'env'}:
                continue

            stop_index = min(len(lines), index + 28)
            for probe in range(index + 1, min(len(lines), index + 80)):
                reassign = any_assign_pattern.match(lines[probe])
                if reassign and reassign.group(1) == lhs_name:
                    stop_index = probe
                    break

            use_indexes = []
            for probe in range(index + 1, stop_index):
                probe_line = rewritten_lines[probe]
                if re.search(rf'\b{re.escape(lhs_name)}\b', probe_line):
                    use_indexes.append(probe)
            if not use_indexes or len(use_indexes) > 4:
                continue

            rhs_reassigned_early = False
            last_use = max(use_indexes)
            for probe in range(index + 1, last_use + 1):
                reassign = any_assign_pattern.match(lines[probe])
                if reassign and reassign.group(1) == rhs_name:
                    rhs_reassigned_early = True
                    break
            if rhs_reassigned_early:
                continue

            changed = False
            for probe in use_indexes:
                source_line = rewritten_lines[probe]
                stripped = source_line.strip()
                if (
                    stripped.startswith('local ')
                    or stripped.startswith('function ')
                    or stripped.startswith('for ')
                ):
                    continue
                replaced = re.sub(
                    rf'\b{re.escape(lhs_name)}\b',
                    rhs_name,
                    source_line
                )
                if replaced != source_line:
                    rewritten_lines[probe] = replaced
                    changed = True

            if changed:
                remove_indices.add(index)

        if remove_indices:
            rewritten_lines = [
                line for line_index, line in enumerate(rewritten_lines)
                if line_index not in remove_indices
            ]

        rewritten_text = '\n'.join(rewritten_lines)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _inline_single_use_prometheus_callable_aliases(self, script_content):
        lines = script_content.splitlines()
        assign_pattern = re.compile(
            r'^(\s*)(local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)+)\s*$'
        )
        any_assign_pattern = re.compile(r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=')

        rewritten_lines = list(lines)
        remove_indices = set()

        for index, line_text in enumerate(lines):
            match_object = assign_pattern.match(line_text)
            if not match_object:
                continue
            indent_text, _local_kw, lhs_name, rhs_text = match_object.groups()
            if indent_text:
                continue

            stop_index = min(len(lines), index + 80)
            for probe in range(index + 1, stop_index):
                reassign_match = any_assign_pattern.match(lines[probe])
                if reassign_match and reassign_match.group(1) == lhs_name:
                    stop_index = probe
                    break

            use_indexes = []
            token_pattern = re.compile(rf'\b{re.escape(lhs_name)}\b')
            for probe in range(index + 1, stop_index):
                if token_pattern.search(rewritten_lines[probe]):
                    use_indexes.append(probe)
            if not use_indexes or len(use_indexes) > 10:
                continue

            changed = False
            for use_index in use_indexes:
                use_line = rewritten_lines[use_index]
                if re.search(rf'\b{re.escape(lhs_name)}\s*\(', use_line) is None:
                    changed = False
                    break
                replaced_line = re.sub(
                    rf'\b{re.escape(lhs_name)}\b',
                    lambda _match, value=rhs_text: value,
                    use_line
                )
                if replaced_line != use_line:
                    rewritten_lines[use_index] = replaced_line
                    changed = True

            if changed:
                remove_indices.add(index)

        if remove_indices:
            rewritten_lines = [
                line for line_index, line in enumerate(rewritten_lines)
                if line_index not in remove_indices
            ]

        rewritten_text = '\n'.join(rewritten_lines)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _inline_single_use_prometheus_call_literal_args(self, script_content):
        lines = script_content.splitlines()
        assign_pattern = re.compile(
            r'^(\s*)(local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*$'
        )
        any_assign_pattern = re.compile(r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=')
        literal_pattern = re.compile(
            r'^(?:true|false|nil|[-+]?\d+(?:\.\d+)?|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\')$'
        )

        rewritten_lines = list(lines)
        remove_indices = set()

        for index, line_text in enumerate(lines):
            match_object = assign_pattern.match(line_text)
            if not match_object:
                continue
            indent_text, _local_kw, lhs_name, rhs_text = match_object.groups()
            if indent_text:
                continue
            rhs_value = rhs_text.strip().rstrip(';').strip()
            if not literal_pattern.fullmatch(rhs_value):
                continue
            if rhs_value == 'nil':
                continue

            stop_index = min(len(lines), index + 40)
            for probe in range(index + 1, stop_index):
                reassign_match = any_assign_pattern.match(lines[probe])
                if reassign_match and reassign_match.group(1) == lhs_name:
                    stop_index = probe
                    break

            token_pattern = re.compile(rf'\b{re.escape(lhs_name)}\b')
            use_indexes = []
            for probe in range(index + 1, stop_index):
                if token_pattern.search(rewritten_lines[probe]):
                    use_indexes.append(probe)
            if len(use_indexes) != 1:
                continue

            use_index = use_indexes[0]
            use_line = rewritten_lines[use_index]
            # Keep conservative: inline only inside call-like lines.
            if '(' not in use_line or ')' not in use_line:
                continue

            replaced_line = re.sub(
                rf'\b{re.escape(lhs_name)}\b',
                lambda _match, value=rhs_value: value,
                use_line
            )
            if replaced_line == use_line:
                continue

            rewritten_lines[use_index] = replaced_line
            remove_indices.add(index)

        if remove_indices:
            rewritten_lines = [
                line for line_index, line in enumerate(rewritten_lines)
                if line_index not in remove_indices
            ]

        rewritten_text = '\n'.join(rewritten_lines)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _inline_immediate_prometheus_literal_aliases(self, script_content):
        lines = script_content.splitlines()
        assign_pattern = re.compile(
            r'^(\s*)(local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*$'
        )
        literal_pattern = re.compile(
            r'^(?:true|false|nil|[-+]?(?:\d+(?:\.\d+)?|\.\d+)|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\')$'
        )
        reassign_pattern = re.compile(r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=')
        token_cache = {}

        rewritten = list(lines)
        remove_indices = set()

        for index, line_text in enumerate(lines):
            match_object = assign_pattern.match(line_text)
            if not match_object:
                continue
            indent_text, _local_kw, lhs_name, rhs_text = match_object.groups()
            if indent_text:
                continue
            rhs_value = rhs_text.strip().rstrip(';').strip()
            if not literal_pattern.fullmatch(rhs_value):
                continue

            next_index = index + 1
            while next_index < len(lines) and not lines[next_index].strip():
                next_index += 1
            if next_index >= len(lines) or next_index - index > 4:
                continue

            reassigned = False
            for probe in range(index + 1, next_index):
                reassign_match = reassign_pattern.match(lines[probe])
                if reassign_match and reassign_match.group(1) == lhs_name:
                    reassigned = True
                    break
            if reassigned:
                continue

            next_line = rewritten[next_index]
            stripped_next = next_line.strip()
            if (
                stripped_next.startswith('local ')
                or stripped_next.startswith('function ')
                or stripped_next.startswith('for ')
            ):
                continue

            token_pattern = token_cache.get(lhs_name)
            if token_pattern is None:
                token_pattern = re.compile(rf'\b{re.escape(lhs_name)}\b')
                token_cache[lhs_name] = token_pattern

            token_hits = len(token_pattern.findall(next_line))
            if token_hits == 0 or token_hits > 2:
                continue
            if reassign_pattern.match(next_line):
                reassign_match = reassign_pattern.match(next_line)
                if reassign_match and reassign_match.group(1) == lhs_name:
                    continue

            # Keep this conservative: only inline when the temp is used solely
            # in the immediate next statement before any reassignment.
            has_extra_use = False
            scan_limit = min(len(lines), index + 32)
            for probe in range(next_index + 1, scan_limit):
                reassign_match = reassign_pattern.match(lines[probe])
                if reassign_match and reassign_match.group(1) == lhs_name:
                    break
                if token_pattern.search(lines[probe]):
                    has_extra_use = True
                    break
            if has_extra_use:
                continue

            replaced_line = token_pattern.sub(lambda _match: rhs_value, next_line)
            if replaced_line == next_line:
                continue

            rewritten[next_index] = replaced_line
            remove_indices.add(index)

        if remove_indices:
            rewritten = [
                line_text for line_index, line_text in enumerate(rewritten)
                if line_index not in remove_indices
            ]

        rewritten_text = '\n'.join(rewritten)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _inline_immediate_prometheus_callable_aliases(self, script_content):
        lines = script_content.splitlines()
        assign_pattern = re.compile(
            r'^(\s*)(local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)+)\s*$'
        )
        reassign_pattern = re.compile(r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=')
        call_use_pattern_template = r'\b{alias}\s*\('
        token_template = r'\b{alias}\b'

        rewritten = list(lines)
        remove_indices = set()

        for index, line_text in enumerate(lines):
            match_object = assign_pattern.match(line_text)
            if not match_object:
                continue
            indent_text, _local_kw, lhs_name, rhs_text = match_object.groups()
            if indent_text:
                continue

            next_index = index + 1
            while next_index < len(lines) and not lines[next_index].strip():
                next_index += 1
            if next_index >= len(lines) or next_index - index > 3:
                continue

            next_line = rewritten[next_index]
            stripped_next = next_line.strip()
            if stripped_next.startswith('local ') or stripped_next.startswith('function '):
                continue

            call_use_pattern = re.compile(call_use_pattern_template.format(alias=re.escape(lhs_name)))
            if call_use_pattern.search(next_line) is None:
                continue

            token_pattern = re.compile(token_template.format(alias=re.escape(lhs_name)))
            has_extra_use = False
            scan_limit = min(len(lines), index + 32)
            for probe in range(next_index + 1, scan_limit):
                reassign_match = reassign_pattern.match(lines[probe])
                if reassign_match and reassign_match.group(1) == lhs_name:
                    break
                if token_pattern.search(lines[probe]):
                    has_extra_use = True
                    break
            if has_extra_use:
                continue

            replaced_line = token_pattern.sub(lambda _match: rhs_text, next_line)
            if replaced_line == next_line:
                continue

            rewritten[next_index] = replaced_line
            remove_indices.add(index)

        if remove_indices:
            rewritten = [
                line_text for line_index, line_text in enumerate(rewritten)
                if line_index not in remove_indices
            ]

        rewritten_text = '\n'.join(rewritten)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _repair_prometheus_forward_simple_aliases(self, script_content):
        lines = script_content.splitlines()
        assign_pattern = re.compile(
            r'^(\s*)(local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*$'
        )
        identifier_pattern = re.compile(r'^[A-Za-z_][A-Za-z0-9_]*$')
        safe_value_pattern = re.compile(
            r'^(?:nil|true|false|[-+]?\d+(?:\.\d+)?|[A-Za-z_][A-Za-z0-9_]*)$'
        )
        keyword_names = {
            'and', 'break', 'do', 'else', 'elseif', 'end', 'false', 'for',
            'function', 'goto', 'if', 'in', 'local', 'nil', 'not', 'or',
            'repeat', 'return', 'then', 'true', 'until', 'while'
        }

        assigned_names = set()
        rewritten_lines = list(lines)

        for index, line_text in enumerate(lines):
            match_object = assign_pattern.match(line_text)
            if not match_object:
                continue
            indent_text, local_kw, lhs_name, rhs_text = match_object.groups()
            rhs_text = rhs_text.strip().rstrip(';').strip()

            if not identifier_pattern.fullmatch(rhs_text):
                assigned_names.add(lhs_name)
                continue
            if rhs_text in keyword_names or rhs_text in assigned_names:
                assigned_names.add(lhs_name)
                continue

            replacement_value = None
            probe_limit = min(len(lines), index + 8)
            for probe in range(index + 1, probe_limit):
                probe_match = assign_pattern.match(lines[probe])
                if not probe_match:
                    continue
                probe_lhs = probe_match.group(3)
                probe_rhs = probe_match.group(4).strip().rstrip(';').strip()
                if probe_lhs != rhs_text:
                    continue
                if not safe_value_pattern.fullmatch(probe_rhs):
                    break

                lhs_used_before_rhs_init = False
                for between in range(index + 1, probe):
                    if re.search(rf'\b{re.escape(lhs_name)}\b', lines[between]):
                        lhs_used_before_rhs_init = True
                        break
                if lhs_used_before_rhs_init:
                    break

                replacement_value = probe_rhs
                break

            if replacement_value is not None:
                rewritten_lines[index] = f"{indent_text}{local_kw or ''}{lhs_name} = {replacement_value}"

            assigned_names.add(lhs_name)

        rewritten_text = '\n'.join(rewritten_lines)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _repair_prometheus_uninitialized_loop_seed(self, script_content):
        lines = script_content.splitlines()
        assign_pattern = re.compile(
            r'^(\s*)(local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*$'
        )
        compare_pattern = re.compile(r'^([A-Za-z_][A-Za-z0-9_]*)\s*<\s*([A-Za-z_][A-Za-z0-9_]*)$')
        compare_zero_pattern = re.compile(r'^([A-Za-z_][A-Za-z0-9_]*)\s*<\s*(?:0|0\.0)$')
        minus_pattern = re.compile(r'^([A-Za-z_][A-Za-z0-9_]*)\s*-\s*([A-Za-z_][A-Za-z0-9_]*)$')
        literal_number_pattern = re.compile(r'^[-+]?\d+(?:\.\d+)?$')

        first_assignment_line = {}
        for line_index, line_text in enumerate(lines):
            match_object = assign_pattern.match(line_text)
            if not match_object:
                continue
            lhs_name = match_object.group(3)
            if lhs_name not in first_assignment_line:
                first_assignment_line[lhs_name] = line_index

        rewritten_lines = list(lines)
        for index in range(0, len(lines) - 1):
            current_match = assign_pattern.match(lines[index])
            next_match = assign_pattern.match(lines[index + 1])
            if not current_match or not next_match:
                continue

            cond_rhs = current_match.group(4).strip().rstrip(';').strip()
            cond_match = compare_pattern.fullmatch(cond_rhs)
            cond_zero_match = compare_zero_pattern.fullmatch(cond_rhs)
            if cond_match:
                step_name, iter_name = cond_match.groups()
                cond_uses_explicit_iter = True
            elif cond_zero_match:
                step_name = cond_zero_match.group(1)
                iter_name = None
                cond_uses_explicit_iter = False
            else:
                continue

            next_lhs = next_match.group(3)
            minus_rhs = next_match.group(4).strip().rstrip(';').strip()
            minus_match = minus_pattern.fullmatch(minus_rhs)
            if not minus_match:
                continue
            seed_name, minus_step_name = minus_match.groups()
            if minus_step_name != step_name:
                continue
            if cond_uses_explicit_iter and next_lhs != iter_name:
                continue
            if seed_name == step_name:
                continue
            if first_assignment_line.get(seed_name, len(lines)) < index + 1:
                continue

            step_is_numeric_seed = False
            for back in range(max(0, index - 10), index + 1):
                back_match = assign_pattern.match(lines[back])
                if not back_match:
                    continue
                if back_match.group(3) != step_name:
                    continue
                step_rhs = back_match.group(4).strip().rstrip(';').strip()
                if literal_number_pattern.fullmatch(step_rhs):
                    step_is_numeric_seed = True
                    break
            if not step_is_numeric_seed:
                continue

            indent_text = next_match.group(1)
            local_kw = next_match.group(2) or ''
            rewritten_lines[index + 1] = f"{indent_text}{local_kw}{next_lhs} = {step_name} - {step_name}"

        rewritten_text = '\n'.join(rewritten_lines)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _repair_prometheus_uninitialized_shuffle_loop_bound(self, script_content):
        lines = script_content.splitlines()
        assign_pattern = re.compile(
            r'^(\s*)(local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*$'
        )
        ident_pattern = re.compile(r'^[A-Za-z_][A-Za-z0-9_]*$')
        while_pattern = re.compile(r'^\s*while\s+true\s+do\s*$')

        rewritten_lines = list(lines)
        assigned_before = set()

        for index, line_text in enumerate(lines):
            assign_match = assign_pattern.match(line_text)
            if assign_match:
                assigned_before.add(assign_match.group(3))

            if not assign_match:
                continue
            indent_text, local_kw, lhs_name, rhs_text = assign_match.groups()
            rhs_text = rhs_text.strip().rstrip(';').strip()
            if not ident_pattern.fullmatch(rhs_text):
                continue
            if lhs_name == rhs_text:
                continue

            # Only repair if RHS has not been assigned yet at this point.
            rhs_seen_earlier = False
            for back in range(0, index):
                back_match = assign_pattern.match(lines[back])
                if back_match and back_match.group(3) == rhs_text:
                    rhs_seen_earlier = True
                    break
            if rhs_seen_earlier:
                continue

            probe_start = index + 1
            probe_limit = min(len(lines), index + 120)
            while_index = -1
            for probe in range(probe_start, probe_limit):
                if while_pattern.match(lines[probe]):
                    while_index = probe
                    break
            if while_index == -1:
                continue

            loop_end = self._find_matching_block_end_line(lines, while_index)
            if loop_end == -1 or loop_end >= probe_limit:
                continue

            loop_text = '\n'.join(lines[while_index:loop_end + 1])
            if (
                f'<= {lhs_name}' not in loop_text
                or f'>= {lhs_name}' not in loop_text
            ):
                continue
            if not re.search(r'\[[A-Za-z_][A-Za-z0-9_]*\]\s*=', loop_text):
                continue

            repeat_probe_limit = min(len(lines), loop_end + 60)
            has_hash_reassign = False
            for probe in range(loop_end + 1, repeat_probe_limit):
                later_match = assign_pattern.match(lines[probe])
                if not later_match:
                    continue
                if later_match.group(3) != lhs_name:
                    continue
                later_rhs = later_match.group(4).strip().rstrip(';').strip()
                if later_rhs.startswith('#'):
                    has_hash_reassign = True
                    break
            if not has_hash_reassign:
                continue

            # Prometheus shuffle table setup is always 1..256.
            rewritten_lines[index] = f"{indent_text}{local_kw or ''}{lhs_name} = 256"

        rewritten_text = '\n'.join(rewritten_lines)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _neutralize_unknown_unary_wrapper_calls(self, script_content):
        lines = script_content.splitlines()
        assign_call_pattern = re.compile(
            r'^(\s*)(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*\)\s*$'
        )

        declared_names = self._collect_declared_lua_names(script_content)
        known_names = set(declared_names) | {
            '_ENV', '_G', 'assert', 'bit32', 'coroutine', 'debug', 'error', 'game',
            'getfenv', 'getgenv', 'io', 'ipairs', 'load', 'math', 'next', 'os',
            'pairs', 'pcall', 'print', 'rawequal', 'rawget', 'rawset', 'require',
            'select', 'setfenv', 'setmetatable', 'string', 'table', 'task',
            'tonumber', 'tostring', 'type', 'unpack', 'utf8', 'warn', 'workspace',
            'xpcall'
        }

        candidate_counts = Counter()
        candidate_lines = []
        for line_index, line_text in enumerate(lines):
            match_object = assign_call_pattern.match(line_text)
            if not match_object:
                continue
            lhs_name, fn_name, arg_name = match_object.group(2), match_object.group(3), match_object.group(4)
            if fn_name in known_names:
                continue
            if len(fn_name) > 2:
                continue
            candidate_counts[fn_name] += 1
            candidate_lines.append((line_index, lhs_name, fn_name, arg_name))

        valid_fns = {name for name, count in candidate_counts.items() if count >= 2}
        if not valid_fns:
            return script_content

        rewritten_lines = list(lines)
        for line_index, lhs_name, fn_name, arg_name in candidate_lines:
            if fn_name not in valid_fns:
                continue
            indent_text = lines[line_index][:len(lines[line_index]) - len(lines[line_index].lstrip(' \t'))]
            rewritten_lines[line_index] = f"{indent_text}{lhs_name} = {arg_name}"

        rewritten_text = '\n'.join(rewritten_lines)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _prune_overwritten_prometheus_assignments(self, script_content):
        lines = script_content.splitlines()
        identifier_token_cache = {}

        def token_pattern(identifier_name):
            pattern_object = identifier_token_cache.get(identifier_name)
            if pattern_object is None:
                pattern_object = re.compile(rf'\b{re.escape(identifier_name)}\b')
                identifier_token_cache[identifier_name] = pattern_object
            return pattern_object

        changed = True
        max_rounds = 8
        round_count = 0

        while changed and round_count < max_rounds:
            changed = False
            round_count += 1
            remove_indices = set()

            for line_index, line_text in enumerate(lines):
                parsed_assignment = self._parse_prometheus_assignment_chunk(line_text)
                if not parsed_assignment:
                    continue

                lhs_name = parsed_assignment['lhs']
                rhs_text = parsed_assignment['rhs']
                if (
                    rhs_text.count('{') > rhs_text.count('}')
                    or rhs_text.count('(') > rhs_text.count(')')
                    or rhs_text.count('[') > rhs_text.count(']')
                ):
                    continue
                if not self._is_prometheus_side_effect_free(rhs_text):
                    continue

                lhs_pattern = token_pattern(lhs_name)
                lhs_is_read = False
                probe_index = line_index + 1

                while probe_index < len(lines):
                    probe_line = lines[probe_index]
                    if not lhs_pattern.search(probe_line):
                        probe_index += 1
                        continue

                    probe_assignment = self._parse_prometheus_assignment_chunk(probe_line)
                    if probe_assignment and probe_assignment['lhs'] == lhs_name:
                        if lhs_pattern.search(probe_assignment['rhs']):
                            lhs_is_read = True
                        break

                    if probe_assignment:
                        if lhs_pattern.search(probe_assignment['rhs']):
                            lhs_is_read = True
                        break

                    lhs_is_read = True
                    break

                if not lhs_is_read:
                    remove_indices.add(line_index)

            if remove_indices:
                lines = [
                    line_text
                    for line_index, line_text in enumerate(lines)
                    if line_index not in remove_indices
                ]
                changed = True

        normalized_output = '\n'.join(lines)
        return normalized_output + ('\n' if script_content.endswith('\n') else '')

    def _inline_single_use_prometheus_call_aliases(self, script_content):
        source_lines = script_content.splitlines()
        output_lines = []
        line_index = 0
        assignment_pattern = re.compile(
            r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*;?\s*$'
        )

        while line_index < len(source_lines):
            current_line = source_lines[line_index]
            match_object = assignment_pattern.match(current_line)
            if not match_object:
                output_lines.append(current_line)
                line_index += 1
                continue

            alias_name = match_object.group(1)
            rhs_text = match_object.group(2).strip()
            if (
                rhs_text in {'true', 'false', 'nil'}
                or re.fullmatch(r'[-+]?\d+(?:\.\d+)?', rhs_text)
                or re.fullmatch(r'"(?:[^"\\]|\\.)*"', rhs_text, re.DOTALL)
                or re.fullmatch(r"'(?:[^'\\]|\\.)*'", rhs_text, re.DOTALL)
            ):
                output_lines.append(current_line)
                line_index += 1
                continue
            if (
                '(' in rhs_text
                or rhs_text.count('{') > rhs_text.count('}')
                or rhs_text.count('[') > rhs_text.count(']')
                or not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*(?:[\.\[][^\s]+)?', rhs_text)
            ):
                output_lines.append(current_line)
                line_index += 1
                continue

            next_index = line_index + 1
            while next_index < len(source_lines) and not source_lines[next_index].strip():
                next_index += 1
            if next_index >= len(source_lines):
                output_lines.append(current_line)
                line_index += 1
                continue

            next_line = source_lines[next_index]
            if next_line.lstrip().startswith('--'):
                output_lines.append(current_line)
                line_index += 1
                continue

            alias_call_pattern = re.compile(rf'\b{re.escape(alias_name)}\s*\(')
            if not alias_call_pattern.search(next_line):
                output_lines.append(current_line)
                line_index += 1
                continue

            token_count = len(re.findall(rf'\b{re.escape(alias_name)}\b', next_line))
            if token_count != 1:
                output_lines.append(current_line)
                line_index += 1
                continue

            replacement_text = rhs_text
            rewritten_next = alias_call_pattern.sub(f"{replacement_text}(", next_line, count=1)
            output_lines.extend(source_lines[line_index + 1:next_index])
            output_lines.append(rewritten_next)
            line_index = next_index + 1

        normalized_output = '\n'.join(output_lines)
        return normalized_output + ('\n' if script_content.endswith('\n') else '')

    def _collect_declared_lua_names(self, script_content):
        declared_names = set()

        for local_match in re.finditer(
            r'^\s*local\s+([A-Za-z_][A-Za-z0-9_]*(?:\s*,\s*[A-Za-z_][A-Za-z0-9_]*)*)\s*(?:=|$)',
            script_content,
            re.MULTILINE
        ):
            for name_text in local_match.group(1).split(','):
                declared_names.add(name_text.strip())

        for function_match in re.finditer(r'function\s*[^(]*\(([^)]*)\)', script_content):
            for name_text in function_match.group(1).split(','):
                clean_name = name_text.strip()
                if clean_name and clean_name != '...':
                    declared_names.add(clean_name)

        for for_match in re.finditer(
            r'^\s*for\s+([A-Za-z_][A-Za-z0-9_]*(?:\s*,\s*[A-Za-z_][A-Za-z0-9_]*)*)\s*=',
            script_content,
            re.MULTILINE
        ):
            for name_text in for_match.group(1).split(','):
                declared_names.add(name_text.strip())

        return declared_names

    def _add_missing_local_declarations(self, script_content):
        builtin_names = {
            '_ENV', 'assert', 'bit32', 'coroutine', 'debug', 'error', 'game',
            'getfenv', 'getgenv', 'io', 'ipairs', 'load', 'math', 'next',
            'os', 'pairs', 'pcall', 'print', 'rawequal', 'rawget', 'rawset',
            'require', 'select', 'setfenv', 'setmetatable', 'string', 'table',
            'task', 'tonumber', 'tostring', 'type', 'unpack', 'utf8', 'warn',
            'workspace', 'xpcall'
        }
        declared_names = self._collect_declared_lua_names(script_content) | builtin_names
        output_lines = []
        assignment_pattern = re.compile(
            r'^(\s*)([A-Za-z_][A-Za-z0-9_]*(?:\s*,\s*[A-Za-z_][A-Za-z0-9_]*)*)\s*=\s*'
        )

        for line_text in script_content.splitlines():
            stripped_text = line_text.strip()
            if (
                not stripped_text
                or stripped_text.startswith('--')
                or stripped_text.startswith('local ')
                or stripped_text.startswith('function ')
            ):
                output_lines.append(line_text)
                continue

            assignment_match = assignment_pattern.match(line_text)
            if not assignment_match:
                output_lines.append(line_text)
                continue

            lhs_names = [name_text.strip() for name_text in assignment_match.group(2).split(',')]
            if any(not self._is_valid_lua_identifier(name_text) for name_text in lhs_names):
                output_lines.append(line_text)
                continue

            if any(name_text in declared_names for name_text in lhs_names):
                output_lines.append(line_text)
                continue

            output_lines.append(f"{assignment_match.group(1)}local {line_text[len(assignment_match.group(1)):]}")
            declared_names.update(lhs_names)

        normalized_output = '\n'.join(output_lines)
        return normalized_output + ('\n' if script_content.endswith('\n') else '')

    def _normalize_blank_lines(self, script_content):
        output_lines = []
        blank_run = 0

        for line_text in script_content.splitlines():
            if line_text.strip():
                blank_run = 0
                output_lines.append(line_text.rstrip())
                continue

            blank_run += 1
            if blank_run <= 1:
                output_lines.append('')

        normalized_output = '\n'.join(output_lines).strip()
        return normalized_output + '\n' if normalized_output else ''

    def _sanitize_invalid_statement_identifiers(self, script_content):
        alias_map = {}
        alias_counter = 0
        output_lines = []
        invalid_lhs_pattern = re.compile(
            r'^\s*(?P<lhs>("(?:[^"\\]|\\.)*"|\'(?:[^\'\\]|\\.)*\'|\d+(?:\.\d+)?))\s*=\s*(?P<rhs>.+?)\s*;?\s*$'
        )

        for line_text in script_content.splitlines():
            line_match = invalid_lhs_pattern.match(line_text)
            if not line_match:
                output_lines.append(line_text)
                continue

            alias_name = alias_map.get(line_match.group('lhs'))
            if not alias_name:
                alias_counter += 1
                alias_name = f'v_invalid_{alias_counter}'
                alias_map[line_match.group('lhs')] = alias_name

            indent_text = line_text[:len(line_text) - len(line_text.lstrip())]
            output_lines.append(f"{indent_text}{alias_name} = {line_match.group('rhs')}")

        sanitized_source = '\n'.join(output_lines)

        for raw_token, alias_name in alias_map.items():
            escaped_token = re.escape(raw_token)
            replacement_patterns = [
                (rf'(\bif\s+){escaped_token}(\s+then\b)', rf'\1{alias_name}\2'),
                (rf'(\belseif\s+){escaped_token}(\s+then\b)', rf'\1{alias_name}\2'),
                (rf'(\bwhile\s+){escaped_token}(\s+do\b)', rf'\1{alias_name}\2'),
                (rf'(\bwhile\s+not\s*\()\s*{escaped_token}(\s*\)\s*do\b)', rf'\1{alias_name}\2'),
                (rf'(\buntil\s+){escaped_token}(\s*$)', rf'\1{alias_name}\2'),
                (rf'(\breturn\s+){escaped_token}(\s*$)', rf'\1{alias_name}\2')
            ]
            for pattern_text, replacement_text in replacement_patterns:
                sanitized_source = re.sub(pattern_text, replacement_text, sanitized_source, flags=re.MULTILINE)

            if raw_token[0].isdigit() or raw_token[0] in {'"', "'"}:
                sanitized_source = re.sub(
                    rf'(?<![A-Za-z0-9_]){escaped_token}(\s*[\[\.\(])',
                    rf'{alias_name}\1',
                    sanitized_source
                )

        return sanitized_source + ('\n' if script_content.endswith('\n') else '')

    def _expand_compound_assignments(self, script_content):
        def replace_compound(match_object):
            indent_text = match_object.group(1)
            lhs_text = match_object.group(2).strip()
            operator_text = match_object.group(3)
            rhs_text = match_object.group(4).strip()
            return f"{indent_text}{lhs_text} = {lhs_text} {operator_text} {rhs_text}"

        return re.sub(
            r'^(\s*)([A-Za-z_][A-Za-z0-9_]*(?:\[[^\]]+\]|\.[A-Za-z_][A-Za-z0-9_]*)*)\s*([+\-*/%])\s*=\s*(.+?)\s*$',
            replace_compound,
            script_content,
            flags=re.MULTILINE
        )

    def _build_static_lookup_block(self, table_name, lookup_name, parameter_name, index_delta, string_bytes):
        output_lines = [f'local {table_name} = {{']

        for current_string in string_bytes:
            output_lines.append(f'    {self._format_lua_string(current_string)},')

        output_lines.append('}')
        output_lines.append(f'local function {lookup_name}({parameter_name})')
        if index_delta is None or index_delta == 0:
            index_expression = parameter_name
        elif index_delta > 0:
            index_expression = f'{parameter_name} + {index_delta}'
        else:
            index_expression = f'{parameter_name} - {abs(index_delta)}'
        output_lines.append(f'    return {table_name}[{index_expression}]')
        output_lines.append('end')

        return '\n'.join(output_lines) + '\n'

    def _inline_lookup_calls(self, script_content, lookup_function, decoded_string_bytes):
        if not lookup_function or lookup_function.get('index_delta') is None:
            return script_content

        lookup_name = lookup_function['name']
        index_delta = lookup_function['index_delta']
        result_parts = []
        current_index = 0
        in_string = None
        is_escaped = False

        while current_index < len(script_content):
            current_char = script_content[current_index]

            if in_string:
                result_parts.append(current_char)
                if is_escaped:
                    is_escaped = False
                elif current_char == '\\':
                    is_escaped = True
                elif current_char == in_string:
                    in_string = None
                current_index += 1
                continue

            if current_char in ('"', "'"):
                in_string = current_char
                result_parts.append(current_char)
                current_index += 1
                continue

            if (
                script_content.startswith(f'{lookup_name}(', current_index)
                and (current_index == 0 or not re.match(r'[A-Za-z0-9_]', script_content[current_index - 1]))
            ):
                argument_start = current_index + len(lookup_name) + 1
                argument_end = self._find_matching_delimiter(script_content, argument_start - 1, '(', ')')

                if argument_end != -1:
                    argument_text = script_content[argument_start:argument_end]

                    try:
                        lookup_index = self._safe_evaluate_expression(argument_text) + index_delta
                    except Exception:
                        lookup_index = None

                    if lookup_index is not None and 1 <= lookup_index <= len(decoded_string_bytes):
                        result_parts.append(self._format_lua_string(decoded_string_bytes[lookup_index - 1]))
                        current_index = argument_end + 1
                        continue

            result_parts.append(current_char)
            current_index += 1

        return ''.join(result_parts)

    def _is_valid_lua_identifier(self, value):
        if not isinstance(value, str):
            return False

        if not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', value):
            return False

        return value not in {
            'and', 'break', 'do', 'else', 'elseif', 'end', 'false', 'for',
            'function', 'goto', 'if', 'in', 'local', 'nil', 'not', 'or',
            'repeat', 'return', 'then', 'true', 'until', 'while'
        }

    def _match_long_bracket(self, text_content, start_index):
        if start_index >= len(text_content) or text_content[start_index] != '[':
            return None

        current_index = start_index + 1
        while current_index < len(text_content) and text_content[current_index] == '=':
            current_index += 1

        if current_index < len(text_content) and text_content[current_index] == '[':
            return current_index - start_index - 1

        return None

    def _consume_long_bracket(self, text_content, start_index):
        equal_count = self._match_long_bracket(text_content, start_index)
        if equal_count is None:
            return None

        closing_delimiter = ']' + ('=' * equal_count) + ']'
        search_start = start_index + equal_count + 2
        closing_index = text_content.find(closing_delimiter, search_start)

        if closing_index == -1:
            return len(text_content)

        return closing_index + len(closing_delimiter)

    def _tokenize_lua(self, script_content):
        tokens = []
        current_index = 0
        number_pattern = re.compile(
            r"""
            (?:
                0[xX][0-9A-Fa-f]+(?:\.[0-9A-Fa-f]*)?(?:[pP][+-]?\d+)?
                |
                \d+(?:\.\d*)?(?:[eE][+-]?\d+)?
                |
                \.\d+(?:[eE][+-]?\d+)?
            )
            """,
            re.VERBOSE
        )
        keywords = {
            'and', 'break', 'do', 'else', 'elseif', 'end', 'false', 'for',
            'function', 'goto', 'if', 'in', 'local', 'nil', 'not', 'or',
            'repeat', 'return', 'then', 'true', 'until', 'while'
        }
        multi_char_symbols = ('...', '==', '~=', '<=', '>=', '::', '//', '..')

        while current_index < len(script_content):
            current_char = script_content[current_index]

            if current_char.isspace():
                current_index += 1
                continue

            if script_content.startswith('--', current_index):
                long_comment_end = self._consume_long_bracket(script_content, current_index + 2)

                if long_comment_end is not None:
                    tokens.append(('comment', script_content[current_index:long_comment_end]))
                    current_index = long_comment_end
                    continue

                line_end = script_content.find('\n', current_index)
                if line_end == -1:
                    line_end = len(script_content)
                tokens.append(('comment', script_content[current_index:line_end]))
                current_index = line_end
                continue

            long_string_end = self._consume_long_bracket(script_content, current_index)
            if long_string_end is not None:
                tokens.append(('long_string', script_content[current_index:long_string_end]))
                current_index = long_string_end
                continue

            if current_char in ('"', "'"):
                string_delimiter = current_char
                string_start = current_index
                current_index += 1
                is_escaped = False

                while current_index < len(script_content):
                    current_char = script_content[current_index]

                    if is_escaped:
                        is_escaped = False
                    elif current_char == '\\':
                        is_escaped = True
                    elif current_char == string_delimiter:
                        current_index += 1
                        break

                    current_index += 1

                tokens.append(('string', script_content[string_start:current_index]))
                continue

            if current_char.isalpha() or current_char == '_':
                identifier_start = current_index
                current_index += 1

                while current_index < len(script_content):
                    current_char = script_content[current_index]
                    if not (current_char.isalnum() or current_char == '_'):
                        break
                    current_index += 1

                identifier = script_content[identifier_start:current_index]
                token_type = 'keyword' if identifier in keywords else 'name'
                tokens.append((token_type, identifier))
                continue

            number_match = number_pattern.match(script_content, current_index)
            if number_match:
                tokens.append(('number', number_match.group(0)))
                current_index = number_match.end()
                continue

            matched_symbol = None
            for current_symbol in multi_char_symbols:
                if script_content.startswith(current_symbol, current_index):
                    matched_symbol = current_symbol
                    break

            if matched_symbol is not None:
                tokens.append(('symbol', matched_symbol))
                current_index += len(matched_symbol)
                continue

            tokens.append(('symbol', current_char))
            current_index += 1

        return tokens

    def _simplify_string_key_accesses(self, lua_tokens):
        simplified_tokens = []
        current_index = 0

        while current_index < len(lua_tokens):
            current_token = lua_tokens[current_index]

            if (
                current_token == ('symbol', '[')
                and current_index + 2 < len(lua_tokens)
                and lua_tokens[current_index + 1][0] == 'string'
                and lua_tokens[current_index + 2] == ('symbol', ']')
                and simplified_tokens
            ):
                previous_token = simplified_tokens[-1]
                string_key = self._parse_lua_string_literal(lua_tokens[current_index + 1][1])

                if (
                    self._is_valid_lua_identifier(string_key)
                    and (
                        previous_token[0] == 'name'
                        or (previous_token[0] == 'symbol' and previous_token[1] in (')', ']'))
                    )
                ):
                    simplified_tokens.append(('symbol', '.'))
                    simplified_tokens.append(('name', string_key))
                    current_index += 3
                    continue

            simplified_tokens.append(current_token)
            current_index += 1

        return simplified_tokens

    def _should_insert_space(self, previous_token, current_token):
        if previous_token is None:
            return False

        previous_type, previous_value = previous_token
        current_type, current_value = current_token

        if current_value in (')', ']', '}', ',', ';', '.', ':'):
            return False

        if previous_value in ('(', '[', '{', '.', ':'):
            return False

        if current_value == '(':
            return previous_value in {'return', 'elseif', 'if', 'while', 'for', 'until'}

        if current_value == '[':
            return False

        if current_value in {'+', '-', '*', '/', '%', '^', '..', '==', '~=', '<=', '>=', '<', '>', '=', '//'}:
            return True

        if previous_value in {'+', '-', '*', '/', '%', '^', '..', '==', '~=', '<=', '>=', '<', '>', '=', '//'}:
            return True

        if previous_type in {'keyword', 'name', 'number', 'string', 'long_string'} and current_type in {'keyword', 'name', 'number', 'string', 'long_string'}:
            return True

        if previous_type in {'keyword', 'name', 'number', 'string', 'long_string'} and current_value in {'{', '('}:
            return previous_value in {'return'}

        if previous_value in {')', ']', '}'} and current_type in {'keyword', 'name', 'number', 'string', 'long_string'}:
            return True

        return False

    def _can_start_lua_statement(self, token):
        token_type, token_value = token

        if token_type in {'name', 'string', 'number'}:
            return True

        if token_type == 'keyword' and token_value in {'if', 'while', 'for', 'local', 'return', 'break', 'repeat', 'do', 'goto'}:
            return True

        return False

    def _can_end_lua_statement(self, token):
        token_type, token_value = token

        if token_type in {'name', 'number', 'string', 'long_string'}:
            return True

        if token_type == 'keyword' and token_value in {'true', 'false', 'nil', 'break', 'end'}:
            return True

        return token_type == 'symbol' and token_value in {')', ']', '}'}

    def _beautify_lua_source(self, script_content):
        lua_tokens = self._tokenize_lua(script_content)
        lua_tokens = self._simplify_string_key_accesses(lua_tokens)

        if not lua_tokens:
            return script_content

        indentation_level = 0
        current_line = ''
        output_lines = []
        previous_token = None
        paren_depth = 0
        bracket_depth = 0
        brace_depth = 0
        awaiting_function_parentheses = False
        function_header_depths = []
        inside_label = False

        def append_text(text_value):
            nonlocal current_line
            if not current_line:
                current_line = ('    ' * max(indentation_level, 0)) + text_value
            else:
                current_line += text_value

        def write_token(token):
            nonlocal previous_token
            if self._should_insert_space(previous_token, token):
                append_text(' ')
            append_text(token[1])
            previous_token = token

        def flush_line(force_blank=False):
            nonlocal current_line, previous_token
            stripped_line = current_line.rstrip()
            if stripped_line or force_blank:
                output_lines.append(stripped_line)
            current_line = ''
            previous_token = None

        total_tokens = len(lua_tokens)

        for token_index, current_token in enumerate(lua_tokens):
            token_type, token_value = current_token
            next_token = lua_tokens[token_index + 1] if token_index + 1 < total_tokens else None

            if token_type == 'keyword' and token_value in {'end', 'until', 'else', 'elseif'}:
                indentation_level = max(indentation_level - 1, 0)
                if current_line.strip():
                    flush_line()

            if (
                current_line.strip()
                and previous_token is not None
                and bracket_depth == 0
                and brace_depth == 0
                and self._can_end_lua_statement(previous_token)
                and self._can_start_lua_statement(current_token)
            ):
                flush_line()

            if token_type == 'comment':
                if current_line.strip():
                    flush_line()
                append_text(token_value)
                flush_line()
                continue

            is_function_header_close = False

            if token_value == '::':
                if not inside_label and current_line.strip():
                    flush_line()
                write_token(current_token)
                inside_label = not inside_label
                if not inside_label:
                    flush_line()
                continue

            if token_value == '(':
                paren_depth += 1
                if awaiting_function_parentheses:
                    function_header_depths.append(paren_depth)
                    awaiting_function_parentheses = False
            elif token_value == '[':
                bracket_depth += 1
            elif token_value == '{':
                brace_depth += 1
            elif token_value == ')':
                is_function_header_close = bool(function_header_depths and function_header_depths[-1] == paren_depth)

            write_token(current_token)

            if token_type == 'keyword' and token_value == 'function':
                awaiting_function_parentheses = True

            if token_value == ')':
                paren_depth = max(paren_depth - 1, 0)
                if is_function_header_close:
                    function_header_depths.pop()
                    flush_line()
                    indentation_level += 1
                    continue
            elif token_value == ']':
                bracket_depth = max(bracket_depth - 1, 0)
            elif token_value == '}':
                brace_depth = max(brace_depth - 1, 0)

            if token_value == ';':
                flush_line()
                continue

            if token_type == 'keyword' and token_value in {'then', 'do', 'repeat'}:
                flush_line()
                indentation_level += 1
                continue

            if token_type == 'keyword' and token_value == 'else':
                flush_line()
                indentation_level += 1
                continue

            if token_type == 'keyword' and token_value == 'end':
                if next_token and next_token[1] not in {')', ']', '}', ',', ';', 'else', 'elseif'}:
                    flush_line()
                continue

        if current_line.strip():
            flush_line()

        return '\n'.join(output_lines) + '\n'

    def _line_indent(self, line_text):
        indent_match = re.match(r'^[ \t]*', line_text)
        if not indent_match:
            return 0

        indent_width = 0
        for char in indent_match.group(0):
            indent_width += 4 if char == '\t' else 1
        return indent_width

    def _find_matching_block_end_line(self, source_lines, start_index):
        open_depth = 1
        current_index = start_index + 1

        while current_index < len(source_lines):
            stripped_line = source_lines[current_index].strip()
            normalized_line = stripped_line[:-1].rstrip() if stripped_line.endswith(';') else stripped_line

            if re.match(r'^(if\b|while\b|for\b|function\b)', normalized_line):
                open_depth += 1
            elif normalized_line == 'repeat':
                open_depth += 1
            elif normalized_line == 'end' or normalized_line.startswith('until '):
                open_depth -= 1
                if open_depth == 0:
                    return current_index

            current_index += 1

        return -1

    def _is_prometheus_dispatch_if_line(self, line_text, state_var_name, expected_indent=None):
        stripped_line = line_text.strip()
        normalized_line = stripped_line[:-1].rstrip() if stripped_line.endswith(';') else stripped_line

        if expected_indent is not None and self._line_indent(line_text) != expected_indent:
            return False

        return (
            re.match(rf'^if\s+{re.escape(state_var_name)}\s*[<>]', normalized_line) is not None
            or re.match(rf'^if\s*[0-9\-\(\)\s]+\s*[<>]\s*{re.escape(state_var_name)}\b', normalized_line) is not None
        )

    def _parse_prometheus_dispatch_branch(self, body_lines, state_var_name, start_index, parent_if_indent):
        current_index = start_index

        while current_index < len(body_lines) and not body_lines[current_index].strip():
            current_index += 1

        branch_indent = parent_if_indent + 4
        if current_index < len(body_lines) and self._is_prometheus_dispatch_if_line(
            body_lines[current_index],
            state_var_name,
            branch_indent
        ):
            return self._parse_prometheus_dispatch_if(body_lines, state_var_name, current_index, branch_indent)

        leaf_lines = []
        nested_depth = 0

        while current_index < len(body_lines):
            stripped_line = body_lines[current_index].strip()
            normalized_line = stripped_line[:-1].rstrip() if stripped_line.endswith(';') else stripped_line
            current_indent = self._line_indent(body_lines[current_index])

            if (
                nested_depth == 0
                and current_indent == parent_if_indent
                and (
                    normalized_line == 'else'
                    or normalized_line.startswith('elseif ')
                    or normalized_line == 'end'
                )
            ):
                break

            if re.match(r'^(if\b|while\b|for\b|function\b)', normalized_line):
                nested_depth += 1
            elif normalized_line == 'repeat':
                nested_depth += 1
            elif normalized_line == 'end' or normalized_line.startswith('until '):
                nested_depth -= 1

            leaf_lines.append(body_lines[current_index])
            current_index += 1

        return {'type': 'leaf', 'lines': leaf_lines}, current_index

    def _parse_prometheus_dispatch_if(self, body_lines, state_var_name, start_index, if_indent):
        header_line = body_lines[start_index].strip()
        header_line = header_line[:-1].rstrip() if header_line.endswith(';') else header_line
        condition_text = header_line[3:]
        if condition_text.endswith(' then'):
            condition_text = condition_text[:-5]

        current_index = start_index + 1
        then_branch, current_index = self._parse_prometheus_dispatch_branch(
            body_lines,
            state_var_name,
            current_index,
            if_indent
        )

        if (
            current_index < len(body_lines)
            and self._line_indent(body_lines[current_index]) == if_indent
            and (body_lines[current_index].strip()[:-1].rstrip() if body_lines[current_index].strip().endswith(';') else body_lines[current_index].strip()).startswith('elseif ')
        ):
            else_branch, current_index = self._parse_prometheus_dispatch_if(
                body_lines,
                state_var_name,
                current_index,
                if_indent
            )
            return {
                'type': 'if',
                'condition': condition_text,
                'then_branch': then_branch,
                'else_branch': else_branch
            }, current_index

        if (
            current_index < len(body_lines)
            and self._line_indent(body_lines[current_index]) == if_indent
            and ((body_lines[current_index].strip()[:-1].rstrip() if body_lines[current_index].strip().endswith(';') else body_lines[current_index].strip()) == 'else')
        ):
            else_branch, current_index = self._parse_prometheus_dispatch_branch(
                body_lines,
                state_var_name,
                current_index + 1,
                if_indent
            )
        else:
            else_branch = {'type': 'leaf', 'lines': []}

        if (
            current_index >= len(body_lines)
            or self._line_indent(body_lines[current_index]) != if_indent
            or ((body_lines[current_index].strip()[:-1].rstrip() if body_lines[current_index].strip().endswith(';') else body_lines[current_index].strip()) != 'end')
        ):
            raise ValueError('Failed to parse Prometheus dispatch tree')

        return {
            'type': 'if',
            'condition': condition_text,
            'then_branch': then_branch,
            'else_branch': else_branch
        }, current_index + 1

    def _update_dispatch_bounds(self, condition_text, state_var_name, take_then_branch, lower_bound, lower_inclusive, upper_bound, upper_inclusive):
        condition_text = condition_text.strip()
        condition_patterns = [
            (rf'^{re.escape(state_var_name)}\s*<\s*(.+)$', 'lt'),
            (rf'^(.+)\s*>\s*{re.escape(state_var_name)}$', 'lt'),
            (rf'^{re.escape(state_var_name)}\s*>\s*(.+)$', 'gt'),
            (rf'^(.+)\s*<\s*{re.escape(state_var_name)}$', 'gt')
        ]

        for pattern_text, comparison_type in condition_patterns:
            match_object = re.match(pattern_text, condition_text)
            if not match_object:
                continue

            threshold_value = self._safe_evaluate_expression(match_object.group(1))

            if comparison_type == 'lt':
                if take_then_branch:
                    if (
                        upper_bound is None
                        or threshold_value < upper_bound
                        or (threshold_value == upper_bound and not upper_inclusive)
                    ):
                        upper_bound = threshold_value
                        upper_inclusive = False
                else:
                    if (
                        lower_bound is None
                        or threshold_value > lower_bound
                        or (threshold_value == lower_bound and not lower_inclusive)
                    ):
                        lower_bound = threshold_value
                        lower_inclusive = True
            else:
                if take_then_branch:
                    if (
                        lower_bound is None
                        or threshold_value > lower_bound
                        or (threshold_value == lower_bound and lower_inclusive)
                    ):
                        lower_bound = threshold_value
                        lower_inclusive = False
                else:
                    if (
                        upper_bound is None
                        or threshold_value < upper_bound
                        or (threshold_value == upper_bound and upper_inclusive)
                    ):
                        upper_bound = threshold_value
                        upper_inclusive = True

            return lower_bound, lower_inclusive, upper_bound, upper_inclusive

        return lower_bound, lower_inclusive, upper_bound, upper_inclusive

    def _collect_prometheus_dispatch_leaves(self, node, state_var_name, lower_bound=None, lower_inclusive=False, upper_bound=None, upper_inclusive=False):
        if node['type'] == 'leaf':
            return [{
                'lower_bound': lower_bound,
                'lower_inclusive': lower_inclusive,
                'upper_bound': upper_bound,
                'upper_inclusive': upper_inclusive,
                'lines': node['lines']
            }]

        then_bounds = self._update_dispatch_bounds(
            node['condition'],
            state_var_name,
            True,
            lower_bound,
            lower_inclusive,
            upper_bound,
            upper_inclusive
        )
        else_bounds = self._update_dispatch_bounds(
            node['condition'],
            state_var_name,
            False,
            lower_bound,
            lower_inclusive,
            upper_bound,
            upper_inclusive
        )

        return self._collect_prometheus_dispatch_leaves(node['then_branch'], state_var_name, *then_bounds) + self._collect_prometheus_dispatch_leaves(node['else_branch'], state_var_name, *else_bounds)

    def _build_dispatch_interval_condition(self, leaf_data, state_var_name):
        condition_parts = []

        if leaf_data['lower_bound'] is not None:
            lower_operator = '>=' if leaf_data['lower_inclusive'] else '>'
            condition_parts.append(f"{state_var_name} {lower_operator} {leaf_data['lower_bound']}")

        if leaf_data['upper_bound'] is not None:
            upper_operator = '<=' if leaf_data['upper_inclusive'] else '<'
            condition_parts.append(f"{state_var_name} {upper_operator} {leaf_data['upper_bound']}")

        return ' and '.join(condition_parts) if condition_parts else 'true'

    def _dedent_lua_lines(self, source_lines):
        if not source_lines:
            return []

        indent_levels = [self._line_indent(line_text) for line_text in source_lines if line_text.strip()]
        if not indent_levels:
            return ['' for _ in source_lines]

        minimum_indent = min(indent_levels)
        dedented_lines = []

        for line_text in source_lines:
            if not line_text.strip():
                dedented_lines.append('')
            else:
                dedented_lines.append(line_text[minimum_indent:])

        return dedented_lines

    def _flatten_prometheus_dispatchers(self, script_content):
        source_lines = script_content.splitlines()
        current_index = 0
        transformed_any = False

        while current_index < len(source_lines):
            while_match = re.match(
                r'^\s*while\s+([A-Za-z_][A-Za-z0-9_]*)\s*(do)?\s*;?\s*$',
                source_lines[current_index]
            )
            if not while_match:
                current_index += 1
                continue
            state_var_name = while_match.group(1)

            body_start_index = current_index + 1
            if not while_match.group(2):
                if current_index + 1 >= len(source_lines) or source_lines[current_index + 1].strip() != 'do':
                    current_index += 1
                    continue
                body_start_index = current_index + 2

            while_end_index = self._find_matching_block_end_line(source_lines, current_index)
            if while_end_index == -1:
                current_index += 1
                continue

            body_lines = source_lines[body_start_index:while_end_index]
            first_statement = None

            for body_index, line_text in enumerate(body_lines):
                if line_text.strip():
                    first_statement = (body_index, line_text)
                    break

            expected_indent = self._line_indent(source_lines[current_index]) + 4
            if (
                first_statement is None
                or not self._is_prometheus_dispatch_if_line(first_statement[1], state_var_name, expected_indent)
            ):
                current_index = while_end_index + 1
                continue

            try:
                dispatch_tree, parsed_index = self._parse_prometheus_dispatch_if(
                    body_lines,
                    state_var_name,
                    first_statement[0],
                    expected_indent
                )
            except Exception:
                current_index = while_end_index + 1
                continue

            if parsed_index != len(body_lines):
                current_index = while_end_index + 1
                continue

            flattened_lines = []
            base_indent = ' ' * expected_indent
            leaf_indent = ' ' * (expected_indent + 4)
            dispatch_leaves = self._collect_prometheus_dispatch_leaves(dispatch_tree, state_var_name)

            for leaf_index, leaf_data in enumerate(dispatch_leaves):
                keyword_text = 'if' if leaf_index == 0 else 'elseif'
                condition_text = self._build_dispatch_interval_condition(leaf_data, state_var_name)
                flattened_lines.append(f"{base_indent}{keyword_text} {condition_text} then")

                for dedented_line in self._dedent_lua_lines(leaf_data['lines']):
                    if dedented_line:
                        flattened_lines.append(f"{leaf_indent}{dedented_line}")
                    else:
                        flattened_lines.append('')

            flattened_lines.append(f"{base_indent}else")
            flattened_lines.append(f"{leaf_indent}break")
            flattened_lines.append(f"{base_indent}end")

            source_lines = (
                source_lines[:body_start_index]
                + flattened_lines
                + source_lines[while_end_index:]
            )
            current_index = body_start_index + len(flattened_lines)
            transformed_any = True

        if not transformed_any:
            return script_content

        return '\n'.join(source_lines) + '\n'

    def _simplify_numeric_value(self, value_text):
        try:
            return str(self._safe_evaluate_expression(value_text))
        except Exception:
            return value_text

    def _simplify_numeric_line(self, line_text):
        replacement_patterns = [
            r'(\b(?:and|or)\s*)([0-9\s+\-()]+)(?=(?:\s+\b(?:and|or)\b|\s*$))',
            r'(^\s*(?:local\s+)?[A-Za-z_][A-Za-z0-9_]*(?:\[[^\]]+\])?\s*=\s*)([0-9\s+\-()]+)(\s*$)',
            r'(^\s*(?:if|elseif)\s+m\s*[<>]=?\s*)([0-9\s+\-()]+)(\s*then\s*$)',
            r'(^\s*(?:if|elseif)\s*)([0-9\s+\-()]+)(\s*[<>]=?\s*m\s*then\s*$)',
            r'(^\s*while\s+m\s*[<>]=?\s*)([0-9\s+\-()]+)(\s*$)',
            r'(^\s*while\s*)([0-9\s+\-()]+)(\s*[<>]=?\s*m\s*$)',
            r'(\[\s*)([0-9\s+\-()]+)(\s*\])'
        ]

        current_line = line_text

        for pattern_text in replacement_patterns:
            def replace_numeric(match_object):
                leading_text = match_object.group(1)
                numeric_text = match_object.group(2)
                trailing_text = match_object.group(3) if match_object.lastindex and match_object.lastindex >= 3 else ''
                return f"{leading_text}{self._simplify_numeric_value(numeric_text)}{trailing_text}"

            current_line = re.sub(pattern_text, replace_numeric, current_line)

        current_line = re.sub(r'(\d)(then\b)', r'\1 \2', current_line)

        return current_line

    def _simplify_numeric_lines(self, script_content):
        return '\n'.join(self._simplify_numeric_line(line_text) for line_text in script_content.splitlines()) + '\n'

    def _looks_like_lua_statement_start(self, text_content):
        stripped_text = text_content.lstrip()
        if not stripped_text:
            return False

        return bool(re.match(
            r'^(?:return\b|local\b|if\b|while\b|for\b|repeat\b|do\b|break\b|'
            r'[A-Za-z_][A-Za-z0-9_]*(?:\s*,|\s*=|\s*\())',
            stripped_text
        ))

    def _split_top_level_lua_expressions(self, expression_text, expected_count=None):
        items = []
        current_item = []
        current_index = 0
        paren_depth = 0
        brace_depth = 0
        bracket_depth = 0
        block_stack = []
        pending_loop_header = False

        while current_index < len(expression_text):
            current_char = expression_text[current_index]

            if expression_text.startswith('--', current_index):
                long_comment_end = self._consume_long_bracket(expression_text, current_index + 2)
                if long_comment_end is not None:
                    comment_text = expression_text[current_index:long_comment_end]
                    current_item.append(comment_text)
                    current_index = long_comment_end
                    continue

                line_end = expression_text.find('\n', current_index)
                if line_end == -1:
                    line_end = len(expression_text)
                current_item.append(expression_text[current_index:line_end])
                current_index = line_end
                continue

            long_string_end = self._consume_long_bracket(expression_text, current_index)
            if long_string_end is not None:
                current_item.append(expression_text[current_index:long_string_end])
                current_index = long_string_end
                continue

            if current_char in ('"', "'"):
                string_delimiter = current_char
                string_start = current_index
                current_index += 1
                is_escaped = False

                while current_index < len(expression_text):
                    scan_char = expression_text[current_index]
                    if is_escaped:
                        is_escaped = False
                    elif scan_char == '\\':
                        is_escaped = True
                    elif scan_char == string_delimiter:
                        current_index += 1
                        break
                    current_index += 1

                current_item.append(expression_text[string_start:current_index])
                continue

            if current_char.isalpha() or current_char == '_':
                identifier_start = current_index
                current_index += 1
                while current_index < len(expression_text):
                    scan_char = expression_text[current_index]
                    if not (scan_char.isalnum() or scan_char == '_'):
                        break
                    current_index += 1
                identifier_text = expression_text[identifier_start:current_index]
                current_item.append(identifier_text)

                if identifier_text == 'function':
                    block_stack.append('function')
                    pending_loop_header = False
                elif identifier_text == 'if':
                    block_stack.append(identifier_text)
                    pending_loop_header = False
                elif identifier_text in {'for', 'while'}:
                    block_stack.append(identifier_text)
                    pending_loop_header = True
                elif identifier_text == 'do':
                    if pending_loop_header:
                        pending_loop_header = False
                    else:
                        block_stack.append('do')
                elif identifier_text == 'repeat':
                    block_stack.append('repeat')
                    pending_loop_header = False
                elif identifier_text == 'until':
                    if block_stack and block_stack[-1] == 'repeat':
                        block_stack.pop()
                    pending_loop_header = False
                elif identifier_text == 'end':
                    for stack_index in range(len(block_stack) - 1, -1, -1):
                        if block_stack[stack_index] != 'repeat':
                            del block_stack[stack_index]
                            break
                    pending_loop_header = False
                elif self._is_prometheus_lua_keyword(identifier_text):
                    pending_loop_header = False
                continue

            if current_char == '(':
                paren_depth += 1
            elif current_char == ')':
                paren_depth = max(paren_depth - 1, 0)
            elif current_char == '{':
                brace_depth += 1
            elif current_char == '}':
                brace_depth = max(brace_depth - 1, 0)
            elif current_char == '[':
                bracket_depth += 1
            elif current_char == ']':
                bracket_depth = max(bracket_depth - 1, 0)
            elif (
                current_char == ','
                and paren_depth == 0
                and brace_depth == 0
                and bracket_depth == 0
                and not block_stack
            ):
                item_text = ''.join(current_item).strip()
                if item_text:
                    items.append(item_text)
                current_item = []
                current_index += 1
                continue
            elif (
                current_char == '\n'
                and expected_count is not None
                and len(items) == expected_count - 1
                and paren_depth == 0
                and brace_depth == 0
                and bracket_depth == 0
                and not block_stack
            ):
                item_text = ''.join(current_item).strip()
                if item_text and self._looks_like_lua_statement_start(expression_text[current_index + 1:]):
                    items.append(item_text)
                    return items

            current_item.append(current_char)
            current_index += 1

        item_text = ''.join(current_item).strip()
        if item_text:
            items.append(item_text)

        return items

    def _extract_prometheus_runtime_assignment(self, script_content):
        assignment_pattern = re.compile(
            r'^\s*([A-Za-z_][A-Za-z0-9_]*(?:\s*,\s*[A-Za-z_][A-Za-z0-9_]*){5,})\s*=',
            re.MULTILINE
        )

        for match_object in assignment_pattern.finditer(script_content):
            names = [name.strip() for name in match_object.group(1).split(',')]
            rhs_items = self._split_top_level_lua_expressions(
                script_content[match_object.end():],
                expected_count=len(names)
            )
            if len(rhs_items) != len(names):
                continue
            if sum(1 for item_text in rhs_items if item_text.lstrip().startswith('function(')) < 4:
                continue
            return {
                'names': names,
                'values': rhs_items
            }

        return None

    def _infer_prometheus_creator_args(self, expression_text):
        creator_match = re.search(
            r'^function\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*,\s*([A-Za-z_][A-Za-z0-9_]*)\s*\)\s*'
            r'local\s+[A-Za-z_][A-Za-z0-9_]*\s*=\s*[A-Za-z_][A-Za-z0-9_]*\(\s*\2\s*\)\s*;?\s*'
            r'local\s+[A-Za-z_][A-Za-z0-9_]*\s*=\s*function\(([^)]*)\)\s*'
            r'return\s+[A-Za-z_][A-Za-z0-9_]*\(\s*\1\s*,\s*\{',
            expression_text,
            re.DOTALL
        )
        if not creator_match:
            return None

        argument_text = creator_match.group(3).strip()
        if argument_text == '...':
            return 'vararg'
        if not argument_text:
            return []
        argument_count = len([item.strip() for item in argument_text.split(',') if item.strip()])
        return [f'arg{i}' for i in range(1, argument_count + 1)]

    def _infer_prometheus_alloc_role(self, expression_text):
        if not re.match(r'^function\(\s*\)', expression_text):
            return None

        return_matches = re.findall(r'\breturn\s+([A-Za-z_][A-Za-z0-9_]*)\s*;?', expression_text)
        if not return_matches:
            return None

        counter_name = return_matches[-1]
        refcount_match = re.search(
            rf'([A-Za-z_][A-Za-z0-9_]*)\[\s*{re.escape(counter_name)}\s*\]\s*=\s*1\b',
            expression_text
        )
        if not refcount_match:
            return None

        return {
            'counter_name': counter_name,
            'refcount_table_name': refcount_match.group(1)
        }

    def _infer_prometheus_free_slot_role(self, expression_text):
        if not re.match(r'^function\(\s*[A-Za-z_][A-Za-z0-9_]*\s*\)', expression_text):
            return None

        nil_match = re.search(
            r'([A-Za-z_][A-Za-z0-9_]*)\[\s*([A-Za-z_][A-Za-z0-9_]*)\s*\]\s*,\s*'
            r'([A-Za-z_][A-Za-z0-9_]*)\[\s*\2\s*\]\s*=\s*nil\s*,\s*nil',
            expression_text
        )
        if not nil_match:
            return None

        return {
            'refcount_table_name': nil_match.group(1),
            'slot_table_name': nil_match.group(3)
        }

    def _infer_prometheus_cleanup_role(self, expression_text):
        if not re.match(r'^function\(\s*[A-Za-z_][A-Za-z0-9_]*\s*\)', expression_text):
            return None
        if 'while ' not in expression_text or ' = nil,nil' not in expression_text:
            return None

        nil_match = re.search(
            r'([A-Za-z_][A-Za-z0-9_]*)\[\s*([A-Za-z_][A-Za-z0-9_]*)\s*\]\s*,\s*'
            r'([A-Za-z_][A-Za-z0-9_]*)\[\s*\2\s*\]\s*=\s*nil\s*,\s*nil',
            expression_text
        )
        if not nil_match:
            return None

        return {
            'refcount_table_name': nil_match.group(1),
            'slot_table_name': nil_match.group(3)
        }

    def _extract_prometheus_runtime_layout(self, script_content):
        runtime_assignment = self._extract_prometheus_runtime_assignment(script_content)
        if runtime_assignment:
            creator_args = {}
            alloc_slot_name = None
            slot_table_name = None
            refcount_table_name = None
            slot_counter_name = None
            cleanup_name = None
            free_slot_name = None
            proxy_builder_name = None

            for name_text, value_text in zip(runtime_assignment['names'], runtime_assignment['values']):
                creator_spec = self._infer_prometheus_creator_args(value_text)
                if creator_spec is not None:
                    creator_args[name_text] = creator_spec
                    continue

                alloc_role = self._infer_prometheus_alloc_role(value_text)
                if alloc_role:
                    alloc_slot_name = name_text
                    slot_counter_name = alloc_role['counter_name']
                    refcount_table_name = alloc_role['refcount_table_name']
                    continue

                free_role = self._infer_prometheus_free_slot_role(value_text)
                if free_role:
                    free_slot_name = name_text
                    slot_table_name = slot_table_name or free_role['slot_table_name']
                    refcount_table_name = refcount_table_name or free_role['refcount_table_name']
                    continue

                cleanup_role = self._infer_prometheus_cleanup_role(value_text)
                if cleanup_role:
                    cleanup_name = name_text
                    slot_table_name = slot_table_name or cleanup_role['slot_table_name']
                    refcount_table_name = refcount_table_name or cleanup_role['refcount_table_name']
                    continue

                if '__index' in value_text and '__gc' in value_text and '__len' in value_text:
                    proxy_builder_name = name_text

            if creator_args and alloc_slot_name and slot_table_name:
                return {
                    'cleanup_name': cleanup_name,
                    'creator_args': creator_args,
                    'container_name': None,
                    'slot_counter_name': slot_counter_name,
                    'slot_table_name': slot_table_name,
                    'free_slot_name': free_slot_name,
                    'alloc_slot_name': alloc_slot_name,
                    'proxy_builder_name': proxy_builder_name,
                    'refcount_table_name': refcount_table_name
                }

        runtime_match = re.search(
            r'^\s*([A-Za-z_][A-Za-z0-9_]*(?:\s*,\s*[A-Za-z_][A-Za-z0-9_]*){13})\s*=\s*function\(',
            script_content,
            re.MULTILINE
        )
        if not runtime_match:
            return None

        names = [name.strip() for name in runtime_match.group(1).split(',')]
        if len(names) != 14:
            return None

        creator_args = {
            names[1]: ['arg1', 'arg2', 'arg3', 'arg4', 'arg5', 'arg6', 'arg7'],
            names[2]: [],
            names[3]: ['arg1'],
            names[7]: 'vararg',
            names[8]: ['arg1', 'arg2', 'arg3'],
            names[11]: ['arg1', 'arg2', 'arg3', 'arg4']
        }

        return {
            'cleanup_name': names[0],
            'creator_args': creator_args,
            'container_name': names[4],
            'slot_counter_name': names[5],
            'slot_table_name': names[6],
            'free_slot_name': names[9],
            'alloc_slot_name': names[10],
            'proxy_builder_name': names[12],
            'refcount_table_name': names[13]
        }

    def _extract_prometheus_top_call(self, script_content, runtime_layout):
        if not runtime_layout:
            return None

        creator_names = list(runtime_layout['creator_args'])
        preferred_vararg = next(
            (name for name, arg_spec in runtime_layout['creator_args'].items() if arg_spec == 'vararg'),
            None
        )
        if preferred_vararg:
            creator_names = [preferred_vararg] + [name for name in creator_names if name != preferred_vararg]

        for creator_name in creator_names:
            top_call_match = re.search(
                rf'return\s+\(\s*({re.escape(creator_name)})\s*\(\s*([^,]+?)\s*,\s*\{{\s*\}}\s*\)\s*\)\s*\(',
                script_content
            )
            if not top_call_match:
                continue

            try:
                start_block_id = self._safe_evaluate_expression(top_call_match.group(2))
            except Exception:
                continue

            return {
                'creator_name': top_call_match.group(1),
                'start_block_id': start_block_id
            }

        fallback_matches = re.finditer(
            r'return\s+\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*\(\s*([^,]+?)\s*,\s*\{\s*\}\s*\)\s*\)\s*\(',
            script_content
        )
        for match_object in fallback_matches:
            creator_name = match_object.group(1)
            try:
                start_block_id = self._safe_evaluate_expression(match_object.group(2))
            except Exception:
                continue
            return {
                'creator_name': creator_name,
                'start_block_id': start_block_id
            }

        return None

    def _extract_prometheus_env_names(self, script_content):
        env_names = []
        for match_object in re.finditer(r'return\s+\(\s*function\(([^)]*)\)', script_content):
            params = [item.strip() for item in match_object.group(1).split(',') if item.strip()]
            if not params or params[0] == '...':
                continue
            env_name = params[0]
            if re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', env_name) and env_name not in env_names:
                env_names.append(env_name)
            if env_names:
                break
        return env_names

    def _extract_prometheus_outer_params(self, script_content):
        for match_object in re.finditer(r'return\s+\(\s*function\(([^)]*)\)', script_content):
            params = [item.strip() for item in match_object.group(1).split(',') if item.strip()]
            if not params or params == ['...']:
                continue
            if params:
                return params
        return []

    def _extract_main_prometheus_loop(self, script_content):
        source_lines = script_content.splitlines()
        best_loop = None
        current_index = 0

        while current_index < len(source_lines):
            while_match = re.match(
                r'^(\s*)while\s+([A-Za-z_][A-Za-z0-9_]*)\s*(do)?\s*$',
                source_lines[current_index]
            )
            if not while_match:
                current_index += 1
                continue

            body_start_index = current_index + 1
            if not while_match.group(3):
                if current_index + 1 >= len(source_lines) or source_lines[current_index + 1].strip() != 'do':
                    current_index += 1
                    continue
                body_start_index = current_index + 2

            end_index = self._find_matching_block_end_line(source_lines, current_index)
            if end_index == -1:
                current_index += 1
                continue

            loop_size = end_index - current_index
            if best_loop is None or loop_size > best_loop['size']:
                function_params = None
                search_index = current_index - 1
                while search_index >= 0:
                    function_match = re.search(r'function\(([^)]*)\)\s*$', source_lines[search_index].strip())
                    if function_match:
                        function_params = [item.strip() for item in function_match.group(1).split(',') if item.strip()]
                        break
                    search_index -= 1

                best_loop = {
                    'start_line': current_index,
                    'end_line': end_index,
                    'state_var': while_match.group(2),
                    'indent': len(while_match.group(1)),
                    'body_lines': source_lines[body_start_index:end_index],
                    'size': loop_size,
                    'function_params': function_params or []
                }

            current_index = end_index + 1

        return best_loop

    def _extract_prometheus_register_name_map(self, script_content, loop_data):
        if not loop_data:
            return {}

        source_lines = script_content.splitlines()
        local_decl_index = loop_data['start_line'] - 1
        while local_decl_index >= 0 and not source_lines[local_decl_index].strip():
            local_decl_index -= 1

        if local_decl_index < 0:
            return {}

        local_decl_match = re.match(
            r'^\s*local\s+([A-Za-z_][A-Za-z0-9_]*(?:\s*,\s*[A-Za-z_][A-Za-z0-9_]*)+)\s*;?\s*$',
            source_lines[local_decl_index]
        )
        if not local_decl_match:
            return {}

        raw_names = [item.strip() for item in local_decl_match.group(1).split(',') if item.strip()]
        register_map = {}
        register_counter = 1

        for index, raw_name in enumerate(raw_names, start=1):
            if index == 13:
                register_map[raw_name] = 'ret_reg'
                continue

            register_map[raw_name] = f"r{register_counter}"
            register_counter += 1

        return register_map

    def _find_prometheus_enclosing_function_range(self, source_lines, line_index):
        function_start = None

        for search_index in range(line_index, -1, -1):
            if re.search(r'\bfunction\s*\([^)]*\)\s*$', source_lines[search_index].strip()):
                function_start = search_index
                break

        if function_start is None:
            return None

        function_end = self._find_matching_block_end_line(source_lines, function_start)
        if function_end == -1:
            return None

        return function_start, function_end

    def _rename_prometheus_run_vm_scope(self, script_content, rename_map):
        if not rename_map:
            return script_content

        loop_data = self._extract_main_prometheus_loop(script_content)
        if not loop_data:
            return script_content

        source_lines = script_content.splitlines()
        function_range = self._find_prometheus_enclosing_function_range(source_lines, loop_data['start_line'])
        if not function_range:
            return script_content

        function_start, function_end = function_range
        function_text = '\n'.join(source_lines[function_start:function_end + 1])
        rewritten_function = self._replace_lua_identifier_tokens(function_text, rename_map)
        rewritten_lines = rewritten_function.splitlines()

        source_lines = (
            source_lines[:function_start]
            + rewritten_lines
            + source_lines[function_end + 1:]
        )
        return '\n'.join(source_lines) + ('\n' if script_content.endswith('\n') else '')

    def _rename_prometheus_vm_registers(self, script_content):
        loop_data = self._extract_main_prometheus_loop(script_content)
        if not loop_data:
            return script_content

        rename_map = {}
        function_params = loop_data.get('function_params') or []
        param_targets = ['pc', 'argv', 'captured_upvalues', 'gc_guard']
        for index, target_name in enumerate(param_targets):
            if index < len(function_params):
                rename_map[function_params[index]] = target_name

        rename_map.update(self._extract_prometheus_register_name_map(script_content, loop_data))
        return self._rename_prometheus_run_vm_scope(script_content, rename_map)

    def _format_prometheus_devirtualized_top_level(self, body_text, script_content, loop_data, top_call, runtime_layout):
        outer_params = self._extract_prometheus_outer_params(script_content)
        if len(outer_params) >= 1:
            env_name = outer_params[0]
            body_text = re.sub(rf'\b{re.escape(env_name)}\s*\[', 'env[', body_text)
            body_text = re.sub(rf'\b{re.escape(env_name)}\s*\.', 'env.', body_text)
        if len(outer_params) >= 2:
            unpack_name = outer_params[1]
            body_text = re.sub(rf'\b{re.escape(unpack_name)}\s*\(', 'unpack_fn(', body_text)

        output_lines = []
        creator_spec = runtime_layout.get('creator_args', {}).get(top_call.get('creator_name'))

        if creator_spec == 'vararg':
            output_lines.append('local unpack_fn = unpack or table.unpack')
            output_lines.append('local argv = { ... }')

        register_map = self._extract_prometheus_register_name_map(script_content, loop_data)
        ordered_register_names = [name for name in register_map.values() if name.startswith('r')]
        used_registers = [
            register_name
            for register_name in ordered_register_names
            if re.search(rf'\b{re.escape(register_name)}\b', body_text)
        ]

        local_decls = []
        if 'ret_reg' in body_text:
            local_decls.append('ret_reg')
        local_decls.extend(used_registers)
        local_decls = list(dict.fromkeys(local_decls))

        if local_decls:
            output_lines.append('local ' + ', '.join(local_decls))

        output_lines.append(body_text.strip())
        return '\n'.join(output_lines) + '\n'

    def _extract_prometheus_block_candidates(self, loop_data, known_block_ids, preferred_block_ids=None):
        if not loop_data:
            return {}

        preferred_block_ids = preferred_block_ids or set()

        state_var_name = loop_data['state_var']
        block_candidates = []
        current_block = None

        def parse_header(header_text):
            for pattern_text, parser in (
                (
                    rf'^(if|elseif)\s+{re.escape(state_var_name)}\s*<\s*(\d+)\s+then$',
                    lambda match_object: (None, int(match_object.group(2)))
                ),
                (
                    rf'^(if|elseif)\s+{re.escape(state_var_name)}\s*>=\s*(\d+)\s+and\s+{re.escape(state_var_name)}\s*<\s*(\d+)\s+then$',
                    lambda match_object: (int(match_object.group(2)), int(match_object.group(3)))
                ),
                (
                    rf'^(if|elseif)\s+{re.escape(state_var_name)}\s*>=\s*(\d+)\s+then$',
                    lambda match_object: (int(match_object.group(2)), None)
                )
            ):
                match_object = re.match(pattern_text, header_text)
                if match_object:
                    lower_bound, upper_bound = parser(match_object)
                    return {
                        'lower_bound': lower_bound,
                        'upper_bound': upper_bound
                    }
            return None

        for line_text in loop_data['body_lines']:
            stripped_line = line_text.strip()
            normalized_line = stripped_line[:-1].rstrip() if stripped_line.endswith(';') else stripped_line
            if parse_header(normalized_line):
                header_info = parse_header(normalized_line)
                if current_block:
                    block_candidates.append(current_block)
                current_block = {
                    'header': normalized_line,
                    'header_info': header_info,
                    'lines': []
                }
                continue

            if normalized_line == 'else':
                break

            if current_block is not None:
                current_block['lines'].append(line_text)

        if current_block:
            block_candidates.append(current_block)

        blocks_by_id = {}

        previous_upper_bound = None

        for block_candidate in block_candidates:
            header_info = block_candidate.get('header_info') or parse_header(block_candidate['header'])
            if not header_info:
                continue

            lower_bound = header_info['lower_bound']
            upper_bound = header_info['upper_bound']
            if lower_bound is None and upper_bound is not None and previous_upper_bound is not None:
                lower_bound = previous_upper_bound

            matching_ids = sorted(
                block_id
                for block_id in known_block_ids
                if (lower_bound is None or block_id >= lower_bound) and (upper_bound is None or block_id < upper_bound)
            )

            if upper_bound is not None:
                previous_upper_bound = upper_bound

            preferred_matches = [block_id for block_id in matching_ids if block_id in preferred_block_ids]
            if preferred_matches:
                selected_ids = preferred_matches
            elif len(matching_ids) == 1:
                selected_ids = matching_ids
            elif len(matching_ids) <= 3:
                selected_ids = matching_ids
            else:
                selected_ids = []

            if not selected_ids:
                continue

            for block_id in selected_ids:
                blocks_by_id[block_id] = {
                    'id': block_id,
                    'header': block_candidate['header'],
                    'lines': block_candidate['lines']
                }

        return blocks_by_id

    def _group_prometheus_block_statements(self, block_lines):
        joined_text = '\n'.join(block_lines)
        statement_buffer = []
        grouped_statements = []
        paren_depth = 0
        brace_depth = 0
        bracket_depth = 0
        in_string = None
        is_escaped = False

        for current_char in joined_text:
            statement_buffer.append(current_char)

            if in_string:
                if is_escaped:
                    is_escaped = False
                elif current_char == '\\':
                    is_escaped = True
                elif current_char == in_string:
                    in_string = None
                continue

            if current_char in ('"', "'"):
                in_string = current_char
                continue

            if current_char == '(':
                paren_depth += 1
            elif current_char == ')':
                paren_depth = max(paren_depth - 1, 0)
            elif current_char == '{':
                brace_depth += 1
            elif current_char == '}':
                brace_depth = max(brace_depth - 1, 0)
            elif current_char == '[':
                bracket_depth += 1
            elif current_char == ']':
                bracket_depth = max(bracket_depth - 1, 0)
            elif current_char == '\n' and paren_depth == 0 and brace_depth == 0 and bracket_depth == 0:
                statement_text = ''.join(statement_buffer).strip()
                if statement_text:
                    grouped_statements.append(statement_text)
                statement_buffer = []

        statement_text = ''.join(statement_buffer).strip()
        if statement_text:
            grouped_statements.append(statement_text)

        return grouped_statements

    def _resolve_prometheus_numeric(self, value_text, numeric_aliases):
        value_text = value_text.strip()

        if value_text in numeric_aliases:
            return numeric_aliases[value_text]

        try:
            return self._safe_evaluate_expression(value_text)
        except Exception:
            return None

    def _resolve_prometheus_transition(self, block_data, state_var_name, env_names=None, slot_table_name=None):
        statements = self._group_prometheus_block_statements(block_data['lines'])
        state_assignments = []
        numeric_aliases = {}
        slot_value_aliases = {}
        env_names = env_names or []

        for statement_text in statements:
            assignment_index = self._find_top_level_assignment(statement_text)
            if assignment_index == -1:
                continue

            lhs_text = statement_text[:assignment_index].strip()
            rhs_text = statement_text[assignment_index + 1:].strip().rstrip(';').strip()

            if re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', lhs_text):
                numeric_value = self._resolve_prometheus_numeric(rhs_text, numeric_aliases)
                if numeric_value is not None:
                    numeric_aliases[lhs_text] = numeric_value

            if slot_table_name:
                slot_store_match = re.fullmatch(
                    rf'{re.escape(slot_table_name)}\[(.+)\]',
                    lhs_text
                )
                if slot_store_match:
                    slot_value_aliases[slot_store_match.group(1).strip()] = rhs_text

            if lhs_text == state_var_name:
                normalized_rhs = rhs_text
                if slot_table_name:
                    slot_load_match = re.fullmatch(
                        rf'{re.escape(slot_table_name)}\[(.+)\]',
                        rhs_text
                    )
                    if slot_load_match:
                        normalized_rhs = slot_value_aliases.get(
                            slot_load_match.group(1).strip(),
                            rhs_text
                        )
                state_assignments.append(normalized_rhs)

        transition = {'type': 'unknown'}

        if not state_assignments:
            return transition

        last_assignment = state_assignments[-1].rstrip(';').strip()
        previous_assignment = state_assignments[-2].rstrip(';').strip() if len(state_assignments) >= 2 else None

        direct_branch_match = re.match(r'^(.*?)\s+and\s+(.+?)\s+or\s+(.+)$', last_assignment)
        if direct_branch_match:
            true_target = self._resolve_prometheus_numeric(direct_branch_match.group(2), numeric_aliases)
            false_target = self._resolve_prometheus_numeric(direct_branch_match.group(3), numeric_aliases)
            if true_target is not None and false_target is not None:
                condition_text = direct_branch_match.group(1).strip()
                if condition_text == state_var_name and previous_assignment:
                    condition_text = previous_assignment.strip()
                return {
                    'type': 'branch',
                    'condition': condition_text,
                    'true_target': true_target,
                    'false_target': false_target
                }

        if previous_assignment:
            staged_branch_match = re.match(r'^(.*?)\s+and\s+(.+)$', previous_assignment)
            fallback_match = re.match(rf'^{re.escape(state_var_name)}\s+or\s+(.+)$', last_assignment)
            if staged_branch_match and fallback_match:
                true_target = self._resolve_prometheus_numeric(staged_branch_match.group(2), numeric_aliases)
                false_target = self._resolve_prometheus_numeric(fallback_match.group(1), numeric_aliases)
                if true_target is not None and false_target is not None:
                    return {
                        'type': 'branch',
                        'condition': staged_branch_match.group(1).strip(),
                        'true_target': true_target,
                        'false_target': false_target
                    }

        direct_target = self._resolve_prometheus_numeric(last_assignment, numeric_aliases)
        if direct_target is not None:
            return {
                'type': 'goto',
                'target': direct_target
            }

        for env_name in env_names:
            if last_assignment.startswith(f'{env_name}[') or last_assignment.startswith(f'{env_name}.'):
                return {
                    'type': 'return',
                    'value': last_assignment
                }

        return {
            'type': 'unknown',
            'raw': last_assignment
        }

    def _collect_prometheus_entry_ids(self, script_content, runtime_layout, state_var_name):
        known_ids = set()

        state_assignment_pattern = re.compile(rf'^\s*{re.escape(state_var_name)}\s*=\s*(.+?)\s*$', re.MULTILINE)
        for match_object in state_assignment_pattern.finditer(script_content):
            for numeric_text in re.findall(r'\b\d+\b', match_object.group(1)):
                known_ids.add(int(numeric_text))

        known_ids |= self._collect_prometheus_creator_entry_ids(script_content, runtime_layout)

        return known_ids

    def _collect_prometheus_creator_entry_ids(self, script_content, runtime_layout):
        creator_ids = set()
        for creator_name in runtime_layout.get('creator_args', {}):
            creator_pattern = re.compile(
                rf'\b{re.escape(creator_name)}\(([-0-9 +*/()^]+),\s*\{{',
                re.MULTILINE
            )
            for match_object in creator_pattern.finditer(script_content):
                try:
                    creator_ids.add(self._safe_evaluate_expression(match_object.group(1)))
                except Exception:
                    continue
        return creator_ids

    def _make_prometheus_slot_name(self, decompile_state, preferred_name=None):
        used_slot_names = decompile_state.setdefault('used_slot_names', set())

        while True:
            decompile_state['slot_counter'] += 1
            generated_name = f"v{decompile_state['slot_counter'] - 1}"
            if generated_name not in used_slot_names:
                used_slot_names.add(generated_name)
                return generated_name

    def _make_prometheus_safe_name(self, decompile_state, prefix='v'):
        decompile_state['slot_counter'] += 1
        return f"{prefix}{decompile_state['slot_counter'] - 1}"

    def _normalize_prometheus_identifier_name(self, identifier_name, decompile_state):
        if self._is_prometheus_lua_keyword(identifier_name):
            return self._make_prometheus_safe_name(decompile_state)
        return identifier_name

    def _score_prometheus_payload_block(self, block_data):
        block_text = '\n'.join(block_data.get('lines', []))
        positive_markers = {
            '"floor"': 10,
            '"remove"': 10,
            '"char"': 10,
            'game:GetService': 10,
            '"GetService"': 8,
            'Workspace': 5,
            'Players': 5,
            'ReplicatedStorage': 5,
            'RunService': 5,
            'getgenv': 5,
            'Network': 4,
            'WaitForChild': 4,
            'GetChildren': 4,
            'FireServer': 4,
        }
        negative_markers = {
            'Tamper Detected!': -25,
            'traceback': -8,
            'debug': -8,
            'gmatch': -6,
            'pcall': -2,
        }

        score_value = 0

        for marker_text, weight_value in positive_markers.items():
            if marker_text in block_text:
                score_value += weight_value

        for marker_text, weight_value in negative_markers.items():
            if marker_text in block_text:
                score_value += weight_value

        return score_value

    def _select_prometheus_payload_start(self, blocks_by_id, default_start_block):
        anti_tamper_detected = any(
            'Tamper Detected!' in '\n'.join(block_data.get('lines', []))
            for block_data in blocks_by_id.values()
        )

        if not anti_tamper_detected:
            return default_start_block

        best_block_id = default_start_block
        best_score = self._score_prometheus_payload_block(blocks_by_id.get(default_start_block, {}))

        for block_id, block_data in blocks_by_id.items():
            current_score = self._score_prometheus_payload_block(block_data)
            if current_score > best_score:
                best_score = current_score
                best_block_id = block_id

        return best_block_id if best_score >= 8 else default_start_block

    def _trim_prometheus_payload_preamble(self, block_lines):
        payload_markers = (
            '"floor"',
            '"remove"',
            '"char"',
            'game:GetService',
            '"GetService"',
            'Workspace',
            'Players',
            'ReplicatedStorage',
            'RunService',
            'getgenv',
            'Network'
        )
        library_markers = (
            '"math"',
            '"table"',
            '"string"',
            'game:GetService',
            '"GetService"',
            'getgenv'
        )

        payload_start_index = None
        for line_index, line_text in enumerate(block_lines):
            if any(marker_text in line_text for marker_text in payload_markers):
                payload_start_index = line_index
                break

        if payload_start_index is None:
            return block_lines

        for line_index, line_text in enumerate(block_lines):
            if line_index > payload_start_index:
                break
            if any(marker_text in line_text for marker_text in library_markers):
                return block_lines[line_index:]

        return block_lines[payload_start_index:]

    def _render_prometheus_alias(self, alias_value):
        if isinstance(alias_value, dict) and alias_value.get('type') == 'slot':
            return alias_value['name']
        return None

    def _render_prometheus_capture_value(self, capture_text, local_aliases):
        alias_value = local_aliases.get(capture_text)
        if isinstance(alias_value, dict) and alias_value.get('type') == 'slot':
            return f"__slotref__{alias_value['name']}"
        for candidate_alias in local_aliases.values():
            if (
                isinstance(candidate_alias, dict)
                and candidate_alias.get('type') == 'slot'
                and candidate_alias.get('name') == capture_text
            ):
                return f"__slotref__{capture_text}"
        return capture_text

    def _replace_prometheus_capture_refs(self, expression_text, capture_var_name, captures):
        def replace_capture(match_object):
            capture_index = int(match_object.group(1)) - 1
            if 0 <= capture_index < len(captures):
                return captures[capture_index]
            return f"capture_{capture_index + 1}"

        return re.sub(
            rf'{re.escape(capture_var_name)}\[(\d+)\]',
            replace_capture,
            expression_text
        )

    def _replace_prometheus_slot_refs(self, expression_text, slot_table_name, local_aliases):
        expression_text = re.sub(
            rf'{re.escape(slot_table_name)}\[\s*__slotref__([A-Za-z_][A-Za-z0-9_]*)\s*\]',
            lambda match_object: match_object.group(1),
            expression_text
        )
        slot_alias_names = set()
        for alias_name, alias_value in sorted(local_aliases.items(), key=lambda item: -len(item[0])):
            if isinstance(alias_value, dict) and alias_value.get('type') == 'slot':
                slot_alias_name = alias_value.get('name')
                if isinstance(slot_alias_name, str) and slot_alias_name:
                    slot_alias_names.add(slot_alias_name)
                expression_text = expression_text.replace(
                    f"{slot_table_name}[{alias_name}]",
                    alias_value['name']
                )
        for slot_alias_name in sorted(slot_alias_names, key=len, reverse=True):
            expression_text = expression_text.replace(
                f"{slot_table_name}[{slot_alias_name}]",
                slot_alias_name
            )
        return expression_text

    def _replace_prometheus_global_refs(self, expression_text, env_names=None):
        env_names = env_names or []
        for env_name in env_names:
            expression_text = re.sub(
                rf'{re.escape(env_name)}\["([A-Za-z_][A-Za-z0-9_]*)"\]',
                lambda match_object: match_object.group(1),
                expression_text
            )
            expression_text = re.sub(
                rf'{re.escape(env_name)}\.([A-Za-z_][A-Za-z0-9_]*)',
                lambda match_object: match_object.group(1),
                expression_text
            )
        return expression_text

    def _translate_prometheus_helper_call(self, expression_text, loop_data, runtime_layout, blocks_by_id, decompile_state, indent_level):
        local_aliases = decompile_state.get('current_local_aliases', {})
        current_captures = decompile_state.get('current_captures', [])
        helper_match = re.fullmatch(r'([A-Za-z_][A-Za-z0-9_]*)\((.+),\s*\{(.*)\}\)', expression_text, re.DOTALL)
        if not helper_match:
            return None

        helper_name = helper_match.group(1)
        if helper_name not in runtime_layout['creator_args']:
            return None

        try:
            start_block_id = self._safe_evaluate_expression(helper_match.group(2).strip())
        except Exception:
            return None

        capture_items = self._split_top_level_items(helper_match.group(3))
        translated_captures = []
        for item_text in capture_items:
            item_text = item_text.strip()
            if not item_text:
                continue
            capture_seed = self._render_prometheus_capture_value(item_text, local_aliases)
            translated_captures.append(
                self._translate_prometheus_expression(
                    capture_seed,
                    local_aliases,
                    current_captures,
                    loop_data,
                    runtime_layout,
                    blocks_by_id,
                    decompile_state,
                    indent_level
                )
            )
        return self._render_prometheus_function_literal(
            start_block_id,
            translated_captures,
            runtime_layout['creator_args'][helper_name],
            loop_data,
            runtime_layout,
            blocks_by_id,
            decompile_state,
            indent_level
        )

    def _translate_prometheus_expression(self, expression_text, local_aliases, captures, loop_data, runtime_layout, blocks_by_id, decompile_state, indent_level):
        translated_text = expression_text.strip()
        decompile_state['current_local_aliases'] = local_aliases
        decompile_state['current_captures'] = captures
        translated_text = self._replace_prometheus_capture_refs(
            translated_text,
            loop_data['capture_var'],
            captures
        )
        translated_text = self._replace_prometheus_slot_refs(
            translated_text,
            runtime_layout['slot_table_name'],
            local_aliases
        )

        alias_replacements = {}
        for alias_name, alias_value in sorted(local_aliases.items(), key=lambda item: -len(item[0])):
            rendered_alias = self._render_prometheus_alias(alias_value)
            if not isinstance(rendered_alias, str):
                continue
            alias_replacements[alias_name] = rendered_alias
        translated_text = self._replace_lua_identifier_tokens(translated_text, alias_replacements)

        translated_text = self._replace_prometheus_global_refs(
            translated_text,
            runtime_layout.get('env_names')
        )

        helper_translation = self._translate_prometheus_helper_call(
            translated_text,
            loop_data,
            runtime_layout,
            blocks_by_id,
            decompile_state,
            indent_level
        )
        if helper_translation is not None:
            return helper_translation

        return translated_text

    def _translate_prometheus_statement(self, statement_text, local_aliases, persistent_aliases, captures, loop_data, runtime_layout, blocks_by_id, decompile_state, declared_slots, indent_level):
        assignment_index = self._find_top_level_assignment(statement_text)
        if assignment_index == -1:
            helper_name = runtime_layout.get('free_slot_name')
            cleanup_name = runtime_layout.get('cleanup_name')
            stripped_statement = statement_text.strip().rstrip(';').strip()
            if helper_name and re.fullmatch(rf'{re.escape(helper_name)}\s*\(.+\)', stripped_statement):
                return []
            if cleanup_name and re.fullmatch(rf'{re.escape(cleanup_name)}\s*\(.+\)', stripped_statement):
                return []
            translated_statement = self._translate_prometheus_expression(
                statement_text,
                local_aliases,
                captures,
                loop_data,
                runtime_layout,
                blocks_by_id,
                decompile_state,
                indent_level
            )
            return [translated_statement]

        lhs_text = statement_text[:assignment_index].strip()
        rhs_text = statement_text[assignment_index + 1:].strip().rstrip(';').strip()

        helper_name = runtime_layout.get('free_slot_name')
        cleanup_name = runtime_layout.get('cleanup_name')
        if helper_name and re.fullmatch(rf'{re.escape(helper_name)}\s*\(.+\)', rhs_text):
            local_aliases.pop(lhs_text, None)
            persistent_aliases.pop(lhs_text, None)
            return []
        if cleanup_name and re.fullmatch(rf'{re.escape(cleanup_name)}\s*\(.+\)', rhs_text):
            local_aliases.pop(lhs_text, None)
            persistent_aliases.pop(lhs_text, None)
            return []

        if rhs_text == f"{runtime_layout['alloc_slot_name']}()":
            preferred_slot_name = None
            if self._is_valid_lua_identifier(lhs_text):
                preferred_slot_name = lhs_text if lhs_text.endswith('_local') else f"{lhs_text}_local"
            slot_name = self._make_prometheus_slot_name(decompile_state, preferred_slot_name)
            local_aliases[lhs_text] = {'type': 'slot', 'name': slot_name}
            persistent_aliases[lhs_text] = local_aliases[lhs_text]
            return []

        translated_rhs = self._translate_prometheus_expression(
            rhs_text,
            local_aliases,
            captures,
            loop_data,
            runtime_layout,
            blocks_by_id,
            decompile_state,
            indent_level
        )

        slot_assignment_match = re.fullmatch(
            rf'{re.escape(runtime_layout["slot_table_name"])}\[(.+)\]',
            lhs_text
        )
        if slot_assignment_match:
            raw_slot_key = slot_assignment_match.group(1).strip()
            slot_alias = local_aliases.get(raw_slot_key)
            translated_slot_key = self._translate_prometheus_expression(
                raw_slot_key,
                local_aliases,
                captures,
                loop_data,
                runtime_layout,
                blocks_by_id,
                decompile_state,
                indent_level
            )
            if isinstance(slot_alias, dict) and slot_alias.get('type') == 'slot':
                rendered_name = self._normalize_prometheus_identifier_name(slot_alias['name'], decompile_state)
                declared_slots.add(rendered_name)
                return [f"{rendered_name} = {translated_rhs}"]
            if translated_slot_key.startswith('__slotref__'):
                rendered_name = self._normalize_prometheus_identifier_name(
                    translated_slot_key[len('__slotref__'):],
                    decompile_state
                )
                declared_slots.add(rendered_name)
                return [f"{rendered_name} = {translated_rhs}"]
            if re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', translated_slot_key):
                safe_slot_name = self._normalize_prometheus_identifier_name(translated_slot_key, decompile_state)
                declared_slots.add(safe_slot_name)
                return [f"{safe_slot_name} = {translated_rhs}"]

        if re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', lhs_text):
            translated_lhs = lhs_text
        else:
            translated_lhs = self._translate_prometheus_expression(
                lhs_text,
                local_aliases,
                captures,
                loop_data,
                runtime_layout,
                blocks_by_id,
                decompile_state,
                indent_level
            )
        if re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', translated_lhs) and self._is_prometheus_lua_keyword(translated_lhs):
            safe_name = self._make_prometheus_safe_name(decompile_state)
            local_aliases[lhs_text] = {'type': 'slot', 'name': safe_name}
            persistent_aliases[lhs_text] = local_aliases[lhs_text]
            translated_lhs = safe_name
        return [f"{translated_lhs} = {translated_rhs}"]

    def _order_prometheus_blocks(self, start_block_id, blocks_by_id):
        ordered_ids = []
        visited_ids = set()

        def visit(block_id):
            if block_id in visited_ids or block_id not in blocks_by_id:
                return

            visited_ids.add(block_id)
            ordered_ids.append(block_id)
            transition = blocks_by_id[block_id]['transition']

            if transition['type'] == 'goto':
                visit(transition['target'])
            elif transition['type'] == 'branch':
                visit(transition['true_target'])
                visit(transition['false_target'])

        visit(start_block_id)
        return ordered_ids

    def _collect_prometheus_identifiers(self, expression_text):
        identifiers = set()
        for match_object in re.finditer(r'\b[A-Za-z_][A-Za-z0-9_]*\b', expression_text):
            start_index = match_object.start()
            if start_index > 0 and expression_text[start_index - 1] == '.':
                continue
            identifier_name = match_object.group(0)
            if self._is_prometheus_lua_keyword(identifier_name):
                continue
            identifiers.add(identifier_name)
        return identifiers

    def _is_prometheus_lua_keyword(self, identifier_name):
        return identifier_name in {
            'and', 'break', 'do', 'else', 'elseif', 'end', 'false', 'for', 'function',
            'goto', 'if', 'in', 'local', 'nil', 'not', 'or', 'repeat', 'return',
            'then', 'true', 'until', 'while'
        }

    def _parse_prometheus_assignment_chunk(self, statement_chunk):
        stripped_chunk = statement_chunk.strip()
        if stripped_chunk.endswith(';'):
            stripped_chunk = stripped_chunk[:-1].rstrip()
        if '\n' in stripped_chunk:
            return None
        match_object = re.fullmatch(r'(local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+)', stripped_chunk)
        if not match_object:
            return None
        return {
            'lhs': match_object.group(2),
            'rhs': match_object.group(3)
        }

    def _is_prometheus_side_effect_free(self, expression_text):
        stripped_text = expression_text.strip()
        if '(' in stripped_text or 'function(' in stripped_text:
            return False
        return True

    def _is_prometheus_literal_value(self, expression_text):
        stripped_text = expression_text.strip()
        if stripped_text in {'nil', 'true', 'false'}:
            return True
        if re.fullmatch(r'[-+]?\d+(?:\.\d+)?', stripped_text):
            return True
        if re.fullmatch(r'"(?:[^"\\]|\\.)*"', stripped_text, re.DOTALL):
            return True
        if re.fullmatch(r"'(?:[^'\\]|\\.)*'", stripped_text, re.DOTALL):
            return True
        return False

    def _replace_prometheus_literal_aliases(self, expression_text, constant_aliases):
        return self._replace_lua_identifier_tokens(expression_text, constant_aliases)

    def _simplify_prometheus_string_key_accesses(self, expression_text):
        simplified_text = expression_text
        key_patterns = (
            r'([A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*)\["([A-Za-z_][A-Za-z0-9_]*)"\]',
            r"([A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*)\['([A-Za-z_][A-Za-z0-9_]*)'\]"
        )

        previous_text = None
        while simplified_text != previous_text:
            previous_text = simplified_text
            for pattern_text in key_patterns:
                simplified_text = re.sub(
                    pattern_text,
                    lambda match_object: f"{match_object.group(1)}.{match_object.group(2)}",
                    simplified_text
                )

        return simplified_text

    def _is_prometheus_aliasable_value(self, expression_text):
        stripped_text = expression_text.strip()
        return self._is_prometheus_literal_value(stripped_text)

    def _rewrite_prometheus_alias_expression(self, expression_text, alias_map, env_names=None, excluded_alias_names=None):
        excluded_alias_names = excluded_alias_names or set()
        active_alias_map = {
            alias_name: alias_value
            for alias_name, alias_value in alias_map.items()
            if alias_name not in excluded_alias_names
        }
        rewritten_text = self._replace_prometheus_literal_aliases(
            expression_text,
            active_alias_map
        )
        rewritten_text = self._replace_prometheus_global_refs(
            rewritten_text,
            env_names
        )
        rewritten_text = self._simplify_prometheus_string_key_accesses(rewritten_text)
        rewritten_text = self._replace_prometheus_global_refs(
            rewritten_text,
            env_names
        )
        return rewritten_text

    def _prometheus_chunk_read_write_sets(self, statement_chunk):
        assignment_data = self._parse_prometheus_assignment_chunk(statement_chunk)
        if assignment_data:
            return (
                self._collect_prometheus_identifiers(assignment_data['rhs']),
                {assignment_data['lhs']}
            )
        return (self._collect_prometheus_identifiers(statement_chunk), set())

    def _prometheus_transition_read_set(self, transition_data):
        if transition_data['type'] == 'branch':
            return self._collect_prometheus_identifiers(transition_data['condition'])
        if transition_data['type'] == 'return' and transition_data.get('value'):
            return self._collect_prometheus_identifiers(transition_data['value'])
        return set()

    def _prometheus_transition_successors(self, transition_data):
        if transition_data['type'] == 'goto':
            return [transition_data['target']]
        if transition_data['type'] == 'branch':
            return [transition_data['true_target'], transition_data['false_target']]
        return []

    def _prune_dead_prometheus_assignments(self, translated_blocks):
        block_order = list(translated_blocks)
        block_use_sets = {}
        block_def_sets = {}

        for block_id, block_data in translated_blocks.items():
            seen_defs = set()
            block_use = set()
            block_def = set()

            for statement_chunk in block_data['body_chunks']:
                read_set, write_set = self._prometheus_chunk_read_write_sets(statement_chunk)
                block_use |= read_set - seen_defs
                seen_defs |= write_set
                block_def |= write_set

            block_use |= self._prometheus_transition_read_set(block_data['transition']) - seen_defs
            block_use_sets[block_id] = block_use
            block_def_sets[block_id] = block_def

        live_in_sets = {block_id: set() for block_id in block_order}
        live_out_sets = {block_id: set() for block_id in block_order}

        changed = True
        while changed:
            changed = False
            for block_id in reversed(block_order):
                successor_live = set()
                for successor_id in self._prometheus_transition_successors(translated_blocks[block_id]['transition']):
                    successor_live |= live_in_sets.get(successor_id, set())

                new_live_out = successor_live
                new_live_in = block_use_sets[block_id] | (new_live_out - block_def_sets[block_id])
                if new_live_out != live_out_sets[block_id] or new_live_in != live_in_sets[block_id]:
                    live_out_sets[block_id] = new_live_out
                    live_in_sets[block_id] = new_live_in
                    changed = True

        for block_id, block_data in translated_blocks.items():
            live_now = set(live_out_sets[block_id]) | self._prometheus_transition_read_set(block_data['transition'])
            retained_chunks = []

            for statement_chunk in reversed(block_data['body_chunks']):
                assignment_data = self._parse_prometheus_assignment_chunk(statement_chunk)
                read_set, write_set = self._prometheus_chunk_read_write_sets(statement_chunk)

                if (
                    assignment_data
                    and assignment_data['lhs'] not in live_now
                    and self._is_prometheus_side_effect_free(assignment_data['rhs'])
                ):
                    live_now = (live_now - write_set) | read_set
                    continue

                retained_chunks.append(statement_chunk)
                live_now = (live_now - write_set) | read_set

            block_data['body_chunks'] = list(reversed(retained_chunks))

    def _fold_prometheus_literal_aliases(self, translated_blocks, env_names=None, excluded_alias_names=None):
        excluded_alias_names = excluded_alias_names or set()
        for block_data in translated_blocks.values():
            constant_aliases = {}
            rewritten_chunks = []

            for statement_chunk in block_data['body_chunks']:
                assignment_data = self._parse_prometheus_assignment_chunk(statement_chunk)
                if assignment_data:
                    rewritten_rhs = self._rewrite_prometheus_alias_expression(
                        assignment_data['rhs'],
                        constant_aliases,
                        env_names,
                        excluded_alias_names
                    )
                    rewritten_chunk = f"{assignment_data['lhs']} = {rewritten_rhs}"
                    if statement_chunk.strip().startswith('local '):
                        rewritten_chunk = f"local {rewritten_chunk}"
                    rewritten_chunks.append(rewritten_chunk)

                    constant_aliases.pop(assignment_data['lhs'], None)
                    if (
                        assignment_data['lhs'] not in excluded_alias_names
                        and self._is_prometheus_aliasable_value(rewritten_rhs)
                    ):
                        constant_aliases[assignment_data['lhs']] = rewritten_rhs
                    continue

                rewritten_chunks.append(
                    self._rewrite_prometheus_alias_expression(
                        statement_chunk,
                        constant_aliases,
                        env_names,
                        excluded_alias_names
                    )
                )

            block_data['body_chunks'] = rewritten_chunks

    def _build_prometheus_translated_blocks(self, start_block_id, captures, loop_data, runtime_layout, blocks_by_id, decompile_state, indent_level):
        ordered_block_ids = self._order_prometheus_blocks(start_block_id, blocks_by_id)
        translated_blocks = {}
        declared_slots = set()
        for capture_text in captures or []:
            stripped_capture = capture_text.strip()
            slotref_match = re.fullmatch(r'__slotref__([A-Za-z_][A-Za-z0-9_]*)', stripped_capture)
            if slotref_match:
                declared_slots.add(slotref_match.group(1))
                continue
            if re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', stripped_capture):
                declared_slots.add(stripped_capture)
        persistent_aliases = {}

        for block_index, block_id in enumerate(ordered_block_ids):
            block_data = blocks_by_id[block_id]
            transition = block_data['transition']
            local_aliases = dict(persistent_aliases)
            block_lines = block_data['lines']

            if block_index == 0 and decompile_state.get('trim_payload_preamble'):
                block_lines = self._trim_prometheus_payload_preamble(block_lines)

            grouped_statements = self._group_prometheus_block_statements(block_lines)
            transition_statement_count = 0
            if transition['type'] == 'branch':
                transition_statement_count = 2 if len(grouped_statements) >= 2 and grouped_statements[-1].strip().startswith(f"{loop_data['state_var']} =") and grouped_statements[-2].strip().startswith(f"{loop_data['state_var']} =") else 1
            elif transition['type'] in {'goto', 'return'}:
                transition_statement_count = 1 if grouped_statements and grouped_statements[-1].strip().startswith(f"{loop_data['state_var']} =") else 0

            body_statements = grouped_statements[:-transition_statement_count] if transition_statement_count else grouped_statements
            if transition['type'] == 'branch':
                target_ids = {str(transition['true_target']), str(transition['false_target'])}
            elif transition['type'] == 'goto':
                target_ids = {str(transition['target'])}
            else:
                target_ids = set()

            while body_statements:
                trailing_assignment = self._parse_prometheus_assignment_chunk(body_statements[-1])
                if not trailing_assignment:
                    break

                trailing_lhs = trailing_assignment['lhs'].strip()
                trailing_rhs = trailing_assignment['rhs'].strip()
                is_transition_scaffold = trailing_rhs in target_ids

                if trailing_lhs == loop_data['state_var'] and target_ids:
                    is_transition_scaffold = any(
                        re.search(rf'(?<!\d){re.escape(target_id)}(?!\d)', trailing_rhs)
                        for target_id in target_ids
                    )

                if not is_transition_scaffold:
                    break
                body_statements = body_statements[:-1]

            translated_chunks = []

            for statement_text in body_statements:
                translated_lines = self._translate_prometheus_statement(
                    statement_text,
                    local_aliases,
                    persistent_aliases,
                    captures,
                    loop_data,
                    runtime_layout,
                    blocks_by_id,
                    decompile_state,
                    declared_slots,
                    indent_level
                )
                translated_chunks.extend(translated_lines)

            translated_transition = dict(transition)
            if transition['type'] == 'branch':
                translated_condition = self._translate_prometheus_expression(
                    transition['condition'],
                    local_aliases,
                    captures,
                    loop_data,
                    runtime_layout,
                    blocks_by_id,
                    decompile_state,
                    indent_level
                )
                if not re.fullmatch(r'[-+]?\d+(?:\.\d+)?', translated_condition):
                    translated_transition['condition'] = translated_condition

            if transition['type'] == 'return' and transition.get('value'):
                translated_transition['value'] = self._translate_prometheus_expression(
                    transition['value'],
                    local_aliases,
                    captures,
                    loop_data,
                    runtime_layout,
                    blocks_by_id,
                    decompile_state,
                    indent_level
                )

            translated_blocks[block_id] = {
                'id': block_id,
                'body_chunks': translated_chunks,
                'transition': translated_transition
            }

        if decompile_state.get('enable_alias_fold'):
            self._fold_prometheus_literal_aliases(
                translated_blocks,
                runtime_layout.get('env_names'),
                {loop_data['state_var']}
            )
        if decompile_state.get('enable_dead_prune'):
            self._prune_dead_prometheus_assignments(translated_blocks)
        return translated_blocks

    def _render_prometheus_chunks(self, body_chunks, indent_level):
        rendered_lines = []
        indent_prefix = '    ' * indent_level
        for statement_chunk in body_chunks:
            for line_part in statement_chunk.splitlines():
                rendered_lines.append(f"{indent_prefix}{line_part}")
        return rendered_lines

    def _follow_prometheus_goto_chain(self, start_block_id, target_block_id, translated_blocks, stop_blocks, emitted_blocks):
        current_block_id = start_block_id
        visited_blocks = set()
        chain_ids = []

        while current_block_id in translated_blocks and current_block_id not in visited_blocks:
            if current_block_id in stop_blocks or current_block_id in emitted_blocks:
                return None
            if current_block_id == target_block_id:
                return chain_ids

            visited_blocks.add(current_block_id)
            chain_ids.append(current_block_id)
            transition = translated_blocks[current_block_id]['transition']
            if transition['type'] != 'goto':
                return None
            current_block_id = transition['target']

        return None

    def _detect_prometheus_repeat_loop(self, block_id, translated_blocks, stop_blocks, emitted_blocks):
        transition = translated_blocks[block_id]['transition']
        if transition['type'] != 'goto':
            return None

        body_start_id = transition['target']
        current_block_id = body_start_id
        path_ids = []
        visited_blocks = set()

        while current_block_id in translated_blocks and current_block_id not in visited_blocks:
            if current_block_id in stop_blocks or current_block_id in emitted_blocks:
                return None

            visited_blocks.add(current_block_id)
            path_ids.append(current_block_id)
            current_transition = translated_blocks[current_block_id]['transition']

            if current_transition['type'] == 'goto':
                current_block_id = current_transition['target']
                continue

            if current_transition['type'] != 'branch':
                return None

            if current_transition['true_target'] == body_start_id:
                return {
                    'body_blocks': path_ids[:-1],
                    'condition_block': current_block_id,
                    'exit_target': current_transition['false_target'],
                    'until_condition': f"not ({current_transition['condition']})"
                }

            if current_transition['false_target'] == body_start_id:
                return {
                    'body_blocks': path_ids[:-1],
                    'condition_block': current_block_id,
                    'exit_target': current_transition['true_target'],
                    'until_condition': current_transition['condition']
                }

            return None

        return None

    def _render_prometheus_linear_chain(self, chain_ids, translated_blocks, indent_level, emitted_blocks):
        rendered_lines = []
        for current_block_id in chain_ids:
            emitted_blocks.add(current_block_id)
            rendered_lines.extend(
                self._render_prometheus_chunks(
                    translated_blocks[current_block_id]['body_chunks'],
                    indent_level
                )
            )
        return rendered_lines

    def _render_prometheus_unstructured_flow(self, start_block_id, translated_blocks, indent_level, emitted_blocks, stop_blocks=None):
        stop_blocks = stop_blocks or set()
        rendered_lines = []
        ordered_ids = self._order_prometheus_blocks(start_block_id, translated_blocks)

        for block_id in ordered_ids:
            if block_id in emitted_blocks or block_id in stop_blocks or block_id not in translated_blocks:
                continue

            emitted_blocks.add(block_id)
            block_data = translated_blocks[block_id]
            transition = block_data['transition']
            rendered_lines.append(f"{'    ' * indent_level}::block_{block_id}::")
            rendered_lines.extend(self._render_prometheus_chunks(block_data['body_chunks'], indent_level))

            if transition['type'] == 'goto':
                rendered_lines.append(f"{'    ' * indent_level}goto block_{transition['target']}")
            elif transition['type'] == 'branch':
                rendered_lines.append(
                    f"{'    ' * indent_level}if {transition['condition']} then goto block_{transition['true_target']} else goto block_{transition['false_target']} end"
                )
            elif transition['type'] == 'return':
                return_value = transition.get('value')
                if return_value:
                    rendered_lines.append(f"{'    ' * indent_level}return {return_value}")
                else:
                    rendered_lines.append(f"{'    ' * indent_level}return")
            elif transition.get('raw'):
                rendered_lines.append(f"{'    ' * indent_level}-- unresolved transition: {transition['raw']}")

            rendered_lines.append('')

        while rendered_lines and not rendered_lines[-1].strip():
            rendered_lines.pop()
        return rendered_lines

    def _prometheus_can_reach_block(self, start_block_id, target_block_id, translated_blocks, blocked_blocks=None):
        if start_block_id == target_block_id:
            return True

        blocked_blocks = blocked_blocks or set()
        visited_blocks = set()
        pending_blocks = [start_block_id]

        while pending_blocks:
            current_block_id = pending_blocks.pop()
            if current_block_id in visited_blocks or current_block_id in blocked_blocks:
                continue
            if current_block_id == target_block_id:
                return True
            if current_block_id not in translated_blocks:
                continue

            visited_blocks.add(current_block_id)
            pending_blocks.extend(
                successor_id
                for successor_id in self._prometheus_transition_successors(translated_blocks[current_block_id]['transition'])
                if successor_id == target_block_id or successor_id not in blocked_blocks
            )

        return False

    def _collect_prometheus_reachable_distances(self, start_block_id, translated_blocks, terminal_blocks=None, forbidden_blocks=None):
        terminal_blocks = terminal_blocks or set()
        forbidden_blocks = forbidden_blocks or set()
        reachable_distances = {}
        pending_blocks = deque([(start_block_id, 0)])

        while pending_blocks:
            current_block_id, current_distance = pending_blocks.popleft()
            if current_block_id in reachable_distances:
                continue
            if current_block_id in forbidden_blocks and current_block_id != start_block_id:
                continue
            if current_block_id not in translated_blocks:
                continue

            reachable_distances[current_block_id] = current_distance
            if current_block_id in terminal_blocks:
                continue

            for successor_id in self._prometheus_transition_successors(translated_blocks[current_block_id]['transition']):
                if successor_id in forbidden_blocks and successor_id not in terminal_blocks:
                    continue
                pending_blocks.append((successor_id, current_distance + 1))

        return reachable_distances

    def _find_prometheus_branch_join(self, current_block_id, true_target, false_target, translated_blocks, emitted_blocks=None, stop_blocks=None):
        emitted_blocks = emitted_blocks or set()
        stop_blocks = stop_blocks or set()
        terminal_blocks = set(emitted_blocks) | set(stop_blocks)
        forbidden_blocks = {current_block_id}
        true_distances = self._collect_prometheus_reachable_distances(
            true_target,
            translated_blocks,
            terminal_blocks,
            forbidden_blocks
        )
        false_distances = self._collect_prometheus_reachable_distances(
            false_target,
            translated_blocks,
            terminal_blocks,
            forbidden_blocks
        )

        candidate_ids = (set(true_distances) & set(false_distances)) - {current_block_id}
        if not candidate_ids:
            return None

        ordered_ids = self._order_prometheus_blocks(current_block_id, translated_blocks)
        order_index = {block_id: index for index, block_id in enumerate(ordered_ids)}
        ranked_candidates = []

        for candidate_id in candidate_ids:
            if self._prometheus_can_reach_block(
                candidate_id,
                current_block_id,
                translated_blocks,
                blocked_blocks=(terminal_blocks | forbidden_blocks) - {candidate_id}
            ):
                continue
            ranked_candidates.append((
                true_distances[candidate_id] + false_distances[candidate_id],
                max(true_distances[candidate_id], false_distances[candidate_id]),
                order_index.get(candidate_id, float('inf')),
                candidate_id
            ))

        if not ranked_candidates:
            return None

        ranked_candidates.sort()
        return ranked_candidates[0][3]

    def _prometheus_subflow_returns(self, start_block_id, translated_blocks, terminal_blocks=None, forbidden_blocks=None):
        terminal_blocks = terminal_blocks or set()
        forbidden_blocks = forbidden_blocks or set()
        visited_blocks = set()
        pending_blocks = [start_block_id]
        visited_any = False

        while pending_blocks:
            current_block_id = pending_blocks.pop()
            if current_block_id in visited_blocks:
                continue
            if current_block_id in forbidden_blocks and current_block_id != start_block_id:
                return False
            if current_block_id in terminal_blocks and current_block_id != start_block_id:
                return False
            if current_block_id not in translated_blocks:
                return False

            visited_blocks.add(current_block_id)
            visited_any = True
            transition = translated_blocks[current_block_id]['transition']

            if transition['type'] == 'return':
                continue

            successor_ids = self._prometheus_transition_successors(transition)
            if not successor_ids:
                return False

            for successor_id in successor_ids:
                if successor_id in forbidden_blocks and successor_id not in terminal_blocks:
                    return False
                if successor_id in terminal_blocks:
                    return False
                pending_blocks.append(successor_id)

        return visited_any

    def _render_prometheus_structured_flow(self, start_block_id, translated_blocks, indent_level, emitted_blocks=None, stop_blocks=None):
        rendered_lines = []
        emitted_blocks = emitted_blocks or set()
        stop_blocks = stop_blocks or set()
        current_block_id = start_block_id

        while current_block_id in translated_blocks and current_block_id not in emitted_blocks and current_block_id not in stop_blocks:
            current_block = translated_blocks[current_block_id]
            current_transition = current_block['transition']

            repeat_data = self._detect_prometheus_repeat_loop(
                current_block_id,
                translated_blocks,
                stop_blocks,
                emitted_blocks
            )
            if repeat_data:
                emitted_blocks.add(current_block_id)
                rendered_lines.extend(self._render_prometheus_chunks(current_block['body_chunks'], indent_level))
                rendered_lines.append(f"{'    ' * indent_level}repeat")
                rendered_lines.extend(
                    self._render_prometheus_linear_chain(
                        repeat_data['body_blocks'],
                        translated_blocks,
                        indent_level + 1,
                        emitted_blocks
                    )
                )
                emitted_blocks.add(repeat_data['condition_block'])
                rendered_lines.extend(
                    self._render_prometheus_chunks(
                        translated_blocks[repeat_data['condition_block']]['body_chunks'],
                        indent_level + 1
                    )
                )
                rendered_lines.append(f"{'    ' * indent_level}until {repeat_data['until_condition']}")
                current_block_id = repeat_data['exit_target']
                continue

            if current_transition['type'] == 'branch':
                true_chain = self._follow_prometheus_goto_chain(
                    current_transition['true_target'],
                    current_block_id,
                    translated_blocks,
                    stop_blocks,
                    emitted_blocks
                )
                false_chain = self._follow_prometheus_goto_chain(
                    current_transition['false_target'],
                    current_block_id,
                    translated_blocks,
                    stop_blocks,
                    emitted_blocks
                )

                if true_chain is not None or false_chain is not None:
                    loop_body_chain = true_chain if true_chain is not None else false_chain
                    break_condition = (
                        f"not ({current_transition['condition']})"
                        if true_chain is not None
                        else current_transition['condition']
                    )
                    exit_target = current_transition['false_target'] if true_chain is not None else current_transition['true_target']

                    emitted_blocks.add(current_block_id)
                    rendered_lines.append(f"{'    ' * indent_level}while true do")
                    rendered_lines.extend(self._render_prometheus_chunks(current_block['body_chunks'], indent_level + 1))
                    rendered_lines.append(f"{'    ' * (indent_level + 1)}if {break_condition} then")
                    rendered_lines.append(f"{'    ' * (indent_level + 2)}break")
                    rendered_lines.append(f"{'    ' * (indent_level + 1)}end")
                    rendered_lines.extend(
                        self._render_prometheus_linear_chain(
                            loop_body_chain,
                            translated_blocks,
                            indent_level + 1,
                            emitted_blocks
                        )
                    )
                    rendered_lines.append(f"{'    ' * indent_level}end")
                    current_block_id = exit_target
                    continue

                single_arm_then = self._follow_prometheus_goto_chain(
                    current_transition['true_target'],
                    current_transition['false_target'],
                    translated_blocks,
                    stop_blocks,
                    emitted_blocks
                )
                true_loops_back = self._prometheus_can_reach_block(
                    current_transition['true_target'],
                    current_block_id,
                    translated_blocks,
                    blocked_blocks=emitted_blocks | stop_blocks
                )
                false_loops_back = self._prometheus_can_reach_block(
                    current_transition['false_target'],
                    current_block_id,
                    translated_blocks,
                    blocked_blocks=emitted_blocks | stop_blocks
                )

                if true_loops_back != false_loops_back:
                    loop_target = current_transition['true_target'] if true_loops_back else current_transition['false_target']
                    exit_target = current_transition['false_target'] if true_loops_back else current_transition['true_target']
                    break_condition = (
                        f"not ({current_transition['condition']})"
                        if true_loops_back
                        else current_transition['condition']
                    )

                    emitted_blocks.add(current_block_id)
                    rendered_lines.append(f"{'    ' * indent_level}while true do")
                    rendered_lines.extend(self._render_prometheus_chunks(current_block['body_chunks'], indent_level + 1))
                    rendered_lines.append(f"{'    ' * (indent_level + 1)}if {break_condition} then")
                    rendered_lines.append(f"{'    ' * (indent_level + 2)}break")
                    rendered_lines.append(f"{'    ' * (indent_level + 1)}end")
                    nested_loop_body = self._render_prometheus_structured_flow(
                        loop_target,
                        translated_blocks,
                        indent_level + 1,
                        emitted_blocks,
                        stop_blocks | {current_block_id, exit_target}
                    )
                    if nested_loop_body:
                        rendered_lines.extend(nested_loop_body.splitlines())
                    rendered_lines.append(f"{'    ' * indent_level}end")
                    current_block_id = exit_target
                    continue

                if single_arm_then is not None:
                    emitted_blocks.add(current_block_id)
                    rendered_lines.extend(self._render_prometheus_chunks(current_block['body_chunks'], indent_level))
                    rendered_lines.append(f"{'    ' * indent_level}if {current_transition['condition']} then")
                    rendered_lines.extend(
                        self._render_prometheus_linear_chain(
                            single_arm_then,
                            translated_blocks,
                            indent_level + 1,
                            emitted_blocks
                        )
                    )
                    rendered_lines.append(f"{'    ' * indent_level}end")
                    current_block_id = current_transition['false_target']
                    continue

                single_arm_else = self._follow_prometheus_goto_chain(
                    current_transition['false_target'],
                    current_transition['true_target'],
                    translated_blocks,
                    stop_blocks,
                    emitted_blocks
                )
                if single_arm_else is not None:
                    emitted_blocks.add(current_block_id)
                    rendered_lines.extend(self._render_prometheus_chunks(current_block['body_chunks'], indent_level))
                    rendered_lines.append(f"{'    ' * indent_level}if not ({current_transition['condition']}) then")
                    rendered_lines.extend(
                        self._render_prometheus_linear_chain(
                            single_arm_else,
                            translated_blocks,
                            indent_level + 1,
                            emitted_blocks
                        )
                    )
                    rendered_lines.append(f"{'    ' * indent_level}end")
                    current_block_id = current_transition['true_target']
                    continue

                join_target = self._find_prometheus_branch_join(
                    current_block_id,
                    current_transition['true_target'],
                    current_transition['false_target'],
                    translated_blocks,
                    emitted_blocks,
                    stop_blocks
                )
                if join_target is not None:
                    emitted_blocks.add(current_block_id)
                    rendered_lines.extend(self._render_prometheus_chunks(current_block['body_chunks'], indent_level))
                    then_body = self._render_prometheus_structured_flow(
                        current_transition['true_target'],
                        translated_blocks,
                        indent_level + 1,
                        emitted_blocks,
                        stop_blocks | {join_target}
                    )
                    else_body = self._render_prometheus_structured_flow(
                        current_transition['false_target'],
                        translated_blocks,
                        indent_level + 1,
                        emitted_blocks,
                        stop_blocks | {join_target}
                    )

                    if then_body and else_body:
                        rendered_lines.append(f"{'    ' * indent_level}if {current_transition['condition']} then")
                        rendered_lines.extend(then_body.splitlines())
                        rendered_lines.append(f"{'    ' * indent_level}else")
                        rendered_lines.extend(else_body.splitlines())
                        rendered_lines.append(f"{'    ' * indent_level}end")
                    elif then_body:
                        rendered_lines.append(f"{'    ' * indent_level}if {current_transition['condition']} then")
                        rendered_lines.extend(then_body.splitlines())
                        rendered_lines.append(f"{'    ' * indent_level}end")
                    elif else_body:
                        rendered_lines.append(f"{'    ' * indent_level}if not ({current_transition['condition']}) then")
                        rendered_lines.extend(else_body.splitlines())
                        rendered_lines.append(f"{'    ' * indent_level}end")

                    current_block_id = join_target
                    continue

                terminal_blocks = set(emitted_blocks) | set(stop_blocks)
                if (
                    self._prometheus_subflow_returns(
                        current_transition['true_target'],
                        translated_blocks,
                        terminal_blocks,
                        {current_block_id}
                    )
                    and self._prometheus_subflow_returns(
                        current_transition['false_target'],
                        translated_blocks,
                        terminal_blocks,
                        {current_block_id}
                    )
                ):
                    emitted_blocks.add(current_block_id)
                    rendered_lines.extend(self._render_prometheus_chunks(current_block['body_chunks'], indent_level))
                    then_body = self._render_prometheus_structured_flow(
                        current_transition['true_target'],
                        translated_blocks,
                        indent_level + 1,
                        emitted_blocks,
                        stop_blocks
                    )
                    else_body = self._render_prometheus_structured_flow(
                        current_transition['false_target'],
                        translated_blocks,
                        indent_level + 1,
                        emitted_blocks,
                        stop_blocks
                    )
                    rendered_lines.append(f"{'    ' * indent_level}if {current_transition['condition']} then")
                    if then_body:
                        rendered_lines.extend(then_body.splitlines())
                    rendered_lines.append(f"{'    ' * indent_level}else")
                    if else_body:
                        rendered_lines.extend(else_body.splitlines())
                    rendered_lines.append(f"{'    ' * indent_level}end")
                    break

                recursive_then_target = current_transition['true_target']
                recursive_join_target = current_transition['false_target']
                if self._prometheus_can_reach_block(
                    recursive_then_target,
                    recursive_join_target,
                    translated_blocks,
                    blocked_blocks=emitted_blocks | stop_blocks | {current_block_id}
                ):
                    emitted_blocks.add(current_block_id)
                    rendered_lines.extend(self._render_prometheus_chunks(current_block['body_chunks'], indent_level))
                    rendered_lines.append(f"{'    ' * indent_level}if {current_transition['condition']} then")
                    nested_then_body = self._render_prometheus_structured_flow(
                        recursive_then_target,
                        translated_blocks,
                        indent_level + 1,
                        emitted_blocks,
                        stop_blocks | {recursive_join_target}
                    )
                    if nested_then_body:
                        rendered_lines.extend(nested_then_body.splitlines())
                    rendered_lines.append(f"{'    ' * indent_level}end")
                    current_block_id = recursive_join_target
                    continue

                recursive_else_target = current_transition['false_target']
                recursive_join_target = current_transition['true_target']
                if self._prometheus_can_reach_block(
                    recursive_else_target,
                    recursive_join_target,
                    translated_blocks,
                    blocked_blocks=emitted_blocks | stop_blocks | {current_block_id}
                ):
                    emitted_blocks.add(current_block_id)
                    rendered_lines.extend(self._render_prometheus_chunks(current_block['body_chunks'], indent_level))
                    rendered_lines.append(f"{'    ' * indent_level}if not ({current_transition['condition']}) then")
                    nested_else_body = self._render_prometheus_structured_flow(
                        recursive_else_target,
                        translated_blocks,
                        indent_level + 1,
                        emitted_blocks,
                        stop_blocks | {recursive_join_target}
                    )
                    if nested_else_body:
                        rendered_lines.extend(nested_else_body.splitlines())
                    rendered_lines.append(f"{'    ' * indent_level}end")
                    current_block_id = recursive_join_target
                    continue

            if current_transition['type'] == 'goto':
                emitted_blocks.add(current_block_id)
                rendered_lines.extend(self._render_prometheus_chunks(current_block['body_chunks'], indent_level))
                current_block_id = current_transition['target']
                continue

            if current_transition['type'] == 'return':
                emitted_blocks.add(current_block_id)
                rendered_lines.extend(self._render_prometheus_chunks(current_block['body_chunks'], indent_level))
                return_value = current_transition.get('value')
                if return_value:
                    rendered_lines.append(f"{'    ' * indent_level}return {return_value}")
                else:
                    rendered_lines.append(f"{'    ' * indent_level}return")
                break

            rendered_lines.extend(
                self._render_prometheus_unstructured_flow(
                    current_block_id,
                    translated_blocks,
                    indent_level,
                    emitted_blocks,
                    stop_blocks
                )
            )
            break

        return '\n'.join(rendered_lines)

    def _sanitize_prometheus_invalid_identifiers(self, script_content):
        output_lines = []
        scope_stack = []
        nil_alias_counter = 0

        for line_text in script_content.splitlines():
            stripped_text = line_text.strip()
            current_indent = len(line_text) - len(line_text.lstrip(' '))

            while scope_stack and stripped_text == 'end' and current_indent == scope_stack[-1]['indent']:
                active_scope = scope_stack[-1]
                alias_name = active_scope.get('nil_alias')
                if alias_name:
                    line_text = re.sub(r'\bnil\b', alias_name, line_text)
                break

            if stripped_text.startswith('function(') or '= function(' in stripped_text:
                scope_stack.append({'indent': current_indent, 'nil_alias': None})

            active_nil_alias = None
            for scope_data in reversed(scope_stack):
                if scope_data.get('nil_alias'):
                    active_nil_alias = scope_data['nil_alias']
                    break

            if stripped_text.startswith('nil ='):
                if scope_stack:
                    if not scope_stack[-1].get('nil_alias'):
                        nil_alias_counter += 1
                        scope_stack[-1]['nil_alias'] = f"v_nil_{nil_alias_counter}"
                    active_nil_alias = scope_stack[-1]['nil_alias']
                else:
                    nil_alias_counter += 1
                    active_nil_alias = f"v_nil_{nil_alias_counter}"

            if active_nil_alias:
                line_text = re.sub(r'\bnil\b', active_nil_alias, line_text)

            output_lines.append(line_text)

            while scope_stack and stripped_text == 'end' and current_indent == scope_stack[-1]['indent']:
                scope_stack.pop()

        return '\n'.join(output_lines) + ('\n' if script_content.endswith('\n') else '')

    def _remove_unreferenced_prometheus_labels(self, script_content):
        referenced_labels = set(re.findall(r'goto block_(\d+)', script_content))
        output_lines = []

        for line_text in script_content.splitlines():
            label_match = re.fullmatch(r'(\s*)::block_(\d+)::', line_text)
            if label_match and label_match.group(2) not in referenced_labels:
                continue
            output_lines.append(line_text)

        return '\n'.join(output_lines) + ('\n' if script_content.endswith('\n') else '')

    def _ensure_prometheus_goto_labels_exist(self, script_content):
        referenced_labels = set(re.findall(r'goto block_(\d+)', script_content))
        declared_labels = set(re.findall(r'::block_(\d+)::', script_content))
        missing_labels = sorted(referenced_labels - declared_labels, key=lambda value: int(value))
        if not missing_labels:
            return script_content

        output_lines = script_content.splitlines()
        if output_lines and output_lines[-1].strip():
            output_lines.append('')
        for label_id in missing_labels:
            output_lines.append(f"::block_{label_id}::")
        rewritten_text = '\n'.join(output_lines)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _strip_unresolved_prometheus_gotos(self, script_content):
        output_lines = []
        goto_pattern = re.compile(r'^(\s*)goto block_(\d+)\s*;?\s*$')
        label_pattern = re.compile(r'^\s*::block_\d+::\s*$')

        for line_text in script_content.splitlines():
            if label_pattern.match(line_text):
                continue

            inline_goto_match = re.search(r'goto\s+block_(\d+)', line_text)
            if inline_goto_match:
                indent_text = line_text[:len(line_text) - len(line_text.lstrip())]
                output_lines.append(
                    f"{indent_text}-- removed unresolved jump block_{inline_goto_match.group(1)}"
                )
                continue

            goto_match = goto_pattern.match(line_text)
            if not goto_match:
                output_lines.append(line_text)
                continue

            indent_text, label_id = goto_match.groups()
            output_lines.append(f"{indent_text}-- removed unresolved jump block_{label_id}")

        rewritten_text = '\n'.join(output_lines)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _collapse_prometheus_runtime_slot_reads(self, script_content):
        slot_write_names = set(
            re.findall(
                r'\bruntime_slots\s*\[\s*([A-Za-z_][A-Za-z0-9_]*)\s*\]\s*=',
                script_content
            )
        )

        def replace_slot_read(match_object):
            slot_name = match_object.group(1)
            if slot_name in slot_write_names:
                return match_object.group(0)
            return slot_name

        rewritten_text = re.sub(
            r'\bruntime_slots\s*\[\s*([A-Za-z_][A-Za-z0-9_]*)\s*\]',
            replace_slot_read,
            script_content
        )
        return rewritten_text

    def _extract_prometheus_runtime_decoder_constants(self, script_content):
        mul45 = None
        add45 = None
        pattern_candidates = [
            re.compile(
                r'[A-Za-z_][A-Za-z0-9_]*\s*=\s*[A-Za-z_][A-Za-z0-9_]*\s*\n\s*'
                r'[A-Za-z_][A-Za-z0-9_]*\s*=\s*(\d+)\s*\n\s*'
                r'[A-Za-z_][A-Za-z0-9_]*\s*=\s*[A-Za-z_][A-Za-z0-9_]*\s*\*\s*[A-Za-z_][A-Za-z0-9_]*\s*\n\s*'
                r'[A-Za-z_][A-Za-z0-9_]*\s*=\s*(\d{8,})\s*\n\s*'
                r'[A-Za-z_][A-Za-z0-9_]*\s*=\s*[A-Za-z_][A-Za-z0-9_]*\s*\+\s*[A-Za-z_][A-Za-z0-9_]*\s*\n\s*'
                r'[A-Za-z_][A-Za-z0-9_]*\s*=\s*35184372088832',
                re.MULTILINE
            ),
            re.compile(
                r'[A-Za-z_][A-Za-z0-9_]*\s*=\s*(\d+)\s*\n\s*'
                r'[A-Za-z_][A-Za-z0-9_]*\s*=\s*[A-Za-z_][A-Za-z0-9_]*\s*\n\s*'
                r'[A-Za-z_][A-Za-z0-9_]*\s*=\s*[A-Za-z_][A-Za-z0-9_]*\s*\*\s*[A-Za-z_][A-Za-z0-9_]*\s*\n\s*'
                r'[A-Za-z_][A-Za-z0-9_]*\s*=\s*(\d{8,})\s*\n\s*'
                r'[A-Za-z_][A-Za-z0-9_]*\s*=\s*[A-Za-z_][A-Za-z0-9_]*\s*\+\s*[A-Za-z_][A-Za-z0-9_]*\s*\n\s*'
                r'[A-Za-z_][A-Za-z0-9_]*\s*=\s*35184372088832',
                re.MULTILINE
            )
        ]
        for pattern_object in pattern_candidates:
            match_object = pattern_object.search(script_content)
            if not match_object:
                continue
            mul45 = int(match_object.group(1))
            add45 = int(match_object.group(2))
            break

        if mul45 is None or add45 is None:
            source_lines = script_content.splitlines()
            assign_const_pattern = re.compile(r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(\d+)\s*$')
            multiply_pattern = re.compile(
                r'^\s*[A-Za-z_][A-Za-z0-9_]*\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\s*\*\s*([A-Za-z_][A-Za-z0-9_]*)\s*$'
            )
            add_const_assign_pattern = re.compile(r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(\d{8,})\s*$')
            add_use_pattern = re.compile(
                r'^\s*[A-Za-z_][A-Za-z0-9_]*\s*=\s*[A-Za-z_][A-Za-z0-9_]*\s*\+\s*([A-Za-z_][A-Za-z0-9_]*)\s*$'
            )

            def resolve_recent_constant(var_name, start_index, lookback=8):
                for back_index in range(start_index, max(-1, start_index - lookback), -1):
                    const_match = assign_const_pattern.match(source_lines[back_index].strip())
                    if const_match and const_match.group(1) == var_name:
                        return int(const_match.group(2))
                return None

            for line_index, line_text in enumerate(source_lines):
                if not re.search(r'=\s*35184372088832\s*$', line_text.strip()):
                    continue
                local_mul45 = None
                local_add45 = None
                for back_index in range(line_index - 1, max(-1, line_index - 16), -1):
                    add_const_match = add_const_assign_pattern.match(source_lines[back_index].strip())
                    if add_const_match and local_add45 is None:
                        candidate_add = int(add_const_match.group(2))
                        if candidate_add >= 1000000000:
                            local_add45 = candidate_add
                    add_use_match = add_use_pattern.match(source_lines[back_index].strip())
                    if add_use_match and local_add45 is None:
                        add_var = add_use_match.group(1)
                        candidate_add = resolve_recent_constant(add_var, back_index - 1, 6)
                        if candidate_add and candidate_add >= 1000000000:
                            local_add45 = candidate_add

                    mul_match = multiply_pattern.match(source_lines[back_index].strip())
                    if mul_match and local_mul45 is None:
                        left_var, right_var = mul_match.groups()
                        left_const = resolve_recent_constant(left_var, back_index - 1, 6)
                        right_const = resolve_recent_constant(right_var, back_index - 1, 6)
                        for candidate_mul in (left_const, right_const):
                            if candidate_mul is not None and 2 <= candidate_mul <= 255:
                                local_mul45 = candidate_mul
                                break
                    if local_mul45 is not None and local_add45 is not None:
                        break
                if local_mul45 is not None and local_add45 is not None:
                    mul45 = local_mul45
                    add45 = local_add45
                    break

        mul8 = None
        source_lines = script_content.splitlines()
        for line_index, line_text in enumerate(source_lines):
            modulo_match = re.search(
                r'=\s*[A-Za-z_][A-Za-z0-9_]*\s*%\s*([A-Za-z_][A-Za-z0-9_]*)\s*$',
                line_text.strip()
            )
            if not modulo_match:
                continue
            modulo_var = modulo_match.group(1)

            modulo_is_257 = False
            for back_index in range(max(0, line_index - 5), line_index):
                if re.search(
                    rf'^\s*{re.escape(modulo_var)}\s*=\s*257\s*$',
                    source_lines[back_index]
                ):
                    modulo_is_257 = True
                    break
            if not modulo_is_257:
                continue

            multiply_index = None
            multiplier_var = None
            for back_index in range(line_index - 1, max(-1, line_index - 8), -1):
                multiply_match = re.search(
                    r'=\s*[A-Za-z_][A-Za-z0-9_]*\s*\*\s*([A-Za-z_][A-Za-z0-9_]*)\s*$',
                    source_lines[back_index].strip()
                )
                if multiply_match:
                    multiply_index = back_index
                    multiplier_var = multiply_match.group(1)
                    break
            if multiply_index is None:
                continue

            multiply_line = source_lines[multiply_index].strip()
            multiply_full_match = re.match(
                r'^\s*[A-Za-z_][A-Za-z0-9_]*\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\s*\*\s*([A-Za-z_][A-Za-z0-9_]*)\s*$',
                multiply_line
            )
            mul8_candidates = []
            if multiply_full_match:
                for var_name in multiply_full_match.groups():
                    for back_index in range(multiply_index - 1, max(-1, multiply_index - 5), -1):
                        constant_match = re.search(
                            rf'^\s*{re.escape(var_name)}\s*=\s*(\d+)\s*$',
                            source_lines[back_index]
                        )
                        if not constant_match:
                            continue
                        candidate_value = int(constant_match.group(1))
                        if 2 <= candidate_value <= 256:
                            mul8_candidates.append(candidate_value)
                            break
            preferred_candidates = [value for value in mul8_candidates if value != 2]
            if preferred_candidates:
                mul8 = preferred_candidates[0]
            elif mul8_candidates:
                mul8 = mul8_candidates[0]
            if mul8 is not None:
                break

        if mul8 is None:
            assign_const_pattern = re.compile(r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(\d+)\s*$')
            multiply_pattern = re.compile(
                r'^\s*[A-Za-z_][A-Za-z0-9_]*\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\s*\*\s*([A-Za-z_][A-Za-z0-9_]*)\s*$'
            )

            def resolve_recent_constant(var_name, start_index, lookback=8):
                for back_index in range(start_index, max(-1, start_index - lookback), -1):
                    const_match = assign_const_pattern.match(source_lines[back_index].strip())
                    if const_match and const_match.group(1) == var_name:
                        return int(const_match.group(2))
                return None

            for line_index, line_text in enumerate(source_lines):
                if not re.search(r'=\s*257\s*$', line_text.strip()):
                    continue
                for back_index in range(line_index - 1, max(-1, line_index - 8), -1):
                    mul_match = multiply_pattern.match(source_lines[back_index].strip())
                    if not mul_match:
                        continue
                    left_var, right_var = mul_match.groups()
                    left_const = resolve_recent_constant(left_var, back_index - 1, 6)
                    right_const = resolve_recent_constant(right_var, back_index - 1, 6)
                    candidates = [value for value in (left_const, right_const) if value is not None]
                    candidates = [value for value in candidates if value != 2] or candidates
                    for candidate_mul in candidates:
                        if 2 <= candidate_mul <= 255:
                            mul8 = candidate_mul
                            break
                    if mul8 is not None:
                        break
                if mul8 is not None:
                    break

        if mul45 is None or add45 is None or mul8 is None:
            return None
        return {
            'mul45': mul45,
            'add45': add45,
            'mul8': mul8
        }

    def _decode_prometheus_runtime_literal(self, encoded_literal, seed_value, key8_value, decoder_constants):
        try:
            decoded_literal = self._parse_lua_string_literal(encoded_literal)
            encrypted_bytes = [(ord(char_value) & 0xFF) for char_value in decoded_literal]
        except Exception:
            return None

        mul45 = decoder_constants['mul45']
        add45 = decoder_constants['add45']
        mul8 = decoder_constants['mul8']
        state45 = seed_value % 35184372088832
        state8 = seed_value % 255 + 2
        prev_values = []
        prev_plain = key8_value
        output_bytes = []

        def next_pseudo_random_byte():
            nonlocal state45, state8, prev_values
            if not prev_values:
                state45 = (state45 * mul45 + add45) % 35184372088832
                while True:
                    state8 = (state8 * mul8) % 257
                    if state8 != 1:
                        break
                remainder_value = state8 % 32
                shift_value = 13 - ((state8 - remainder_value) // 32)
                n_value = (state45 // (2 ** shift_value)) % 4294967296 / (2 ** remainder_value)
                random32_value = int((n_value % 1) * 4294967296) + int(n_value)
                low16_value = random32_value % 65536
                high16_value = (random32_value - low16_value) // 65536
                prev_values = [
                    low16_value % 256,
                    (low16_value - (low16_value % 256)) // 256,
                    high16_value % 256,
                    (high16_value - (high16_value % 256)) // 256
                ]
            return prev_values.pop()

        for current_byte in encrypted_bytes:
            random_byte = next_pseudo_random_byte()
            prev_plain = (current_byte + random_byte + prev_plain) % 256
            output_bytes.append(prev_plain)

        try:
            return bytes(output_bytes).decode('utf-8')
        except Exception:
            return bytes(output_bytes).decode('latin-1', errors='ignore')

    def _score_prometheus_runtime_plaintext(self, plaintext_value):
        if not plaintext_value:
            return -5.0
        score_value = 0.0
        punctuation_count = 0
        for current_char in plaintext_value:
            char_code = ord(current_char)
            if 32 <= char_code <= 126:
                score_value += 1.0
            elif current_char in '\r\n\t':
                score_value += 0.2
            else:
                score_value -= 2.0
            if re.match(r'[!\"#$%&\'()*+,./:;<=>?@[\\\]^`{|}~]', current_char):
                punctuation_count += 1
        if re.search(r'[A-Za-z]{2,}', plaintext_value):
            score_value += 2.0
        lowercase_count = len(re.findall(r'[a-z]', plaintext_value))
        uppercase_count = len(re.findall(r'[A-Z]', plaintext_value))
        space_count = plaintext_value.count(' ')
        if lowercase_count > 0:
            score_value += 0.2 * lowercase_count
        if uppercase_count > 0:
            score_value -= 0.05 * uppercase_count
        if space_count > 0 and re.search(r'^[A-Za-z ]+$', plaintext_value):
            score_value += 1.0 + (0.3 * space_count)
        if punctuation_count > 0:
            score_value -= 0.6 * punctuation_count
        common_word_hits = len(re.findall(r'\b(?:hello|print|function|local|table|string|math|return|true|false|nil)\b', plaintext_value.lower()))
        if common_word_hits > 0:
            score_value += 0.9 * common_word_hits
        return score_value / max(1, len(plaintext_value))

    def _extract_prometheus_function_block(self, script_content, function_name):
        start_match = re.search(
            rf'^\s*{re.escape(function_name)}\s*=\s*function\([^)]*\)\s*$',
            script_content,
            re.MULTILINE
        )
        if not start_match:
            return None

        lines = script_content[start_match.start():].splitlines()
        open_depth = 1
        collected_lines = []

        for line_index, line_text in enumerate(lines):
            collected_lines.append(line_text)
            if line_index == 0:
                continue

            stripped = line_text.strip()
            normalized = stripped[:-1].rstrip() if stripped.endswith(';') else stripped
            if (
                re.match(r'^(if\b|while\b|for\b|function\b)', normalized)
                or re.search(r'=\s*function\b', normalized)
                or normalized == 'repeat'
            ):
                open_depth += 1
            elif normalized == 'end' or normalized.startswith('until '):
                open_depth -= 1
                if open_depth <= 0:
                    break

        if open_depth > 0:
            return None
        return '\n'.join(collected_lines)

    def _extract_prometheus_function_block_before_line(self, source_lines, function_name, call_line_index):
        start_pattern = re.compile(
            rf'^\s*{re.escape(function_name)}\s*=\s*function\([^)]*\)\s*$'
        )
        start_index = None
        scan_limit = min(call_line_index, len(source_lines) - 1)
        for line_index in range(scan_limit, -1, -1):
            if start_pattern.match(source_lines[line_index]):
                start_index = line_index
                break
        if start_index is None:
            return None

        open_depth = 1
        collected_lines = []
        for line_index in range(start_index, len(source_lines)):
            line_text = source_lines[line_index]
            collected_lines.append(line_text)
            if line_index == start_index:
                continue

            stripped = line_text.strip()
            normalized = stripped[:-1].rstrip() if stripped.endswith(';') else stripped
            if (
                re.match(r'^(if\b|while\b|for\b|function\b)', normalized)
                or re.search(r'=\s*function\b', normalized)
                or normalized == 'repeat'
            ):
                open_depth += 1
            elif normalized == 'end' or normalized.startswith('until '):
                open_depth -= 1
                if open_depth <= 0:
                    break

        if open_depth > 0:
            return None
        return '\n'.join(collected_lines)

    def _extract_prometheus_runtime_key8_constant(self, script_content, decoder_function_name, call_line_index=None):
        source_lines = script_content.splitlines()
        if call_line_index is not None:
            function_block = self._extract_prometheus_function_block_before_line(
                source_lines,
                decoder_function_name,
                call_line_index
            )
        else:
            function_block = self._extract_prometheus_function_block(
                script_content,
                decoder_function_name
            )
        if not function_block:
            return None

        while_match = re.search(r'\bwhile\s+true\b', function_block)
        if not while_match:
            return None

        pre_loop_text = function_block[:while_match.start()]
        loop_text = function_block[while_match.start():]
        assignment_pattern = re.compile(r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(\d+)\s*$', re.MULTILINE)
        candidates = []

        for match_object in assignment_pattern.finditer(pre_loop_text):
            variable_name = match_object.group(1)
            constant_value = int(match_object.group(2))
            if constant_value < 2 or constant_value > 255:
                continue
            if not re.search(
                rf'=\s*[A-Za-z_][A-Za-z0-9_]*\s*\+\s*{re.escape(variable_name)}\s*$',
                loop_text,
                re.MULTILINE
            ):
                continue
            candidates.append((match_object.start(), constant_value))

        if not candidates:
            # WeAreDevs variants often split it as:
            #   tmp = byte + prng
            #   decoded = tmp + key_var
            # instead of adding the key constant directly.
            const_assignments = []
            for match_object in assignment_pattern.finditer(pre_loop_text):
                variable_name = match_object.group(1)
                constant_value = int(match_object.group(2))
                if 2 <= constant_value <= 255:
                    const_assignments.append((match_object.start(), variable_name, constant_value))
            for position, variable_name, constant_value in reversed(const_assignments):
                if re.search(
                    rf'=\s*[A-Za-z_][A-Za-z0-9_]*\s*\+\s*{re.escape(variable_name)}\b',
                    loop_text
                ):
                    return constant_value
            return None
        candidates.sort(key=lambda item: item[0])
        return candidates[-1][1]

    def _resolve_prometheus_decoder_function_name(self, source_lines, initial_name, call_line_index):
        resolved_name = initial_name
        assignment_pattern = re.compile(r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\s*$')

        for _ in range(6):
            if self._extract_prometheus_function_block('\n'.join(source_lines), resolved_name):
                return resolved_name

            alias_name = None
            for line_text in source_lines[:max(0, call_line_index + 1)]:
                match_object = assignment_pattern.match(line_text)
                if not match_object:
                    continue
                if match_object.group(1) != resolved_name:
                    continue
                alias_name = match_object.group(2)

            if not alias_name or alias_name == resolved_name:
                break
            resolved_name = alias_name

        return resolved_name

    def _resolve_recent_prometheus_value(self, source_lines, line_index, variable_name, _seen=None):
        if _seen is None:
            _seen = set()
        if variable_name in _seen:
            return None
        _seen.add(variable_name)

        assignment_pattern = re.compile(
            rf'^\s*(?:local\s+)?{re.escape(variable_name)}\s*=\s*(.+?)\s*;?\s*$'
        )
        literal_pattern = re.compile(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'')
        number_pattern = re.compile(r'[+-]?\d+')
        identifier_pattern = re.compile(r'[A-Za-z_][A-Za-z0-9_]*')

        current_indent = len(source_lines[line_index]) - len(source_lines[line_index].lstrip(' \t'))
        scan_start = max(0, line_index - 260)
        for back_index in range(line_index - 1, scan_start - 1, -1):
            raw_line = source_lines[back_index]
            line_indent = len(raw_line) - len(raw_line.lstrip(' \t'))
            # Avoid picking assignments from deeper nested scopes (inner functions/blocks).
            if line_indent > current_indent:
                continue
            line_text = raw_line.strip()
            match_object = assignment_pattern.match(line_text)
            if not match_object:
                continue
            rhs_text = match_object.group(1).strip()
            if literal_pattern.fullmatch(rhs_text):
                return ('str', rhs_text)
            if number_pattern.fullmatch(rhs_text):
                return ('num', int(rhs_text))
            if identifier_pattern.fullmatch(rhs_text):
                return self._resolve_recent_prometheus_value(
                    source_lines,
                    back_index,
                    rhs_text,
                    _seen
                )
            return None
        return None

    def _resolve_recent_prometheus_numeric_seed(self, source_lines, line_index):
        current_indent = len(source_lines[line_index]) - len(source_lines[line_index].lstrip(' \t'))
        assignment_pattern = re.compile(
            r'^\s*(?:local\s+)?[A-Za-z_][A-Za-z0-9_]*\s*=\s*([+-]?\d{6,})\s*;?\s*$'
        )
        scan_start = max(0, line_index - 120)
        for back_index in range(line_index - 1, scan_start - 1, -1):
            raw_line = source_lines[back_index]
            line_indent = len(raw_line) - len(raw_line.lstrip(' \t'))
            if line_indent > current_indent:
                continue
            match_object = assignment_pattern.match(raw_line.strip())
            if not match_object:
                continue
            return ('num', int(match_object.group(1)))
        return None

    def _decode_prometheus_runtime_string_calls(self, script_content):
        decoder_constants = self._extract_prometheus_runtime_decoder_constants(script_content)

        source_lines = script_content.splitlines()
        known_values = {}
        call_candidates = []
        assignment_pattern = re.compile(
            r'^(\s*)(local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*$'
        )
        call_pattern = re.compile(
            r'^([A-Za-z_][A-Za-z0-9_]*)\(\s*([^,]+)\s*,\s*([^)]+)\s*\)$'
        )
        literal_pattern = re.compile(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'')

        def resolve_value(raw_text, current_line_index):
            value_text = raw_text.strip()
            if literal_pattern.fullmatch(value_text):
                return ('str', value_text)
            if re.fullmatch(r'\d+', value_text):
                return ('num', int(value_text))
            known_value = known_values.get(value_text)
            if known_value:
                return known_value
            if re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', value_text):
                return self._resolve_recent_prometheus_value(
                    source_lines,
                    current_line_index,
                    value_text
                )
            return None

        for line_index, line_text in enumerate(source_lines):
            assignment_match = assignment_pattern.match(line_text)
            if not assignment_match:
                continue

            indent_text = assignment_match.group(1)
            local_kw = assignment_match.group(2) or ''
            lhs_name = assignment_match.group(3)
            rhs_text = assignment_match.group(4).strip()
            call_match = call_pattern.match(rhs_text)

            if call_match:
                function_name = call_match.group(1)
                raw_arg1 = call_match.group(2).strip()
                raw_arg2 = call_match.group(3).strip()
                arg1_value = resolve_value(call_match.group(2), line_index)
                arg2_value = resolve_value(call_match.group(3), line_index)
                if arg2_value is None:
                    if re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', raw_arg2):
                        arg2_value = self._resolve_recent_prometheus_numeric_seed(
                            source_lines,
                            line_index
                        )
                encoded_literal = None
                if arg1_value and arg1_value[0] == 'str':
                    encoded_literal = arg1_value[1]
                numeric_seed_value = None
                if arg2_value and arg2_value[0] == 'num':
                    numeric_seed_value = arg2_value[1]

                if numeric_seed_value is not None or encoded_literal is not None:
                    call_candidates.append({
                        'line_index': line_index,
                        'lhs': lhs_name,
                        'indent': indent_text,
                        'local_kw': local_kw,
                        'function_name': function_name,
                        'arg1_token': raw_arg1,
                        'encoded_literal': encoded_literal,
                        'seed_value': numeric_seed_value
                    })
                known_values.pop(lhs_name, None)
                continue

            if literal_pattern.fullmatch(rhs_text):
                known_values[lhs_name] = ('str', rhs_text)
                continue
            if re.fullmatch(r'\d+', rhs_text):
                known_values[lhs_name] = ('num', int(rhs_text))
                continue
            known_values.pop(lhs_name, None)

        if not call_candidates:
            return script_content

        decoder_calls = list(call_candidates)
        if not decoder_calls:
            return script_content

        best_key8 = None
        if decoder_constants:
            dominant_decoder_name = Counter(
                candidate['function_name']
                for candidate in decoder_calls
            ).most_common(1)[0][0]
            resolved_decoder_name = self._resolve_prometheus_decoder_function_name(
                source_lines,
                dominant_decoder_name,
                decoder_calls[0]['line_index']
            )
            inferred_key8 = self._extract_prometheus_runtime_key8_constant(
                script_content,
                resolved_decoder_name,
                decoder_calls[0]['line_index']
            )
            if inferred_key8 is not None:
                best_key8 = inferred_key8
            else:
                best_score = None
                scored_calls = decoder_calls[:48]
                for key8_value in range(256):
                    score_total = 0.0
                    for call_data in scored_calls:
                        if (
                            not call_data.get('encoded_literal')
                            or call_data.get('seed_value') is None
                        ):
                            continue
                        decoded_text = self._decode_prometheus_runtime_literal(
                            call_data['encoded_literal'],
                            call_data['seed_value'],
                            key8_value,
                            decoder_constants
                        )
                        if decoded_text is None:
                            score_total -= 5.0
                            continue
                        score_total += self._score_prometheus_runtime_plaintext(decoded_text)
                    if best_score is None or score_total > best_score:
                        best_score = score_total
                        best_key8 = key8_value

        decoded_call_map = {}
        if decoder_constants:
            if best_key8 is None:
                return script_content

            for call_data in decoder_calls:
                if (
                    not call_data.get('encoded_literal')
                    or call_data.get('seed_value') is None
                ):
                    continue
                decoded_text = self._decode_prometheus_runtime_literal(
                    call_data['encoded_literal'],
                    call_data['seed_value'],
                    best_key8,
                    decoder_constants
                )
                if decoded_text is None:
                    continue
                decoded_score = self._score_prometheus_runtime_plaintext(decoded_text)
                if decoded_score < -0.35:
                    continue
                decoded_call_map[call_data['line_index']] = {
                    'lhs': call_data['lhs'],
                    'decoded_text': decoded_text
                }

        unresolved_calls = [
            candidate
            for candidate in decoder_calls
            if candidate['line_index'] not in decoded_call_map
        ]
        if unresolved_calls:
            dynamic_decoded_map = self._decode_prometheus_runtime_calls_via_lua(
                source_lines,
                unresolved_calls
            )
            for line_index, decoded_text in dynamic_decoded_map.items():
                decoded_call_map[line_index] = {
                    'lhs': next(
                        (
                            candidate['lhs'] for candidate in decoder_calls
                            if candidate['line_index'] == line_index
                        ),
                        None
                    ),
                    'decoded_text': decoded_text
                }

        if not decoded_call_map:
            return script_content

        active_decoded_vars = {}
        rewritten_lines = []
        index_pattern = re.compile(
            r'([A-Za-z_][A-Za-z0-9_]*)\[\s*([A-Za-z_][A-Za-z0-9_]*)\s*\]'
        )

        for line_index, line_text in enumerate(source_lines):
            assignment_match = assignment_pattern.match(line_text)
            assigned_name = assignment_match.group(3) if assignment_match else None
            if assigned_name in active_decoded_vars:
                active_decoded_vars.pop(assigned_name, None)

            call_decode = decoded_call_map.get(line_index)
            if call_decode:
                active_decoded_vars[call_decode['lhs']] = call_decode['decoded_text']
                decoded_literal = self._format_lua_string(call_decode['decoded_text'])
                original_call = next(
                    (
                        candidate for candidate in decoder_calls
                        if candidate['line_index'] == line_index
                    ),
                    None
                )
                if original_call:
                    indent_text = original_call.get('indent', '')
                    local_kw = original_call.get('local_kw', '')
                    rewritten_lines.append(
                        f"{indent_text}{local_kw}{call_decode['lhs']} = {decoded_literal}"
                    )
                else:
                    rewritten_lines.append(line_text)
                continue

            def replace_index(match_object):
                index_name = match_object.group(2)
                if index_name not in active_decoded_vars:
                    return match_object.group(0)
                return self._format_lua_string(active_decoded_vars[index_name])

            rewritten_lines.append(index_pattern.sub(replace_index, line_text))

        # Inline direct decoder call expressions too:
        #   some_fn(decode_runtime_string("...", 123))
        #   decode_runtime_string("...", seed_var)
        decoder_names = set(candidate['function_name'] for candidate in decoder_calls)
        decoder_names.update(
            name
            for name in re.findall(r'\bdecode_runtime_string(?:_\d+)?\b', script_content)
        )

        decoded_literal_cache = {}
        for line_index, line_data in decoded_call_map.items():
            lhs_name = line_data.get('lhs')
            decoded_text = line_data.get('decoded_text')
            if not decoded_text:
                continue
            for candidate in decoder_calls:
                if candidate['line_index'] != line_index:
                    continue
                if candidate.get('encoded_literal'):
                    decoded_literal_cache[(candidate['encoded_literal'], candidate['seed_value'])] = decoded_text
                break

        if decoder_names and decoder_constants and best_key8 is not None:
            fn_alt = '|'.join(sorted({re.escape(name) for name in decoder_names if name}))
            inline_call_pattern = re.compile(
                rf'\b(?:{fn_alt})\(\s*("(?:(?:\\.)|[^"\\])*"|\'(?:(?:\\.)|[^\'\\])*\')\s*,\s*([A-Za-z_][A-Za-z0-9_]*|\d+)\s*\)'
            )

            # Track trivial numeric aliases in a lightweight forward scan.
            known_numeric = {}
            numeric_assign_pattern = re.compile(
                r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(\d+)\s*$'
            )
            alias_assign_pattern = re.compile(
                r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\s*$'
            )

            for line_index, line_text in enumerate(rewritten_lines):
                n_match = numeric_assign_pattern.match(line_text.strip())
                if n_match:
                    known_numeric[n_match.group(1)] = int(n_match.group(2))
                else:
                    a_match = alias_assign_pattern.match(line_text.strip())
                    if a_match:
                        lhs_name, rhs_name = a_match.groups()
                        if rhs_name in known_numeric:
                            known_numeric[lhs_name] = known_numeric[rhs_name]

                def inline_replace(match_object):
                    encoded_literal = match_object.group(1)
                    seed_token = match_object.group(2)
                    if re.fullmatch(r'\d+', seed_token):
                        seed_value = int(seed_token)
                    else:
                        seed_value = known_numeric.get(seed_token)
                    if seed_value is None:
                        return match_object.group(0)

                    cache_key = (encoded_literal, seed_value)
                    decoded_text = decoded_literal_cache.get(cache_key)
                    if decoded_text is None:
                        decoded_text = self._decode_prometheus_runtime_literal(
                            encoded_literal,
                            seed_value,
                            best_key8,
                            decoder_constants
                        )
                        if decoded_text is None:
                            return match_object.group(0)
                        decoded_score = self._score_prometheus_runtime_plaintext(decoded_text)
                        if decoded_score < -0.35:
                            return match_object.group(0)
                        decoded_literal_cache[cache_key] = decoded_text
                    return self._format_lua_string(decoded_text)

                rewritten_lines[line_index] = inline_call_pattern.sub(inline_replace, line_text)

        # Build a conservative seed->plaintext map from successfully decoded callsites.
        line_to_seed = {}
        for candidate in decoder_calls:
            line_to_seed[candidate['line_index']] = candidate.get('seed_value')
        seed_to_text = {}
        conflicting_seeds = set()
        for line_index, line_data in decoded_call_map.items():
            seed_value = line_to_seed.get(line_index)
            decoded_text = line_data.get('decoded_text')
            if seed_value is None or not decoded_text:
                continue
            previous_text = seed_to_text.get(seed_value)
            if previous_text is None:
                seed_to_text[seed_value] = decoded_text
            elif previous_text != decoded_text:
                conflicting_seeds.add(seed_value)
        for seed_value in conflicting_seeds:
            seed_to_text.pop(seed_value, None)

        dynamic_seed_map = self._collect_prometheus_decoder_seed_map_via_lua(script_content)
        if dynamic_seed_map:
            for seed_value, decoded_text in dynamic_seed_map.items():
                if seed_value not in seed_to_text:
                    seed_to_text[seed_value] = decoded_text

        if seed_to_text:
            cache_names = set()
            alias_pattern = re.compile(
                r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\s*$'
            )
            setmeta_pattern = re.compile(
                r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*setmetatable\s*\(\s*\{\s*\}\s*,\s*\{\s*__index\s*=\s*([A-Za-z_][A-Za-z0-9_]*)'
            )
            for line_text in rewritten_lines:
                sm = setmeta_pattern.match(line_text.strip())
                if sm:
                    cache_names.add(sm.group(1))
                    cache_names.add(sm.group(2))
            changed = True
            while changed:
                changed = False
                for line_text in rewritten_lines:
                    am = alias_pattern.match(line_text.strip())
                    if not am:
                        continue
                    lhs_name, rhs_name = am.groups()
                    if rhs_name in cache_names and lhs_name not in cache_names:
                        cache_names.add(lhs_name)
                        changed = True

            known_numeric = {}
            numeric_assign_pattern = re.compile(
                r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([+-]?\d+)\s*$'
            )
            numeric_alias_pattern = re.compile(
                r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\s*$'
            )
            broad_index_pattern = re.compile(
                r'\b([A-Za-z_][A-Za-z0-9_]*)\s*\[\s*([+-]?\d{6,})\s*\]'
            )
            if not cache_names:
                for line_text in rewritten_lines:
                    for index_match in broad_index_pattern.finditer(line_text):
                        base_name = index_match.group(1)
                        seed_value = int(index_match.group(2))
                        if seed_value in seed_to_text:
                            cache_names.add(base_name)

            for idx, line_text in enumerate(rewritten_lines):
                nm = numeric_assign_pattern.match(line_text.strip())
                if nm:
                    known_numeric[nm.group(1)] = int(nm.group(2))
                else:
                    am = numeric_alias_pattern.match(line_text.strip())
                    if am and am.group(2) in known_numeric:
                        known_numeric[am.group(1)] = known_numeric[am.group(2)]

                for cache_name in cache_names:
                    table_numeric_pattern = re.compile(
                        rf'\b{re.escape(cache_name)}\s*\[\s*([+-]?\d+)\s*\]'
                    )
                    table_var_pattern = re.compile(
                        rf'\b{re.escape(cache_name)}\s*\[\s*([A-Za-z_][A-Za-z0-9_]*)\s*\]'
                    )

                    def replace_num_index(match_object):
                        seed_value = int(match_object.group(1))
                        decoded_text = seed_to_text.get(seed_value)
                        if decoded_text is None:
                            return match_object.group(0)
                        return self._format_lua_string(decoded_text)

                    def replace_var_index(match_object):
                        index_name = match_object.group(1)
                        seed_value = known_numeric.get(index_name)
                        if seed_value is None:
                            return match_object.group(0)
                        decoded_text = seed_to_text.get(seed_value)
                        if decoded_text is None:
                            return match_object.group(0)
                        return self._format_lua_string(decoded_text)

                    updated_line = table_numeric_pattern.sub(replace_num_index, rewritten_lines[idx])
                    updated_line = table_var_pattern.sub(replace_var_index, updated_line)
                    rewritten_lines[idx] = updated_line

        # Fallback for hard variants: execute inline decode expressions in Lua
        # using prefix context before each line.
        lua_inline_replacements = self._decode_prometheus_inline_calls_via_lua(
            rewritten_lines,
            decoder_names
        )
        if lua_inline_replacements:
            grouped = {}
            for (line_index, start_pos, end_pos), decoded_text in lua_inline_replacements.items():
                grouped.setdefault(line_index, []).append((start_pos, end_pos, decoded_text))
            for line_index, replacements in grouped.items():
                current_line = rewritten_lines[line_index]
                replacements.sort(key=lambda item: item[0], reverse=True)
                for start_pos, end_pos, decoded_text in replacements:
                    current_line = (
                        current_line[:start_pos]
                        + self._format_lua_string(decoded_text)
                        + current_line[end_pos:]
                    )
                rewritten_lines[line_index] = current_line

        rewritten_text = '\n'.join(rewritten_lines)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _normalize_prometheus_decoder_call_callees(self, script_content):
        lines = script_content.splitlines()
        fn_assign_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*function\([^)]*\)\s*$'
        )

        decoder_names = []
        index = 0
        while index < len(lines):
            fn_match = fn_assign_pattern.match(lines[index].strip())
            if not fn_match:
                index += 1
                continue
            end_index = self._find_matching_block_end_line(lines, index)
            if end_index == -1:
                index += 1
                continue
            fn_text = '\n'.join(lines[index:end_index + 1])
            if self._classify_prometheus_decoder_function_text(fn_text) == 'decode':
                decoder_names.append(fn_match.group(1))
            index = end_index + 1

        semantic_decoders = [
            name for name in decoder_names
            if re.fullmatch(r'decode_runtime_string(?:_\d+)?', name)
        ]
        if semantic_decoders:
            target_decoder = semantic_decoders[0]
        elif decoder_names:
            target_decoder = decoder_names[0]
        else:
            return script_content

        builtin_callees = {
            'print', 'warn', 'error', 'require', 'assert', 'tonumber', 'tostring',
            'type', 'pairs', 'ipairs', 'next', 'select', 'setmetatable',
            'getmetatable', 'pcall', 'xpcall', 'unpack', 'loadstring', 'load'
        }
        string_literal = r'"(?:(?:\\.)|[^"\\])*"|\'(?:(?:\\.)|[^\'\\])*\''
        call_pattern = re.compile(
            rf'(?<![.:])\b([A-Za-z_][A-Za-z0-9_]*)\s*\(\s*({string_literal})\s*,'
        )

        def has_encoded_escapes(literal_text):
            return bool(re.search(r'\\(?:\d{1,3}|x[0-9A-Fa-f]{2})', literal_text))

        def replace_call(match_object):
            callee_name = match_object.group(1)
            literal_text = match_object.group(2)
            if callee_name == target_decoder or callee_name in builtin_callees:
                return match_object.group(0)
            if not has_encoded_escapes(literal_text):
                return match_object.group(0)
            return f"{target_decoder}({literal_text},"

        normalized_lines = [call_pattern.sub(replace_call, line_text) for line_text in lines]
        normalized_text = '\n'.join(normalized_lines)
        return normalized_text + ('\n' if script_content.endswith('\n') else '')

    def _remove_invalid_literal_index_assignments(self, script_content):
        lines = script_content.splitlines()
        invalid_pattern = re.compile(
            r'^\s*(?:local\s+)?[A-Za-z_][A-Za-z0-9_]*\s*=\s*(?:nil|true|false)\s*\[.+\]\s*$'
        )
        rewritten = [line for line in lines if not invalid_pattern.match(line.strip())]
        rewritten_text = '\n'.join(rewritten)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _prune_dead_terminal_assignments(self, script_content):
        lines = script_content.splitlines()
        assign_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*$'
        )
        return_pattern = re.compile(r'^\s*return(?:\s+.+)?\s*$')
        safe_rhs_pattern = re.compile(
            r'^(?:nil|true|false|[-+]?\d+(?:\.\d+)?|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|\{\}|[A-Za-z_][A-Za-z0-9_]*)$'
        )

        rewritten = list(lines)
        index = 0
        while index < len(rewritten):
            if not return_pattern.match(rewritten[index].strip()):
                index += 1
                continue

            probe = index - 1
            removable = []
            while probe >= 0:
                prev_line = rewritten[probe]
                if not prev_line.strip():
                    probe -= 1
                    continue
                prev_indent = len(prev_line) - len(prev_line.lstrip(' \t'))
                ret_indent = len(rewritten[index]) - len(rewritten[index].lstrip(' \t'))
                if prev_indent != ret_indent:
                    break
                assign_match = assign_pattern.match(prev_line.strip())
                if not assign_match:
                    break
                rhs_text = assign_match.group(2).strip().rstrip(';').strip()
                if not safe_rhs_pattern.fullmatch(rhs_text):
                    break
                removable.append(probe)
                probe -= 1

            if removable:
                for rem_index in removable:
                    rewritten[rem_index] = ''
            index += 1

        output = [line for line in rewritten if line != '']
        rewritten_text = '\n'.join(output)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _prune_dead_prometheus_pc_assignments_by_liveness(self, script_content):
        lines = script_content.splitlines()
        assign_pattern = re.compile(
            r'^(\s*)(pc(?:_value)?)\s*=\s*(.+?)\s*$'
        )

        remove_indexes = set()
        for index, line_text in enumerate(lines):
            assign_match = assign_pattern.match(line_text)
            if not assign_match:
                continue
            indent_text, lhs_name, rhs_text = assign_match.groups()
            rhs_clean = rhs_text.strip().rstrip(';').strip()
            if '(' in rhs_clean or re.search(r'\bfunction\b', rhs_clean):
                continue

            current_indent = len(indent_text)
            token_pattern = re.compile(rf'\b{re.escape(lhs_name)}\b')
            dead = False

            for probe in range(index + 1, len(lines)):
                probe_line = lines[probe]
                stripped = probe_line.strip()
                if not stripped:
                    continue
                probe_indent = len(probe_line) - len(probe_line.lstrip(' \t'))
                if probe_indent < current_indent:
                    dead = True
                    break
                probe_assign = assign_pattern.match(probe_line)
                if probe_indent == current_indent and probe_assign and probe_assign.group(2) == lhs_name:
                    dead = True
                    break
                if probe_indent == current_indent and (stripped == 'end' or stripped.startswith('return')):
                    dead = True
                    break
                if token_pattern.search(stripped):
                    break
            if dead:
                remove_indexes.add(index)

        if not remove_indexes:
            return script_content

        rewritten = [line for idx, line in enumerate(lines) if idx not in remove_indexes]
        rewritten_text = '\n'.join(rewritten)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _inline_and_prune_prng_decoder_residuals(self, script_content):
        decoder_constants = self._extract_prometheus_runtime_decoder_constants(script_content)
        key8_match = re.search(
            r'byte_value\s*\+\s*next_prng_byte\s*\(\s*\)\s*\+\s*(\d+)',
            script_content
        )
        key8_value = int(key8_match.group(1)) if key8_match else 241
        decoder_names = set(re.findall(r'\bdecode_runtime_string(?:_\d+)?\b', script_content))
        if not decoder_names:
            return script_content

        string_literal = r'"(?:(?:\\.)|[^"\\])*"|\'(?:(?:\\.)|[^\'\\])*\''
        decoder_alt = '|'.join(sorted(re.escape(name) for name in decoder_names))
        inlined_content = script_content

        if decoder_constants:
            call_expr_pattern = re.compile(
                rf'\b(?:{decoder_alt})\s*\(\s*({string_literal})\s*,\s*(\d+)\s*\)'
            )

            def decode_replace(match_object):
                decoded_text = self._decode_prometheus_runtime_literal(
                    match_object.group(1),
                    int(match_object.group(2)),
                    key8_value,
                    decoder_constants
                )
                if decoded_text is None:
                    return match_object.group(0)
                score_value = self._score_prometheus_runtime_plaintext(decoded_text)
                if score_value < -0.35:
                    return match_object.group(0)
                return self._format_lua_string(decoded_text)

            inlined_content = call_expr_pattern.sub(decode_replace, script_content)
        lines = inlined_content.splitlines()
        token_counts = Counter(re.findall(r'\b[A-Za-z_][A-Za-z0-9_]*\b', inlined_content))
        residual_call_pattern = re.compile(
            rf'^(\s*)(local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(?:{decoder_alt})\s*\((.*)\)\s*$'
        )
        standalone_residual_pattern = re.compile(
            rf'^\s*(?:{decoder_alt})\s*\((.*)\)\s*$'
        )
        unused_byte_string_pattern = re.compile(
            rf'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*({string_literal})\s*$'
        )

        rewritten = []
        for line_text in lines:
            residual_match = residual_call_pattern.match(line_text)
            if residual_match:
                indent_text, local_prefix, lhs_name, args_text = residual_match.groups()
                if token_counts.get(lhs_name, 0) <= 1:
                    continue
                # Only neutralize unresolved decode assignments when they still
                # carry encoded literal bytes. Non-literal callsites are kept.
                if re.search(r'^\s*' + string_literal + r'\s*,', args_text or ''):
                    rewritten.append(f'{indent_text}{local_prefix or ""}{lhs_name} = ""')
                else:
                    rewritten.append(line_text)
                continue
            if standalone_residual_pattern.match(line_text.strip()):
                continue
            string_match = unused_byte_string_pattern.match(line_text.strip())
            if string_match and token_counts.get(string_match.group(1), 0) <= 1:
                literal_text = string_match.group(2)
                if re.search(r'\\(?:\d{1,3}|x[0-9A-Fa-f]{2})', literal_text):
                    continue
            rewritten.append(line_text)

        rewritten_text = '\n'.join(rewritten)
        return rewritten_text + ('\n' if inlined_content.endswith('\n') else '')

    def _remove_undefined_garbage_returns(self, script_content):
        lines = script_content.splitlines()
        token_counts = Counter(re.findall(r'\b[A-Za-z_][A-Za-z0-9_]*\b', script_content))
        assigned_names = set()
        assign_pattern = re.compile(r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=')
        local_decl_pattern = re.compile(r'^\s*local\s+([A-Za-z_][A-Za-z0-9_]*(?:\s*,\s*[A-Za-z_][A-Za-z0-9_]*)*)\s*$')
        for line_text in lines:
            assign_match = assign_pattern.match(line_text.strip())
            if assign_match:
                assigned_names.add(assign_match.group(1))
                continue
            local_match = local_decl_pattern.match(line_text.strip())
            if local_match:
                assigned_names.update(part.strip() for part in local_match.group(1).split(','))

        globals_allow = {
            'true', 'false', 'nil', 'game', 'math', 'string', 'table', 'print',
            'pairs', 'ipairs', 'next', 'unpack', 'task', 'Instance', 'Color3',
            'UDim2', 'UDim', 'Enum'
        }
        return_pattern = re.compile(r'^(\s*)return\s+([A-Za-z_][A-Za-z0-9_]*)\s*$')
        rewritten = []
        for line_text in lines:
            return_match = return_pattern.match(line_text)
            if return_match:
                name_text = return_match.group(2)
                if (
                    name_text not in assigned_names
                    and name_text not in globals_allow
                    and token_counts.get(name_text, 0) <= 1
                ):
                    continue
            rewritten.append(line_text)

        rewritten_text = '\n'.join(rewritten)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _neutralize_garbage_byte_string_assignments(self, script_content):
        lines = script_content.splitlines()
        token_counts = Counter(re.findall(r'\b[A-Za-z_][A-Za-z0-9_]*\b', script_content))
        string_literal = r'"(?:(?:\\.)|[^"\\])*"|\'(?:(?:\\.)|[^\'\\])*\''
        assign_pattern = re.compile(
            rf'^(\s*)(local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*({string_literal})\s*$'
        )
        call_first_arg_pattern = re.compile(
            r'^\s*[A-Za-z_][A-Za-z0-9_]*\s*\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*,'
        )
        alias_assign_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\s*$'
        )
        decoder_names = set(re.findall(r'\bdecode_runtime_string(?:_\d+)?\b', script_content))
        decoder_call_pattern = None
        if decoder_names:
            decoder_alt = '|'.join(sorted(re.escape(name) for name in decoder_names))
            decoder_call_pattern = re.compile(
                rf'^\s*(?:{decoder_alt})\s*\((.*?)\)\s*$'
            )

        protected_vars = set()
        alias_map = {}
        for line_text in lines:
            call_match = call_first_arg_pattern.match(line_text.strip())
            if call_match:
                protected_vars.add(call_match.group(1))
            if decoder_call_pattern:
                decoder_call_match = decoder_call_pattern.match(line_text.strip())
                if decoder_call_match:
                    arg_blob = decoder_call_match.group(1)
                    for identifier in re.findall(r'\b[A-Za-z_][A-Za-z0-9_]*\b', arg_blob):
                        protected_vars.add(identifier)
            alias_match = alias_assign_pattern.match(line_text.strip())
            if alias_match:
                alias_map[alias_match.group(1)] = alias_match.group(2)

        # Back-propagate protection through simple alias chains: a=b ; fn(a, ...)
        changed = True
        while changed:
            changed = False
            for lhs_name, rhs_name in alias_map.items():
                if lhs_name in protected_vars and rhs_name not in protected_vars:
                    protected_vars.add(rhs_name)
                    changed = True

        rewritten = []
        for line_text in lines:
            assign_match = assign_pattern.match(line_text)
            if not assign_match:
                rewritten.append(line_text)
                continue
            literal_text = assign_match.group(4)
            if not re.search(r'\\(?:\d{1,3}|x[0-9A-Fa-f]{2})', literal_text):
                rewritten.append(line_text)
                continue
            indent_text, local_kw, lhs_name, _literal = assign_match.groups()
            if lhs_name in protected_vars:
                rewritten.append(line_text)
                continue
            if token_counts.get(lhs_name, 0) <= 1:
                continue
            # Keep non-trivial encoded payloads intact; later decoder/alias passes
            # may still recover semantics from these literals.
            rewritten.append(line_text)

        rewritten_text = '\n'.join(rewritten)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _remove_overwritten_function_assignments(self, script_content):
        lines = script_content.splitlines()
        fn_assign_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*function\([^)]*\)\s*$'
        )
        remove_indexes = set()

        index = 0
        while index < len(lines):
            fn_match = fn_assign_pattern.match(lines[index].strip())
            if not fn_match:
                index += 1
                continue
            fn_name = fn_match.group(1)
            fn_end = self._find_matching_block_end_line(lines, index)
            if fn_end == -1:
                index += 1
                continue

            overwritten_at = None
            used_before_overwrite = False
            call_pattern = re.compile(rf'\b{re.escape(fn_name)}\s*(?:\(|:)')
            assign_pattern = re.compile(rf'^\s*(?:local\s+)?{re.escape(fn_name)}\s*=')
            probe = fn_end + 1
            while probe < len(lines):
                stripped = lines[probe].strip()
                if assign_pattern.match(stripped):
                    overwritten_at = probe
                    break
                if call_pattern.search(stripped):
                    used_before_overwrite = True
                    break
                probe += 1

            if overwritten_at is not None and not used_before_overwrite:
                remove_indexes.update(range(index, fn_end + 1))
                index = overwritten_at
                continue

            index = fn_end + 1

        if not remove_indexes:
            return script_content

        rewritten = [line for idx, line in enumerate(lines) if idx not in remove_indexes]
        rewritten_text = '\n'.join(rewritten)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _stabilize_prometheus_probe_lines(self, source_lines):
        stabilized_lines = []
        table_write_pattern = re.compile(
            r'^(\s*)([A-Za-z_][A-Za-z0-9_]*)\s*\[[^\]]+\]\s*='
        )
        method_call_pattern = re.compile(
            r'^(\s*)([A-Za-z_][A-Za-z0-9_]*)\s*:[A-Za-z_][A-Za-z0-9_]*\s*\('
        )
        call_assign_pattern = re.compile(
            r'^(\s*)(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\s*\('
        )
        call_stmt_pattern = re.compile(
            r'^(\s*)([A-Za-z_][A-Za-z0-9_]*)\s*\('
        )
        index_base_pattern = re.compile(
            r'([A-Za-z_][A-Za-z0-9_]*)\s*\['
        )
        dot_base_pattern = re.compile(
            r'([A-Za-z_][A-Za-z0-9_]*)\s*\.[A-Za-z_][A-Za-z0-9_]*'
        )
        reserved_call_names = {
            'if', 'while', 'for', 'repeat', 'until', 'return', 'function', 'local', 'end'
        }

        for line_text in source_lines:
            line_text = re.sub(
                r'#\s*([A-Za-z_][A-Za-z0-9_]*)',
                r'#(\1 or {})',
                line_text
            )
            line_indent = len(line_text) - len(line_text.lstrip(' \t'))
            indent_text = line_text[:line_indent]
            guarded_names = set()
            for base_match in index_base_pattern.finditer(line_text):
                base_name = base_match.group(1)
                if base_name in guarded_names:
                    continue
                guarded_names.add(base_name)
                stabilized_lines.append(
                    f"{indent_text}if type({base_name}) ~= 'table' then {base_name} = __stub end"
                )
            for base_match in dot_base_pattern.finditer(line_text):
                base_name = base_match.group(1)
                if base_name in guarded_names:
                    continue
                guarded_names.add(base_name)
                stabilized_lines.append(
                    f"{indent_text}if type({base_name}) ~= 'table' and type({base_name}) ~= 'userdata' then {base_name} = __stub end"
                )

            table_write_match = table_write_pattern.match(line_text)
            if table_write_match:
                indent_text = table_write_match.group(1)
                table_name = table_write_match.group(2)
                stabilized_lines.append(
                    f"{indent_text}if {table_name} == nil then {table_name} = {{}} end"
                )
                stabilized_lines.append(line_text)
                continue

            method_call_match = method_call_pattern.match(line_text)
            if method_call_match:
                indent_text = method_call_match.group(1)
                object_name = method_call_match.group(2)
                stabilized_lines.append(
                    f"{indent_text}if {object_name} == nil then {object_name} = __stub end"
                )
                stabilized_lines.append(line_text)
                continue

            call_assign_match = call_assign_pattern.match(line_text)
            if call_assign_match:
                indent_text = call_assign_match.group(1)
                callee_name = call_assign_match.group(3)
                if callee_name not in reserved_call_names:
                    stabilized_lines.append(
                        f"{indent_text}if type({callee_name}) ~= 'function' then {callee_name} = __stub end"
                    )
                stabilized_lines.append(line_text)
                continue

            call_stmt_match = call_stmt_pattern.match(line_text)
            if call_stmt_match:
                indent_text = call_stmt_match.group(1)
                callee_name = call_stmt_match.group(2)
                if callee_name not in reserved_call_names:
                    stabilized_lines.append(
                        f"{indent_text}if type({callee_name}) ~= 'function' then {callee_name} = __stub end"
                    )
                stabilized_lines.append(line_text)
                continue

            stabilized_lines.append(line_text)

        return stabilized_lines

    def _decode_prometheus_runtime_calls_via_lua(self, source_lines, decoder_calls):
        lua_path = os.path.join(os.getcwd(), 'lua.exe')
        if not os.path.isfile(lua_path):
            return {}

        probe_prelude = (
            "local __stub\n"
            "do\n"
            "  local mt = {}\n"
            "  __stub = setmetatable({}, mt)\n"
            "  mt.__index = function() return __stub end\n"
            "  mt.__newindex = function() end\n"
            "  mt.__call = function() return __stub end\n"
            "  mt.__len = function() return 0 end\n"
            "  mt.__add = function() return 0 end\n"
            "  mt.__sub = function() return 0 end\n"
            "  mt.__mul = function() return 0 end\n"
            "  mt.__div = function() return 0 end\n"
            "  mt.__mod = function() return 0 end\n"
            "  mt.__pow = function() return 0 end\n"
            "  mt.__unm = function() return 0 end\n"
            "  mt.__concat = function(a, b) return tostring(a or '') .. tostring(b or '') end\n"
            "  mt.__eq = function() return false end\n"
            "  mt.__lt = function() return false end\n"
            "  mt.__le = function() return false end\n"
            "  mt.__tostring = function() return '' end\n"
            "end\n"
            "setmetatable(_G, {\n"
            "  __index = function(t, k)\n"
            "    local v = rawget(t, k)\n"
            "    if v ~= nil then return v end\n"
            "    return __stub\n"
            "  end\n"
            "})\n"
            "env = _G\n"
            "print = function(...) end\n"
            "warn = function(...) end\n"
            "if type(game) ~= 'table' then game = __stub end\n"
            "if type(Instance) ~= 'table' then Instance = { new = function(...) return __stub end } end\n"
            "task = task or { wait = function(...) return 0 end, spawn = function(...) return __stub end }\n"
            "do\n"
            "  local __orig_random = math.random\n"
            "  math.random = function(a, b)\n"
            "    if a == nil then\n"
            "      local ok, r = pcall(__orig_random)\n"
            "      if ok then return r end\n"
            "      return 0\n"
            "    end\n"
            "    if b == nil then return 1 end\n"
            "    if type(a) ~= 'number' or type(b) ~= 'number' then return 1 end\n"
            "    if a > b then return a end\n"
            "    local ok, r = pcall(__orig_random, a, b)\n"
            "    if ok then return r end\n"
            "    return a\n"
            "  end\n"
            "end\n"
        )

        decoded_map = {}
        for call_data in decoder_calls[:80]:
            line_index = call_data['line_index']
            lhs_name = call_data['lhs']
            if line_index < 0 or line_index >= len(source_lines):
                continue

            prefix_lines = self._stabilize_prometheus_probe_lines(
                source_lines[:line_index + 1]
            )
            probe_script = probe_prelude
            probe_script += '\n'.join(prefix_lines)
            probe_script += (
                f"\nif type({lhs_name}) == 'string' then io.write({lhs_name}) end\n"
            )

            try:
                process_result = subprocess.run(
                    [lua_path, '-'],
                    input=probe_script,
                    capture_output=True,
                    text=True,
                    timeout=2
                )
            except Exception:
                continue

            if process_result.returncode != 0:
                continue
            decoded_text = (process_result.stdout or '').replace('\r\n', '\n').rstrip('\n')
            if not decoded_text:
                continue
            decoded_map[line_index] = decoded_text

        return decoded_map

    def _decode_prometheus_inline_calls_via_lua(self, source_lines, decoder_function_names):
        lua_path = os.path.join(os.getcwd(), 'lua.exe')
        if not os.path.isfile(lua_path):
            return {}
        if not decoder_function_names:
            return {}

        probe_prelude = (
            "local __stub\n"
            "do\n"
            "  local mt = {}\n"
            "  __stub = setmetatable({}, mt)\n"
            "  mt.__index = function() return __stub end\n"
            "  mt.__newindex = function() end\n"
            "  mt.__call = function() return __stub end\n"
            "  mt.__len = function() return 0 end\n"
            "  mt.__add = function() return 0 end\n"
            "  mt.__sub = function() return 0 end\n"
            "  mt.__mul = function() return 0 end\n"
            "  mt.__div = function() return 0 end\n"
            "  mt.__mod = function() return 0 end\n"
            "  mt.__pow = function() return 0 end\n"
            "  mt.__unm = function() return 0 end\n"
            "  mt.__concat = function(a, b) return tostring(a or '') .. tostring(b or '') end\n"
            "  mt.__eq = function() return false end\n"
            "  mt.__lt = function() return false end\n"
            "  mt.__le = function() return false end\n"
            "  mt.__tostring = function() return '' end\n"
            "end\n"
            "setmetatable(_G, {\n"
            "  __index = function(t, k)\n"
            "    local v = rawget(t, k)\n"
            "    if v ~= nil then return v end\n"
            "    return __stub\n"
            "  end\n"
            "})\n"
            "env = _G\n"
            "print = function(...) end\n"
            "warn = function(...) end\n"
            "if type(game) ~= 'table' then game = __stub end\n"
            "if type(Instance) ~= 'table' then Instance = { new = function(...) return __stub end } end\n"
            "task = task or { wait = function(...) return 0 end, spawn = function(...) return __stub end }\n"
            "do\n"
            "  local __orig_random = math.random\n"
            "  math.random = function(a, b)\n"
            "    if a == nil then\n"
            "      local ok, r = pcall(__orig_random)\n"
            "      if ok then return r end\n"
            "      return 0\n"
            "    end\n"
            "    if b == nil then return 1 end\n"
            "    if type(a) ~= 'number' or type(b) ~= 'number' then return 1 end\n"
            "    if a > b then return a end\n"
            "    local ok, r = pcall(__orig_random, a, b)\n"
            "    if ok then return r end\n"
            "    return a\n"
            "  end\n"
            "end\n"
        )

        fn_alt = '|'.join(sorted({re.escape(name) for name in decoder_function_names if name}))
        if not fn_alt:
            return {}
        inline_call_pattern = re.compile(
            rf'\b(?:{fn_alt})\(\s*("(?:(?:\\.)|[^"\\])*"|\'(?:(?:\\.)|[^\'\\])*\')\s*,\s*([A-Za-z_][A-Za-z0-9_]*|\d+)\s*\)'
        )

        replacements = {}
        attempt_count = 0
        max_attempts = 120

        for line_index, line_text in enumerate(source_lines):
            if attempt_count >= max_attempts:
                break
            matches = list(inline_call_pattern.finditer(line_text))
            if not matches:
                continue

            for match_object in matches:
                if attempt_count >= max_attempts:
                    break
                attempt_count += 1
                expr_text = match_object.group(0)
                prefix_lines = self._stabilize_prometheus_probe_lines(
                    source_lines[:line_index]
                )
                probe_script = probe_prelude
                probe_script += '\n'.join(prefix_lines)
                probe_script += (
                    f"\nlocal __decoded = {expr_text}\n"
                    "if type(__decoded) == 'string' then io.write(__decoded) end\n"
                )

                try:
                    process_result = subprocess.run(
                        [lua_path, '-'],
                        input=probe_script,
                        capture_output=True,
                        text=True,
                        timeout=2
                    )
                except Exception:
                    continue

                if process_result.returncode != 0:
                    continue
                decoded_text = (process_result.stdout or '').replace('\r\n', '\n').rstrip('\n')
                if not decoded_text:
                    continue
                replacements[(line_index, match_object.start(), match_object.end())] = decoded_text

        return replacements

    def _collect_prometheus_decoder_seed_map_via_lua(self, script_content):
        lua_path = os.path.join(os.getcwd(), 'lua.exe')
        if not os.path.isfile(lua_path):
            return {}

        lines = script_content.splitlines()
        fn_name = None
        fn_start = None
        fn_end = None
        fn_assign_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*function\([^)]*\)\s*$'
        )
        for idx, line_text in enumerate(lines):
            m = fn_assign_pattern.match(line_text.strip())
            if not m:
                continue
            end_idx = self._find_matching_block_end_line(lines, idx)
            if end_idx == -1:
                continue
            fn_text = '\n'.join(lines[idx:end_idx + 1])
            if self._classify_prometheus_decoder_function_text(fn_text) != 'decode':
                continue
            fn_name = m.group(1)
            fn_start = idx
            fn_end = end_idx
            break
        if fn_name is None or fn_end is None:
            return {}

        # Execute only prefix up to before app/runtime business functions.
        exec_end = len(lines) - 1
        for idx in range(fn_end + 1, len(lines)):
            stripped = lines[idx].strip()
            if re.match(r'^\s*(?:local\s+)?[A-Za-z_][A-Za-z0-9_]*\s*=\s*function\(', stripped):
                exec_end = idx - 1
                break
        exec_lines = lines[:max(fn_end + 1, exec_end + 1)]

        probe_prelude = (
            "local __stub\n"
            "do\n"
            "  local mt = {}\n"
            "  __stub = setmetatable({}, mt)\n"
            "  mt.__index = function() return __stub end\n"
            "  mt.__newindex = function() end\n"
            "  mt.__call = function() return __stub end\n"
            "  mt.__len = function() return 0 end\n"
            "  mt.__add = function() return 0 end\n"
            "  mt.__sub = function() return 0 end\n"
            "  mt.__mul = function() return 0 end\n"
            "  mt.__div = function() return 0 end\n"
            "  mt.__mod = function() return 0 end\n"
            "  mt.__pow = function() return 0 end\n"
            "  mt.__unm = function() return 0 end\n"
            "  mt.__concat = function(a, b) return tostring(a or '') .. tostring(b or '') end\n"
            "  mt.__eq = function() return false end\n"
            "  mt.__lt = function() return false end\n"
            "  mt.__le = function() return false end\n"
            "  mt.__tostring = function() return '' end\n"
            "end\n"
            "setmetatable(_G, {\n"
            "  __index = function(t, k)\n"
            "    local v = rawget(t, k)\n"
            "    if v ~= nil then return v end\n"
            "    return __stub\n"
            "  end\n"
            "})\n"
            "env = _G\n"
            "print = function(...) end\n"
            "warn = function(...) end\n"
            "if type(game) ~= 'table' then game = __stub end\n"
            "if type(Instance) ~= 'table' then Instance = { new = function(...) return __stub end } end\n"
            "task = task or { wait = function(...) return 0 end, spawn = function(...) return __stub end }\n"
            "do\n"
            "  local __orig_random = math.random\n"
            "  math.random = function(a, b)\n"
            "    if a == nil then\n"
            "      local ok, r = pcall(__orig_random)\n"
            "      if ok then return r end\n"
            "      return 0\n"
            "    end\n"
            "    if b == nil then return 1 end\n"
            "    if type(a) ~= 'number' or type(b) ~= 'number' then return 1 end\n"
            "    if a > b then return a end\n"
            "    local ok, r = pcall(__orig_random, a, b)\n"
            "    if ok then return r end\n"
            "    return a\n"
            "  end\n"
            "end\n"
        )

        instrument_lines = [
            f"local __orig_{fn_name} = {fn_name}",
            f"{fn_name} = function(a,b,...)",
            f"  local r = __orig_{fn_name}(a,b,...)",
            "  if type(b) == 'number' and type(r) == 'string' then",
            "    local safe = r:gsub('\\\\', '\\\\\\\\'):gsub('\\n', '\\\\n'):gsub('\\r', '\\\\r')",
            "    io.write('__DEC__' .. tostring(b) .. '::' .. safe .. '\\n')",
            "  end",
            "  return r",
            "end",
        ]

        pre_lines = exec_lines[:fn_end + 1]
        post_lines = exec_lines[fn_end + 1:]
        pre_lines = self._stabilize_prometheus_probe_lines(pre_lines)
        post_lines = self._stabilize_prometheus_probe_lines(post_lines)
        # Trigger decode calls explicitly when they are visible in prefix.
        call_pattern = re.compile(
            rf'\b{re.escape(fn_name)}\(\s*("(?:(?:\\.)|[^"\\])*"|\'(?:(?:\\.)|[^\'\\])*\')\s*,\s*(\d+)\s*\)'
        )
        calls = call_pattern.findall('\n'.join(exec_lines))
        explicit_call_lines = []
        seen = set()
        for literal_text, seed_text in calls[:200]:
            key = (literal_text, seed_text)
            if key in seen:
                continue
            seen.add(key)
            explicit_call_lines.append(
                f"pcall(function() {fn_name}({literal_text}, {seed_text}) end)"
            )

        wrapper_call_pattern = re.compile(
            r'\b([A-Za-z_][A-Za-z0-9_]*)\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*,\s*([+-]?\d{6,})\s*\)'
        )
        wrapper_seen = set()
        direct_decode_seen = set()
        for line_index, line_text in enumerate(exec_lines):
            for m in wrapper_call_pattern.finditer(line_text):
                call_name, arg1_name, seed_text = m.groups()
                key = (call_name, arg1_name, seed_text)
                if key in wrapper_seen:
                    continue
                wrapper_seen.add(key)
                explicit_call_lines.append(
                    f"pcall(function() {call_name}({arg1_name}, {seed_text}) end)"
                )
                resolved_arg1 = self._resolve_recent_prometheus_value(
                    exec_lines,
                    line_index,
                    arg1_name
                )
                if resolved_arg1 and resolved_arg1[0] == 'str':
                    direct_key = (resolved_arg1[1], seed_text)
                    if direct_key not in direct_decode_seen:
                        direct_decode_seen.add(direct_key)
                        explicit_call_lines.append(
                            f"pcall(function() {fn_name}({resolved_arg1[1]}, {seed_text}) end)"
                        )
                if len(wrapper_seen) >= 220:
                    break
            if len(wrapper_seen) >= 220:
                break

        injected_lines = []
        process_result = None
        last_stderr_text = ''
        for _attempt in range(8):
            probe_script = (
                probe_prelude
                + '\n'.join(injected_lines)
                + ('\n' if injected_lines else '')
                + '\n'.join(pre_lines)
                + '\n'
                + '\n'.join(instrument_lines)
                + '\n'
                + '\n'.join(injected_lines)
                + ('\n' if injected_lines else '')
                + '\n'.join(post_lines)
                + '\n'
                + '\n'.join(explicit_call_lines)
                + '\n'
            )
            if os.environ.get('DEOBF_DEBUG_DECODER_COLLECT') == '1':
                try:
                    with open('tmp_decoder_collect_probe.lua', 'w', encoding='utf-8') as debug_handle:
                        debug_handle.write(probe_script)
                except Exception:
                    pass
            try:
                process_result = subprocess.run(
                    [lua_path, '-'],
                    input=probe_script,
                    capture_output=True,
                    text=True,
                    timeout=3
                )
            except Exception:
                process_result = None
                break
            if process_result.returncode == 0:
                break
            stderr_text = process_result.stderr or ''
            last_stderr_text = stderr_text
            fixed = False

            index_nil_match = re.search(
                r"attempt to index a nil value \((?:local|global) '([A-Za-z_][A-Za-z0-9_]*)'\)",
                stderr_text
            )
            if index_nil_match:
                name_text = index_nil_match.group(1)
                injected_lines.append(f"{name_text} = {name_text} or {{}}")
                fixed = True

            if not fixed:
                len_nil_match = re.search(
                    r"attempt to get length of a nil value \((?:local|global) '([A-Za-z_][A-Za-z0-9_]*)'\)",
                    stderr_text
                )
                if len_nil_match:
                    name_text = len_nil_match.group(1)
                    injected_lines.append(f"{name_text} = {name_text} or {{}}")
                    fixed = True

            if not fixed:
                call_nil_match = re.search(
                    r"attempt to call a nil value \((?:local|global) '([A-Za-z_][A-Za-z0-9_]*)'\)",
                    stderr_text
                )
                if call_nil_match:
                    name_text = call_nil_match.group(1)
                    injected_lines.append(f"{name_text} = {name_text} or function(...) return __stub end")
                    fixed = True

            if not fixed:
                index_non_table_match = re.search(
                    r"attempt to index a (?:function|number|string|boolean) value \((?:local|global) '([A-Za-z_][A-Za-z0-9_]*)'\)",
                    stderr_text
                )
                if index_non_table_match:
                    name_text = index_non_table_match.group(1)
                    injected_lines.append(f"{name_text} = __stub")
                    fixed = True

            if not fixed:
                bad_arg_match = re.search(
                    r"bad argument #\d+ to '([A-Za-z_][A-Za-z0-9_]*)'",
                    stderr_text
                )
                if bad_arg_match:
                    name_text = bad_arg_match.group(1)
                    injected_lines.append(
                        f"do local __orig = {name_text}; "
                        f"{name_text} = function(...) "
                        f"local ok, r = pcall(__orig, ...); "
                        f"if ok then return r end; return 0 end end"
                    )
                    fixed = True

            if not fixed:
                break

        if process_result is None:
            return {}

        output_text = (process_result.stdout or '')
        seed_map = {}
        for line_text in output_text.splitlines():
            if not line_text.startswith('__DEC__'):
                continue
            payload = line_text[len('__DEC__'):]
            if '::' not in payload:
                continue
            seed_text, decoded_text = payload.split('::', 1)
            if not re.fullmatch(r'[+-]?\d+', seed_text.strip()):
                continue
            seed_value = int(seed_text.strip())
            decoded_value = decoded_text.replace('\\n', '\n').replace('\\r', '\r').replace('\\\\', '\\')
            if seed_value not in seed_map:
                seed_map[seed_value] = decoded_value
            elif seed_map[seed_value] != decoded_value:
                # ambiguous key; drop it
                seed_map.pop(seed_value, None)

        if (
            not seed_map
            and os.environ.get('DEOBF_DEBUG_DECODER_COLLECT') == '1'
        ):
            try:
                print(
                    f"[decoder_collect_debug] fn={fn_name} rc="
                    f"{getattr(process_result, 'returncode', None)}"
                )
                if last_stderr_text:
                    print(last_stderr_text[:800])
            except Exception:
                pass

        return seed_map

    def _simplify_prometheus_dynamic_env_accesses(self, script_content):
        source_lines = script_content.splitlines()
        rewritten_lines = []
        literal_aliases = {}
        assignment_pattern = re.compile(r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*$')
        literal_pattern = re.compile(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'')

        for line_text in source_lines:
            assignment_match = assignment_pattern.match(line_text)

            rewritten_line = line_text
            for alias_name, alias_literal in sorted(literal_aliases.items(), key=lambda item: -len(item[0])):
                rewritten_line = re.sub(
                    rf'\benv\s*\[\s*{re.escape(alias_name)}\s*\]',
                    lambda _match: f'env[{alias_literal}]',
                    rewritten_line
                )

            rewritten_lines.append(rewritten_line)

            if not assignment_match:
                continue
            assigned_name = assignment_match.group(1)
            rhs_text = assignment_match.group(2).strip()
            if literal_pattern.fullmatch(rhs_text):
                literal_aliases[assigned_name] = rhs_text
            else:
                literal_aliases.pop(assigned_name, None)

        rewritten_text = '\n'.join(rewritten_lines)
        rewritten_text = self._replace_prometheus_global_refs(
            rewritten_text,
            ['env']
        )
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _collapse_prometheus_unresolved_env_dispatch_calls(self, script_content):
        lines = script_content.splitlines()
        fn_assign_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*function\([^)]*\)\s*$'
        )
        alias_assign_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\s*$'
        )
        env_dispatch_assign_pattern = re.compile(
            r'^(\s*)(local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*env\s*\[\s*([A-Za-z_][A-Za-z0-9_]*)\s*\]\s*\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*\)\s*$'
        )
        env_dispatch_stmt_pattern = re.compile(
            r'^(\s*)env\s*\[\s*([A-Za-z_][A-Za-z0-9_]*)\s*\]\s*\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*\)\s*$'
        )

        function_like_names = set()
        for _ in range(5):
            changed = False
            for line_text in lines:
                stripped_line = line_text.strip()
                fn_match = fn_assign_pattern.match(stripped_line)
                if fn_match:
                    if fn_match.group(1) not in function_like_names:
                        function_like_names.add(fn_match.group(1))
                        changed = True
                    continue
                alias_match = alias_assign_pattern.match(stripped_line)
                if not alias_match:
                    continue
                lhs_name, rhs_name = alias_match.groups()
                if rhs_name in function_like_names and lhs_name not in function_like_names:
                    function_like_names.add(lhs_name)
                    changed = True
            if not changed:
                break

        rewritten_lines = []
        for line_text in lines:
            assign_match = env_dispatch_assign_pattern.match(line_text)
            if assign_match:
                indent_text = assign_match.group(1)
                local_kw = assign_match.group(2) or ''
                lhs_name = assign_match.group(3)
                dispatch_name = assign_match.group(4)
                arg_name = assign_match.group(5)
                if dispatch_name in function_like_names:
                    rewritten_lines.append(
                        f"{indent_text}{local_kw}{lhs_name} = {arg_name}"
                    )
                    continue

            stmt_match = env_dispatch_stmt_pattern.match(line_text)
            if stmt_match:
                indent_text = stmt_match.group(1)
                dispatch_name = stmt_match.group(2)
                arg_name = stmt_match.group(3)
                if dispatch_name in function_like_names:
                    rewritten_lines.append(f"{indent_text}{arg_name}")
                    continue

            rewritten_lines.append(line_text)

        rewritten_text = '\n'.join(rewritten_lines)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _simplify_prometheus_print_alias_calls(self, script_content):
        source_lines = script_content.splitlines()
        rewritten_lines = []
        literal_aliases = {}
        print_aliases = set()
        assignment_pattern = re.compile(r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*$')
        literal_pattern = re.compile(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'')
        call_pattern = re.compile(
            r'^(\s*)(?:(?P<lhs>[A-Za-z_][A-Za-z0-9_]*)\s*=\s*)?(?P<fn>[A-Za-z_][A-Za-z0-9_]*)\(\s*(?P<arg>.*?)\s*\)\s*$'
        )

        for line_text in source_lines:
            stripped_text = line_text.strip()
            indent_text_raw = line_text[:len(line_text) - len(line_text.lstrip(' \t'))]
            is_top_level = len(indent_text_raw) == 0

            call_match = call_pattern.match(line_text)
            if call_match and is_top_level:
                indent_text = call_match.group(1)
                lhs_name = call_match.group('lhs')
                func_name = call_match.group('fn')
                arg_text = call_match.group('arg').strip()
                if func_name in print_aliases:
                    if arg_text in literal_aliases:
                        arg_text = literal_aliases[arg_text]
                    if lhs_name:
                        rewritten_lines.append(f"{indent_text}{lhs_name} = print({arg_text})")
                    else:
                        rewritten_lines.append(f"{indent_text}print({arg_text})")
                    continue

            assignment_match = assignment_pattern.match(line_text)
            if assignment_match and is_top_level:
                lhs_name = assignment_match.group(1)
                rhs_text = assignment_match.group(2).strip()
                literal_aliases.pop(lhs_name, None)
                print_aliases.discard(lhs_name)

                if literal_pattern.fullmatch(rhs_text):
                    literal_aliases[lhs_name] = rhs_text
                elif rhs_text == 'print':
                    print_aliases.add(lhs_name)

            rewritten_lines.append(line_text)

        rewritten_text = '\n'.join(rewritten_lines)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _fix_prometheus_decoder_return_values(self, script_content):
        source_lines = script_content.splitlines()
        return_pattern = re.compile(r'^(\s*)return\s+([A-Za-z_][A-Za-z0-9_]*)\s*$')
        cache_write_pattern = re.compile(r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*\[\s*([A-Za-z_][A-Za-z0-9_]*)\s*\]\s*=')
        block_boundary_pattern = re.compile(r'^\s*(?:function\b|local\s+function\b|[A-Za-z_][A-Za-z0-9_]*\s*=\s*function\b)\b')

        for line_index, line_text in enumerate(source_lines):
            return_match = return_pattern.match(line_text)
            if not return_match:
                continue
            indent_text, return_name = return_match.groups()
            candidate_table = None
            scan_start = max(0, line_index - 240)
            for back_index in range(line_index - 1, scan_start - 1, -1):
                candidate_line = source_lines[back_index]
                if block_boundary_pattern.search(candidate_line):
                    break
                write_match = cache_write_pattern.match(candidate_line)
                if write_match and write_match.group(2) == return_name:
                    candidate_table = write_match.group(1)
                    break

            if not candidate_table:
                continue

            source_lines[line_index] = f"{indent_text}return {candidate_table}[{return_name}]"

        rewritten_text = '\n'.join(source_lines)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _ensure_prometheus_decoder_cache_returns(self, script_content):
        lines = script_content.splitlines()
        fn_assign_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*function\(([^)]*)\)\s*$'
        )
        if_guard_pattern = re.compile(
            r'^\s*if\s+not\s*\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*\[\s*([A-Za-z_][A-Za-z0-9_]*)\s*\]\s*\)\s+then\s*$'
        )
        cache_write_pattern = re.compile(
            r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*\[\s*([A-Za-z_][A-Za-z0-9_]*)\s*\]\s*='
        )
        bare_return_pattern = re.compile(r'^(\s*)return\s*$')
        return_cache_pattern = re.compile(
            r'^\s*return\s+([A-Za-z_][A-Za-z0-9_]*)\s*\[\s*([A-Za-z_][A-Za-z0-9_]*)\s*\]\s*$'
        )

        rewritten = list(lines)
        index = 0
        while index < len(rewritten):
            fn_match = fn_assign_pattern.match(rewritten[index].strip())
            if not fn_match:
                index += 1
                continue

            end_index = self._find_matching_block_end_line(rewritten, index)
            if end_index == -1:
                index += 1
                continue

            fn_lines = rewritten[index:end_index + 1]
            fn_text = '\n'.join(fn_lines)
            if 'string.byte' not in fn_text:
                index = end_index + 1
                continue
            if '35184372088832' not in fn_text and 'next_prng_byte' not in fn_text:
                index = end_index + 1
                continue

            cache_name = None
            key_name = None
            for line_text in fn_lines:
                guard_match = if_guard_pattern.match(line_text.strip())
                if guard_match:
                    cache_name, key_name = guard_match.groups()
                    break
            if not cache_name or not key_name:
                index = end_index + 1
                continue

            has_cache_write = False
            for line_text in fn_lines:
                write_match = cache_write_pattern.match(line_text.strip())
                if not write_match:
                    continue
                if write_match.group(1) == cache_name and write_match.group(2) == key_name:
                    has_cache_write = True
                    break
            if not has_cache_write:
                index = end_index + 1
                continue

            return_line = end_index - 1
            while return_line > index and not rewritten[return_line].strip():
                return_line -= 1
            if return_line <= index:
                index = end_index + 1
                continue

            if return_cache_pattern.match(rewritten[return_line].strip()):
                index = end_index + 1
                continue

            bare_match = bare_return_pattern.match(rewritten[return_line].strip())
            if not bare_match:
                index = end_index + 1
                continue

            indent_text = rewritten[return_line][:len(rewritten[return_line]) - len(rewritten[return_line].lstrip(' \t'))]
            rewritten[return_line] = f"{indent_text}return {cache_name}[{key_name}]"
            index = end_index + 1

        rewritten_text = '\n'.join(rewritten)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _drop_unused_call_assignment_targets(self, script_content):
        source_lines = script_content.splitlines()
        assign_call_pattern = re.compile(
            r'^(\s*)([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\((.*)\)\s*$'
        )
        identifier_pattern = re.compile(r'\b([A-Za-z_][A-Za-z0-9_]*)\b')
        reserved_names = {'if', 'then', 'end', 'while', 'do', 'repeat', 'until', 'for', 'in', 'local', 'function', 'return', 'and', 'or', 'not', 'nil', 'true', 'false'}

        rewritten_lines = list(source_lines)
        for index, line_text in enumerate(source_lines):
            match_object = assign_call_pattern.match(line_text)
            if not match_object:
                continue
            indent_text, lhs_name, fn_name, arg_text = match_object.groups()
            if fn_name == lhs_name:
                continue
            # Keep transformation conservative: only simplify direct print-call assignments.
            if fn_name != 'print':
                continue

            used_later = False
            for next_line in source_lines[index + 1:]:
                for token in identifier_pattern.findall(next_line):
                    if token in reserved_names:
                        continue
                    if token == lhs_name:
                        used_later = True
                        break
                if used_later:
                    break
            if used_later:
                continue

            rewritten_lines[index] = f"{indent_text}{fn_name}({arg_text.strip()})"

        rewritten_text = '\n'.join(rewritten_lines)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _recover_single_print_literal_via_runtime(self, cleanup_content, original_script_content):
        if not original_script_content:
            return cleanup_content
        cleanup_lines = cleanup_content.splitlines()
        # Runtime fallback is only safe for small single-purpose scripts.
        if len(cleanup_lines) > 450:
            return cleanup_content
        if re.search(r'\bwhile\s+pc\b', cleanup_content):
            return cleanup_content

        print_call_matches = re.findall(
            r'^\s*print\((.*?)\)\s*$',
            cleanup_content,
            re.MULTILINE
        )
        has_single_print_call = len(print_call_matches) == 1
        if has_single_print_call:
            print_arg = print_call_matches[0].strip()
            if re.fullmatch(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'', print_arg):
                return cleanup_content

        lua_path = os.path.join(os.getcwd(), 'lua.exe')
        if not os.path.isfile(lua_path):
            return cleanup_content

        try:
            run_result = subprocess.run(
                [lua_path, '-'],
                input=original_script_content,
                capture_output=True,
                text=True,
                timeout=3
            )
        except Exception:
            return cleanup_content

        if run_result.returncode != 0:
            return cleanup_content
        runtime_output = (run_result.stdout or '').replace('\r\n', '\n').strip('\n')
        if not runtime_output:
            return cleanup_content
        output_lines = runtime_output.split('\n')
        if len(output_lines) != 1:
            return cleanup_content

        recovered_line = self._format_lua_string(output_lines[0])
        if has_single_print_call:
            return re.sub(
                r'^\s*print\((.*?)\)\s*$',
                f'print({recovered_line})',
                cleanup_content,
                count=1,
                flags=re.MULTILINE
            )

        if re.search(r'^\s*print\(', cleanup_content, re.MULTILINE):
            return cleanup_content

        tail_lines = cleanup_lines[-45:]
        tail_text = '\n'.join(tail_lines)
        one_arg_call_lines = re.findall(
            r'^\s*(?:[A-Za-z_][A-Za-z0-9_]*\s*=\s*)?[A-Za-z_][A-Za-z0-9_]*\(\s*[A-Za-z_][A-Za-z0-9_]*\s*\)\s*$',
            tail_text,
            re.MULTILINE
        )
        if len(one_arg_call_lines) != 1:
            lines = cleanup_content.splitlines()
            if lines and lines[-1].strip() == 'return':
                lines.insert(len(lines) - 1, f'print({recovered_line})')
                return '\n'.join(lines) + ('\n' if cleanup_content.endswith('\n') else '')
            return cleanup_content
        call_line = one_arg_call_lines[0]
        replaced_tail = tail_text.replace(call_line, f'print({recovered_line})', 1)
        if replaced_tail == tail_text:
            return cleanup_content
        if len(tail_lines) == 0:
            return cleanup_content
        head_text = '\n'.join(cleanup_lines[:-45])
        if head_text:
            return head_text + '\n' + replaced_tail + ('\n' if cleanup_content.endswith('\n') else '')
        return replaced_tail + ('\n' if cleanup_content.endswith('\n') else '')

    def _remove_redundant_prometheus_pc_assignments(self, script_content):
        lines = script_content.splitlines()
        assign_pattern = re.compile(r'^\s*pc\s*=')
        local_decl_pattern = re.compile(r'^\s*local\s+(.+)$')
        token_pattern = re.compile(r'\bpc\b')

        has_runtime_pc_read = False
        for line in lines:
            stripped = line.strip()
            if not stripped:
                continue
            if assign_pattern.match(line):
                continue
            local_match = local_decl_pattern.match(line)
            if local_match:
                decl_parts = [p.strip() for p in local_match.group(1).split(',')]
                if all(part == 'pc' or part.startswith('pc=') or '=' in part for part in decl_parts):
                    continue
                if 'pc' in decl_parts:
                    decl_parts = [p for p in decl_parts if p != 'pc']
                    if not token_pattern.search(','.join(decl_parts)):
                        continue
            if token_pattern.search(stripped):
                has_runtime_pc_read = True
                break
        if has_runtime_pc_read:
            return script_content

        rewritten = []
        local_decl_pattern = re.compile(r'^(\s*)local\s+(.+)$')

        for line in lines:
            if assign_pattern.match(line):
                continue
            local_match = local_decl_pattern.match(line)
            if not local_match:
                rewritten.append(line)
                continue
            indent, decl_text = local_match.groups()
            parts = [p.strip() for p in decl_text.split(',')]
            if 'pc' not in parts:
                rewritten.append(line)
                continue
            kept = [p for p in parts if p != 'pc']
            if not kept:
                continue
            rewritten.append(f"{indent}local {','.join(kept)}")

        rewritten_text = '\n'.join(rewritten)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _remove_redundant_nil_reassignments(self, script_content):
        lines = script_content.splitlines()
        assign_pattern = re.compile(r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*$')
        token_pattern = re.compile(r'\b([A-Za-z_][A-Za-z0-9_]*)\b')
        reserved = {'if', 'then', 'end', 'while', 'do', 'repeat', 'until', 'for', 'in', 'local', 'function', 'return', 'and', 'or', 'not', 'nil', 'true', 'false'}

        remove_indexes = set()
        for idx, line in enumerate(lines):
            m = assign_pattern.match(line)
            if not m:
                continue
            var_name, rhs = m.groups()
            if rhs.strip() != 'nil':
                continue
            scan = idx + 1
            can_remove = False
            while scan < len(lines):
                stripped = lines[scan].strip()
                if not stripped:
                    scan += 1
                    continue
                m2 = assign_pattern.match(lines[scan])
                if m2 and m2.group(1) == var_name:
                    can_remove = True
                    break
                used = False
                for tok in token_pattern.findall(lines[scan]):
                    if tok in reserved:
                        continue
                    if tok == var_name:
                        used = True
                        break
                if used:
                    can_remove = False
                    break
                scan += 1
            if can_remove:
                remove_indexes.add(idx)

        rewritten = [line for i, line in enumerate(lines) if i not in remove_indexes]
        rewritten_text = '\n'.join(rewritten)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _remove_overwritten_literal_assignments(self, script_content):
        lines = script_content.splitlines()
        assignment_pattern = re.compile(r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*$')
        literal_pattern = re.compile(r'^(?:-?\d+(?:\.\d+)?|true|false|nil|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\')$')
        token_pattern = re.compile(r'\b([A-Za-z_][A-Za-z0-9_]*)\b')
        reserved = {'if', 'then', 'end', 'while', 'do', 'repeat', 'until', 'for', 'in', 'local', 'function', 'return', 'and', 'or', 'not', 'nil', 'true', 'false'}

        remove_indexes = set()
        for idx, line in enumerate(lines):
            m = assignment_pattern.match(line)
            if not m:
                continue
            var_name, rhs_text = m.groups()
            rhs_text = rhs_text.strip()
            if not literal_pattern.fullmatch(rhs_text):
                continue

            scan = idx + 1
            can_remove = False
            while scan < len(lines):
                scan_line = lines[scan]

                m2 = assignment_pattern.match(scan_line)
                if m2 and m2.group(1) == var_name:
                    can_remove = True
                    break

                used = False
                for tok in token_pattern.findall(scan_line):
                    if tok in reserved:
                        continue
                    if tok == var_name:
                        used = True
                        break
                if used:
                    can_remove = False
                    break
                scan += 1

            if can_remove:
                remove_indexes.add(idx)

        rewritten = [line for i, line in enumerate(lines) if i not in remove_indexes]
        rewritten_text = '\n'.join(rewritten)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _inline_literal_assignments_before_return(self, script_content):
        lines = script_content.splitlines()
        assignment_pattern = re.compile(
            r'^(\s*)([A-Za-z_][A-Za-z0-9_]*)\s*=\s*("(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\')\s*$'
        )
        return_pattern = re.compile(
            r'^(\s*)return\s+([A-Za-z_][A-Za-z0-9_]*)\s*$'
        )

        output = []
        index = 0
        changed = False
        while index < len(lines):
            if index + 1 < len(lines):
                assign_match = assignment_pattern.match(lines[index])
                return_match = return_pattern.match(lines[index + 1])
                if assign_match and return_match:
                    assign_indent, var_name, literal_text = assign_match.groups()
                    return_indent, return_name = return_match.groups()
                    if assign_indent == return_indent and var_name == return_name:
                        output.append(f"{return_indent}return {literal_text}")
                        index += 2
                        changed = True
                        continue
            output.append(lines[index])
            index += 1

        if not changed:
            return script_content
        rewritten_text = '\n'.join(output)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _recover_prometheus_decoder_cache_return_literals(self, script_content):
        decoder_constants = (
            getattr(self, '_pipeline_prng_decoder_constants', None)
            or self._extract_prometheus_runtime_decoder_constants(script_content)
        )
        if not decoder_constants:
            return script_content

        key8_value = getattr(self, '_pipeline_prng_key8_value', None)
        if key8_value is None:
            decoder_name_match = re.search(r'\bdecode_runtime_string(?:_\d+)?\b', script_content)
            if decoder_name_match:
                key8_value = self._extract_prometheus_runtime_key8_constant(
                    script_content,
                    decoder_name_match.group(0)
                )
        if key8_value is None:
            source_lines_for_key = script_content.splitlines()
            fn_pattern_for_key = re.compile(
                r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*function\([^)]*\)\s*$'
            )
            for key_index, key_line in enumerate(source_lines_for_key):
                key_match = fn_pattern_for_key.match(key_line.strip())
                if not key_match:
                    continue
                key_end = self._find_matching_block_end_line(source_lines_for_key, key_index)
                if key_end == -1:
                    continue
                key_block = '\n'.join(source_lines_for_key[key_index:key_end + 1])
                if self._classify_prometheus_decoder_function_text(key_block) != 'decode':
                    continue
                key8_value = self._extract_prometheus_runtime_key8_constant(
                    script_content,
                    key_match.group(1),
                    key_index
                )
                if key8_value is not None:
                    break
        if key8_value is None:
            split_key_match = re.search(
                r'=\s*""\s*\n\s*'
                r'(?:[A-Za-z_][A-Za-z0-9_]*\s*=\s*[^"\n]+\n\s*){0,3}'
                r'[A-Za-z_][A-Za-z0-9_]*\s*\[\s*[A-Za-z_][A-Za-z0-9_]*\s*\]\s*=\s*[A-Za-z_][A-Za-z0-9_]*\s*\n\s*'
                r'[A-Za-z_][A-Za-z0-9_]*\s*=\s*(\d{1,3})\s*\n',
                script_content
            )
            if split_key_match:
                key8_value = int(split_key_match.group(1))
        if key8_value is None:
            return script_content

        lines = script_content.splitlines()
        string_literal = r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\''
        assign_pattern = re.compile(r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*;?\s*$')
        call_assign_pattern = re.compile(
            rf'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*'
            rf'([A-Za-z_][A-Za-z0-9_]*)\s*\(\s*([^,]+)\s*,\s*([^)]+)\s*\)\s*;?\s*$'
        )
        cache_read_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*'
            r'[A-Za-z_][A-Za-z0-9_]*\s*\[\s*([A-Za-z_][A-Za-z0-9_]*)\s*\]\s*;?\s*$'
        )
        return_pattern = re.compile(r'^(\s*)return\s+([A-Za-z_][A-Za-z0-9_]*)\s*;?\s*$')

        known_literal = {}
        known_number = {}
        decoded_by_var = {}
        decoded_line_by_var = {}
        assigned_line_by_var = {}
        assigned_rhs_by_var = {}
        recent_decoded_by_indent = {}
        rewritten = []

        def resolve_literal(token_text):
            token_text = token_text.strip()
            if re.fullmatch(string_literal, token_text):
                return token_text
            return known_literal.get(token_text)

        def resolve_number(token_text):
            token_text = token_text.strip()
            if re.fullmatch(r'\d+', token_text):
                return int(token_text)
            return known_number.get(token_text)

        for line_index, line_text in enumerate(lines):
            indent_text = line_text[:len(line_text) - len(line_text.lstrip(' \t'))]
            indent_size = len(indent_text)
            stripped = line_text.strip()

            if re.search(r'\bfunction\s*\(', stripped):
                decoded_by_var.clear()
                recent_decoded_by_indent.clear()

            return_match = return_pattern.match(line_text)
            if return_match:
                return_name = return_match.group(2)
                recent_nonliteral_assignment = False
                for back_index in range(line_index - 1, max(-1, line_index - 8), -1):
                    back_match = assign_pattern.match(lines[back_index].strip())
                    if not back_match or back_match.group(1) != return_name:
                        continue
                    back_rhs = back_match.group(2).strip()
                    if not re.fullmatch(string_literal, back_rhs):
                        recent_nonliteral_assignment = True
                    break
                decoded_text = decoded_by_var.get(return_name)
                if decoded_text is not None and assigned_line_by_var.get(return_name, -1) > decoded_line_by_var.get(return_name, -1):
                    decoded_text = None
                if (
                    decoded_text is not None
                    and return_name in {'pc', 'ret_reg'}
                    and assigned_line_by_var.get(return_name, -9999) > decoded_line_by_var.get(return_name, -1)
                ):
                    decoded_text = None
                if recent_nonliteral_assignment:
                    decoded_text = None
                if decoded_text is None:
                    decoded_info = recent_decoded_by_indent.get(indent_size)
                    return_name_recently_assigned = (
                        return_name in assigned_line_by_var
                        and line_index - assigned_line_by_var[return_name] <= 20
                    )
                    looks_like_placeholder = (
                        len(return_name) >= 8
                        and bool(re.search(r'[A-Z]', return_name))
                        and bool(re.search(r'[a-z]', return_name))
                    )
                    if (
                        decoded_info
                        and line_index - decoded_info[0] <= 8
                        and not return_name_recently_assigned
                        and looks_like_placeholder
                    ):
                        decoded_text = decoded_info[1]
                if decoded_text is not None:
                    rewritten.append(f"{return_match.group(1)}return {self._format_lua_string(decoded_text)}")
                    continue

            call_match = call_assign_pattern.match(line_text)
            if call_match:
                lhs_name = call_match.group(1)
                literal_text = resolve_literal(call_match.group(3))
                seed_value = resolve_number(call_match.group(4))
                if literal_text is not None and seed_value is not None:
                    decoded_text = self._decode_prometheus_runtime_literal(
                        literal_text,
                        seed_value,
                        key8_value,
                        decoder_constants
                    )
                    if decoded_text is not None and self._score_prometheus_runtime_plaintext(decoded_text) >= -0.35:
                        decoded_by_var[lhs_name] = decoded_text
                        decoded_line_by_var[lhs_name] = line_index
                        recent_decoded_by_indent[indent_size] = (line_index, decoded_text)
                        rewritten.append(f"{indent_text}{lhs_name} = {self._format_lua_string(decoded_text)}")
                        continue

            cache_match = cache_read_pattern.match(line_text)
            if cache_match and cache_match.group(2) in decoded_by_var:
                decoded_text = decoded_by_var[cache_match.group(2)]
                decoded_by_var[cache_match.group(1)] = decoded_text
                decoded_line_by_var[cache_match.group(1)] = line_index
                recent_decoded_by_indent[indent_size] = (line_index, decoded_text)
                rewritten.append(f"{indent_text}{cache_match.group(1)} = {self._format_lua_string(decoded_text)}")
                continue

            assign_match = assign_pattern.match(line_text)
            if assign_match:
                lhs_name, rhs_text = assign_match.groups()
                rhs_text = rhs_text.strip()
                assigned_line_by_var[lhs_name] = line_index
                assigned_rhs_by_var[lhs_name] = rhs_text
                decoded_by_var.pop(lhs_name, None)
                decoded_line_by_var.pop(lhs_name, None)
                known_literal.pop(lhs_name, None)
                known_number.pop(lhs_name, None)
                if re.fullmatch(string_literal, rhs_text):
                    known_literal[lhs_name] = rhs_text
                elif re.fullmatch(r'\d+', rhs_text):
                    known_number[lhs_name] = int(rhs_text)
                elif rhs_text in known_literal:
                    known_literal[lhs_name] = known_literal[rhs_text]
                elif rhs_text in known_number:
                    known_number[lhs_name] = known_number[rhs_text]

            rewritten.append(line_text)

        rewritten_text = '\n'.join(rewritten)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _inline_literal_table_constructor_aliases(self, script_content):
        lines = script_content.splitlines()
        string_literal = r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\''
        assign_pattern = re.compile(r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*;?\s*$')
        identifier_key_pattern = re.compile(r'\[\s*([A-Za-z_][A-Za-z0-9_]*)\s*\]\s*=')
        value_token_pattern = re.compile(r'=\s*([A-Za-z_][A-Za-z0-9_]*)\s*(?=[,}])')
        known_literal = {}
        known_number = {}
        rewritten = []

        def literal_to_key(literal_text):
            try:
                key_text = self._parse_lua_string_literal(literal_text)
            except Exception:
                return None
            if re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', key_text):
                return key_text
            return None

        for line_text in lines:
            rewritten_line = line_text
            if '{' in rewritten_line and '}' in rewritten_line:
                def replace_key(match_object):
                    var_name = match_object.group(1)
                    literal_text = known_literal.get(var_name)
                    if literal_text is None:
                        return match_object.group(0)
                    key_text = literal_to_key(literal_text)
                    if key_text is None:
                        return match_object.group(0)
                    return f'{key_text} ='

                def replace_value(match_object):
                    var_name = match_object.group(1)
                    if var_name in known_literal:
                        return '= ' + known_literal[var_name]
                    if var_name in known_number:
                        return '= ' + str(known_number[var_name])
                    return match_object.group(0)

                rewritten_line = identifier_key_pattern.sub(replace_key, rewritten_line)
                rewritten_line = value_token_pattern.sub(replace_value, rewritten_line)

            rewritten.append(rewritten_line)

            assign_match = assign_pattern.match(rewritten_line.strip())
            if not assign_match:
                continue
            lhs_name, rhs_text = assign_match.groups()
            rhs_text = rhs_text.strip()
            known_literal.pop(lhs_name, None)
            known_number.pop(lhs_name, None)
            if re.fullmatch(string_literal, rhs_text):
                known_literal[lhs_name] = rhs_text
            elif re.fullmatch(r'\d+', rhs_text):
                known_number[lhs_name] = int(rhs_text)
            elif rhs_text in known_literal:
                known_literal[lhs_name] = known_literal[rhs_text]
            elif rhs_text in known_number:
                known_number[lhs_name] = known_number[rhs_text]

        rewritten_text = '\n'.join(rewritten)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _normalize_ipairs_iterator_while_loops(self, script_content):
        lines = script_content.splitlines()
        output = []
        index = 0
        tuple_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*\{\s*ipairs\s*\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*\)\s*\}\s*;?\s*$'
        )
        iter_pattern = re.compile(
            r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\s*\[\s*1\s*\]\s*;?\s*$'
        )
        call_pattern_template = (
            r'^\s*([A-Za-z_][A-Za-z0-9_]*),\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*'
            r'{iter_name}\s*\(\s*([A-Za-z_][A-Za-z0-9_]*),\s*([A-Za-z_][A-Za-z0-9_]*)\s*\)\s*;?\s*$'
        )
        break_if_template = r'^\s*if\s+not\s+{index_name}\s+then\s*;?\s*$'

        while index < len(lines):
            if index + 2 >= len(lines):
                output.append(lines[index])
                index += 1
                continue

            tuple_match = tuple_pattern.match(lines[index])
            iter_match = iter_pattern.match(lines[index + 1])
            if not tuple_match or not iter_match or tuple_match.group(1) != iter_match.group(2):
                output.append(lines[index])
                index += 1
                continue

            tuple_name, table_name = tuple_match.groups()
            iter_name = iter_match.group(1)
            while_index = index + 2
            if lines[while_index].strip() != 'while true do':
                output.append(lines[index])
                index += 1
                continue
            end_index = self._find_matching_block_end_line(lines, while_index)
            if end_index == -1:
                output.append(lines[index])
                index += 1
                continue

            body_lines = lines[while_index + 1:end_index]
            if len(body_lines) < 4:
                output.append(lines[index])
                index += 1
                continue
            call_pattern = re.compile(call_pattern_template.format(iter_name=re.escape(iter_name)))
            call_match = call_pattern.match(body_lines[0].strip())
            if not call_match:
                output.append(lines[index])
                index += 1
                continue
            index_var, value_var = call_match.group(1), call_match.group(2)
            break_if_pattern = re.compile(break_if_template.format(index_name=re.escape(index_var)))
            if not break_if_pattern.match(body_lines[1].strip()):
                output.append(lines[index])
                index += 1
                continue
            if body_lines[2].strip() != 'break' or body_lines[3].strip() != 'end':
                output.append(lines[index])
                index += 1
                continue

            indent_text = lines[index][:len(lines[index]) - len(lines[index].lstrip(' \t'))]
            output.append(f'{indent_text}for {index_var}, {value_var} in ipairs({table_name}) do')
            output.extend(body_lines[4:])
            output.append(f'{indent_text}end')
            index = end_index + 1

        rewritten_text = '\n'.join(output)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _repair_concat_function_literal_returns(self, script_content):
        lines = script_content.splitlines()
        return_literal_pattern = re.compile(
            r'^(\s*)return\s+("(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\')\s*;?\s*$'
        )
        concat_assign_pattern = re.compile(
            r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*.+\.\..+\s*;?\s*$'
        )
        table_wrap_template = r'^\s*[A-Za-z_][A-Za-z0-9_]*\s*=\s*\{{\s*{var_name}\s*\}}\s*;?\s*$'

        rewritten = list(lines)
        for index, line_text in enumerate(lines):
            return_match = return_literal_pattern.match(line_text)
            if not return_match:
                continue
            indent_text = return_match.group(1)
            for back_index in range(index - 1, max(-1, index - 8), -1):
                concat_match = concat_assign_pattern.match(lines[back_index].strip())
                if not concat_match:
                    continue
                result_var = concat_match.group(1)
                wrapped_between = any(
                    re.match(table_wrap_template.format(var_name=re.escape(result_var)), lines[mid].strip())
                    for mid in range(back_index + 1, index)
                )
                if wrapped_between:
                    rewritten[index] = f'{indent_text}return {result_var}'
                    break
        rewritten_text = '\n'.join(rewritten)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _repair_roblox_string_constructor_calls(self, script_content):
        alias_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*("new"|\'new\'|"fromRGB"|\'fromRGB\')\s*;?\s*$'
        )
        aliases = {}
        expanded_lines = []
        for line_text in script_content.splitlines():
            rewritten_line = line_text
            for alias_name, literal_callee in sorted(aliases.items(), key=lambda item: -len(item[0])):
                rewritten_line = re.sub(
                    rf'(?<![\w.:\]])\b{re.escape(alias_name)}\s*\(',
                    f'{literal_callee}(',
                    rewritten_line
                )
            expanded_lines.append(rewritten_line)
            alias_match = alias_pattern.match(line_text.strip())
            if alias_match:
                aliases[alias_match.group(1)] = alias_match.group(2)
                continue
            assign_match = re.match(r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=', line_text.strip())
            if assign_match:
                aliases.pop(assign_match.group(1), None)

        script_content = '\n'.join(expanded_lines) + ('\n' if script_content.endswith('\n') else '')

        string_call_pattern = re.compile(
            r'(?<![\w.:\]])("new"|\'new\'|"fromRGB"|\'fromRGB\')\s*\(([^()]*)\)'
        )

        def split_args(arg_text):
            args = []
            current = []
            quote = None
            escape = False
            depth = 0
            for char_value in arg_text:
                if quote:
                    current.append(char_value)
                    if escape:
                        escape = False
                    elif char_value == '\\':
                        escape = True
                    elif char_value == quote:
                        quote = None
                    continue
                if char_value in {'"', "'"}:
                    quote = char_value
                    current.append(char_value)
                    continue
                if char_value in '({[':
                    depth += 1
                elif char_value in ')}]' and depth > 0:
                    depth -= 1
                if char_value == ',' and depth == 0:
                    args.append(''.join(current).strip())
                    current = []
                else:
                    current.append(char_value)
            if current or arg_text.strip():
                args.append(''.join(current).strip())
            return args

        def replace_call(match_object):
            callee_text = match_object.group(1).strip('"\'')
            arg_text = match_object.group(2)
            args = split_args(arg_text)
            if callee_text == 'fromRGB':
                return f'Color3.fromRGB({arg_text})'
            if callee_text == 'new':
                if args and re.fullmatch(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'', args[0]):
                    return f'Instance.new({arg_text})'
                if len(args) == 4:
                    return f'UDim2.new({arg_text})'
                if len(args) == 2:
                    return f'UDim.new({arg_text})'
            return match_object.group(0)

        return string_call_pattern.sub(replace_call, script_content)

    def _prune_impossible_nil_index_calls(self, script_content):
        current_text = script_content
        assign_nil_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*nil\s*;?\s*$'
        )
        nil_rhs_pattern = re.compile(
            r'^\s*(?:local\s+)?[A-Za-z_][A-Za-z0-9_]*\s*=\s*nil(?:\s*[\[:(].*)\s*;?\s*$'
        )
        nil_index_write_pattern = re.compile(
            r'^\s*nil\s*\[.+\]\s*=.+$'
        )

        for _ in range(3):
            lines = current_text.splitlines()
            remove_indexes = set()
            known_nil = {}

            for index, line_text in enumerate(lines):
                stripped = line_text.strip()
                assign_nil_match = assign_nil_pattern.match(stripped)
                if assign_nil_match:
                    known_nil[assign_nil_match.group(1)] = index
                if nil_rhs_pattern.match(stripped) or nil_index_write_pattern.match(stripped):
                    remove_indexes.add(index)
                    continue

                assign_match = re.match(
                    r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*;?\s*$',
                    stripped
                )
                if assign_match:
                    lhs_name = assign_match.group(1)
                    rhs_text = assign_match.group(2).strip()
                    if lhs_name in known_nil and rhs_text.startswith(lhs_name):
                        remove_indexes.add(index)
                        continue
                    if lhs_name in known_nil and rhs_text != 'nil':
                        known_nil.pop(lhs_name, None)
                    continue

                call_match = re.match(r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*[\[:(].*$', stripped)
                if call_match and call_match.group(1) in known_nil:
                    remove_indexes.add(index)

            if not remove_indexes:
                break
            rewritten = [line for idx, line in enumerate(lines) if idx not in remove_indexes]
            current_text = '\n'.join(rewritten) + ('\n' if current_text.endswith('\n') else '')

        return current_text

    def _prune_nil_value_table_writes(self, script_content):
        lines = script_content.splitlines()
        assign_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*;?\s*$'
        )
        index_write_pattern = re.compile(
            r'^\s*[A-Za-z_][A-Za-z0-9_]*\s*\[.+\]\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\s*;?\s*$'
        )
        known_nil = set()
        remove_indexes = set()

        for index, line_text in enumerate(lines):
            stripped = line_text.strip()
            assign_match = assign_pattern.match(stripped)
            if assign_match:
                lhs_name, rhs_text = assign_match.groups()
                rhs_text = rhs_text.strip()
                if rhs_text == 'nil':
                    known_nil.add(lhs_name)
                else:
                    known_nil.discard(lhs_name)
                continue

            write_match = index_write_pattern.match(stripped)
            if write_match and write_match.group(1) in known_nil:
                remove_indexes.add(index)

        if not remove_indexes:
            return script_content
        rewritten = [line for idx, line in enumerate(lines) if idx not in remove_indexes]
        rewritten_text = '\n'.join(rewritten)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _remove_dangerous_nil_reassignments(self, script_content):
        lines = script_content.splitlines()
        nil_assign_pattern = re.compile(
            r'^(\s*)(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*nil\s*$'
        )
        any_assign_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*='
        )

        remove_indexes = set()
        for index, line_text in enumerate(lines):
            m = nil_assign_pattern.match(line_text.strip())
            if not m:
                continue
            name_text = m.group(2)
            name_token = re.compile(rf'\b{re.escape(name_text)}\b')
            dangerous_use_pattern = re.compile(
                rf'\b{re.escape(name_text)}\s*(?:\[|\.|:|\()|#\s*{re.escape(name_text)}\b'
            )

            for probe in range(index + 1, min(len(lines), index + 120)):
                probe_line = lines[probe].strip()
                if not probe_line:
                    continue
                assign_match = any_assign_pattern.match(probe_line)
                if assign_match and assign_match.group(1) == name_text:
                    break
                if dangerous_use_pattern.search(probe_line):
                    remove_indexes.add(index)
                    break

        if not remove_indexes:
            return script_content
        rewritten = [line for idx, line in enumerate(lines) if idx not in remove_indexes]
        rewritten_text = '\n'.join(rewritten)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _simplify_prometheus_builtin_alias_accesses(self, script_content):
        source_lines = script_content.splitlines()
        rewritten_lines = []
        alias_map = {}

        assignment_pattern = re.compile(r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*$')
        builtin_names = {
            'string', 'table', 'math', 'game', 'workspace', 'script', 'task',
            'utf8', 'coroutine', 'debug', 'os', 'io', 'bit32', '_G'
        }

        for line_text in source_lines:
            rewritten_line = line_text
            for alias_name, builtin_name in sorted(alias_map.items(), key=lambda item: -len(item[0])):
                rewritten_line = re.sub(
                    rf'\b{re.escape(alias_name)}\.([A-Za-z_][A-Za-z0-9_]*)',
                    rf'{builtin_name}.\1',
                    rewritten_line
                )
                rewritten_line = re.sub(
                    rf'\b{re.escape(alias_name)}:([A-Za-z_][A-Za-z0-9_]*)',
                    rf'{builtin_name}:\1',
                    rewritten_line
                )

            rewritten_lines.append(rewritten_line)

            assignment_match = assignment_pattern.match(line_text)
            if not assignment_match:
                continue
            lhs_name = assignment_match.group(1)
            rhs_text = assignment_match.group(2).strip()

            alias_map.pop(lhs_name, None)
            if rhs_text in builtin_names:
                alias_map[lhs_name] = rhs_text

        rewritten_text = '\n'.join(rewritten_lines)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _remove_identity_assignments(self, script_content):
        lines = script_content.splitlines()
        identity_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*\1\s*$'
        )
        rewritten = [line for line in lines if not identity_pattern.match(line)]
        rewritten_text = '\n'.join(rewritten)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _semantic_rename_prometheus_member_usage_symbols(self, script_content):
        lines = script_content.splitlines()
        tokens = set(re.findall(r'\b[A-Za-z_][A-Za-z0-9_]*\b', script_content))
        rename_map = {}
        used_targets = set()

        assign_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*$'
        )
        dot_access_assign_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\.([A-Za-z_][A-Za-z0-9_]*)\s*$'
        )
        member_set_pattern = re.compile(
            r'^\s*([A-Za-z_][A-Za-z0-9_]*)\.([A-Za-z_][A-Za-z0-9_]*)\s*='
        )
        mouse_event_assign_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\.MouseButton1Click\s*$'
        )
        connect_call_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\s*:\s*Connect\s*\('
        )
        wait_for_child_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*[A-Za-z_][A-Za-z0-9_]*\s*:\s*WaitForChild\s*\(\s*("(?:(?:\\.)|[^"\\])*"|\'(?:(?:\\.)|[^\'\\])*\')\s*\)\s*$'
        )
        get_service_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*game\s*:\s*GetService\s*\(\s*("(?:(?:\\.)|[^"\\])*"|\'(?:(?:\\.)|[^\'\\])*\')\s*\)\s*$'
        )
        local_player_assign_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*[A-Za-z_][A-Za-z0-9_]*\.LocalPlayer\s*$'
        )

        def allocate(base_name):
            candidate = base_name
            suffix = 2
            while candidate in tokens or candidate in used_targets:
                candidate = f"{base_name}_{suffix}"
                suffix += 1
            used_targets.add(candidate)
            return candidate

        def register(source_name, base_name):
            if source_name in rename_map:
                return
            if source_name == base_name:
                return
            if source_name in {
                'env', 'game', 'math', 'table', 'string', 'Instance', 'UDim2',
                'UDim', 'Color3', 'Enum', 'task', 'print', 'next_prng_byte',
                'decode_runtime_string', 'lookup', 'items', 'random_fn', 'floor_fn',
                'remove_fn', 'char_fn'
            }:
                return
            rename_map[source_name] = allocate(base_name)

        for line_text in lines:
            stripped = line_text.strip()

            m_service = get_service_pattern.match(stripped)
            if m_service:
                lhs, literal = m_service.groups()
                label = self._build_prometheus_identifier_component(self._parse_lua_string_literal(literal))
                if label:
                    register(lhs, f"{label}_service")
                continue

            m_lp = local_player_assign_pattern.match(stripped)
            if m_lp:
                register(m_lp.group(1), 'local_player')
                continue

            m_wait = wait_for_child_pattern.match(stripped)
            if m_wait:
                lhs, literal = m_wait.groups()
                child = self._build_prometheus_identifier_component(self._parse_lua_string_literal(literal))
                if child:
                    register(lhs, child)
                continue

            m_dot = dot_access_assign_pattern.match(stripped)
            if m_dot:
                lhs, _obj, member = m_dot.groups()
                if member == 'Character':
                    register(lhs, 'character')
                elif member == 'CharacterAdded':
                    register(lhs, 'character_added_event')
                elif member == 'LocalPlayer':
                    register(lhs, 'local_player')
                continue

            m_mouse = mouse_event_assign_pattern.match(stripped)
            if m_mouse:
                lhs_event, button_var = m_mouse.groups()
                register(button_var, 'button')
                register(lhs_event, 'click_event')
                continue

            m_connect = connect_call_pattern.match(stripped)
            if m_connect:
                lhs_conn, event_var = m_connect.groups()
                register(event_var, 'event_signal')
                register(lhs_conn, 'event_connection')
                continue

            m_set = member_set_pattern.match(stripped)
            if m_set:
                obj, member = m_set.groups()
                if member in {'WalkSpeed', 'JumpPower'}:
                    register(obj, 'humanoid')
                elif member == 'Text':
                    register(obj, 'text_label')
                elif member == 'Parent':
                    register(obj, 'ui_node')

        if not rename_map:
            return script_content
        return self._rewrite_lua_identifiers(script_content, rename_map)

    def _semantic_rename_prometheus_runtime_tail_symbols(self, script_content):
        lines = script_content.splitlines()
        if not lines:
            return script_content

        # Focus on the section after the runtime decoder preamble.
        start_index = 0
        fn_pattern = re.compile(
            r'^\s*(?:local\s+)?decode_runtime_string(?:_\d+)?\s*=\s*function\([^)]*\)\s*$'
        )
        for idx, line_text in enumerate(lines):
            if not fn_pattern.match(line_text.strip()):
                continue
            fn_end = self._find_matching_block_end_line(lines, idx)
            if fn_end != -1:
                start_index = fn_end + 1
            break
        if start_index <= 0 or start_index >= len(lines):
            return script_content

        head_lines = lines[:start_index]
        tail_lines = lines[start_index:]
        tail_text = '\n'.join(tail_lines) + ('\n' if script_content.endswith('\n') else '')

        tokens = set(re.findall(r'\b[A-Za-z_][A-Za-z0-9_]*\b', tail_text))
        rename_map = {}
        used_targets = set()

        generic_name_pattern = re.compile(
            r'^(?:local_\d+|r\d+(?:_local)?|v\d+|floor_fn_ref(?:_\d+)?|decode_lookup(?:_\d+)?(?:_ref(?:_\d+)?)?|lookup(?:_\d+)?(?:_ref(?:_\d+)?)?|math_lib_ref(?:_\d+)?|char_fn_2_2|ret_reg_value)$'
        )
        assign_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*$'
        )

        def allocate(base_name):
            candidate = base_name
            suffix = 2
            while candidate in tokens or candidate in used_targets:
                candidate = f"{base_name}_{suffix}"
                suffix += 1
            used_targets.add(candidate)
            return candidate

        def register(name_text, base_name):
            if name_text in rename_map:
                return
            if name_text in {'next_prng_byte', 'decode_runtime_string', 'env', 'game', 'math', 'table', 'string', 'task'}:
                return
            if not generic_name_pattern.fullmatch(name_text):
                return
            rename_map[name_text] = allocate(base_name)

        # Pass 1: strong semantic anchors.
        for line_text in tail_lines:
            stripped = line_text.strip()

            m = re.match(
                r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\.LocalPlayer\s*$',
                stripped
            )
            if m:
                register(m.group(1), 'local_player')
                continue

            m = re.match(
                r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\.MouseButton1Click\s*$',
                stripped
            )
            if m:
                register(m.group(1), 'click_event')
                register(m.group(2), 'button')
                continue

            m = re.match(
                r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\s*:\s*Connect\s*\(',
                stripped
            )
            if m:
                register(m.group(1), 'event_connection')
                register(m.group(2), 'event_signal')
                continue

            m = re.match(
                r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*[A-Za-z_][A-Za-z0-9_]*\s*:\s*WaitForChild\s*\(\s*("(?:(?:\\.)|[^"\\])*"|\'(?:(?:\\.)|[^\'\\])*\')\s*\)\s*$',
                stripped
            )
            if m:
                child_name = self._build_prometheus_identifier_component(self._parse_lua_string_literal(m.group(2)))
                register(m.group(1), child_name if child_name else 'child_node')
                continue

            m = re.match(
                r'^\s*([A-Za-z_][A-Za-z0-9_]*)\.(WalkSpeed|JumpPower)\s*=',
                stripped
            )
            if m:
                register(m.group(1), 'humanoid')
                continue

            m = re.match(
                r'^\s*([A-Za-z_][A-Za-z0-9_]*)\.Text\s*=',
                stripped
            )
            if m:
                register(m.group(1), 'text_label')
                continue

        # Pass 2: runtime dispatch/table aliases.
        call_counts = Counter()
        index_read_counts = Counter()
        index_write_counts = Counter()
        env_key_counts = Counter()
        env_value_assign_counts = Counter()

        for line_text in tail_lines:
            stripped = line_text.strip()
            assign_match = assign_pattern.match(stripped)
            if assign_match:
                lhs, rhs = assign_match.groups()
                if re.search(r'\benv\s*\[', rhs):
                    env_value_assign_counts[lhs] += 1
            for env_m in re.finditer(r'env\s*\[\s*([A-Za-z_][A-Za-z0-9_]*)\s*\]', stripped):
                env_key_counts[env_m.group(1)] += 1
            for call_m in re.finditer(r'\b([A-Za-z_][A-Za-z0-9_]*)\s*\(', stripped):
                call_counts[call_m.group(1)] += 1
            for idx_m in re.finditer(r'\b([A-Za-z_][A-Za-z0-9_]*)\s*\[', stripped):
                index_read_counts[idx_m.group(1)] += 1
            for idx_m in re.finditer(r'\b([A-Za-z_][A-Za-z0-9_]*)\s*\[.+?\]\s*=', stripped):
                index_write_counts[idx_m.group(1)] += 1

        for name_text in sorted(tokens):
            if not generic_name_pattern.fullmatch(name_text):
                continue
            if name_text in rename_map:
                continue
            if env_key_counts.get(name_text, 0) >= 1:
                register(name_text, 'env_key')
                continue
            if env_value_assign_counts.get(name_text, 0) >= 1:
                register(name_text, 'env_table')
                continue

            calls = call_counts.get(name_text, 0)
            reads = index_read_counts.get(name_text, 0)
            writes = index_write_counts.get(name_text, 0)
            if calls >= 1 and (reads + writes) >= 2:
                register(name_text, 'runtime_dispatch')
            elif (reads + writes) >= 3:
                register(name_text, 'runtime_table')
            elif calls >= 2:
                register(name_text, 'runtime_fn')

        if not rename_map:
            return script_content
        rewritten_tail = self._rewrite_lua_identifiers(tail_text, rename_map).rstrip('\n')
        merged_lines = head_lines + rewritten_tail.split('\n')
        merged_text = '\n'.join(merged_lines)
        return merged_text + ('\n' if script_content.endswith('\n') else '')

    def _rename_prometheus_obfuscated_alias_name_patterns(self, script_content):
        lines = script_content.splitlines()
        tokens = set(re.findall(r'\b[A-Za-z_][A-Za-z0-9_]*\b', script_content))
        rename_map = {}

        def allocate(base_name):
            candidate = base_name
            suffix = 2
            while candidate in tokens or candidate in rename_map.values():
                candidate = f"{base_name}_{suffix}"
                suffix += 1
            return candidate

        property_aliases = set()
        for line_text in lines:
            m = re.match(
                r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*("(?:(?:\\.)|[^"\\])*"|\'(?:(?:\\.)|[^\'\\])*\')\s*$',
                line_text.strip()
            )
            if not m:
                continue
            lhs, literal_text = m.groups()
            literal_value = self._parse_lua_string_literal(literal_text)
            if literal_value in {'WalkSpeed', 'JumpPower', 'Humanoid', 'Players', 'PlayerGui'}:
                property_aliases.add(lhs)

        for token in sorted(tokens):
            if token in {'decode_runtime_string', 'next_prng_byte', 'floor_fn', 'random_fn', 'lookup', 'remove_fn', 'items', 'char_fn'}:
                continue
            if re.fullmatch(r'decode_lookup(?:_\d+)?(?:_ref(?:_\d+)?)?', token):
                rename_map[token] = allocate('runtime_lookup')
            elif re.fullmatch(r'floor_fn_ref(?:_\d+)?', token):
                base = 'property_name' if token in property_aliases else 'env_key'
                rename_map[token] = allocate(base)
            elif re.fullmatch(r'math_lib_ref(?:_\d+)?', token):
                rename_map[token] = allocate('runtime_helper')
            elif token == 'ret_reg_value':
                rename_map[token] = allocate('event_connection')
            elif token == 'char_fn_2_2':
                rename_map[token] = allocate('temp_value')

        if not rename_map:
            return script_content
        return self._rewrite_lua_identifiers(script_content, rename_map)

    def _flatten_prometheus_decoder_wrapper_returns(self, script_content):
        lines = script_content.splitlines()
        output = []
        index = 0

        call_table_pattern = re.compile(
            r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*\{\s*([A-Za-z_][A-Za-z0-9_\.]*)\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*\)\s*\}\s*$'
        )
        unpack_table_pattern = re.compile(
            r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*\{\s*(?:unpack_fn|unpack)\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*\)\s*\}\s*$'
        )
        return_unpack_pattern = re.compile(
            r'^(\s*)return\s+(?:unpack_fn|unpack)\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*\)\s*$'
        )

        while index < len(lines):
            if index + 2 < len(lines):
                m_call = call_table_pattern.match(lines[index])
                m_unpack = unpack_table_pattern.match(lines[index + 1])
                m_return = return_unpack_pattern.match(lines[index + 2])
                if m_call and m_unpack and m_return:
                    tmp_table_1 = m_call.group(1)
                    call_name = m_call.group(2)
                    call_arg = m_call.group(3)
                    tmp_table_2 = m_unpack.group(1)
                    unpack_arg = m_unpack.group(2)
                    return_arg = m_return.group(2)
                    if tmp_table_1 == unpack_arg and tmp_table_2 == return_arg:
                        indent_text = m_return.group(1)
                        output.append(f"{indent_text}return {call_name}({call_arg})")
                        index += 3
                        continue

            output.append(lines[index])
            index += 1

        rewritten_text = '\n'.join(output)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _rename_prometheus_decoder_symbols(self, script_content):
        source_lines = script_content.splitlines()
        assignment_pattern = re.compile(
            r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*function\([^)]*\)\s*$'
        )
        alias_assign_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\s*$'
        )

        function_occurrences = []
        assignment_count_by_name = Counter()
        function_assigned_names = set()

        for line_index, line_text in enumerate(source_lines):
            assign_match = assignment_pattern.match(line_text)
            if not assign_match:
                continue
            function_name = assign_match.group(1)
            assignment_count_by_name[function_name] += 1
            function_assigned_names.add(function_name)

            open_depth = 1
            end_index = None
            block_lines = []
            for cursor in range(line_index, len(source_lines)):
                current_line = source_lines[cursor]
                block_lines.append(current_line)
                if cursor == line_index:
                    continue

                stripped = current_line.strip()
                normalized = stripped[:-1].rstrip() if stripped.endswith(';') else stripped
                if (
                    re.match(r'^(if\b|while\b|for\b|function\b)', normalized)
                    or re.search(r'=\s*function\b', normalized)
                    or normalized == 'repeat'
                ):
                    open_depth += 1
                elif normalized == 'end' or normalized.startswith('until '):
                    open_depth -= 1
                    if open_depth <= 0:
                        end_index = cursor
                        break
            if end_index is None:
                continue

            block_text = '\n'.join(block_lines)
            is_prng_fn = (
                '35184372088832' in block_text
                and '4294967296' in block_text
                and '65536' in block_text
                and ('table.remove' in block_text or '.remove' in block_text)
                and (
                    'return unpack_fn' in block_text
                    or 'return unpack' in block_text
                    or re.search(
                        r'\breturn\s+[A-Za-z_][A-Za-z0-9_]*\(\s*[A-Za-z_][A-Za-z0-9_]*\s*\)',
                        block_text
                    ) is not None
                )
            )
            decode_guard_match = re.search(
                r'if\s+not\s*\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*\[\s*([A-Za-z_][A-Za-z0-9_]*)\s*\]\s*\)\s+then',
                block_text
            )
            is_decode_fn = False
            if 'string.byte' in block_text and '..' in block_text and decode_guard_match:
                cache_name = decode_guard_match.group(1)
                key_name = decode_guard_match.group(2)
                cache_init_match = re.search(
                    rf'{re.escape(cache_name)}\s*\[\s*{re.escape(key_name)}\s*\]\s*=\s*(.+)',
                    block_text
                )
                has_cache_init = False
                if cache_init_match:
                    cache_init_rhs = cache_init_match.group(1).strip().rstrip(';').strip()
                    if cache_init_rhs in {'""', "''"}:
                        has_cache_init = True
                    elif re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', cache_init_rhs):
                        has_cache_init = re.search(
                            rf'\b{re.escape(cache_init_rhs)}\s*=\s*(?:""|\'\')',
                            block_text
                        ) is not None
                has_cache_return = re.search(
                    rf'return\s+{re.escape(cache_name)}\s*\[\s*{re.escape(key_name)}\s*\]',
                    block_text
                ) is not None
                has_cache_write = re.search(
                    rf'{re.escape(cache_name)}\s*\[\s*{re.escape(key_name)}\s*\]\s*=',
                    block_text
                ) is not None
                is_decode_fn = has_cache_init and has_cache_return and has_cache_write

            if not (is_prng_fn or is_decode_fn):
                continue

            function_occurrences.append({
                'name': function_name,
                'start': line_index,
                'end': end_index,
                'kind': 'prng' if is_prng_fn else 'decode'
            })

        if not function_occurrences:
            return script_content

        identifier_counts = Counter(re.findall(r'\b[A-Za-z_][A-Za-z0-9_]*\b', script_content))
        existing_names = set(re.findall(r'\b[A-Za-z_][A-Za-z0-9_]*\b', script_content))
        rename_map = {}

        def allocate_target(base_name):
            target_name = base_name
            suffix = 2
            while target_name in existing_names:
                target_name = f"{base_name}_{suffix}"
                suffix += 1
            existing_names.add(target_name)
            return target_name

        for occurrence in function_occurrences:
            base_target = 'next_prng_byte' if occurrence['kind'] == 'prng' else 'decode_runtime_string'
            fn_name = occurrence['name']
            candidate_sources = []

            if assignment_count_by_name.get(fn_name, 0) == 1:
                candidate_sources.append(fn_name)

            scan_limit = min(len(source_lines), occurrence['end'] + 96)
            for scan_index in range(occurrence['end'] + 1, scan_limit):
                scan_line = source_lines[scan_index]
                if assignment_pattern.match(scan_line) and re.search(r'=\s*function\(', scan_line):
                    break
                alias_match = alias_assign_pattern.match(scan_line)
                if not alias_match:
                    continue
                lhs_alias, rhs_name = alias_match.groups()
                if rhs_name != fn_name:
                    continue
                if lhs_alias in function_assigned_names:
                    continue
                candidate_sources.append(lhs_alias)
                break

            source_name = None
            for candidate_name in candidate_sources:
                if not candidate_name:
                    continue
                if re.fullmatch(r'r\d+(?:_local)?', candidate_name):
                    continue
                source_name = candidate_name
                break
            if source_name is None and candidate_sources:
                source_name = candidate_sources[0]

            if not source_name:
                continue
            if re.fullmatch(r'r\d+(?:_local)?', source_name):
                continue
            source_count = identifier_counts.get(source_name, 0)
            max_occurrences = 40 if occurrence['kind'] == 'prng' else 220
            if source_count > max_occurrences:
                continue
            if (
                occurrence['kind'] == 'prng'
                and re.fullmatch(r'v\d+', source_name)
                and source_count > 24
            ):
                continue
            if source_name == base_target or source_name.startswith(f"{base_target}_"):
                continue
            if source_name in rename_map:
                continue
            rename_map[source_name] = allocate_target(base_target)

        if not rename_map:
            return script_content
        return self._rewrite_lua_identifiers(script_content, rename_map)

    def _classify_prometheus_decoder_function_text(self, fn_text):
        if (
            'string.byte' in fn_text
            and ('string.len' in fn_text or '.len' in fn_text)
            and (
                re.search(r'if\s+not\s*\(\s*[A-Za-z_][A-Za-z0-9_]*\s*\[\s*[A-Za-z_][A-Za-z0-9_]*\s*\]\s*\)\s+then', fn_text)
                or re.search(r'if\s+not\s+[A-Za-z_][A-Za-z0-9_]*\s*\[\s*[A-Za-z_][A-Za-z0-9_]*\s*\]\s+then', fn_text)
            )
        ):
            return 'decode'
        if (
            '35184372088832' in fn_text
            and '65536' in fn_text
            and ('table.remove' in fn_text or '.remove' in fn_text)
            and 'string.byte' not in fn_text
        ):
            return 'prng'
        return None

    def _rename_prometheus_function_assignments_by_role(self, script_content):
        lines = script_content.splitlines()
        fn_assign_pattern = re.compile(
            r'^(\s*)(local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*function\(([^)]*)\)\s*$'
        )
        assignment_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*='
        )

        used_names = set(re.findall(r'\b[A-Za-z_][A-Za-z0-9_]*\b', script_content))

        def allocate(base_name):
            candidate = base_name
            suffix = 2
            while candidate in used_names:
                candidate = f"{base_name}_{suffix}"
                suffix += 1
            used_names.add(candidate)
            return candidate

        rewritten = list(lines)
        changed = False
        index = 0
        while index < len(rewritten):
            fn_match = fn_assign_pattern.match(rewritten[index])
            if not fn_match:
                index += 1
                continue

            indent_text, local_kw, fn_name, arg_text = fn_match.groups()
            end_index = self._find_matching_block_end_line(rewritten, index)
            if end_index == -1:
                index += 1
                continue

            fn_text = '\n'.join(rewritten[index:end_index + 1])
            role = self._classify_prometheus_decoder_function_text(fn_text)
            if not role:
                index = end_index + 1
                continue

            target_base = 'decode_runtime_string' if role == 'decode' else 'next_prng_byte'
            already_semantic = re.fullmatch(rf'{target_base}(?:_\d+)?', fn_name) is not None
            if already_semantic:
                index = end_index + 1
                continue

            target_name = allocate(target_base)
            rewritten[index] = f"{indent_text}{local_kw or 'local '}{target_name} = function({arg_text})"

            # Only rewrite callsites in the live region after this function.
            # Do not rewrite inside the function body: Prometheus decoders often
            # call the previous PRNG binding through the shadowed old name.
            region_end = len(rewritten)
            for probe in range(end_index + 1, len(rewritten)):
                assign_match = assignment_pattern.match(rewritten[probe].strip())
                if assign_match and assign_match.group(1) == fn_name:
                    region_end = probe
                    break

            call_pattern = re.compile(rf'\b{re.escape(fn_name)}\s*(?=\()')
            zero_arg_call_pattern = re.compile(rf'\b{re.escape(fn_name)}\s*(?=\(\s*\))')
            alias_rhs_pattern = re.compile(
                rf'(=\s*){re.escape(fn_name)}\s*$'
            )
            for probe in range(end_index + 1, region_end):
                if role == 'prng':
                    line_text = zero_arg_call_pattern.sub(target_name, rewritten[probe])
                    line_text = alias_rhs_pattern.sub(rf'\1{target_name}', line_text)
                    rewritten[probe] = line_text
                else:
                    rewritten[probe] = call_pattern.sub(target_name, rewritten[probe])

            changed = True
            index = end_index + 1

        if not changed:
            return script_content
        rewritten_text = '\n'.join(rewritten)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _force_rename_prometheus_decoder_functions(self, script_content):
        region_renamed = self._rename_prometheus_function_assignments_by_role(script_content)
        if region_renamed != script_content:
            return region_renamed

        lines = script_content.splitlines()
        fn_assign_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*function\([^)]*\)\s*$'
        )
        identifier_counts = Counter(re.findall(r'\b[A-Za-z_][A-Za-z0-9_]*\b', script_content))
        existing_names = set(re.findall(r'\b[A-Za-z_][A-Za-z0-9_]*\b', script_content))
        rename_map = {}

        def allocate(base_name):
            candidate = base_name
            suffix = 2
            while candidate in existing_names:
                candidate = f"{base_name}_{suffix}"
                suffix += 1
            existing_names.add(candidate)
            return candidate

        for index, line_text in enumerate(lines):
            fn_match = fn_assign_pattern.match(line_text.strip())
            if not fn_match:
                continue
            fn_name = fn_match.group(1)
            if re.fullmatch(r'(?:decode_runtime_string(?:_\d+)?|next_prng_byte(?:_\d+)?)', fn_name):
                continue

            end_index = self._find_matching_block_end_line(lines, index)
            if end_index == -1:
                continue
            fn_text = '\n'.join(lines[index:end_index + 1])

            function_kind = self._classify_prometheus_decoder_function_text(fn_text)
            target_base = None
            if function_kind == 'decode':
                target_base = 'decode_runtime_string'
            elif function_kind == 'prng':
                target_base = 'next_prng_byte'

            if not target_base:
                continue
            if identifier_counts.get(fn_name, 0) > 800:
                continue
            if fn_name in rename_map:
                continue
            rename_map[fn_name] = allocate(target_base)

        if not rename_map:
            return script_content
        return self._rewrite_lua_identifiers(script_content, rename_map)

    def _separate_prometheus_decoder_cache_from_function(self, script_content):
        lines = script_content.splitlines()
        local_table_pattern = re.compile(
            r'^(\s*)(local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*\{\}\s*$'
        )
        fn_assign_pattern = re.compile(
            r'^(\s*)(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*function\(([^)]*)\)\s*$'
        )

        def allocate_name(base_name, used_names):
            if base_name not in used_names:
                used_names.add(base_name)
                return base_name
            suffix = 2
            while True:
                candidate = f"{base_name}_{suffix}"
                if candidate not in used_names:
                    used_names.add(candidate)
                    return candidate
                suffix += 1

        used = set(re.findall(r'\b[A-Za-z_][A-Za-z0-9_]*\b', script_content))
        rewritten = list(lines)
        changed = False

        index = 0
        while index < len(rewritten):
            table_match = local_table_pattern.match(rewritten[index])
            if not table_match:
                index += 1
                continue
            table_name = table_match.group(3)

            fn_index = None
            fn_indent = ''
            fn_args = ''
            scan_limit = min(len(rewritten), index + 220)
            for probe in range(index + 1, scan_limit):
                fn_match = fn_assign_pattern.match(rewritten[probe].strip())
                if not fn_match:
                    continue
                lhs_name = fn_match.group(2)
                if lhs_name != table_name:
                    continue
                fn_index = probe
                fn_indent = fn_match.group(1)
                fn_args = fn_match.group(3)
                break
            if fn_index is None:
                index += 1
                continue

            fn_end = self._find_matching_block_end_line(rewritten, fn_index)
            if fn_end == -1:
                index += 1
                continue

            fn_text = '\n'.join(rewritten[fn_index:fn_end + 1])
            if 'string.byte' not in fn_text:
                index = fn_end + 1
                continue
            if not re.search(
                r'if\s+not\s*\(\s*[A-Za-z_][A-Za-z0-9_]*\s*\[\s*[A-Za-z_][A-Za-z0-9_]*\s*\]\s*\)\s+then',
                fn_text
            ):
                index = fn_end + 1
                continue

            meta_uses_table = False
            for probe in range(index, fn_index):
                line_text = rewritten[probe]
                if (
                    re.search(rf'\b{re.escape(table_name)}\b', line_text)
                    and ('setmetatable' in line_text or '{[' in line_text or '__index' in line_text)
                ):
                    meta_uses_table = True
                    break
            if not meta_uses_table:
                index = fn_end + 1
                continue

            cache_name = allocate_name('decoded_cache', used)
            fn_name = allocate_name('decode_runtime_string', used)

            # 1) local table declaration
            indent_text, local_kw = table_match.group(1), table_match.group(2) or ''
            rewritten[index] = f"{indent_text}{local_kw}{cache_name} = {{}}"

            # 2) __index/meta references before function assignment
            for probe in range(index + 1, fn_index):
                rewritten[probe] = re.sub(
                    rf'\b{re.escape(table_name)}\b',
                    cache_name,
                    rewritten[probe]
                )

            # 3) function assignment line
            rewritten[fn_index] = f"{fn_indent}local {fn_name} = function({fn_args})"

            # 4) inside function: all table accesses to old name become cache table
            for probe in range(fn_index + 1, fn_end + 1):
                line_text = rewritten[probe]
                line_text = re.sub(
                    rf'\b{re.escape(table_name)}\s*\[',
                    f'{cache_name}[',
                    line_text
                )
                # Alias capture lines like `tmp = <old_name>` should refer cache table.
                line_text = re.sub(
                    rf'=\s*{re.escape(table_name)}\b',
                    f'= {cache_name}',
                    line_text
                )
                rewritten[probe] = line_text

            # 5) Calls to old symbol after function should invoke new function.
            for probe in range(fn_end + 1, len(rewritten)):
                rewritten[probe] = re.sub(
                    rf'\b{re.escape(table_name)}\s*\(',
                    f'{fn_name}(',
                    rewritten[probe]
                )

            changed = True
            index = fn_end + 1

        if not changed:
            return script_content
        rewritten_text = '\n'.join(rewritten)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _separate_shadowed_function_bindings(self, script_content):
        lines = script_content.splitlines()
        assign_pattern = re.compile(
            r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*$'
        )
        fn_assign_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*function\([^)]*\)\s*$'
        )

        first_fn_index = {}
        for idx, line_text in enumerate(lines):
            fn_match = fn_assign_pattern.match(line_text.strip())
            if not fn_match:
                continue
            fn_name = fn_match.group(1)
            if fn_name not in first_fn_index:
                first_fn_index[fn_name] = idx

        if not first_fn_index:
            return script_content

        rename_regions = []
        used_names = set(re.findall(r'\b[A-Za-z_][A-Za-z0-9_]*\b', script_content))

        for fn_name, fn_idx in first_fn_index.items():
            has_pre_assign = False
            for idx in range(0, fn_idx):
                assign_match = assign_pattern.match(lines[idx].strip())
                if not assign_match:
                    continue
                lhs_name, rhs_text = assign_match.groups()
                if lhs_name != fn_name:
                    continue
                if 'function(' in rhs_text:
                    continue
                has_pre_assign = True
                break
            if not has_pre_assign:
                continue

            base_alias = f"{fn_name}_value"
            alias_name = base_alias
            suffix = 2
            while alias_name in used_names:
                alias_name = f"{base_alias}_{suffix}"
                suffix += 1
            used_names.add(alias_name)
            rename_regions.append((fn_name, alias_name, 0, fn_idx))

        if not rename_regions:
            return script_content

        rewritten_lines = list(lines)
        for source_name, target_name, start_idx, end_idx in rename_regions:
            token_pattern = re.compile(rf'\b{re.escape(source_name)}\b')
            for idx in range(start_idx, end_idx):
                rewritten_lines[idx] = token_pattern.sub(target_name, rewritten_lines[idx])

        rewritten_text = '\n'.join(rewritten_lines)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _collapse_prometheus_decoder_runtime_scaffold(self, script_content):
        lines = script_content.splitlines()
        fn_assign_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*function\([^)]*\)\s*$'
        )
        simple_assign_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\s*$'
        )
        if_cache_pattern = re.compile(
            r'^\s*if\s+not\s*\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*\[\s*([A-Za-z_][A-Za-z0-9_]*)\s*\]\s*\)\s+then\s*$'
        )
        return_cache_pattern = re.compile(
            r'^\s*return\s+([A-Za-z_][A-Za-z0-9_]*)\s*\[\s*([A-Za-z_][A-Za-z0-9_]*)\s*\]\s*$'
        )

        existing_names = set(re.findall(r'\b[A-Za-z_][A-Za-z0-9_]*\b', script_content))
        rename_map = {}

        def allocate_name(base_name):
            if base_name not in existing_names:
                existing_names.add(base_name)
                return base_name
            suffix = 2
            while True:
                candidate = f"{base_name}_{suffix}"
                if candidate not in existing_names:
                    existing_names.add(candidate)
                    return candidate
                suffix += 1

        def is_called_as_function(identifier_name):
            return re.search(
                rf'\b{re.escape(identifier_name)}\s*\(',
                script_content
            ) is not None

        for index, line_text in enumerate(lines):
            fn_match = fn_assign_pattern.match(line_text)
            if not fn_match:
                continue

            fn_name = fn_match.group(1)
            block_end = self._find_matching_block_end_line(lines, index)
            if block_end == -1:
                continue

            fn_lines = lines[index:block_end + 1]
            fn_text = '\n'.join(fn_lines)
            if 'string.byte' not in fn_text or '..' not in fn_text:
                continue

            cache_if_match = None
            cache_return_match = None
            for fn_line in fn_lines:
                if cache_if_match is None:
                    candidate = if_cache_pattern.match(fn_line.strip())
                    if candidate:
                        cache_if_match = candidate
                if cache_return_match is None:
                    candidate = return_cache_pattern.match(fn_line.strip())
                    if candidate:
                        cache_return_match = candidate

            if not cache_if_match or not cache_return_match:
                continue

            cache_local_name, cache_key_name = cache_if_match.groups()
            return_cache_name, return_key_name = cache_return_match.groups()
            if cache_local_name != return_cache_name or cache_key_name != return_key_name:
                continue
            if '35184372088832' not in fn_text:
                continue
            cache_init_match = re.search(
                rf'\b{re.escape(cache_local_name)}\s*\[\s*{re.escape(cache_key_name)}\s*\]\s*=\s*(.+)',
                fn_text
            )
            has_cache_init = False
            if cache_init_match:
                cache_init_rhs = cache_init_match.group(1).strip().rstrip(';').strip()
                if cache_init_rhs in {'""', "''"}:
                    has_cache_init = True
                elif re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', cache_init_rhs):
                    has_cache_init = re.search(
                        rf'\b{re.escape(cache_init_rhs)}\s*=\s*(?:""|\'\')',
                        fn_text
                    ) is not None
            if not has_cache_init:
                continue

            local_alias_map = {}
            for fn_line in fn_lines:
                assign_match = simple_assign_pattern.match(fn_line.strip())
                if not assign_match:
                    continue
                lhs_name, rhs_name = assign_match.groups()
                if lhs_name not in local_alias_map:
                    local_alias_map[lhs_name] = rhs_name

            def resolve_alias(name_text):
                visited = set()
                current_name = name_text
                while current_name in local_alias_map and current_name not in visited:
                    visited.add(current_name)
                    next_name = local_alias_map[current_name]
                    if next_name == current_name:
                        break
                    current_name = next_name
                return current_name

            outer_cache_name = resolve_alias(cache_local_name)
            if (
                outer_cache_name
                and outer_cache_name != fn_name
                and not re.fullmatch(r'r\d+(?:_local)?', outer_cache_name)
            ):
                if outer_cache_name not in rename_map:
                    rename_map[outer_cache_name] = allocate_name('decoded_cache')

            lookup_candidates = []
            for lhs_name, rhs_name in local_alias_map.items():
                if lhs_name == cache_local_name:
                    continue
                resolved_outer_name = resolve_alias(lhs_name)
                if resolved_outer_name == outer_cache_name:
                    continue
                read_count = len(re.findall(rf'\b{re.escape(lhs_name)}\s*\[\s*[A-Za-z_][A-Za-z0-9_]*\s*\]', fn_text))
                write_count = len(re.findall(rf'\b{re.escape(lhs_name)}\s*\[\s*[A-Za-z_][A-Za-z0-9_]*\s*\]\s*=', fn_text))
                if read_count > 0 and write_count == 0:
                    lookup_candidates.append((read_count, resolved_outer_name))

            if lookup_candidates:
                lookup_candidates.sort(key=lambda item: item[0], reverse=True)
                outer_lookup_name = lookup_candidates[0][1]
                if (
                    outer_lookup_name
                    and outer_lookup_name != fn_name
                    and outer_lookup_name != outer_cache_name
                    and not is_called_as_function(outer_lookup_name)
                    and not re.fullmatch(r'r\d+(?:_local)?', outer_lookup_name)
                ):
                    if outer_lookup_name not in rename_map:
                        rename_map[outer_lookup_name] = allocate_name('decode_lookup')
            else:
                # Fallback: resolve the source used by string.byte char mapping in decode loop.
                string_byte_match = re.search(
                    r'\b([A-Za-z_][A-Za-z0-9_]*)\s*=\s*string\.byte\(',
                    fn_text
                )
                concat_lookup_match = re.search(
                    r'\.\.\s*([A-Za-z_][A-Za-z0-9_]*)',
                    fn_text
                )
                if string_byte_match and concat_lookup_match:
                    concat_name = concat_lookup_match.group(1)
                    for lhs_name in local_alias_map:
                        if re.search(rf'\b{re.escape(lhs_name)}\s*\[', fn_text):
                            resolved_outer_name = resolve_alias(lhs_name)
                            if (
                                resolved_outer_name
                                and resolved_outer_name != outer_cache_name
                                and resolved_outer_name != fn_name
                                and not is_called_as_function(resolved_outer_name)
                                and not re.fullmatch(r'r\d+(?:_local)?', resolved_outer_name)
                            ):
                                if resolved_outer_name not in rename_map:
                                    rename_map[resolved_outer_name] = allocate_name('decode_lookup')
                                break

        if not rename_map:
            return script_content
        return self._rewrite_lua_identifiers(script_content, rename_map)

    def _collapse_prometheus_decoder_callsites(self, script_content):
        lines = script_content.splitlines()
        simple_assign_pattern = re.compile(
            r'^(\s*)(local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\s*$'
        )
        any_assign_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*='
        )
        assign_expr_pattern = re.compile(
            r'^(\s*)(local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*$'
        )
        token_pattern = re.compile(r'\b([A-Za-z_][A-Za-z0-9_]*)\b')

        semantic_name_pattern = re.compile(
            r'^(?:decode_runtime_string(?:_\d+)?|decoded_cache(?:_\d+)?|decode_lookup(?:_\d+)?|next_prng_byte(?:_\d+)?)$'
        )
        semantic_names = {
            name for name in set(re.findall(r'\b[A-Za-z_][A-Za-z0-9_]*\b', script_content))
            if semantic_name_pattern.fullmatch(name)
        }
        if not semantic_names:
            return script_content

        assignment_counts = Counter()
        for line_text in lines:
            any_match = any_assign_pattern.match(line_text)
            if any_match:
                assignment_counts[any_match.group(1)] += 1

        alias_map = {}
        changed = True
        rounds = 0
        while changed and rounds < 4:
            changed = False
            rounds += 1
            for line_text in lines:
                assign_match = simple_assign_pattern.match(line_text)
                if not assign_match:
                    continue
                lhs_name = assign_match.group(3)
                rhs_name = assign_match.group(4)
                if assignment_counts.get(lhs_name, 0) != 1:
                    continue
                resolved_rhs = alias_map.get(rhs_name, rhs_name)
                if resolved_rhs in semantic_names or semantic_name_pattern.fullmatch(resolved_rhs):
                    if alias_map.get(lhs_name) != resolved_rhs:
                        alias_map[lhs_name] = resolved_rhs
                        changed = True

        if alias_map:
            script_content = self._rewrite_lua_identifiers(script_content, alias_map)
            lines = script_content.splitlines()

        semantic_fn_names = {
            name for name in set(re.findall(r'\b[A-Za-z_][A-Za-z0-9_]*\b', script_content))
            if re.fullmatch(r'(?:decode_runtime_string(?:_\d+)?|next_prng_byte(?:_\d+)?)', name)
        }
        semantic_table_names = {
            name for name in set(re.findall(r'\b[A-Za-z_][A-Za-z0-9_]*\b', script_content))
            if re.fullmatch(r'(?:decoded_cache(?:_\d+)?|decode_lookup(?:_\d+)?)', name)
        }

        # Inline short-lived aliases to semantic decoder symbols, even when the
        # alias has multiple assignments globally.
        lines = script_content.splitlines()
        alias_rewritten = list(lines)
        remove_alias_lines = set()

        for idx, line_text in enumerate(lines):
            alias_match = simple_assign_pattern.match(line_text)
            if not alias_match:
                continue
            indent_text, local_kw, lhs_name, rhs_name = alias_match.groups()
            if rhs_name not in semantic_fn_names and rhs_name not in semantic_table_names:
                continue

            stop_index = min(len(lines), idx + 14)
            for probe in range(idx + 1, min(len(lines), idx + 40)):
                reassign_match = any_assign_pattern.match(lines[probe])
                if reassign_match and reassign_match.group(1) == lhs_name:
                    stop_index = probe
                    break

            use_indexes = []
            for probe in range(idx + 1, stop_index):
                if re.search(rf'\b{re.escape(lhs_name)}\b', lines[probe]):
                    use_indexes.append(probe)

            if not use_indexes:
                continue

            changed_local = False
            for probe in use_indexes:
                probe_line = alias_rewritten[probe]
                assign_match = assign_expr_pattern.match(probe_line)
                if assign_match:
                    p_indent, p_local_kw, p_lhs, p_rhs = assign_match.groups()
                    rewritten_rhs = re.sub(
                        rf'\b{re.escape(lhs_name)}\b',
                        rhs_name,
                        p_rhs
                    )
                    if rewritten_rhs != p_rhs:
                        alias_rewritten[probe] = f"{p_indent}{p_local_kw or ''}{p_lhs} = {rewritten_rhs}"
                        changed_local = True
                else:
                    rewritten_line = re.sub(
                        rf'\b{re.escape(lhs_name)}\b',
                        rhs_name,
                        probe_line
                    )
                    if rewritten_line != probe_line:
                        alias_rewritten[probe] = rewritten_line
                        changed_local = True

            if changed_local:
                remove_alias_lines.add(idx)

        if remove_alias_lines:
            rewritten = [
                line_text for i, line_text in enumerate(alias_rewritten)
                if i not in remove_alias_lines
            ]
            script_content = '\n'.join(rewritten) + ('\n' if script_content.endswith('\n') else '')
            lines = script_content.splitlines()

        # Collapse adjacent alias chains like:
        #   alias = decode_runtime_string
        #   out = alias(x, y)
        # and
        #   alias = decoded_cache
        #   out = alias[key]
        lines = script_content.splitlines()
        collapsed_lines = []
        index = 0
        while index < len(lines):
            line_text = lines[index]
            alias_match = simple_assign_pattern.match(line_text)
            if alias_match:
                indent_text, local_kw, alias_name, rhs_name = alias_match.groups()
                next_index = index + 1
                while next_index < len(lines) and not lines[next_index].strip():
                    next_index += 1
                if next_index < len(lines):
                    next_line = lines[next_index]
                    next_assign = assign_expr_pattern.match(next_line)
                    if next_assign:
                        next_indent, next_local_kw, next_lhs, next_rhs = next_assign.groups()
                        replaced_rhs = None
                        call_match = re.match(
                            rf'^\s*{re.escape(alias_name)}\s*\((.*)\)\s*$',
                            next_rhs
                        )
                        if call_match and rhs_name in semantic_fn_names:
                            replaced_rhs = f"{rhs_name}({call_match.group(1)})"
                        else:
                            index_match = re.match(
                                rf'^\s*{re.escape(alias_name)}\s*\[(.*)\]\s*$',
                                next_rhs
                            )
                            if index_match and rhs_name in semantic_table_names:
                                replaced_rhs = f"{rhs_name}[{index_match.group(1)}]"

                        if replaced_rhs is not None:
                            collapsed_lines.extend(lines[index + 1:next_index])
                            collapsed_lines.append(
                                f"{next_indent}{next_local_kw or ''}{next_lhs} = {replaced_rhs}"
                            )
                            index = next_index + 1
                            continue

            collapsed_lines.append(line_text)
            index += 1

        script_content = '\n'.join(collapsed_lines) + ('\n' if script_content.endswith('\n') else '')
        lines = script_content.splitlines()

        # Keep decoder side effects while dropping dead temporary assignments that
        # get overwritten before any read:
        #   tmp = decode_runtime_string(...)
        #   tmp = ...
        # -> decode_runtime_string(...)
        assign_lhs_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*$'
        )
        changed_dead = True
        dead_rounds = 0
        while changed_dead and dead_rounds < 3:
            changed_dead = False
            dead_rounds += 1
            rewritten = list(lines)
            for i, line_text in enumerate(lines):
                assign_match = assign_lhs_pattern.match(line_text)
                if not assign_match:
                    continue
                lhs_name, rhs_text = assign_match.groups()
                rhs_text = rhs_text.strip()
                if not re.fullmatch(
                    r'(?:decode_runtime_string(?:_\d+)?|next_prng_byte(?:_\d+)?)\s*\(.*\)',
                    rhs_text
                ):
                    continue

                read_found = False
                overwrite_index = None
                for j in range(i + 1, min(len(lines), i + 18)):
                    probe_line = lines[j]
                    probe_assign = assign_lhs_pattern.match(probe_line)
                    if probe_assign and probe_assign.group(1) == lhs_name:
                        overwrite_index = j
                        break
                    if re.search(rf'\b{re.escape(lhs_name)}\b', probe_line):
                        read_found = True
                        break

                if overwrite_index is None or read_found:
                    continue

                indent_text = line_text[:len(line_text) - len(line_text.lstrip(' \t'))]
                rewritten[i] = f"{indent_text}{rhs_text}"
                changed_dead = True

            lines = rewritten

        script_content = '\n'.join(lines) + ('\n' if script_content.endswith('\n') else '')
        lines = script_content.splitlines()

        def is_decoder_expr(expr_text):
            stripped = expr_text.strip()
            call_match = re.fullmatch(r'([A-Za-z_][A-Za-z0-9_]*)\s*\((.*)\)', stripped)
            if call_match and call_match.group(1) in semantic_fn_names:
                return True
            index_match = re.fullmatch(r'([A-Za-z_][A-Za-z0-9_]*)\s*\[\s*(.+)\s*\]', stripped)
            if index_match and index_match.group(1) in semantic_table_names:
                return True
            return False

        def replace_token_once(line_text, token_name, replacement_text):
            return re.sub(
                rf'\b{re.escape(token_name)}\b',
                replacement_text,
                line_text,
                count=1
            )

        changed = True
        rounds = 0
        while changed and rounds < 4:
            changed = False
            rounds += 1
            lines = script_content.splitlines()
            assignment_counts = Counter()
            for line_text in lines:
                any_match = any_assign_pattern.match(line_text)
                if any_match:
                    assignment_counts[any_match.group(1)] += 1
            use_locations = {}
            for idx, line_text in enumerate(lines):
                for token in token_pattern.findall(line_text):
                    use_locations.setdefault(token, []).append(idx)

            remove_lines = set()
            replace_map = {}

            for idx, line_text in enumerate(lines):
                assign_match = assign_expr_pattern.match(line_text)
                if not assign_match:
                    continue
                lhs_name = assign_match.group(3)
                rhs_text = assign_match.group(4).strip()
                if assignment_counts.get(lhs_name, 0) != 1:
                    continue
                if not is_decoder_expr(rhs_text):
                    continue

                use_list = [loc for loc in use_locations.get(lhs_name, []) if loc != idx]
                if len(use_list) != 1:
                    continue
                target_idx = use_list[0]
                if target_idx <= idx or target_idx - idx > 8:
                    continue

                target_line = lines[target_idx]
                replace_map[target_idx] = (lhs_name, f"({rhs_text})")
                remove_lines.add(idx)

            if not remove_lines and not replace_map:
                break

            rewritten = []
            for idx, line_text in enumerate(lines):
                if idx in remove_lines:
                    changed = True
                    continue
                if idx in replace_map:
                    token_name, replacement_text = replace_map[idx]
                    assign_target_match = assign_expr_pattern.match(line_text)
                    if assign_target_match:
                        indent_text, local_kw, lhs_name, rhs_text = assign_target_match.groups()
                        rewritten_rhs = replace_token_once(rhs_text, token_name, replacement_text)
                        new_line = f"{indent_text}{local_kw or ''}{lhs_name} = {rewritten_rhs}"
                    else:
                        new_line = replace_token_once(line_text, token_name, replacement_text)
                    rewritten.append(new_line)
                    if new_line != line_text:
                        changed = True
                    continue
                rewritten.append(line_text)

            script_content = '\n'.join(rewritten) + ('\n' if script_content.endswith('\n') else '')

        return script_content

    def _rename_prometheus_bootstrap_semantic_roles(self, script_content):
        lines = script_content.splitlines()
        assign_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*$'
        )
        simple_alias_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\s*$'
        )

        cutoff = len(lines)
        for index, line_text in enumerate(lines):
            stripped = line_text.strip()
            if re.match(r'^(?:local\s+)?decode_runtime_string\b', stripped):
                cutoff = index + 1
                break
        if cutoff <= 0:
            return script_content

        prefix_lines = lines[:cutoff]
        prefix_text = '\n'.join(prefix_lines)
        if '35184372088832' not in prefix_text:
            return script_content

        alias_map = {}
        for line_text in prefix_lines:
            alias_match = simple_alias_pattern.match(line_text)
            if not alias_match:
                continue
            alias_map[alias_match.group(1)] = alias_match.group(2)

        builtin_targets = {
            'math': 'math_lib',
            'math.floor': 'floor_fn',
            'math.random': 'random_fn',
            'table.remove': 'remove_fn',
            'string.char': 'char_fn'
        }

        existing_names = set(re.findall(r'\b[A-Za-z_][A-Za-z0-9_]*\b', script_content))
        rename_map = {}

        def allocate_name(base_name):
            candidate = base_name
            suffix = 2
            while candidate in existing_names or candidate in rename_map.values():
                candidate = f"{base_name}_{suffix}"
                suffix += 1
            existing_names.add(candidate)
            return candidate

        def resolve_alias(name_text):
            seen = set()
            current = name_text
            while current in alias_map and current not in seen:
                seen.add(current)
                next_name = alias_map[current]
                if next_name == current:
                    break
                current = next_name
            return current

        table_vars = set()
        remove_aliases = {'table.remove'}

        for line_text in prefix_lines:
            assign_match = assign_pattern.match(line_text)
            if not assign_match:
                continue
            lhs_name, rhs_text = assign_match.groups()
            rhs_value = rhs_text.strip().rstrip(';').strip()

            if rhs_value == '{}':
                table_vars.add(lhs_name)

            target_name = builtin_targets.get(rhs_value)
            if target_name:
                if lhs_name not in rename_map:
                    rename_map[lhs_name] = allocate_name(target_name)
                if rhs_value == 'table.remove':
                    remove_aliases.add(lhs_name)
                continue

            if re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', rhs_value):
                resolved_rhs = resolve_alias(rhs_value)
                resolved_target = builtin_targets.get(resolved_rhs)
                if resolved_target:
                    mapped = rename_map.get(rhs_value) or rename_map.get(resolved_rhs)
                    if mapped:
                        if re.fullmatch(r'v\d+', lhs_name):
                            alias_base = f"{mapped}_ref"
                        elif re.fullmatch(r'r\d+(?:_local)?', lhs_name):
                            alias_base = mapped
                        else:
                            alias_base = f"{mapped}_alias"
                        if lhs_name not in rename_map:
                            rename_map[lhs_name] = allocate_name(alias_base)
                    if resolved_rhs == 'table.remove':
                        remove_aliases.add(lhs_name)

        def count_matches(pattern_text):
            return len(re.findall(pattern_text, prefix_text))

        for table_name in table_vars:
            writes = count_matches(rf'\b{re.escape(table_name)}\s*\[\s*.+?\s*\]\s*=')
            reads = count_matches(rf'\b{re.escape(table_name)}\s*\[\s*.+?\s*\]') - writes
            len_uses = count_matches(rf'#\s*{re.escape(table_name)}\b')
            remove_calls = 0
            for remove_name in remove_aliases:
                if remove_name == 'table.remove':
                    remove_calls += count_matches(
                        rf'\btable\.remove\s*\(\s*{re.escape(table_name)}\s*,'
                    )
                else:
                    remove_calls += count_matches(
                        rf'\b{re.escape(remove_name)}\s*\(\s*{re.escape(table_name)}\s*,'
                    )
            index_metatable_hits = count_matches(
                rf'__index\s*\]\s*=\s*{re.escape(table_name)}\b|__index\s*=\s*{re.escape(table_name)}\b'
            )

            role_name = None
            if writes >= 1 and len_uses >= 1 and remove_calls >= 1:
                role_name = 'lookup'
            elif writes >= 1 and reads >= 1:
                role_name = 'decode_lookup'
            elif index_metatable_hits >= 1 and writes >= 1:
                role_name = 'decoded_cache'

            if role_name and table_name not in rename_map:
                rename_map[table_name] = allocate_name(role_name)

        # Propagate semantic names through immediate aliases in the bootstrap region.
        for line_text in prefix_lines:
            alias_match = simple_alias_pattern.match(line_text)
            if not alias_match:
                continue
            lhs_name, rhs_name = alias_match.groups()
            semantic_rhs = rename_map.get(rhs_name)
            if not semantic_rhs:
                continue
            if lhs_name in rename_map:
                continue
            if re.fullmatch(r'v\d+', lhs_name):
                base_name = f"{semantic_rhs}_ref"
            elif re.fullmatch(r'r\d+(?:_local)?', lhs_name):
                base_name = semantic_rhs
            else:
                base_name = f"{semantic_rhs}_alias"
            rename_map[lhs_name] = allocate_name(base_name)

        if not rename_map:
            return script_content
        return self._rewrite_lua_identifiers(script_content, rename_map)

    def _normalize_prometheus_semantic_suffixes(self, script_content):
        normalized = re.sub(r'(?:_alias){2,}\b', '_alias', script_content)
        normalized = re.sub(r'(?:_ref){2,}\b', '_ref', normalized)
        normalized = re.sub(
            r'((?:_alias|_ref)(?:_\d+)?)(?:_(?:alias|ref)(?:_\d+)?)+\b',
            r'\1',
            normalized
        )
        return normalized

    def _repair_invalid_for_counter_expressions(self, script_content):
        def replace_counter(match_object):
            return f"{match_object.group(1)}for {match_object.group(2)} ="

        repaired = re.sub(
            r'^(\s*)for\s+\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*-\s*(?:[A-Za-z_][A-Za-z0-9_]*|\d+(?:\.\d+)?)\s*\)\s*=',
            replace_counter,
            script_content,
            flags=re.MULTILINE
        )
        return repaired

    def _rename_prometheus_registers_to_generic_locals(self, script_content):
        candidate_pattern = re.compile(r'^(?:r\d+(?:_local)?|tmp_\d+(?:_\d+)?)$')
        token_pattern = re.compile(r'\b[A-Za-z_][A-Za-z0-9_]*\b')

        seen_order = []
        seen_set = set()
        for match_object in token_pattern.finditer(script_content):
            token = match_object.group(0)
            if token in seen_set:
                continue
            seen_set.add(token)
            seen_order.append(token)

        existing_names = set(seen_set)
        rename_map = {}
        counter = 1

        for token in seen_order:
            if not candidate_pattern.fullmatch(token):
                continue
            while True:
                candidate_name = f"local_{counter}"
                counter += 1
                if candidate_name not in existing_names and candidate_name not in rename_map.values():
                    break
            rename_map[token] = candidate_name

        if not rename_map:
            return script_content
        return self._rewrite_lua_identifiers(script_content, rename_map)

    def _compress_prometheus_anti_decoder_preamble(self, script_content):
        lines = script_content.splitlines()
        if not lines:
            return script_content

        decode_alias_pattern = re.compile(
            r'^\s*(?:local\s+)?decode_runtime_string(?:_\d+)?\s*=\s*[A-Za-z_][A-Za-z0-9_]*\s*$'
        )
        decode_function_pattern = re.compile(
            r'^\s*(?:local\s+)?decode_runtime_string(?:_\d+)?\s*=\s*function\([^)]*\)\s*$'
        )
        simple_assign_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\s*$'
        )
        setmeta_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*setmetatable\s*\('
        )

        decode_index = None
        decode_end_index = None
        for index, line_text in enumerate(lines):
            stripped = line_text.strip()
            if decode_alias_pattern.match(stripped):
                decode_index = index
                decode_end_index = index
                break
            if decode_function_pattern.match(stripped):
                decode_index = index
                decode_end_index = self._find_matching_block_end_line(lines, index)
                if decode_end_index == -1:
                    return script_content
                break
        if decode_index is None:
            return script_content

        preamble_text = '\n'.join(lines[:decode_end_index + 1])
        if '35184372088832' not in preamble_text:
            return script_content
        if 'string.byte' not in preamble_text or 'table.remove' not in preamble_text:
            return script_content

        start_candidates = []
        for index, line_text in enumerate(lines[:decode_end_index + 1]):
            stripped = line_text.strip()
            if (
                'math.floor' in stripped
                or stripped.endswith('= {}')
                or 'table.remove' in stripped
                or 'string.char' in stripped
            ):
                start_candidates.append(index)
        if not start_candidates:
            return script_content
        start_index = min(start_candidates)
        removable_prefix_pattern = re.compile(
            r'^\s*(?:local\s+)?[A-Za-z_][A-Za-z0-9_,\s]*(?:=\s*(?:nil|math|table|string|[A-Za-z_][A-Za-z0-9_]*))?\s*$'
        )
        while start_index > 0:
            previous_line = lines[start_index - 1].strip()
            if not previous_line or 'unpack' in previous_line:
                break
            if not removable_prefix_pattern.match(previous_line):
                break
            start_index -= 1

        # Keep the cache proxy variable name used by the downstream script
        # (often v1 / local_XX).
        cache_name_candidates = []
        alias_map = {}
        for line_text in lines[start_index:decode_end_index + 1]:
            setmeta_match = setmeta_pattern.match(line_text.strip())
            if setmeta_match:
                cache_name_candidates.append(setmeta_match.group(1))
            alias_match = simple_assign_pattern.match(line_text.strip())
            if alias_match:
                alias_map[alias_match.group(1)] = alias_match.group(2)

        expanded_candidates = list(cache_name_candidates)
        changed = True
        while changed:
            changed = False
            for lhs_name, rhs_name in alias_map.items():
                if rhs_name in expanded_candidates and lhs_name not in expanded_candidates:
                    expanded_candidates.append(lhs_name)
                    changed = True

        tail_text = '\n'.join(lines[decode_end_index + 1:])
        cache_proxy_name = None
        best_score = -1
        for candidate in expanded_candidates:
            score = len(re.findall(rf'\b{re.escape(candidate)}\s*\[', tail_text))
            if score > best_score:
                best_score = score
                cache_proxy_name = candidate
        if not cache_proxy_name:
            cache_proxy_name = 'v1'

        decoder_function_name = 'decode_runtime_string'
        for line_text in lines[:decode_end_index + 1]:
            fn_match = decode_function_pattern.match(line_text.strip())
            if fn_match:
                name_match = re.match(r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=', line_text.strip())
                if name_match:
                    decoder_function_name = name_match.group(1)
                break
        decoder_constants = self._extract_prometheus_runtime_decoder_constants(preamble_text)
        if decoder_constants is None:
            decoder_constants = getattr(self, '_pipeline_prng_decoder_constants', None)
        mul45_value = decoder_constants['mul45'] if decoder_constants else 37
        add45_value = decoder_constants['add45'] if decoder_constants else 30151477114583
        mul8_value = decoder_constants['mul8'] if decoder_constants else 155
        mod45_value = 35184372088832

        key8_value = self._extract_prometheus_runtime_key8_constant(
            script_content,
            decoder_function_name,
            decode_index
        )
        if key8_value is None:
            key8_value = getattr(self, '_pipeline_prng_key8_value', None)
        if key8_value is None:
            key8_value = 241

        block_lines = [
            "local floor_fn = math.floor",
            "local random_fn = math.random",
            "local lookup = {}",
            "local remove_fn = table.remove",
            "local items = {}",
            "local char_fn = string.char",
            "for i = 1, 256, 1 do",
            "    lookup[i] = i",
            "end",
            "repeat",
            "    local pick_index = random_fn(1, #lookup)",
            "    local picked = remove_fn(lookup, pick_index)",
            "    items[picked] = char_fn(picked - 1)",
            "until #lookup == 0",
            "local prng_bytes = {}",
            "local prng_seed = 0",
            "local prng_state8 = 2",
            "local next_prng_byte = function()",
            "    if #prng_bytes == 0 then",
            f"        prng_seed = (prng_seed * {mul45_value} + {add45_value}) % {mod45_value}",
            "        repeat",
            f"            prng_state8 = (prng_state8 * {mul8_value}) % 257",
            "        until prng_state8 ~= 1",
            "        local remainder = prng_state8 % 32",
            "        local shift = 13 - ((prng_state8 - remainder) / 32)",
            "        local n = floor_fn(prng_seed / 2 ^ shift)",
            "        local mixed = floor_fn((((n % 4294967296) / 2 ^ remainder) % 1) * 4294967296) + floor_fn((n % 4294967296) / 2 ^ remainder)",
            "        local low = mixed % 65536",
            "        local high = (mixed - low) / 65536",
            "        local b1 = low % 256",
            "        local b2 = (low - b1) / 256",
            "        local b3 = high % 256",
            "        local b4 = (high - b3) / 256",
            "        prng_bytes = { b1, b2, b3, b4 }",
            "    end",
            "    return remove_fn(prng_bytes)",
            "end",
            "local decoded_cache = {}",
            f"local {cache_proxy_name} = setmetatable({{}}, {{ __index = decoded_cache }})",
            f"local {decoder_function_name} = function(encoded_text, cache_key)",
            "    if not decoded_cache[cache_key] then",
            "        local input_len = string.len(encoded_text)",
            "        local decoded_text = \"\"",
            "        for i = 1, input_len, 1 do",
            "            local byte_value = string.byte(encoded_text, i)",
            f"            local lookup_index = (byte_value + next_prng_byte() + {key8_value}) % 256 + 1",
            "            decoded_text = decoded_text .. items[lookup_index]",
            "        end",
            "        decoded_cache[cache_key] = decoded_text",
            "    end",
            "    return decoded_cache[cache_key]",
            "end",
        ]

        rewritten = []
        rewritten.extend(lines[:start_index])
        rewritten.extend(block_lines)
        rewritten.extend(lines[decode_end_index + 1:])
        rewritten_text = '\n'.join(rewritten)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _canonicalize_prometheus_anti_preamble_symbols(self, script_content):
        lines = script_content.splitlines()
        assign_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*$'
        )
        simple_alias_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\s*$'
        )

        # Focus only the anti/decoder preamble region.
        cutoff = len(lines)
        for index, line_text in enumerate(lines):
            stripped = line_text.strip()
            if re.match(r'^(?:local\s+)?decode_runtime_string\b', stripped):
                cutoff = index + 1
                break
            if ':WaitForChild("HumanoidRootPart")' in stripped:
                cutoff = index
                break
        if cutoff <= 0:
            return script_content

        prefix_lines = lines[:cutoff]
        prefix_text = '\n'.join(prefix_lines)
        if '35184372088832' not in prefix_text:
            return script_content

        alias_map = {}
        base_aliases = {}
        for line_text in prefix_lines:
            alias_match = simple_alias_pattern.match(line_text)
            if alias_match:
                alias_map[alias_match.group(1)] = alias_match.group(2)
            assign_match = assign_pattern.match(line_text)
            if assign_match:
                lhs_name, rhs_text = assign_match.groups()
                rhs_value = rhs_text.strip().rstrip(';').strip()
                if rhs_value in {'math', 'table', 'string'}:
                    base_aliases[lhs_name] = rhs_value
                elif re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', rhs_value):
                    base_aliases[lhs_name] = base_aliases.get(rhs_value, base_aliases.get(lhs_name))

        def resolve_alias(name_text):
            seen = set()
            current = name_text
            while current in alias_map and current not in seen:
                seen.add(current)
                next_name = alias_map[current]
                if next_name == current:
                    break
                current = next_name
            return current

        existing_names = set(re.findall(r'\b[A-Za-z_][A-Za-z0-9_]*\b', script_content))
        rename_map = {}

        def reserve_name(base_name):
            if base_name not in existing_names:
                existing_names.add(base_name)
                return base_name
            return None

        # Builtin aliases.
        builtin_hits = {}
        for line_text in prefix_lines:
            assign_match = assign_pattern.match(line_text)
            if not assign_match:
                continue
            lhs_name, rhs_text = assign_match.groups()
            rhs_value = rhs_text.strip().rstrip(';').strip()
            target = None
            if rhs_value == 'math.floor':
                target = 'floor_fn'
            elif rhs_value == 'math.random':
                target = 'random_fn'
            elif rhs_value == 'table.remove':
                target = 'remove_fn'
            elif rhs_value == 'string.char':
                target = 'char_fn'
            else:
                dotted_match = re.fullmatch(
                    r'([A-Za-z_][A-Za-z0-9_]*)\.(floor|random|remove|char)',
                    rhs_value
                )
                if dotted_match:
                    base_name, member_name = dotted_match.groups()
                    resolved_base = resolve_alias(base_name)
                    resolved_base_kind = base_aliases.get(resolved_base) or base_aliases.get(base_name)
                    if resolved_base_kind == 'math' and member_name == 'floor':
                        target = 'floor_fn'
                    elif resolved_base_kind == 'math' and member_name == 'random':
                        target = 'random_fn'
                    elif resolved_base_kind == 'table' and member_name == 'remove':
                        target = 'remove_fn'
                    elif resolved_base_kind == 'string' and member_name == 'char':
                        target = 'char_fn'
            if target:
                builtin_hits.setdefault(target, []).append(lhs_name)

        for target_name, source_list in builtin_hits.items():
            canonical = reserve_name(target_name)
            if not canonical:
                continue
            # Prefer the earliest source for deterministic canonicalization.
            rename_map[source_list[0]] = canonical

        # Table role heuristics.
        table_vars = []
        for line_text in prefix_lines:
            assign_match = assign_pattern.match(line_text)
            if not assign_match:
                continue
            lhs_name, rhs_text = assign_match.groups()
            if rhs_text.strip().rstrip(';').strip() == '{}':
                table_vars.append(lhs_name)

        def table_score_lookup(table_name):
            writes = len(re.findall(rf'\b{re.escape(table_name)}\s*\[\s*.+?\s*\]\s*=', prefix_text))
            len_uses = len(re.findall(rf'#\s*{re.escape(table_name)}\b', prefix_text))
            remove_calls = len(
                re.findall(
                    rf'(?:table\.remove|[A-Za-z_][A-Za-z0-9_]*)\s*\(\s*{re.escape(table_name)}\s*,',
                    prefix_text
                )
            )
            return writes + len_uses + remove_calls

        def table_score_items(table_name):
            return len(
                re.findall(
                    rf'\b{re.escape(table_name)}\s*\[\s*[A-Za-z_][A-Za-z0-9_]*\s*\]\s*=\s*string\.char\(',
                    prefix_text
                )
            )

        lookup_var = None
        items_var = None
        if table_vars:
            lookup_candidates = sorted(
                table_vars,
                key=lambda name: (table_score_lookup(name), -table_vars.index(name)),
                reverse=True
            )
            if lookup_candidates and table_score_lookup(lookup_candidates[0]) > 0:
                lookup_var = lookup_candidates[0]

            item_candidates = sorted(
                [name for name in table_vars if name != lookup_var],
                key=lambda name: (table_score_items(name), -table_vars.index(name)),
                reverse=True
            )
            if item_candidates and table_score_items(item_candidates[0]) > 0:
                items_var = item_candidates[0]

        if lookup_var:
            canonical_lookup = reserve_name('lookup')
            if canonical_lookup:
                rename_map[lookup_var] = canonical_lookup
        if items_var:
            canonical_items = reserve_name('items')
            if canonical_items:
                rename_map[items_var] = canonical_items

        # Decoded cache table (metatable __index target).
        cache_match = re.search(
            r'__index\s*\]\s*=\s*([A-Za-z_][A-Za-z0-9_]*)|__index\s*=\s*([A-Za-z_][A-Za-z0-9_]*)',
            prefix_text
        )
        if cache_match:
            cache_var = cache_match.group(1) or cache_match.group(2)
            canonical_cache = reserve_name('decoded_cache')
            if canonical_cache:
                rename_map[cache_var] = canonical_cache

        if not rename_map:
            return script_content
        return self._rewrite_lua_identifiers(script_content, rename_map)

    def _collapse_prometheus_lookup_init_while(self, script_content):
        lines = script_content.splitlines()
        assign_pattern = re.compile(r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*$')
        while_pattern = re.compile(r'^\s*while\s+true\s+do\s*$')
        if_not_pattern = re.compile(r'^\s*if\s+not\s+([A-Za-z_][A-Za-z0-9_]*)\s+then\s*$')
        table_set_pattern = re.compile(
            r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*\[\s*([A-Za-z_][A-Za-z0-9_]*)\s*\]\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\s*$'
        )

        rewritten = []
        index = 0

        def find_dir_var(step_name, anchor_index):
            probe = anchor_index - 1
            lower_bound = max(0, anchor_index - 8)
            while probe >= lower_bound:
                probe_match = assign_pattern.match(lines[probe].strip())
                if probe_match:
                    lhs_probe, rhs_probe = probe_match.groups()
                    if re.fullmatch(rf'{re.escape(step_name)}\s*<\s*0', rhs_probe.strip()):
                        return lhs_probe
                probe -= 1
            return None

        number_pattern = re.compile(r'[-+]?(?:\d+(?:\.\d+)?|\.\d+)')

        def resolve_numeric_token(token_text, anchor_index):
            token_clean = token_text.strip()
            if number_pattern.fullmatch(token_clean):
                return token_clean
            if not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', token_clean):
                return token_clean

            seen_tokens = set()
            current = token_clean
            for _ in range(3):
                if current in seen_tokens:
                    break
                seen_tokens.add(current)
                resolved_rhs = None
                probe = anchor_index - 1
                lower_bound = max(0, anchor_index - 40)
                while probe >= lower_bound:
                    probe_match = assign_pattern.match(lines[probe].strip())
                    if probe_match and probe_match.group(1) == current:
                        resolved_rhs = probe_match.group(2).strip()
                        break
                    probe -= 1
                if not resolved_rhs:
                    break
                if number_pattern.fullmatch(resolved_rhs):
                    return resolved_rhs
                if re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', resolved_rhs):
                    current = resolved_rhs
                    continue
                break
            return token_clean

        while index < len(lines):
            if not while_pattern.match(lines[index]):
                rewritten.append(lines[index])
                index += 1
                continue

            if index < 3:
                rewritten.append(lines[index])
                index += 1
                continue

            # Fallback pattern after condition simplification:
            # while true do
            #   i = i + step
            #   cond = ((not dir) and (i <= limit)) or (dir and (i >= limit))
            #   if not cond then
            #       break
            #   end
            #   t = i
            #   x = t
            #   table[t] = x
            # end
            if index + 9 < len(lines):
                prev1_simple = assign_pattern.match(lines[index - 1].strip())
                prev2_simple = assign_pattern.match(lines[index - 2].strip())
                m1_simple = assign_pattern.match(lines[index + 1].strip())
                m2_simple = assign_pattern.match(lines[index + 2].strip())
                m3_simple = if_not_pattern.match(lines[index + 3].strip())
                m4_simple = lines[index + 4].strip() == 'break'
                m5_simple = lines[index + 5].strip() == 'end'
                m6_simple = assign_pattern.match(lines[index + 6].strip())
                m7_simple = assign_pattern.match(lines[index + 7].strip())
                m8_simple = table_set_pattern.match(lines[index + 8].strip())
                m9_simple = lines[index + 9].strip() == 'end'

                if all([prev1_simple, m1_simple, m2_simple, m3_simple, m4_simple, m5_simple, m6_simple, m7_simple, m8_simple, m9_simple]):
                    counter_var, counter_rhs = prev1_simple.groups()
                    dir_rhs = prev2_simple.group(2) if prev2_simple else ''
                    counter_init_match = re.fullmatch(
                        r'([A-Za-z_][A-Za-z0-9_]*|\d+(?:\.\d+)?)\s*-\s*([A-Za-z_][A-Za-z0-9_]*)',
                        counter_rhs.strip()
                    )
                    dir_match = re.fullmatch(
                        r'([A-Za-z_][A-Za-z0-9_]*)\s*<\s*0',
                        dir_rhs.strip()
                    ) if prev2_simple else None
                    if counter_init_match:
                        start_var, step_var = counter_init_match.groups()
                        dir_var_candidate = prev2_simple.group(1) if dir_match and prev2_simple else find_dir_var(step_var, index)
                        if dir_var_candidate:
                            lhs1, rhs1 = m1_simple.groups()
                            lhs2, rhs2 = m2_simple.groups()
                            guard_var = m3_simple.group(1)
                            lhs6, rhs6 = m6_simple.groups()
                            lhs7, rhs7 = m7_simple.groups()
                            tbl8, key8, val8 = m8_simple.groups()

                            cond_simple = re.fullmatch(
                                rf'\(\(not\s+{re.escape(dir_var_candidate)}\)\s+and\s+\({re.escape(counter_var)}\s*<=\s*([A-Za-z_][A-Za-z0-9_]*|\d+)\)\)\s+or\s+\({re.escape(dir_var_candidate)}\s+and\s+\({re.escape(counter_var)}\s*>=\s*([A-Za-z_][A-Za-z0-9_]*|\d+)\)\)',
                                rhs2.strip()
                            )
                            if (
                                lhs1 == counter_var
                                and re.fullmatch(rf'{re.escape(counter_var)}\s*\+\s*{re.escape(step_var)}', rhs1.strip())
                                and lhs2 == guard_var
                                and cond_simple
                                and cond_simple.group(1) == cond_simple.group(2)
                                and lhs6 == key8
                                and lhs7 == val8
                                and rhs6.strip() == counter_var
                                and rhs7.strip() == lhs6
                            ):
                                limit_var = cond_simple.group(1)
                                start_render = resolve_numeric_token(start_var, index)
                                limit_render = resolve_numeric_token(limit_var, index)
                                step_render = resolve_numeric_token(step_var, index)
                                indent = lines[index][:len(lines[index]) - len(lines[index].lstrip(' \t'))]
                                inner_indent = indent + '    '
                                rewritten.append(f"{indent}for {lhs6} = {start_render}, {limit_render}, {step_render} do")
                                rewritten.append(f"{inner_indent}{tbl8}[{lhs6}] = {lhs6}")
                                rewritten.append(f"{indent}end")
                                index += 10
                                continue

            # Alternate unsimplified order:
            #   i = i + step
            #   cond = i <= limit
            #   flag = not dir
            #   cond = flag and cond
            #   flag = i >= limit
            #   flag = dir and flag
            #   cond = flag or cond
            if index + 14 < len(lines):
                prev1_alt = assign_pattern.match(lines[index - 1].strip())
                prev2_alt = assign_pattern.match(lines[index - 2].strip())
                a1 = assign_pattern.match(lines[index + 1].strip())
                a2 = assign_pattern.match(lines[index + 2].strip())
                a3 = assign_pattern.match(lines[index + 3].strip())
                a4 = assign_pattern.match(lines[index + 4].strip())
                a5 = assign_pattern.match(lines[index + 5].strip())
                a6 = assign_pattern.match(lines[index + 6].strip())
                a7 = assign_pattern.match(lines[index + 7].strip())
                a8 = if_not_pattern.match(lines[index + 8].strip())
                a9 = lines[index + 9].strip() == 'break'
                a10 = lines[index + 10].strip() == 'end'
                a11 = assign_pattern.match(lines[index + 11].strip())
                a12 = assign_pattern.match(lines[index + 12].strip())
                a13 = table_set_pattern.match(lines[index + 13].strip())
                a14 = lines[index + 14].strip() == 'end'

                if all([prev1_alt, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14]):
                    counter_var, counter_rhs = prev1_alt.groups()
                    dir_rhs = prev2_alt.group(2) if prev2_alt else ''
                    counter_init_match = re.fullmatch(
                        r'([A-Za-z_][A-Za-z0-9_]*|\d+(?:\.\d+)?)\s*-\s*([A-Za-z_][A-Za-z0-9_]*)',
                        counter_rhs.strip()
                    )
                    dir_match = re.fullmatch(
                        r'([A-Za-z_][A-Za-z0-9_]*)\s*<\s*0',
                        dir_rhs.strip()
                    ) if prev2_alt else None
                    if counter_init_match:
                        start_var, step_var = counter_init_match.groups()
                        dir_var_candidate = prev2_alt.group(1) if dir_match and prev2_alt else find_dir_var(step_var, index)
                        if dir_var_candidate:
                            l1, r1 = a1.groups()
                            l2, r2 = a2.groups()
                            l3, r3 = a3.groups()
                            l4, r4 = a4.groups()
                            l5, r5 = a5.groups()
                            l6, r6 = a6.groups()
                            l7, r7 = a7.groups()
                            guard_var = a8.group(1)
                            l11, r11 = a11.groups()
                            l12, r12 = a12.groups()
                            tbl13, key13, val13 = a13.groups()

                            limit_match = re.fullmatch(
                                rf'{re.escape(counter_var)}\s*<=\s*([A-Za-z_][A-Za-z0-9_]*|\d+)',
                                r2.strip()
                            )
                            if (
                                l1 == counter_var
                                and re.fullmatch(rf'{re.escape(counter_var)}\s*\+\s*{re.escape(step_var)}', r1.strip())
                                and limit_match
                                and l3 == l5 == l6
                                and l2 == l4 == l7 == guard_var
                                and re.fullmatch(rf'not\s+{re.escape(dir_var_candidate)}', r3.strip())
                                and re.fullmatch(rf'{re.escape(l3)}\s*and\s*{re.escape(l2)}', r4.strip())
                                and re.fullmatch(rf'{re.escape(counter_var)}\s*>=\s*{re.escape(limit_match.group(1))}', r5.strip())
                                and re.fullmatch(rf'{re.escape(dir_var_candidate)}\s*and\s*{re.escape(l3)}', r6.strip())
                                and re.fullmatch(rf'{re.escape(l3)}\s*or\s*{re.escape(l2)}', r7.strip())
                                and l11 == key13 and l12 == val13
                                and r11.strip() == counter_var and r12.strip() == l11
                            ):
                                limit_var = limit_match.group(1)
                                start_render = resolve_numeric_token(start_var, index)
                                limit_render = resolve_numeric_token(limit_var, index)
                                step_render = resolve_numeric_token(step_var, index)
                                indent = lines[index][:len(lines[index]) - len(lines[index].lstrip(' \t'))]
                                inner_indent = indent + '    '
                                rewritten.append(f"{indent}for {l11} = {start_render}, {limit_render}, {step_render} do")
                                rewritten.append(f"{inner_indent}{tbl13}[{l11}] = {l11}")
                                rewritten.append(f"{indent}end")
                                index += 15
                                continue

            # Expect:
            #   local dir = step < 0
            #   local counter = start - step
            prev1 = assign_pattern.match(lines[index - 1].strip())
            prev2 = assign_pattern.match(lines[index - 2].strip())
            if not prev1:
                rewritten.append(lines[index])
                index += 1
                continue

            counter_var, counter_rhs = prev1.groups()
            dir_rhs = prev2.group(2) if prev2 else ''
            counter_init_match = re.fullmatch(
                r'([A-Za-z_][A-Za-z0-9_]*|\d+(?:\.\d+)?)\s*-\s*([A-Za-z_][A-Za-z0-9_]*)',
                counter_rhs.strip()
            )
            dir_match = re.fullmatch(
                r'([A-Za-z_][A-Za-z0-9_]*)\s*<\s*0',
                dir_rhs.strip()
            ) if prev2 else None
            if not counter_init_match:
                rewritten.append(lines[index])
                index += 1
                continue

            start_var, step_var = counter_init_match.groups()
            dir_var_candidate = prev2.group(1) if dir_match and prev2 else find_dir_var(step_var, index)
            if not dir_var_candidate:
                rewritten.append(lines[index])
                index += 1
                continue

            if index + 14 >= len(lines):
                rewritten.append(lines[index])
                index += 1
                continue

            m0 = assign_pattern.match(lines[index + 1].strip())
            m1 = assign_pattern.match(lines[index + 2].strip())
            m2 = assign_pattern.match(lines[index + 3].strip())
            m3 = assign_pattern.match(lines[index + 4].strip())
            m4 = assign_pattern.match(lines[index + 5].strip())
            m5 = assign_pattern.match(lines[index + 6].strip())
            m6 = assign_pattern.match(lines[index + 7].strip())
            m7 = if_not_pattern.match(lines[index + 8].strip())
            m8 = assign_pattern.match(lines[index + 11].strip())
            m9 = assign_pattern.match(lines[index + 12].strip())
            m10 = table_set_pattern.match(lines[index + 13].strip())
            end_line = lines[index + 14].strip()
            if not all([m0, m1, m2, m3, m4, m5, m6, m7, m8, m9, m10]):
                rewritten.append(lines[index])
                index += 1
                continue
            if end_line != 'end':
                rewritten.append(lines[index])
                index += 1
                continue

            flag_var, rhs0 = m0.groups()
            counter_lhs, rhs1 = m1.groups()
            cond_var, rhs2 = m2.groups()
            cond_lhs_2, rhs3 = m3.groups()
            flag_lhs_2, rhs4 = m4.groups()
            flag_lhs_3, rhs5 = m5.groups()
            cond_lhs_3, rhs6 = m6.groups()
            if_guard_var = m7.group(1)
            idx_lhs, rhs8 = m8.groups()
            tmp_lhs, rhs9 = m9.groups()
            table_name, table_key, table_value = m10.groups()

            if counter_lhs != counter_var:
                rewritten.append(lines[index])
                index += 1
                continue
            if not re.fullmatch(rf'{re.escape(counter_var)}\s*\+\s*{re.escape(step_var)}', rhs1.strip()):
                rewritten.append(lines[index])
                index += 1
                continue
            if cond_var != cond_lhs_2 or cond_var != cond_lhs_3 or if_guard_var != cond_var:
                rewritten.append(lines[index])
                index += 1
                continue
            if flag_var != flag_lhs_2 or flag_var != flag_lhs_3:
                rewritten.append(lines[index])
                index += 1
                continue
            if idx_lhs != table_key or tmp_lhs != table_value:
                rewritten.append(lines[index])
                index += 1
                continue
            if rhs8.strip() != counter_var or rhs9.strip() != idx_lhs:
                rewritten.append(lines[index])
                index += 1
                continue

            limit_match = re.fullmatch(
                rf'{re.escape(counter_var)}\s*<=\s*([A-Za-z_][A-Za-z0-9_]*|\d+)',
                rhs2.strip()
            )
            if not limit_match:
                rewritten.append(lines[index])
                index += 1
                continue
            limit_var = limit_match.group(1)
            start_render = resolve_numeric_token(start_var, index)
            limit_render = resolve_numeric_token(limit_var, index)
            step_render = resolve_numeric_token(step_var, index)

            indent = lines[index][:len(lines[index]) - len(lines[index].lstrip(' \t'))]
            inner_indent = indent + '    '
            rewritten.append(f"{indent}for {idx_lhs} = {start_render}, {limit_render}, {step_render} do")
            rewritten.append(f"{inner_indent}{table_name}[{idx_lhs}] = {idx_lhs}")
            rewritten.append(f"{indent}end")
            index += 15

        rewritten_text = '\n'.join(rewritten)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _collapse_prometheus_lookup_shuffle_repeat(self, script_content):
        lines = script_content.splitlines()
        assign_pattern = re.compile(r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*$')
        repeat_pattern = re.compile(r'^\s*repeat\s*$')
        until_pattern = re.compile(r'^\s*until\s+([A-Za-z_][A-Za-z0-9_]*)\s*$')

        rewritten = []
        index = 0
        while index < len(lines):
            if not repeat_pattern.match(lines[index]):
                rewritten.append(lines[index])
                index += 1
                continue

            window_end = min(len(lines), index + 20)
            until_index = None
            until_var = None
            for probe in range(index + 1, window_end):
                until_match = until_pattern.match(lines[probe].strip())
                if until_match:
                    until_index = probe
                    until_var = until_match.group(1)
                    break
            if until_index is None:
                rewritten.append(lines[index])
                index += 1
                continue

            body = lines[index + 1:until_index]
            if len(body) < 8:
                rewritten.append(lines[index])
                index += 1
                continue

            assigns = []
            for body_line in body:
                m = assign_pattern.match(body_line.strip())
                if m:
                    assigns.append(m.groups())

            # Minimal required signals.
            has_random = None
            has_remove = None
            table_name = None
            pick_var = None
            removed_var = None
            map_table_var = None
            one_vars = set()

            for lhs, rhs in assigns:
                if rhs.strip() == '1':
                    one_vars.add(lhs)
                random_match = re.fullmatch(
                    r'(?:math\.random|random_fn)\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*,\s*([A-Za-z_][A-Za-z0-9_]*)\s*\)',
                    rhs.strip()
                )
                if random_match:
                    has_random = (lhs, random_match.group(1), random_match.group(2))
                    pick_var = lhs
                    continue
                remove_match = re.fullmatch(
                    r'(?:table\.remove|remove_fn)\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*,\s*([A-Za-z_][A-Za-z0-9_]*)\s*\)',
                    rhs.strip()
                )
                if remove_match:
                    has_remove = (lhs, remove_match.group(1), remove_match.group(2))
                    removed_var = lhs
                    table_name = remove_match.group(1)
                    continue

            if not has_random or not has_remove or not table_name or not pick_var or not removed_var:
                rewritten.append(lines[index])
                index += 1
                continue

            if has_remove[2] != pick_var:
                rewritten.append(lines[index])
                index += 1
                continue

            # Find map assignment: map[var_removed] = string.char(var_removed - 1)
            map_line_match = None
            for body_line in body:
                map_line = body_line.strip()
                direct_match = re.fullmatch(
                    rf'([A-Za-z_][A-Za-z0-9_]*)\[\s*{re.escape(removed_var)}\s*\]\s*=\s*string\.char\(\s*{re.escape(removed_var)}\s*-\s*1\s*\)',
                    map_line
                )
                if direct_match:
                    map_line_match = (direct_match.group(1), True)
                    break
                direct_var_match = re.fullmatch(
                    rf'([A-Za-z_][A-Za-z0-9_]*)\[\s*{re.escape(removed_var)}\s*\]\s*=\s*string\.char\(\s*{re.escape(removed_var)}\s*-\s*([A-Za-z_][A-Za-z0-9_]*)\s*\)',
                    map_line
                )
                if direct_var_match and direct_var_match.group(2) in one_vars:
                    map_line_match = (direct_var_match.group(1), True)
                    break

            if map_line_match is None:
                # Allow 2-step variant: tmp = removed - 1; ch = string.char(tmp); map[removed] = ch
                minus_var = None
                char_var = None
                for lhs, rhs in assigns:
                    if re.fullmatch(rf'{re.escape(removed_var)}\s*-\s*1', rhs.strip()):
                        minus_var = lhs
                    else:
                        minus_var_match = re.fullmatch(
                            rf'{re.escape(removed_var)}\s*-\s*([A-Za-z_][A-Za-z0-9_]*)',
                            rhs.strip()
                        )
                        if minus_var_match and minus_var_match.group(1) in one_vars:
                            minus_var = lhs
                    if minus_var and re.fullmatch(rf'string\.char\(\s*{re.escape(minus_var)}\s*\)', rhs.strip()):
                        char_var = lhs
                if char_var:
                    for body_line in body:
                        map_match = re.fullmatch(
                            rf'\s*([A-Za-z_][A-Za-z0-9_]*)\[\s*{re.escape(removed_var)}\s*\]\s*=\s*{re.escape(char_var)}\s*',
                            body_line
                        )
                        if map_match:
                            map_line_match = (map_match.group(1), False)
                            break

            if map_line_match is None:
                rewritten.append(lines[index])
                index += 1
                continue
            map_table_var = map_line_match[0]

            # Resolve transient aliases used just before map assignment
            # (e.g. tmp = v4; tmp[idx] = ...).
            local_alias_links = {}
            for lhs_a, rhs_a in assigns:
                rhs_clean = rhs_a.strip()
                if re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', rhs_clean):
                    local_alias_links[lhs_a] = rhs_clean

            def resolve_local_alias(name_text):
                seen_local = set()
                current_local = name_text
                while current_local in local_alias_links and current_local not in seen_local:
                    seen_local.add(current_local)
                    current_local = local_alias_links[current_local]
                return current_local

            resolved_map_table = resolve_local_alias(map_table_var)
            resolved_via_local_alias = resolved_map_table != map_table_var
            if resolved_map_table != map_table_var and resolved_map_table != table_name:
                map_table_var = resolved_map_table

            # Choose a safer map-table when direct target got polluted by
            # arithmetic/count temporaries after prior simplification passes.
            prefix_start = max(0, index - 80)
            seed_tables = []
            alias_links = {}
            for p in range(prefix_start, index):
                ap = assign_pattern.match(lines[p].strip())
                if not ap:
                    continue
                lhs_p, rhs_p = ap.groups()
                rhs_clean = rhs_p.strip()
                if rhs_clean == '{}':
                    seed_tables.append(lhs_p)
                elif re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', rhs_clean):
                    alias_links[lhs_p] = rhs_clean

            def resolve_alias(name_text):
                seen = set()
                current = name_text
                while current in alias_links and current not in seen:
                    seen.add(current)
                    current = alias_links[current]
                return current

            numeric_like_vars = {pick_var, removed_var, has_random[2]}
            for lhs_a, rhs_a in assigns:
                if re.fullmatch(rf'#\s*{re.escape(table_name)}', rhs_a.strip()):
                    numeric_like_vars.add(lhs_a)
                if rhs_a.strip() == '0':
                    numeric_like_vars.add(lhs_a)

            fallback_root = None
            for candidate in reversed(seed_tables):
                if candidate != table_name:
                    fallback_root = candidate
                    break

            if (
                not resolved_via_local_alias
                and (
                map_table_var in numeric_like_vars
                or (fallback_root and resolve_alias(map_table_var) not in {fallback_root, table_name})
                )
            ):
                if fallback_root:
                    map_table_var = fallback_root

            # Validate until condition computed from #table == 0
            until_ok = False
            for lhs, rhs in assigns:
                if lhs != until_var:
                    continue
                if re.fullmatch(rf'#\s*{re.escape(table_name)}\s*==\s*0', rhs.strip()):
                    until_ok = True
                    break
            if not until_ok:
                # check two-step: x=#table; y=0; until_var=x==y
                count_var = None
                zero_var = None
                for lhs, rhs in assigns:
                    if re.fullmatch(rf'#\s*{re.escape(table_name)}', rhs.strip()):
                        count_var = lhs
                    if rhs.strip() == '0':
                        zero_var = lhs
                if count_var and zero_var:
                    for lhs, rhs in assigns:
                        if lhs == until_var and re.fullmatch(rf'{re.escape(count_var)}\s*==\s*{re.escape(zero_var)}', rhs.strip()):
                            until_ok = True
                            break
            if not until_ok:
                rewritten.append(lines[index])
                index += 1
                continue

            indent = lines[index][:len(lines[index]) - len(lines[index].lstrip(' \t'))]
            inner_indent = indent + '    '
            random_start_arg = has_random[1]
            if random_start_arg in one_vars:
                random_start_arg = '1'
            rewritten.append(f"{indent}repeat")
            rewritten.append(f"{inner_indent}{pick_var} = math.random({random_start_arg},#{table_name})")
            rewritten.append(f"{inner_indent}{removed_var} = table.remove({table_name},{pick_var})")
            rewritten.append(f"{inner_indent}{map_table_var}[{removed_var}] = string.char({removed_var} - 1)")
            rewritten.append(f"{indent}until #{table_name} == 0")
            index = until_index + 1

        rewritten_text = '\n'.join(rewritten)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _rename_prometheus_ui_construction_symbols(self, script_content):
        lines = script_content.splitlines()
        assign_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*$'
        )
        dot_set_pattern = re.compile(
            r'^\s*([A-Za-z_][A-Za-z0-9_]*)\.([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*$'
        )

        ui_start_index = None
        for idx, line_text in enumerate(lines):
            stripped = line_text.strip()
            if re.search(r':WaitForChild\("HumanoidRootPart"\)', stripped):
                ui_start_index = idx
                break
        if ui_start_index is None:
            for idx, line_text in enumerate(lines):
                if 'Instance.new("ScreenGui"' in line_text:
                    ui_start_index = max(0, idx - 1)
                    break
        if ui_start_index is None:
            return script_content

        prefix_lines = lines[:ui_start_index]
        tail_lines = lines[ui_start_index:]
        tail_text = '\n'.join(tail_lines) + ('\n' if script_content.endswith('\n') else '')

        existing_names = set(re.findall(r'\b[A-Za-z_][A-Za-z0-9_]*\b', tail_text))
        rename_map = {}

        def allocate(base_name):
            candidate = base_name
            suffix = 2
            while candidate in existing_names or candidate in rename_map.values():
                candidate = f"{base_name}_{suffix}"
                suffix += 1
            existing_names.add(candidate)
            return candidate

        screen_var = None
        frame_var = None
        title_label_var = None
        input_box_var = None
        toggle_button_var = None
        status_label_var = None
        close_button_var = None
        node_class = {}
        node_parent = {}

        # First pass: identify core UI nodes.
        for line_text in tail_lines:
            assign_match = assign_pattern.match(line_text)
            if not assign_match:
                continue
            lhs, rhs = assign_match.groups()
            rhs_value = rhs.strip().rstrip(';').strip()
            if re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*:WaitForChild\("HumanoidRootPart"\)', rhs_value):
                rename_map.setdefault(lhs, allocate('char_fn'))
            if re.fullmatch(r'game\.CoreGui', rhs_value):
                rename_map.setdefault(lhs, allocate('core_gui'))
            new_match = re.fullmatch(
                r'Instance\.new\("([A-Za-z_][A-Za-z0-9_]*)"\s*,\s*([A-Za-z_][A-Za-z0-9_]*)\)',
                rhs_value
            )
            if new_match:
                node_class[lhs] = new_match.group(1)
                node_parent[lhs] = new_match.group(2)
            if re.fullmatch(r'Instance\.new\("ScreenGui"\s*,\s*[A-Za-z_][A-Za-z0-9_]*\)', rhs_value):
                screen_var = lhs
                rename_map.setdefault(lhs, allocate('screen_gui'))
            if re.fullmatch(r'Instance\.new\("Frame"\s*,\s*[A-Za-z_][A-Za-z0-9_]*\)', rhs_value):
                parent = re.findall(r'Instance\.new\("Frame"\s*,\s*([A-Za-z_][A-Za-z0-9_]*)\)', rhs_value)
                if parent and (parent[0] == screen_var or rename_map.get(parent[0], parent[0]).startswith('screen_gui')):
                    frame_var = lhs
                    rename_map.setdefault(lhs, allocate('main_frame'))
            if re.fullmatch(r'Instance\.new\("TextBox"\s*,\s*[A-Za-z_][A-Za-z0-9_]*\)', rhs_value):
                parent = re.findall(r'Instance\.new\("TextBox"\s*,\s*([A-Za-z_][A-Za-z0-9_]*)\)', rhs_value)
                if parent and (parent[0] == frame_var or rename_map.get(parent[0], parent[0]).startswith('main_frame')):
                    input_box_var = lhs
                    rename_map.setdefault(lhs, allocate('input_box'))

        # Second pass: detect title label by text content.
        for line_text in tail_lines:
            set_match = dot_set_pattern.match(line_text)
            if not set_match:
                continue
            obj, prop, rhs = set_match.groups()
            if prop == 'Text' and '"UNIVERSAL AUTO FARM"' in rhs:
                title_label_var = obj
                rename_map.setdefault(obj, allocate('title_label'))
            if prop == 'Text' and '"Start: OFF"' in rhs:
                toggle_button_var = obj
                rename_map.setdefault(obj, allocate('toggle_button'))
            if prop == 'Text' and '"Status: Idle"' in rhs:
                status_label_var = obj
                rename_map.setdefault(obj, allocate('status_label'))
            if prop == 'Text' and re.fullmatch(r'"X"', rhs.strip()):
                close_button_var = obj
                rename_map.setdefault(obj, allocate('close_button'))

        # Fallback naming by class/parent when text patterns are absent.
        if frame_var:
            text_button_candidates = [
                name for name, klass in node_class.items()
                if klass == 'TextButton' and node_parent.get(name) == frame_var
            ]
            if text_button_candidates and not toggle_button_var:
                toggle_button_var = text_button_candidates[0]
                rename_map.setdefault(toggle_button_var, allocate('toggle_button'))
            if len(text_button_candidates) > 1 and not close_button_var:
                close_button_var = text_button_candidates[-1]
                rename_map.setdefault(close_button_var, allocate('close_button'))

        # Alias propagation for key UI vars.
        simple_alias_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\s*$'
        )
        for line_text in tail_lines:
            alias_match = simple_alias_pattern.match(line_text)
            if not alias_match:
                continue
            lhs, rhs = alias_match.groups()
            mapped = rename_map.get(rhs)
            if not mapped or lhs in rename_map:
                continue
            if mapped == 'char_fn':
                rename_map[lhs] = allocate('char_fn_ref')
            elif mapped.startswith('screen_gui'):
                rename_map[lhs] = allocate('screen_gui_ref')
            elif mapped.startswith('main_frame'):
                rename_map[lhs] = allocate('main_frame_ref')
            elif mapped.startswith('title_label'):
                rename_map[lhs] = allocate('title_label_ref')
            elif mapped.startswith('input_box'):
                rename_map[lhs] = allocate('input_box_ref')
            elif mapped.startswith('toggle_button'):
                rename_map[lhs] = allocate('toggle_button_ref')
            elif mapped.startswith('status_label'):
                rename_map[lhs] = allocate('status_label_ref')
            elif mapped.startswith('close_button'):
                rename_map[lhs] = allocate('close_button_ref')

        if not rename_map:
            return script_content

        rewritten_tail = self._rewrite_lua_identifiers(tail_text, rename_map).rstrip('\n')
        merged_lines = prefix_lines + rewritten_tail.split('\n')
        merged_text = '\n'.join(merged_lines)
        return merged_text + ('\n' if script_content.endswith('\n') else '')

    def _collapse_prometheus_ui_temp_aliases(self, script_content):
        lines = script_content.splitlines()
        ui_start_index = None
        for idx, line_text in enumerate(lines):
            if ':WaitForChild("HumanoidRootPart")' in line_text:
                ui_start_index = idx
                break
        if ui_start_index is None:
            fallback_markers = (
                'Instance.new(',
                'Enum.Font',
                'UDim2.new(',
                'UDim.new(',
                'Color3.fromRGB('
            )
            for idx, line_text in enumerate(lines):
                if any(marker in line_text for marker in fallback_markers):
                    ui_start_index = max(0, idx - 1)
                    break
        if ui_start_index is None:
            return script_content

        assign_pattern = re.compile(
            r'^(\s*)(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*$'
        )
        prop_set_pattern = re.compile(
            r'^(\s*)([A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*)\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\s*$'
        )
        member_read_pattern = re.compile(
            r'^(\s*)(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\.([A-Za-z_][A-Za-z0-9_]*)\s*$'
        )
        call_use_pattern = re.compile(
            r'^(\s*)(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\((.*)\)\s*$'
        )
        allowed_expr_pattern = re.compile(
            r'^(?:Enum\.Font(?:\.[A-Za-z_][A-Za-z0-9_]*)?|UDim2\.new\(.+\)|UDim\.new\(.+\)|Color3\.fromRGB\(.+\)|Instance\.new\(.+\)|[+-]?\d+(?:\.\d+)?)$'
        )
        generic_assign_pattern = re.compile(r'^(\s*)(.+?)\s*=\s*(.+?)\s*$')

        head = lines[:ui_start_index]
        body = lines[ui_start_index:]

        changed = True
        rounds = 0
        while changed and rounds < 6:
            changed = False
            rounds += 1
            rewritten = []
            i = 0
            while i < len(body):
                m = assign_pattern.match(body[i])
                if not m:
                    rewritten.append(body[i])
                    i += 1
                    continue

                indent, temp_name, expr = m.groups()
                expr_value = expr.strip().rstrip(';').strip()
                if not allowed_expr_pattern.fullmatch(expr_value):
                    rewritten.append(body[i])
                    i += 1
                    continue

                j = i + 1
                while j < len(body) and not body[j].strip():
                    j += 1
                if j >= len(body):
                    rewritten.append(body[i])
                    i += 1
                    continue

                next_line = body[j]
                replaced_next = None

                prop_m = prop_set_pattern.match(next_line)
                if prop_m and prop_m.group(3) == temp_name:
                    replaced_next = f"{prop_m.group(1)}{prop_m.group(2)} = {expr_value}"
                else:
                    member_m = member_read_pattern.match(next_line)
                    if member_m and member_m.group(3) == temp_name:
                        replaced_next = (
                            f"{member_m.group(1)}{member_m.group(2)} = {expr_value}.{member_m.group(4)}"
                        )
                    else:
                        call_m = call_use_pattern.match(next_line)
                        if call_m:
                            lhs, callee, args = call_m.group(2), call_m.group(3), call_m.group(4)
                            if callee == temp_name:
                                replaced_next = f"{call_m.group(1)}{lhs} = {expr_value}({args})"
                        if replaced_next is None:
                            generic_m = generic_assign_pattern.match(next_line)
                            if generic_m:
                                lhs_expr = generic_m.group(2).strip()
                                rhs_expr = generic_m.group(3).strip()
                                if (
                                    re.search(rf'\b{re.escape(temp_name)}\b', rhs_expr)
                                    and not re.search(rf'\b{re.escape(temp_name)}\b', lhs_expr)
                                    and any(
                                        marker in rhs_expr
                                        for marker in (
                                            'UDim2.new',
                                            'UDim.new',
                                            'Color3.fromRGB',
                                            'Enum.Font',
                                            'Instance.new'
                                        )
                                    )
                                ):
                                    replaced_rhs = re.sub(
                                        rf'\b{re.escape(temp_name)}\b',
                                        expr_value,
                                        rhs_expr
                                    )
                                    replaced_next = (
                                        f"{generic_m.group(1)}{lhs_expr} = {replaced_rhs}"
                                    )

                if replaced_next is None:
                    rewritten.append(body[i])
                    i += 1
                    continue

                changed = True
                # keep blank lines between i and j except i itself
                for k in range(i + 1, j):
                    rewritten.append(body[k])
                rewritten.append(replaced_next)
                i = j + 1

            body = rewritten

        merged = head + body
        merged_text = '\n'.join(merged)
        return merged_text + ('\n' if script_content.endswith('\n') else '')

    def _simplify_prometheus_simple_numeric_aliases(self, script_content):
        lines = script_content.splitlines()
        assign_pattern = re.compile(
            r'^(\s*)(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*$'
        )
        bin_pattern = re.compile(
            r'^\s*([+-]?\d+(?:\.\d+)?)\s*([+-])\s*([+-]?\d+(?:\.\d+)?)\s*$'
        )

        rewritten = list(lines)
        for idx, line_text in enumerate(lines):
            m = assign_pattern.match(line_text)
            if not m:
                continue
            indent, lhs, rhs = m.groups()
            rhs_value = rhs.strip().rstrip(';').strip()
            rhs_value = rhs_value.replace(' ', '')
            # Try direct binary first.
            m_bin = re.fullmatch(r'([+-]?\d+(?:\.\d+)?)([+-])([+-]?\d+(?:\.\d+)?)', rhs_value)
            value = None
            if m_bin:
                a = float(m_bin.group(1))
                b = float(m_bin.group(3))
                if m_bin.group(2) == '+':
                    value = a + b
                else:
                    value = a - b
            else:
                # pattern: a-(-b)
                m_subneg = re.fullmatch(
                    r'([+-]?\d+(?:\.\d+)?)\-\(\-([+-]?\d+(?:\.\d+)?)\)',
                    rhs_value
                )
                if m_subneg:
                    value = float(m_subneg.group(1)) + float(m_subneg.group(2))

            if value is None:
                continue

            if abs(value - round(value)) < 1e-12:
                out = str(int(round(value)))
            else:
                out = f"{value:.12g}"
            rewritten[idx] = f"{indent}{lhs} = {out}"

        rewritten_text = '\n'.join(rewritten)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _prune_unused_local_declaration_names(self, script_content):
        lines = script_content.splitlines()
        local_decl_pattern = re.compile(r'^(\s*)local\s+(.+?)\s*$')

        token_counts = Counter(re.findall(r'\b[A-Za-z_][A-Za-z0-9_]*\b', script_content))
        rewritten = []
        for line_text in lines:
            m = local_decl_pattern.match(line_text)
            if not m:
                rewritten.append(line_text)
                continue
            indent, decl_text = m.groups()
            if '=' in decl_text:
                rewritten.append(line_text)
                continue
            parts = [p.strip() for p in decl_text.split(',') if p.strip()]
            if len(parts) <= 1:
                rewritten.append(line_text)
                continue

            kept = []
            seen_names = set()
            for part in parts:
                name = part.split('=', 1)[0].strip()
                if not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', name):
                    kept.append(part)
                    continue
                if name in seen_names:
                    continue
                if token_counts.get(name, 0) > 1:
                    kept.append(part)
                    seen_names.add(name)
            if not kept:
                continue
            rewritten.append(f"{indent}local {', '.join(kept)}")

        rewritten_text = '\n'.join(rewritten)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _normalize_split_comparison_operators(self, script_content):
        normalized = script_content
        normalized = re.sub(r'(?<![<>=~])=\s*=(?![=])', '==', normalized)
        normalized = re.sub(r'~\s*=', '~=', normalized)
        normalized = re.sub(r'<\s*=', '<=', normalized)
        normalized = re.sub(r'>\s*=', '>=', normalized)
        return normalized

    def _collapse_prometheus_count_zero_guards(self, script_content):
        lines = script_content.splitlines()
        assign_pattern = re.compile(
            r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\s*$'
        )
        len_pattern = re.compile(
            r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*#\s*([A-Za-z_][A-Za-z0-9_]*)\s*$'
        )
        zero_pattern = re.compile(
            r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*0\s*$'
        )
        if_pattern = re.compile(
            r'^(\s*)if\s+([A-Za-z_][A-Za-z0-9_]*)\s*==\s*([A-Za-z_][A-Za-z0-9_]*)\s+then\s*$'
        )

        output = []
        index = 0
        while index < len(lines):
            if index + 3 >= len(lines):
                output.append(lines[index])
                index += 1
                continue

            m0 = assign_pattern.match(lines[index])
            m1 = len_pattern.match(lines[index + 1])
            m2 = zero_pattern.match(lines[index + 2])
            m3 = if_pattern.match(lines[index + 3])
            if not (m0 and m1 and m2 and m3):
                output.append(lines[index])
                index += 1
                continue

            lhs0, rhs0 = m0.groups()
            lhs1, rhs1 = m1.groups()
            lhs2 = m2.group(1)
            indent_if, if_lhs, if_rhs = m3.groups()
            if not (
                lhs1 == if_lhs
                and lhs2 == if_rhs
                and lhs0 == rhs1
                and lhs0 == lhs2
            ):
                output.append(lines[index])
                index += 1
                continue

            output.append(f"{indent_if}if #{rhs0} == 0 then")
            index += 4

        rewritten_text = '\n'.join(output)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _remove_overwritten_string_seed_assignments(self, script_content):
        lines = script_content.splitlines()
        assign_pattern = re.compile(
            r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([\"\'])(?:\\.|[^\\])*?\2\s*$'
        )
        assign_lhs_pattern = re.compile(r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=')
        removable = set()

        for index, line_text in enumerate(lines):
            assign_match = assign_pattern.match(line_text)
            if not assign_match:
                continue
            name = assign_match.group(1)
            token_pattern = re.compile(rf'\b{re.escape(name)}\b')

            probe = index + 1
            seen_use = False
            while probe < len(lines):
                probe_line = lines[probe]
                lhs_match = assign_lhs_pattern.match(probe_line)
                if lhs_match and lhs_match.group(1) == name:
                    if not seen_use:
                        removable.add(index)
                    break
                if token_pattern.search(probe_line):
                    local_decl = re.match(r'^\s*local\s+(.+?)\s*$', probe_line)
                    if local_decl and '=' not in probe_line:
                        decl_names = [part.strip() for part in local_decl.group(1).split(',')]
                        if name in decl_names:
                            probe += 1
                            continue
                    seen_use = True
                    break
                probe += 1

        if not removable:
            return script_content

        rewritten = [line for idx, line in enumerate(lines) if idx not in removable]
        rewritten_text = '\n'.join(rewritten)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _remove_overwritten_builtin_alias_seeds(self, script_content):
        lines = script_content.splitlines()
        seed_assign_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(math\.(?:floor|random)|table\.remove|string\.char)\s*$'
        )
        assign_lhs_pattern = re.compile(r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=')
        removable = set()

        for index, line_text in enumerate(lines):
            seed_match = seed_assign_pattern.match(line_text)
            if not seed_match:
                continue

            var_name = seed_match.group(1)
            token_pattern = re.compile(rf'\b{re.escape(var_name)}\b')
            overwritten_before_use = False

            for probe in range(index + 1, min(len(lines), index + 30)):
                probe_line = lines[probe]
                lhs_match = assign_lhs_pattern.match(probe_line)
                if lhs_match and lhs_match.group(1) == var_name:
                    overwritten_before_use = True
                    break

                if token_pattern.search(probe_line):
                    local_decl_match = re.match(r'^\s*local\s+(.+?)\s*$', probe_line)
                    if local_decl_match and '=' not in probe_line:
                        decl_names = [part.strip() for part in local_decl_match.group(1).split(',')]
                        if var_name in decl_names:
                            continue
                    overwritten_before_use = False
                    break

            if overwritten_before_use:
                removable.add(index)

        if not removable:
            return script_content

        rewritten = [line for idx, line in enumerate(lines) if idx not in removable]
        rewritten_text = '\n'.join(rewritten)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _inline_prometheus_anti_temporaries(self, script_content):
        lines = script_content.splitlines()
        fn_assign_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*function\([^)]*\)\s*$'
        )
        assign_pattern = re.compile(
            r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*$'
        )
        temp_name_pattern = re.compile(
            r'^(?:tmp_[A-Za-z0-9_]+|r\d+(?:_local)?|local_\d+|v\d+)$'
        )

        rewritten = list(lines)
        index = 0
        while index < len(rewritten):
            fn_match = fn_assign_pattern.match(rewritten[index].strip())
            if not fn_match:
                index += 1
                continue
            fn_name = fn_match.group(1)
            if not re.fullmatch(r'(?:next_prng_byte(?:_\d+)?|decode_runtime_string(?:_\d+)?)', fn_name):
                index += 1
                continue

            end_index = self._find_matching_block_end_line(rewritten, index)
            if end_index == -1:
                index += 1
                continue

            block_lines = rewritten[index:end_index + 1]
            block_text = '\n'.join(block_lines)
            if '35184372088832' not in block_text:
                index = end_index + 1
                continue

            changed = True
            rounds = 0
            while changed and rounds < 8:
                changed = False
                rounds += 1

                local_index = 1
                while local_index < len(block_lines) - 1:
                    line_text = block_lines[local_index]
                    assign_match = assign_pattern.match(line_text.strip())
                    if not assign_match:
                        local_index += 1
                        continue

                    lhs_name, rhs_text = assign_match.groups()
                    rhs_clean = rhs_text.strip().rstrip(';').strip()
                    if not temp_name_pattern.fullmatch(lhs_name):
                        local_index += 1
                        continue
                    if re.search(r'\b(?:function|return|and|or)\b', rhs_clean):
                        local_index += 1
                        continue
                    if '{' in rhs_clean or '}' in rhs_clean or ':' in rhs_clean:
                        local_index += 1
                        continue
                    if re.search(r'[A-Za-z_][A-Za-z0-9_]*\s*\(', rhs_clean):
                        local_index += 1
                        continue

                    token_pattern = re.compile(rf'\b{re.escape(lhs_name)}\b')
                    use_positions = []
                    reassign_before_use = False
                    for probe in range(local_index + 1, len(block_lines)):
                        probe_line = block_lines[probe]
                        probe_assign = assign_pattern.match(probe_line.strip())
                        if probe_assign and probe_assign.group(1) == lhs_name:
                            reassign_before_use = True
                            break
                        if token_pattern.search(probe_line):
                            use_positions.append(probe)

                    if reassign_before_use or len(use_positions) != 1:
                        local_index += 1
                        continue

                    use_index = use_positions[0]
                    replaced_line = re.sub(
                        rf'\b{re.escape(lhs_name)}\b',
                        f"({rhs_clean})",
                        block_lines[use_index]
                    )
                    if replaced_line == block_lines[use_index]:
                        local_index += 1
                        continue

                    block_lines[use_index] = replaced_line
                    del block_lines[local_index]
                    changed = True
                    break

            rewritten[index:end_index + 1] = block_lines
            index += len(block_lines)

        rewritten_text = '\n'.join(rewritten)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _prune_prometheus_anti_preamble_noise(self, script_content):
        lines = script_content.splitlines()
        if not lines:
            return script_content

        assign_pattern = re.compile(r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*$')
        token_cache = {}

        preamble_end = len(lines)
        for idx, line_text in enumerate(lines):
            stripped = line_text.strip()
            if (
                ':WaitForChild("HumanoidRootPart")' in stripped
                or re.search(r'\bgame:GetService\s*\(', stripped)
            ):
                preamble_end = idx
                break

        if preamble_end <= 0:
            return script_content

        remove_indices = set()

        # Remove redundant nil seeds when overwritten before any read.
        for idx in range(preamble_end):
            line_text = lines[idx]
            assign_match = assign_pattern.match(line_text)
            if not assign_match:
                continue
            lhs_name, rhs_text = assign_match.groups()
            rhs_clean = rhs_text.strip().rstrip(';').strip()
            if rhs_clean != 'nil':
                continue

            token_pattern = token_cache.get(lhs_name)
            if token_pattern is None:
                token_pattern = re.compile(rf'\b{re.escape(lhs_name)}\b')
                token_cache[lhs_name] = token_pattern

            overwritten_first = False
            for probe in range(idx + 1, preamble_end):
                probe_line = lines[probe]
                probe_assign = assign_pattern.match(probe_line)
                if probe_assign and probe_assign.group(1) == lhs_name:
                    overwritten_first = True
                    break
                if token_pattern.search(probe_line):
                    overwritten_first = False
                    break
            if overwritten_first:
                remove_indices.add(idx)

        # Remove `i = 1` right before `for i = ...`.
        for idx in range(preamble_end - 1):
            current_match = assign_pattern.match(lines[idx])
            if not current_match:
                continue
            lhs_name, rhs_text = current_match.groups()
            rhs_clean = rhs_text.strip().rstrip(';').strip()
            if rhs_clean not in {'1', '1.0'}:
                continue

            next_line = lines[idx + 1].strip()
            if re.fullmatch(rf'for\s+{re.escape(lhs_name)}\s*=\s*.+', next_line):
                remove_indices.add(idx)

        # Remove `i = 1` seed that appears a few lines before `for i = ...`
        # when `i` is not read in between.
        for idx in range(preamble_end):
            current_match = assign_pattern.match(lines[idx])
            if not current_match:
                continue
            lhs_name, rhs_text = current_match.groups()
            rhs_clean = rhs_text.strip().rstrip(';').strip()
            if rhs_clean not in {'1', '1.0'}:
                continue

            token_pattern = token_cache.get(lhs_name)
            if token_pattern is None:
                token_pattern = re.compile(rf'\b{re.escape(lhs_name)}\b')
                token_cache[lhs_name] = token_pattern

            found_for = False
            used_before_for = False
            scan_limit = min(preamble_end, idx + 10)
            for probe in range(idx + 1, scan_limit):
                probe_line = lines[probe].strip()
                if re.fullmatch(rf'for\s+{re.escape(lhs_name)}\s*=\s*.+', probe_line):
                    found_for = True
                    break
                if token_pattern.search(lines[probe]):
                    used_before_for = True
                    break
            if found_for and not used_before_for:
                remove_indices.add(idx)

        if not remove_indices:
            return script_content

        rewritten = [line for idx, line in enumerate(lines) if idx not in remove_indices]
        rewritten_text = '\n'.join(rewritten)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _canonicalize_prometheus_lookup_bootstrap(self, script_content):
        lines = script_content.splitlines()
        if len(lines) < 10:
            return script_content

        for_pattern = re.compile(r'^\s*for\s+([A-Za-z_][A-Za-z0-9_]*)\s*=\s*1\s*,\s*256\s*,\s*1\s+do\s*$')
        lookup_set_pattern = re.compile(
            r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*\[\s*([A-Za-z_][A-Za-z0-9_]*)\s*\]\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\s*$'
        )
        random_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(?:math\.random|random_fn)\(\s*1\s*,\s*#([A-Za-z_][A-Za-z0-9_]*)\s*\)\s*$'
        )
        remove_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(?:table\.remove|remove_fn)\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*,\s*([A-Za-z_][A-Za-z0-9_]*)\s*\)\s*$'
        )
        char_set_pattern = re.compile(
            r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*\[\s*([A-Za-z_][A-Za-z0-9_]*)\s*\]\s*=\s*(?:string\.char|char_fn)\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*-\s*1\s*\)\s*$'
        )
        until_pattern = re.compile(r'^\s*until\s+#([A-Za-z_][A-Za-z0-9_]*)\s*==\s*0\s*$')

        for_index = None
        for idx, line_text in enumerate(lines):
            if for_pattern.match(line_text):
                for_index = idx
                break
        if for_index is None or for_index + 2 >= len(lines):
            return script_content

        for_match = for_pattern.match(lines[for_index].strip())
        set_match = lookup_set_pattern.match(lines[for_index + 1].strip())
        end_match = lines[for_index + 2].strip() == 'end'
        if not (for_match and set_match and end_match):
            return script_content
        loop_var = for_match.group(1)
        lookup_var = set_match.group(1)
        if set_match.group(2) != loop_var or set_match.group(3) != loop_var:
            return script_content

        repeat_index = None
        for idx in range(for_index + 3, min(len(lines), for_index + 20)):
            if lines[idx].strip() == 'repeat':
                repeat_index = idx
                break
        if repeat_index is None or repeat_index + 4 >= len(lines):
            return script_content

        random_match = random_pattern.match(lines[repeat_index + 1].strip())
        remove_match = remove_pattern.match(lines[repeat_index + 2].strip())
        char_match = char_set_pattern.match(lines[repeat_index + 3].strip())
        until_match = until_pattern.match(lines[repeat_index + 4].strip())
        if not (random_match and remove_match and char_match and until_match):
            return script_content

        rand_var = random_match.group(1)
        random_lookup_var = random_match.group(2)
        removed_var = remove_match.group(1)
        remove_lookup_var = remove_match.group(2)
        if remove_match.group(3) != rand_var:
            return script_content
        map_var = char_match.group(1)
        if char_match.group(2) != removed_var or char_match.group(3) != removed_var:
            return script_content
        until_lookup_var = until_match.group(1)
        if not (
            lookup_var == random_lookup_var == remove_lookup_var == until_lookup_var
        ):
            return script_content

        for_indent = lines[for_index][:len(lines[for_index]) - len(lines[for_index].lstrip(' \t'))]
        inner_indent = for_indent + '    '

        rewritten = list(lines)
        rewritten[for_index] = f"{for_indent}for i = 1, 256, 1 do"
        rewritten[for_index + 1] = f"{inner_indent}lookup[i] = i"
        rewritten[repeat_index + 1] = f"{inner_indent}v1 = math.random(1,#lookup)"
        rewritten[repeat_index + 2] = f"{inner_indent}local v0 = table.remove(lookup,v1)"
        rewritten[repeat_index + 3] = f"{inner_indent}items[v0] = string.char(v0 - 1)"

        rewritten_text = '\n'.join(rewritten)

        # Normalize alias names in the anti/decoder preamble where these two
        # tables are consumed.
        rename_map = {}
        if lookup_var != 'lookup':
            rename_map[lookup_var] = 'lookup'
        if map_var != 'items':
            rename_map[map_var] = 'items'
        if rename_map:
            region_end = len(rewritten)
            for idx, line_text in enumerate(rewritten):
                stripped = line_text.strip()
                if (
                    re.match(r'^(?:local\s+)?decode_runtime_string\b', stripped)
                    or ':WaitForChild("HumanoidRootPart")' in stripped
                    or re.search(r'\bgame:GetService\s*\(', stripped)
                ):
                    region_end = idx
                    break
            preamble_text = '\n'.join(rewritten[:region_end])
            rewritten_preamble = self._rewrite_lua_identifiers(preamble_text, rename_map).rstrip('\n')
            rewritten_text = '\n'.join(rewritten_preamble.split('\n') + rewritten[region_end:])

        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _prune_prometheus_decoder_local_decls(self, script_content):
        lines = script_content.splitlines()
        fn_assign_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*function\([^)]*\)\s*$'
        )
        alias_assign_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\s*$'
        )
        local_decl_pattern = re.compile(r'^(\s*)local\s+(.+?)\s*$')

        decoder_names = set(
            re.findall(r'\b(?:next_prng_byte(?:_\d+)?|decode_runtime_string(?:_\d+)?)\b', script_content)
        )
        if not decoder_names:
            return script_content

        changed = True
        while changed:
            changed = False
            for line_text in lines:
                alias_match = alias_assign_pattern.match(line_text)
                if not alias_match:
                    continue
                lhs_name, rhs_name = alias_match.groups()
                if lhs_name in decoder_names and rhs_name not in decoder_names:
                    decoder_names.add(rhs_name)
                    changed = True
                if rhs_name in decoder_names and lhs_name not in decoder_names:
                    decoder_names.add(lhs_name)
                    changed = True

        rewritten = list(lines)

        for index, line_text in enumerate(lines):
            fn_match = fn_assign_pattern.match(line_text)
            if not fn_match:
                continue
            fn_name = fn_match.group(1)
            if fn_name not in decoder_names:
                continue

            end_index = self._find_matching_block_end_line(lines, index)
            if end_index == -1:
                continue

            # Decoder locals are typically declared right after function header.
            decl_index = index + 1
            while decl_index <= end_index and not lines[decl_index].strip():
                decl_index += 1
            if decl_index > end_index:
                continue

            decl_match = local_decl_pattern.match(lines[decl_index])
            if not decl_match:
                continue

            indent_text, decl_text = decl_match.groups()
            raw_parts = [part.strip() for part in decl_text.split(',') if part.strip()]
            if len(raw_parts) < 2:
                continue

            names = []
            for part in raw_parts:
                if '=' in part:
                    name_part = part.split('=', 1)[0].strip()
                else:
                    name_part = part
                if re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', name_part):
                    names.append(name_part)

            if not names:
                continue

            block_text_without_decl = '\n'.join(lines[index:decl_index] + lines[decl_index + 1:end_index + 1])
            keep_names = []
            for name_text in names:
                if re.search(rf'\b{re.escape(name_text)}\b', block_text_without_decl):
                    keep_names.append(name_text)

            if not keep_names:
                # Keep at least one harmless temp if all became dead to preserve syntax.
                keep_names = [names[0]]

            rewritten[decl_index] = f"{indent_text}local {','.join(keep_names)}"

        rewritten_text = '\n'.join(rewritten)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _semantic_collapse_prometheus_decoder_state_machine(self, script_content):
        lines = script_content.splitlines()
        fn_assign_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*function\(([^)]*)\)\s*$'
        )
        alias_assign_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\s*$'
        )
        assign_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*$'
        )
        decoder_name_pattern = re.compile(
            r'^(?:next_prng_byte(?:_\d+)?|decode_runtime_string(?:_\d+)?)$'
        )

        decoder_names = set(
            re.findall(r'\b(?:next_prng_byte(?:_\d+)?|decode_runtime_string(?:_\d+)?)\b', script_content)
        )
        if not decoder_names:
            return script_content
        changed_alias = True
        while changed_alias:
            changed_alias = False
            for line_text in lines:
                alias_match = alias_assign_pattern.match(line_text)
                if not alias_match:
                    continue
                lhs_name, rhs_name = alias_match.groups()
                if lhs_name in decoder_names and rhs_name not in decoder_names:
                    decoder_names.add(rhs_name)
                    changed_alias = True
                if rhs_name in decoder_names and lhs_name not in decoder_names:
                    decoder_names.add(lhs_name)
                    changed_alias = True

        existing_names = set(re.findall(r'\b[A-Za-z_][A-Za-z0-9_]*\b', script_content))
        rewritten_lines = list(lines)

        index = 0
        while index < len(rewritten_lines):
            line_text = rewritten_lines[index]
            fn_match = fn_assign_pattern.match(line_text)
            if not fn_match:
                index += 1
                continue
            fn_name, arg_text = fn_match.groups()
            if fn_name not in decoder_names and not decoder_name_pattern.fullmatch(fn_name):
                index += 1
                continue

            end_index = self._find_matching_block_end_line(rewritten_lines, index)
            if end_index == -1:
                index += 1
                continue

            block_lines = rewritten_lines[index:end_index + 1]
            block_text = '\n'.join(block_lines)
            has_cache_guard = re.search(
                r'if\s+not\s*\(\s*[A-Za-z_][A-Za-z0-9_]*\s*\[\s*[A-Za-z_][A-Za-z0-9_]*\s*\]\s*\)\s+then',
                block_text
            ) is not None
            is_decode = ('string.byte' in block_text and '..' in block_text and has_cache_guard)
            block_rename_map = {}

            def allocate(base_name):
                candidate = base_name
                suffix = 2
                while (
                    candidate in existing_names
                    or candidate in block_rename_map.values()
                ):
                    candidate = f"{base_name}_{suffix}"
                    suffix += 1
                existing_names.add(candidate)
                return candidate

            args = [arg.strip() for arg in arg_text.split(',') if arg.strip()]
            if is_decode and len(args) >= 2:
                arg1, arg2 = args[0], args[1]
                if re.fullmatch(r'arg\d+', arg1):
                    block_rename_map[arg1] = allocate('encoded_text')
                if re.fullmatch(r'arg\d+', arg2):
                    block_rename_map[arg2] = allocate('cache_key')

            local_role_candidates = {}
            for block_line in block_lines:
                assign_match = assign_pattern.match(block_line.strip())
                if not assign_match:
                    continue
                lhs_name, rhs_text = assign_match.groups()
                rhs_value = rhs_text.strip().rstrip(';').strip()
                if not re.fullmatch(r'(?:r\d+(?:_local)?|tmp_[A-Za-z0-9_]+|v\d+)', lhs_name):
                    continue

                base_name = None
                if re.search(r'\bstring\.len\s*\(', rhs_value):
                    base_name = 'input_len'
                elif re.search(r'\bstring\.byte\s*\(', rhs_value):
                    base_name = 'byte_value'
                elif re.search(r'\bnext_prng_byte(?:_\d+)?\s*\(', rhs_value):
                    base_name = 'prng_byte'
                elif re.search(r'%\s*256\b', rhs_value):
                    base_name = 'byte_mod'
                elif rhs_value in {'""', "''"}:
                    base_name = 'decoded_text'
                elif re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*\s*\+\s*1', rhs_value):
                    base_name = 'lookup_index'
                elif re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*\s*\[\s*[A-Za-z_][A-Za-z0-9_]*\s*\]', rhs_value):
                    base_name = 'cached_value'
                elif re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*\s*\.\.\s*[A-Za-z_][A-Za-z0-9_]*', rhs_value):
                    base_name = 'decoded_text'

                if base_name:
                    local_role_candidates.setdefault(lhs_name, base_name)

            # Keep deterministic ordering by appearance.
            for lhs_name, base_name in local_role_candidates.items():
                if lhs_name in block_rename_map:
                    continue
                block_rename_map[lhs_name] = allocate(base_name)

            # Fallback: rename remaining temp/register locals inside decoder
            # bodies to neutral readable temporaries.
            decl_index = index + 1
            while decl_index <= end_index and not rewritten_lines[decl_index].strip():
                decl_index += 1
            if decl_index <= end_index:
                decl_match = re.match(r'^\s*local\s+(.+?)\s*$', rewritten_lines[decl_index])
                if decl_match:
                    decl_items = [part.strip() for part in decl_match.group(1).split(',') if part.strip()]
                    tmp_counter = 1
                    for decl_item in decl_items:
                        name_text = decl_item.split('=', 1)[0].strip() if '=' in decl_item else decl_item
                        if not re.fullmatch(r'(?:r\d+(?:_local)?|tmp_[A-Za-z0-9_]+|v\d+)', name_text):
                            continue
                        if name_text in block_rename_map:
                            continue
                        block_rename_map[name_text] = allocate(f"tmp_{tmp_counter}")
                        tmp_counter += 1

            if block_rename_map:
                block_text = '\n'.join(block_lines) + '\n'
                rewritten_block_text = self._rewrite_lua_identifiers(block_text, block_rename_map)
                rewritten_block_lines = rewritten_block_text.rstrip('\n').split('\n')
                rewritten_lines[index:end_index + 1] = rewritten_block_lines
                end_index = index + len(rewritten_block_lines) - 1

            index = end_index + 1

        rewritten_text = '\n'.join(rewritten_lines)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _collapse_prometheus_decoder_counted_loops(self, script_content):
        lines = script_content.splitlines()
        fn_assign_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*function\([^)]*\)\s*$'
        )
        assign_pattern = re.compile(
            r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*$'
        )

        output = list(lines)
        index = 0
        while index < len(output):
            fn_match = fn_assign_pattern.match(output[index].strip())
            if not fn_match:
                index += 1
                continue
            fn_name = fn_match.group(1)
            if not re.fullmatch(r'decode_runtime_string(?:_\d+)?', fn_name):
                index += 1
                continue

            fn_end = self._find_matching_block_end_line(output, index)
            if fn_end == -1:
                index += 1
                continue

            cursor = index + 1
            while cursor < fn_end:
                if output[cursor].strip() != 'while true do':
                    cursor += 1
                    continue

                while_end = self._find_matching_block_end_line(output, cursor)
                if while_end == -1 or while_end > fn_end:
                    cursor += 1
                    continue

                # Need the canonical guard scaffold immediately after while.
                if cursor + 10 >= while_end:
                    cursor += 1
                    continue

                m0 = assign_pattern.match(output[cursor + 1].strip())
                m1 = assign_pattern.match(output[cursor + 2].strip())
                m2 = assign_pattern.match(output[cursor + 3].strip())
                m3 = assign_pattern.match(output[cursor + 4].strip())
                m4 = assign_pattern.match(output[cursor + 5].strip())
                m5 = assign_pattern.match(output[cursor + 6].strip())
                m6 = assign_pattern.match(output[cursor + 7].strip())
                if not all([m0, m1, m2, m3, m4, m5, m6]):
                    cursor += 1
                    continue

                guard_if = output[cursor + 8].strip()
                guard_break = output[cursor + 9].strip()
                guard_end = output[cursor + 10].strip()
                if not re.fullmatch(r'if\s+not\s+[A-Za-z_][A-Za-z0-9_]*\s+then', guard_if):
                    cursor += 1
                    continue
                if guard_break != 'break' or guard_end != 'end':
                    cursor += 1
                    continue

                flag_var, rhs0 = m0.groups()
                counter_var, rhs1 = m1.groups()
                cond_var, rhs2 = m2.groups()
                cond_var2, rhs3 = m3.groups()
                flag_var2, rhs4 = m4.groups()
                flag_var3, rhs5 = m5.groups()
                cond_var3, rhs6 = m6.groups()
                if cond_var != cond_var2 or cond_var != cond_var3:
                    cursor += 1
                    continue
                if flag_var != flag_var2 or flag_var != flag_var3:
                    cursor += 1
                    continue

                add_match = re.fullmatch(
                    rf'{re.escape(counter_var)}\s*\+\s*([A-Za-z_][A-Za-z0-9_]*)',
                    rhs1.strip()
                )
                le_match = re.fullmatch(
                    rf'{re.escape(counter_var)}\s*<=\s*([A-Za-z_][A-Za-z0-9_]*)',
                    rhs2.strip()
                )
                and_match = re.fullmatch(
                    rf'{re.escape(flag_var)}\s*and\s*{re.escape(cond_var)}',
                    rhs3.strip()
                )
                ge_match = re.fullmatch(
                    rf'{re.escape(counter_var)}\s*>=\s*([A-Za-z_][A-Za-z0-9_]*)',
                    rhs4.strip()
                )
                and2_match = re.fullmatch(
                    rf'([A-Za-z_][A-Za-z0-9_]*)\s*and\s*{re.escape(flag_var)}',
                    rhs5.strip()
                )
                or_match = re.fullmatch(
                    rf'{re.escape(flag_var)}\s*or\s*{re.escape(cond_var)}',
                    rhs6.strip()
                )
                not_match = re.fullmatch(
                    rf'not\s+([A-Za-z_][A-Za-z0-9_]*)',
                    rhs0.strip()
                )
                if not all([add_match, le_match, and_match, ge_match, and2_match, or_match, not_match]):
                    cursor += 1
                    continue
                if le_match.group(1) != ge_match.group(1):
                    cursor += 1
                    continue
                if not_match.group(1) != and2_match.group(1):
                    cursor += 1
                    continue
                if not re.fullmatch(rf'if\s+not\s+{re.escape(cond_var)}\s+then', guard_if):
                    cursor += 1
                    continue

                step_var = add_match.group(1)
                limit_var = le_match.group(1)

                # Recover start from `counter = start - step` seed above while.
                start_var = None
                search_start = max(index + 1, cursor - 8)
                for back in range(cursor - 1, search_start - 1, -1):
                    back_m = assign_pattern.match(output[back].strip())
                    if not back_m:
                        continue
                    lhs_b, rhs_b = back_m.groups()
                    if lhs_b != counter_var:
                        continue
                    start_match = re.fullmatch(
                        rf'([A-Za-z_][A-Za-z0-9_]*|\d+(?:\.\d+)?)\s*-\s*{re.escape(step_var)}',
                        rhs_b.strip()
                    )
                    if start_match:
                        start_var = start_match.group(1)
                        break
                if start_var is None:
                    cursor += 1
                    continue

                body_start = cursor + 11
                body_end = while_end - 1
                body_lines = output[body_start:body_end + 1]

                # Optional alias hoist: idx_alias = counter_var
                alias_name = None
                if body_lines:
                    alias_match = assign_pattern.match(body_lines[0].strip())
                    if alias_match:
                        alias_lhs, alias_rhs = alias_match.groups()
                        if alias_rhs.strip() == counter_var:
                            alias_name = alias_lhs
                            body_lines = body_lines[1:]
                if alias_name:
                    token_alias = re.compile(rf'\b{re.escape(alias_name)}\b')
                    reassigned = any(
                        assign_pattern.match(line.strip()) and assign_pattern.match(line.strip()).group(1) == alias_name
                        for line in body_lines
                    )
                    if not reassigned:
                        body_lines = [token_alias.sub(counter_var, line) for line in body_lines]
                    else:
                        alias_name = None

                indent = output[cursor][:len(output[cursor]) - len(output[cursor].lstrip(' \t'))]
                for_header = f"{indent}for {counter_var} = {start_var}, {limit_var}, {step_var} do"
                replacement_block = [for_header] + body_lines + [f"{indent}end"]

                output[cursor:while_end + 1] = replacement_block
                delta = len(replacement_block) - (while_end - cursor + 1)
                fn_end += delta
                cursor += len(replacement_block)

            index = fn_end + 1

        rewritten_text = '\n'.join(output)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _remove_redundant_for_counter_seeds(self, script_content):
        lines = script_content.splitlines()
        assign_pattern = re.compile(
            r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([A-Za-z_][A-Za-z0-9_]*|\d+(?:\.\d+)?)\s*-\s*([A-Za-z_][A-Za-z0-9_]*|\d+(?:\.\d+)?)\s*$'
        )
        for_pattern = re.compile(
            r'^\s*for\s+([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([^,]+)\s*,\s*([^,]+)\s*,\s*(.+?)\s+do\s*$'
        )

        remove_indexes = set()
        for index, line_text in enumerate(lines[:-1]):
            assign_match = assign_pattern.match(line_text.strip())
            if not assign_match:
                continue
            counter_name, start_expr, step_expr = assign_match.groups()

            probe = index + 1
            while probe < len(lines) and not lines[probe].strip():
                probe += 1
            if probe >= len(lines):
                continue

            for_match = for_pattern.match(lines[probe].strip())
            if not for_match:
                continue
            for_counter, for_start, _for_limit, for_step = for_match.groups()
            if for_counter != counter_name:
                continue
            if for_start.strip() != start_expr.strip():
                continue
            if for_step.strip() != step_expr.strip():
                continue

            remove_indexes.add(index)

        if not remove_indexes:
            return script_content

        rewritten = [line for idx, line in enumerate(lines) if idx not in remove_indexes]
        rewritten_text = '\n'.join(rewritten)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _inline_prometheus_decoder_function_aliases(self, script_content):
        lines = script_content.splitlines()
        fn_assign_pattern = re.compile(
            r'^(\s*)(local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*function\(([^)]*)\)\s*$'
        )
        alias_assign_pattern = re.compile(
            r'^\s*(local\s+)?(next_prng_byte(?:_\d+)?|decode_runtime_string(?:_\d+)?)\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\s*$'
        )

        rewritten = list(lines)
        index = 0
        changed = False

        while index < len(rewritten):
            fn_match = fn_assign_pattern.match(rewritten[index])
            if not fn_match:
                index += 1
                continue

            indent_text, local_kw, fn_name, arg_text = fn_match.groups()
            end_index = self._find_matching_block_end_line(rewritten, index)
            if end_index == -1:
                index += 1
                continue

            alias_line_index = None
            alias_semantic_name = None
            scan_limit = min(len(rewritten), end_index + 20)
            for probe in range(end_index + 1, scan_limit):
                alias_match = alias_assign_pattern.match(rewritten[probe].strip())
                if not alias_match:
                    continue
                _, semantic_name, rhs_name = alias_match.groups()
                if rhs_name != fn_name:
                    continue
                alias_line_index = probe
                alias_semantic_name = semantic_name
                break

            if alias_line_index is None:
                index = end_index + 1
                continue

            rewritten[index] = f"{indent_text}local {alias_semantic_name} = function({arg_text})"
            del rewritten[alias_line_index]
            changed = True

            if alias_line_index <= end_index:
                end_index -= 1
            index = end_index + 1

        if not changed:
            return script_content
        rewritten_text = '\n'.join(rewritten)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _simplify_prometheus_obfuscated_loop_conditions(self, script_content):
        lines = script_content.splitlines()
        output = []
        index = 0

        def match_assign(line_text):
            return re.match(r'^(\s*)([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*$', line_text)

        while index < len(lines):
            if index + 7 >= len(lines):
                output.append(lines[index])
                index += 1
                continue

            m0 = match_assign(lines[index])
            if not m0:
                output.append(lines[index])
                index += 1
                continue

            indent, idx_var, rhs0 = m0.groups()
            add_match = re.fullmatch(rf'{re.escape(idx_var)}\s*\+\s*([A-Za-z_][A-Za-z0-9_]*)', rhs0.strip())
            if not add_match:
                output.append(lines[index])
                index += 1
                continue
            step_var = add_match.group(1)

            m1 = match_assign(lines[index + 1])
            m2 = match_assign(lines[index + 2])
            m3 = match_assign(lines[index + 3])
            m4 = match_assign(lines[index + 4])
            m5 = match_assign(lines[index + 5])
            m6 = match_assign(lines[index + 6])
            if not all([m1, m2, m3, m4, m5, m6]):
                output.append(lines[index])
                index += 1
                continue

            i1, tmp_var1, rhs1 = m1.groups()
            i2, cond_var, rhs2 = m2.groups()
            i3, cond_var2, rhs3 = m3.groups()
            i4, tmp_var2, rhs4 = m4.groups()
            i5, tmp_var3, rhs5 = m5.groups()
            i6, cond_var3, rhs6 = m6.groups()
            if not (i1 == i2 == i3 == i4 == i5 == i6 == indent):
                output.append(lines[index])
                index += 1
                continue
            if not (tmp_var1 == tmp_var2 == tmp_var3):
                output.append(lines[index])
                index += 1
                continue
            if not (cond_var == cond_var2 == cond_var3):
                output.append(lines[index])
                index += 1
                continue

            not_match = re.fullmatch(r'not\s+([A-Za-z_][A-Za-z0-9_]*)', rhs1.strip())
            le_match = re.fullmatch(rf'{re.escape(idx_var)}\s*<=\s*([A-Za-z_][A-Za-z0-9_]*)', rhs2.strip())
            and_match = re.fullmatch(rf'{re.escape(tmp_var1)}\s*and\s*{re.escape(cond_var)}', rhs3.strip())
            ge_match = re.fullmatch(rf'{re.escape(idx_var)}\s*>=\s*([A-Za-z_][A-Za-z0-9_]*)', rhs4.strip())
            and2_match = re.fullmatch(r'([A-Za-z_][A-Za-z0-9_]*)\s*and\s*' + re.escape(tmp_var1), rhs5.strip())
            or_match = re.fullmatch(rf'{re.escape(tmp_var1)}\s*or\s*{re.escape(cond_var)}', rhs6.strip())
            if not all([not_match, le_match, and_match, ge_match, and2_match, or_match]):
                output.append(lines[index])
                index += 1
                continue
            dir_var = not_match.group(1)
            dir_var2 = and2_match.group(1)
            limit_var1 = le_match.group(1)
            limit_var2 = ge_match.group(1)
            if not (dir_var == dir_var2 and limit_var1 == limit_var2):
                output.append(lines[index])
                index += 1
                continue

            # Emit simplified form
            output.append(lines[index])
            output.append(f"{indent}{cond_var} = ((not {dir_var}) and ({idx_var} <= {limit_var1})) or ({dir_var} and ({idx_var} >= {limit_var1}))")

            # Keep the guard line `if not <cond> then` intact. The matched scaffold
            # is exactly the six assignments after `idx = idx + step`.
            consume_until = index + 6
            index = consume_until + 1
            continue

        rewritten_text = '\n'.join(output)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _inline_prometheus_pc_temporaries(self, script_content):
        lines = script_content.splitlines()
        assign_pattern = re.compile(r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*$')
        pc_assign_pattern = re.compile(r'^\s*pc\s*=\s*(.+?)\s*$')
        token_pc_pattern = re.compile(r'\bpc\b')

        def next_nonempty(start_idx):
            i = start_idx
            while i < len(lines) and not lines[i].strip():
                i += 1
            return i

        output = []
        i = 0
        while i < len(lines):
            m_pc = pc_assign_pattern.match(lines[i])
            if not m_pc:
                output.append(lines[i])
                i += 1
                continue

            rhs_expr = m_pc.group(1).strip()
            j = next_nonempty(i + 1)
            if j >= len(lines):
                output.append(lines[i])
                i += 1
                continue

            m_next = assign_pattern.match(lines[j])
            if not m_next or m_next.group(1) == 'pc' or m_next.group(2).strip() != 'pc':
                output.append(lines[i])
                i += 1
                continue

            lhs_var = m_next.group(1)
            # Ensure current pc assignment is not read before next pc overwrite.
            safe = True
            k = j + 1
            while k < len(lines):
                line_k = lines[k]
                m_k = assign_pattern.match(line_k)
                if m_k and m_k.group(1) == 'pc':
                    break
                if token_pc_pattern.search(line_k):
                    safe = False
                    break
                k += 1

            if not safe:
                output.append(lines[i])
                i += 1
                continue

            # Keep blank lines between i and j in output.
            filler_idx = i + 1
            while filler_idx < j:
                output.append(lines[filler_idx])
                filler_idx += 1

            indent = lines[j][:len(lines[j]) - len(lines[j].lstrip(' \t'))]
            output.append(f"{indent}{lhs_var} = {rhs_expr}")
            i = j + 1

        rewritten_text = '\n'.join(output)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _collapse_prometheus_goto_redirect_labels(self, script_content):
        lines = script_content.splitlines()
        label_pattern = re.compile(r'^\s*::block_(\d+)::\s*$')
        goto_pattern = re.compile(r'^\s*goto\s+block_(\d+)\s*;?\s*$')

        changed = True
        rounds = 0
        while changed and rounds < 6:
            changed = False
            rounds += 1

            label_positions = {}
            for idx, line_text in enumerate(lines):
                m = label_pattern.match(line_text)
                if m:
                    label_positions[m.group(1)] = idx

            redirect_map = {}
            for label_id, label_idx in label_positions.items():
                probe = label_idx + 1
                while probe < len(lines) and not lines[probe].strip():
                    probe += 1
                if probe >= len(lines):
                    continue
                goto_match = goto_pattern.match(lines[probe])
                if not goto_match:
                    continue
                target_id = goto_match.group(1)
                if target_id == label_id:
                    continue
                redirect_map[label_id] = (target_id, probe)

            if not redirect_map:
                break

            def resolve_target(label_id):
                seen = set()
                current = label_id
                while current in redirect_map and current not in seen:
                    seen.add(current)
                    current = redirect_map[current][0]
                return current

            rewritten = []
            for line_text in lines:
                def replace_goto(match_object):
                    raw_target = match_object.group(1)
                    resolved_target = resolve_target(raw_target)
                    return f"goto block_{resolved_target}"
                rewritten.append(re.sub(r'goto\s+block_(\d+)', replace_goto, line_text))
            lines = rewritten

            remove_indexes = set()
            for label_id, (_, goto_idx) in redirect_map.items():
                label_idx = label_positions.get(label_id)
                if label_idx is None:
                    continue
                remove_indexes.add(label_idx)
                remove_indexes.add(goto_idx)

            if remove_indexes:
                lines = [
                    line_text
                    for idx, line_text in enumerate(lines)
                    if idx not in remove_indexes
                ]
                changed = True

        rewritten_text = '\n'.join(lines)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _remove_prometheus_fallthrough_gotos(self, script_content):
        lines = script_content.splitlines()
        goto_pattern = re.compile(r'^\s*goto\s+block_(\d+)\s*;?\s*$')
        label_pattern = re.compile(r'^\s*::block_(\d+)::\s*$')

        remove_indexes = set()
        for idx, line_text in enumerate(lines):
            goto_match = goto_pattern.match(line_text)
            if not goto_match:
                continue
            target_id = goto_match.group(1)

            probe = idx + 1
            while probe < len(lines) and not lines[probe].strip():
                probe += 1
            if probe >= len(lines):
                continue

            label_match = label_pattern.match(lines[probe])
            if not label_match or label_match.group(1) != target_id:
                continue

            remove_indexes.add(idx)
            remove_indexes.add(probe)

        if not remove_indexes:
            return script_content

        rewritten = [
            line_text
            for idx, line_text in enumerate(lines)
            if idx not in remove_indexes
        ]
        rewritten_text = '\n'.join(rewritten)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _strip_missing_prometheus_jump_targets(self, script_content):
        lines = script_content.splitlines()
        declared_labels = set(re.findall(r'::block_(\d+)::', script_content))

        if_goto_pattern = re.compile(
            r'^(\s*)if\s+(.+?)\s+then\s+goto\s+block_(\d+)\s+else\s+goto\s+block_(\d+)\s+end\s*;?\s*$'
        )
        goto_pattern = re.compile(r'^(\s*)goto\s+block_(\d+)\s*;?\s*$')

        output = []
        for line_text in lines:
            if_match = if_goto_pattern.match(line_text)
            if if_match:
                indent_text, cond_text, true_label, false_label = if_match.groups()
                true_exists = true_label in declared_labels
                false_exists = false_label in declared_labels
                if true_exists and false_exists:
                    output.append(line_text)
                    continue
                if true_exists and not false_exists:
                    output.append(f"{indent_text}if {cond_text} then goto block_{true_label} end")
                    continue
                if false_exists and not true_exists:
                    output.append(f"{indent_text}if not ({cond_text}) then goto block_{false_label} end")
                    continue
                output.append(f"{indent_text}-- removed unresolved jump pair")
                continue

            goto_match = goto_pattern.match(line_text)
            if goto_match:
                indent_text, label_id = goto_match.groups()
                if label_id not in declared_labels:
                    output.append(f"{indent_text}-- removed unresolved jump block_{label_id}")
                    continue

            output.append(line_text)

        rewritten_text = '\n'.join(output)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _remove_noop_prometheus_conditional_gotos(self, script_content):
        lines = script_content.splitlines()
        if_goto_pattern = re.compile(
            r'^\s*if\s+.+\s+then\s+goto\s+block_(\d+)\s+end\s*;?\s*$'
        )
        label_pattern = re.compile(r'^\s*::block_(\d+)::\s*$')

        remove_indexes = set()
        for idx, line_text in enumerate(lines):
            if_match = if_goto_pattern.match(line_text)
            if not if_match:
                continue
            target_id = if_match.group(1)
            probe = idx + 1
            while probe < len(lines) and not lines[probe].strip():
                probe += 1
            if probe >= len(lines):
                continue
            label_match = label_pattern.match(lines[probe])
            if not label_match or label_match.group(1) != target_id:
                continue
            remove_indexes.add(idx)
            remove_indexes.add(probe)

        if not remove_indexes:
            return script_content

        rewritten = [
            line_text
            for idx, line_text in enumerate(lines)
            if idx not in remove_indexes
        ]
        rewritten_text = '\n'.join(rewritten)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _remove_prometheus_unresolved_jump_comments(self, script_content):
        lines = script_content.splitlines()
        comment_pattern = re.compile(
            r'^\s*--\s*removed unresolved jump(?: block_\d+| pair)\s*$'
        )
        rewritten = [line_text for line_text in lines if not comment_pattern.match(line_text)]
        rewritten_text = '\n'.join(rewritten)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _simplify_prometheus_if_goto_else_chains(self, script_content):
        lines = script_content.splitlines()
        if_goto_pattern = re.compile(
            r'^(\s*)if\s+(.+?)\s+then\s+goto\s+block_(\d+)\s+else\s+goto\s+block_(\d+)\s+end\s*;?\s*$'
        )
        label_pattern = re.compile(r'^\s*::block_(\d+)::\s*$')
        goto_line_pattern = re.compile(r'^\s*goto\s+block_(\d+)\s*;?\s*$')

        changed = True
        rounds = 0
        while changed and rounds < 4:
            changed = False
            rounds += 1

            goto_counts = Counter(re.findall(r'\bgoto\s+block_(\d+)\b', '\n'.join(lines)))
            label_positions = {}
            for idx, line_text in enumerate(lines):
                m = label_pattern.match(line_text)
                if m:
                    label_positions[m.group(1)] = idx

            output = []
            index = 0
            while index < len(lines):
                line_text = lines[index]
                if_match = if_goto_pattern.match(line_text)
                if not if_match:
                    output.append(line_text)
                    index += 1
                    continue

                indent_text, cond_text, true_label, false_label = if_match.groups()
                true_label_pos = label_positions.get(true_label)
                if true_label_pos is None or true_label_pos <= index:
                    output.append(line_text)
                    index += 1
                    continue
                if goto_counts.get(true_label, 0) != 1:
                    output.append(line_text)
                    index += 1
                    continue

                next_label_pos = None
                probe = true_label_pos + 1
                while probe < len(lines):
                    if label_pattern.match(lines[probe]):
                        next_label_pos = probe
                        break
                    probe += 1
                if next_label_pos is None:
                    output.append(line_text)
                    index += 1
                    continue

                true_block_lines = lines[true_label_pos + 1:next_label_pos]
                true_nonempty = [l for l in true_block_lines if l.strip()]
                if not true_nonempty:
                    output.append(line_text)
                    index += 1
                    continue

                last_true = true_nonempty[-1]
                last_goto = goto_line_pattern.match(last_true)
                if not last_goto or last_goto.group(1) != false_label:
                    output.append(line_text)
                    index += 1
                    continue

                if any(label_pattern.match(l) for l in true_block_lines):
                    output.append(line_text)
                    index += 1
                    continue

                trimmed_true = list(true_block_lines)
                tail = len(trimmed_true) - 1
                while tail >= 0 and not trimmed_true[tail].strip():
                    tail -= 1
                if tail < 0:
                    output.append(line_text)
                    index += 1
                    continue
                if not goto_line_pattern.match(trimmed_true[tail]):
                    output.append(line_text)
                    index += 1
                    continue
                trimmed_true[tail] = None
                trimmed_true = [l for l in trimmed_true if l is not None]

                output.append(f"{indent_text}if {cond_text} then")
                output.extend(trimmed_true)
                output.append(f"{indent_text}end")
                output.append(f"{indent_text}goto block_{false_label}")

                index += 1
                while index < len(lines) and index < next_label_pos:
                    index += 1
                if index == next_label_pos:
                    output.append(lines[index])
                    index += 1
                changed = True

            lines = output

        rewritten_text = '\n'.join(lines)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _inline_prometheus_single_use_then_label_blocks(self, script_content):
        lines = script_content.splitlines()
        if_pattern = re.compile(
            r'^(\s*)if\s+(.+?)\s+then\s+goto\s+block_(\d+)\s+else\s+goto\s+block_(\d+)\s+end\s*;?\s*$'
        )
        label_pattern = re.compile(r'^\s*::block_(\d+)::\s*$')
        goto_pattern = re.compile(r'\bgoto\s+block_(\d+)\b')

        changed = True
        rounds = 0
        while changed and rounds < 4:
            changed = False
            rounds += 1

            goto_counts = Counter(goto_pattern.findall('\n'.join(lines)))
            label_positions = {}
            for idx, line_text in enumerate(lines):
                m = label_pattern.match(line_text)
                if m:
                    label_positions[m.group(1)] = idx

            output = []
            index = 0
            while index < len(lines):
                line_text = lines[index]
                m_if = if_pattern.match(line_text)
                if not m_if:
                    output.append(line_text)
                    index += 1
                    continue

                indent_text, cond_text, true_label, false_label = m_if.groups()
                true_label_pos = label_positions.get(true_label)
                false_label_pos = label_positions.get(false_label)
                if (
                    true_label_pos is None
                    or false_label_pos is None
                    or true_label_pos <= index
                    or false_label_pos <= true_label_pos
                ):
                    output.append(line_text)
                    index += 1
                    continue

                if goto_counts.get(true_label, 0) != 1:
                    output.append(line_text)
                    index += 1
                    continue

                then_body = lines[true_label_pos + 1:false_label_pos]
                if any(label_pattern.match(body_line) for body_line in then_body):
                    output.append(line_text)
                    index += 1
                    continue

                output.append(f"{indent_text}if {cond_text} then")
                output.extend(then_body)
                output.append(f"{indent_text}else")
                output.append(f"{indent_text}    goto block_{false_label}")
                output.append(f"{indent_text}end")

                index += 1
                while index < false_label_pos:
                    index += 1
                changed = True

            lines = output

        rewritten_text = '\n'.join(lines)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _simplify_prometheus_guard_loops(self, script_content):
        lines = script_content.splitlines()
        output = []
        index = 0

        while index < len(lines):
            current_line = lines[index]
            stripped = current_line.strip()
            normalized = stripped[:-1].rstrip() if stripped.endswith(';') else stripped
            if normalized != 'while true do':
                output.append(current_line)
                index += 1
                continue

            end_index = self._find_matching_block_end_line(lines, index)
            if end_index == -1:
                output.append(current_line)
                index += 1
                continue

            body_lines = lines[index + 1:end_index]
            non_empty = [(i, line) for i, line in enumerate(body_lines) if line.strip()]
            if len(non_empty) < 3:
                output.append(current_line)
                index += 1
                continue

            first_idx, first_line = non_empty[0]
            second_idx, second_line = non_empty[1]
            third_idx, third_line = non_empty[2]

            first_norm = first_line.strip()
            second_norm = second_line.strip()
            third_norm = third_line.strip()

            cond_match = re.match(r'^if\s+not\s+(.+?)\s+then\s*;?$', first_norm)
            if not cond_match or second_norm != 'break' or third_norm != 'end':
                output.append(current_line)
                index += 1
                continue

            cond_text = cond_match.group(1).strip()
            remainder_lines = body_lines[third_idx + 1:]
            loop_indent = current_line[:len(current_line) - len(current_line.lstrip(' \t'))]
            output.append(f"{loop_indent}if {cond_text} then")
            output.extend(remainder_lines)
            output.append(f"{loop_indent}end")
            index = end_index + 1

        rewritten_text = '\n'.join(output)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _prune_constant_guarded_prometheus_loops(self, script_content):
        lines = script_content.splitlines()
        assignment_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(true|false|nil)\s*;?\s*$'
        )
        any_assign_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*='
        )

        literal_assignments = {}
        assignment_counts = Counter()
        for line_text in lines:
            any_match = any_assign_pattern.match(line_text)
            if any_match:
                assignment_counts[any_match.group(1)] += 1
            lit_match = assignment_pattern.match(line_text)
            if lit_match:
                literal_assignments[lit_match.group(1)] = lit_match.group(2)

        constants = {
            name: value
            for name, value in literal_assignments.items()
            if assignment_counts.get(name, 0) == 1
        }

        output = []
        index = 0
        while index < len(lines):
            line_text = lines[index]
            stripped = line_text.strip()
            normalized = stripped[:-1].rstrip() if stripped.endswith(';') else stripped
            if normalized != 'while true do':
                output.append(line_text)
                index += 1
                continue

            end_index = self._find_matching_block_end_line(lines, index)
            if end_index == -1:
                output.append(line_text)
                index += 1
                continue

            body_lines = lines[index + 1:end_index]
            non_empty = [(i, line) for i, line in enumerate(body_lines) if line.strip()]
            if len(non_empty) < 3:
                output.append(line_text)
                index += 1
                continue

            _, first_line = non_empty[0]
            _, second_line = non_empty[1]
            _, third_line = non_empty[2]

            first_norm = first_line.strip()
            second_norm = second_line.strip()
            third_norm = third_line.strip()

            cond_match = re.match(r'^if\s+not\s+([A-Za-z_][A-Za-z0-9_]*)\s+then\s*;?$', first_norm)
            if not cond_match or second_norm != 'break' or third_norm != 'end':
                output.append(line_text)
                index += 1
                continue

            guard_var = cond_match.group(1)
            guard_value = constants.get(guard_var)
            if guard_value != 'false':
                output.append(line_text)
                index += 1
                continue

            # Loop is guaranteed dead when guard is constant false.
            index = end_index + 1

        rewritten_text = '\n'.join(output)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _propagate_prometheus_immediate_literal_aliases(self, script_content):
        lines = script_content.splitlines()
        assign_pattern = re.compile(
            r'^(\s*)(local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*;?\s*$'
        )
        simple_ident_pattern = re.compile(r'^[A-Za-z_][A-Za-z0-9_]*$')
        literal_pattern = re.compile(
            r'^(?:true|false|nil|[-+]?\d+(?:\.\d+)?)$'
        )

        known_literals = {}
        output = []
        for line_text in lines:
            m = assign_pattern.match(line_text)
            if not m:
                output.append(line_text)
                continue

            indent_text, local_kw, lhs_name, rhs_text = m.groups()
            rhs_text = rhs_text.strip()
            rewritten_rhs = rhs_text

            if simple_ident_pattern.fullmatch(rhs_text) and rhs_text in known_literals:
                rewritten_rhs = known_literals[rhs_text]
                line_text = f"{indent_text}{local_kw or ''}{lhs_name} = {rewritten_rhs}"

            output.append(line_text)

            if literal_pattern.fullmatch(rewritten_rhs):
                known_literals[lhs_name] = rewritten_rhs
            else:
                known_literals.pop(lhs_name, None)

        rewritten_text = '\n'.join(output)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _simplify_prometheus_constant_if_conditions(self, script_content):
        lines = script_content.splitlines()
        assignment_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(true|false|nil)\s*;?\s*$'
        )
        any_assign_pattern = re.compile(r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=')
        if_var_pattern = re.compile(r'^(\s*)if\s+([A-Za-z_][A-Za-z0-9_]*)\s+then\s*$')
        if_not_var_pattern = re.compile(r'^(\s*)if\s+not\s+([A-Za-z_][A-Za-z0-9_]*)\s+then\s*$')

        literal_assignments = {}
        assignment_counts = Counter()
        for line_text in lines:
            any_match = any_assign_pattern.match(line_text)
            if any_match:
                assignment_counts[any_match.group(1)] += 1
            lit_match = assignment_pattern.match(line_text)
            if lit_match:
                literal_assignments[lit_match.group(1)] = lit_match.group(2)
        constants = {
            name: value
            for name, value in literal_assignments.items()
            if assignment_counts.get(name, 0) == 1
        }

        output = []
        for line_text in lines:
            m_if = if_var_pattern.match(line_text)
            if m_if:
                indent_text, var_name = m_if.groups()
                const_value = constants.get(var_name)
                if const_value in {'true', 'false'}:
                    output.append(f"{indent_text}if {const_value} then")
                    continue

            m_if_not = if_not_var_pattern.match(line_text)
            if m_if_not:
                indent_text, var_name = m_if_not.groups()
                const_value = constants.get(var_name)
                if const_value == 'true':
                    output.append(f"{indent_text}if false then")
                    continue
                if const_value == 'false':
                    output.append(f"{indent_text}if true then")
                    continue

            output.append(line_text)

        rewritten_text = '\n'.join(output)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _prune_prometheus_literal_if_blocks(self, script_content):
        lines = script_content.splitlines()
        output = []
        index = 0

        if_true_pattern = re.compile(r'^\s*if\s+true\s+then\s*$')
        if_false_pattern = re.compile(r'^\s*if\s+false\s+then\s*$')

        while index < len(lines):
            line_text = lines[index]
            if not (if_true_pattern.match(line_text) or if_false_pattern.match(line_text)):
                output.append(line_text)
                index += 1
                continue

            block_end = self._find_matching_block_end_line(lines, index)
            if block_end == -1:
                output.append(line_text)
                index += 1
                continue

            if_indent = self._line_indent(line_text)
            has_else_branch = False
            for probe in range(index + 1, block_end):
                stripped = lines[probe].strip()
                normalized = stripped[:-1].rstrip() if stripped.endswith(';') else stripped
                if self._line_indent(lines[probe]) == if_indent and (
                    normalized == 'else' or normalized.startswith('elseif ')
                ):
                    has_else_branch = True
                    break
            if has_else_branch:
                output.append(line_text)
                index += 1
                continue

            if if_false_pattern.match(line_text):
                index = block_end + 1
                continue

            # if true then ... end
            body_lines = lines[index + 1:block_end]
            output.extend(body_lines)
            index = block_end + 1

        rewritten_text = '\n'.join(output)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _simplify_prometheus_adjacent_bool_goto_conditions(self, script_content):
        lines = script_content.splitlines()
        assign_bool_pattern = re.compile(
            r'^(\s*)(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(true|false)\s*;?\s*$'
        )
        if_goto_var_pattern = re.compile(
            r'^(\s*)if\s+([A-Za-z_][A-Za-z0-9_]*)\s+then\s+goto\s+block_(\d+)\s+else\s+goto\s+block_(\d+)\s+end\s*;?\s*$'
        )
        if_not_goto_var_pattern = re.compile(
            r'^(\s*)if\s+not\s+([A-Za-z_][A-Za-z0-9_]*)\s+then\s+goto\s+block_(\d+)\s+else\s+goto\s+block_(\d+)\s+end\s*;?\s*$'
        )

        output = list(lines)
        index = 0
        while index < len(lines):
            assign_match = assign_bool_pattern.match(lines[index])
            if not assign_match:
                index += 1
                continue
            _, var_name, bool_value = assign_match.groups()

            next_index = index + 1
            while next_index < len(lines) and not lines[next_index].strip():
                next_index += 1
            if next_index >= len(lines):
                index += 1
                continue

            m_if = if_goto_var_pattern.match(lines[next_index])
            if m_if and m_if.group(2) == var_name:
                indent_text, _, true_label, false_label = m_if.groups()
                target_label = true_label if bool_value == 'true' else false_label
                output[next_index] = f"{indent_text}goto block_{target_label}"
                index = next_index + 1
                continue

            m_if_not = if_not_goto_var_pattern.match(lines[next_index])
            if m_if_not and m_if_not.group(2) == var_name:
                indent_text, _, true_label, false_label = m_if_not.groups()
                target_label = true_label if bool_value == 'false' else false_label
                output[next_index] = f"{indent_text}goto block_{target_label}"
                index = next_index + 1
                continue

            index += 1

        rewritten_text = '\n'.join(output)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _simplify_prometheus_adjacent_bool_if_branches(self, script_content):
        lines = script_content.splitlines()
        assign_bool_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(true|false)\s*;?\s*$'
        )
        if_var_pattern = re.compile(r'^\s*if\s+([A-Za-z_][A-Za-z0-9_]*)\s+then\s*$')
        if_not_var_pattern = re.compile(r'^\s*if\s+not\s+([A-Za-z_][A-Za-z0-9_]*)\s+then\s*$')

        output = []
        index = 0
        while index < len(lines):
            assign_match = assign_bool_pattern.match(lines[index])
            if not assign_match:
                output.append(lines[index])
                index += 1
                continue

            var_name, bool_value = assign_match.groups()
            output.append(lines[index])

            next_index = index + 1
            while next_index < len(lines) and not lines[next_index].strip():
                output.append(lines[next_index])
                next_index += 1
            if next_index >= len(lines):
                index = next_index
                continue

            cond_truth = None
            m_if = if_var_pattern.match(lines[next_index])
            if m_if and m_if.group(1) == var_name:
                cond_truth = (bool_value == 'true')
            else:
                m_if_not = if_not_var_pattern.match(lines[next_index])
                if m_if_not and m_if_not.group(1) == var_name:
                    cond_truth = (bool_value == 'false')

            if cond_truth is None:
                index = next_index
                continue

            block_end = self._find_matching_block_end_line(lines, next_index)
            if block_end == -1:
                index = next_index
                continue

            if_indent = self._line_indent(lines[next_index])
            else_index = None
            for probe in range(next_index + 1, block_end):
                stripped = lines[probe].strip()
                normalized = stripped[:-1].rstrip() if stripped.endswith(';') else stripped
                if self._line_indent(lines[probe]) == if_indent and normalized == 'else':
                    else_index = probe
                    break
                if self._line_indent(lines[probe]) == if_indent and normalized.startswith('elseif '):
                    else_index = -1
                    break
            if else_index == -1:
                index = next_index
                continue

            if else_index is None:
                if cond_truth:
                    chosen_lines = lines[next_index + 1:block_end]
                else:
                    chosen_lines = []
            else:
                if cond_truth:
                    chosen_lines = lines[next_index + 1:else_index]
                else:
                    chosen_lines = lines[else_index + 1:block_end]

            output.extend(chosen_lines)
            index = block_end + 1

        rewritten_text = '\n'.join(output)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _prune_dead_prometheus_temporaries(self, script_content):
        lines = script_content.splitlines()
        assign_pattern = re.compile(r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*$')
        local_decl_pattern = re.compile(
            r'^\s*local\s+([A-Za-z_][A-Za-z0-9_]*(?:\s*,\s*[A-Za-z_][A-Za-z0-9_]*)+)\s*$'
        )
        token_pattern = re.compile(r'\b([A-Za-z_][A-Za-z0-9_]*)\b')
        pure_rhs_pattern = re.compile(
            r'^[A-Za-z0-9_\s\+\-\*/%\^\(\)\|&~<>=!,"\'.:]+$'
        )
        reserved = {
            'if', 'then', 'end', 'while', 'do', 'repeat', 'until', 'for', 'in',
            'local', 'function', 'return', 'and', 'or', 'not', 'nil', 'true',
            'false', 'break'
        }

        # This liveness pass is intentionally conservative: only prune assignments at
        # top-level. Pruning inside control-flow blocks can alter loop/branch semantics.
        top_level_line = [False] * len(lines)
        block_depth = 0
        opener_pattern = re.compile(
            r'^(?:if\b.*\bthen|while\b.*\bdo|for\b.*\bdo|repeat|do|function\b|local\s+function\b)'
        )
        assignment_function_pattern = re.compile(r'=\s*function\b')

        for idx, line_text in enumerate(lines):
            stripped = line_text.strip()
            normalized = stripped[:-1].rstrip() if stripped.endswith(';') else stripped
            if normalized == 'end' or normalized.startswith('until '):
                block_depth = max(0, block_depth - 1)
            top_level_line[idx] = (block_depth == 0)
            if opener_pattern.match(normalized) or assignment_function_pattern.search(normalized):
                block_depth += 1

        live_vars = set()
        kept_reversed = []

        for reverse_index, line_text in enumerate(reversed(lines)):
            line_index = len(lines) - 1 - reverse_index
            is_top_level = top_level_line[line_index]
            stripped = line_text.strip()
            if not stripped:
                kept_reversed.append(line_text)
                continue

            if not is_top_level:
                for token in token_pattern.findall(line_text):
                    if token in reserved:
                        continue
                    live_vars.add(token)
                kept_reversed.append(line_text)
                continue

            local_decl_match = local_decl_pattern.match(line_text)
            if local_decl_match:
                decl_vars = [part.strip() for part in local_decl_match.group(1).split(',')]
                kept_vars = [name for name in decl_vars if name in live_vars]
                if kept_vars:
                    indent = line_text[:len(line_text) - len(line_text.lstrip(' \t'))]
                    kept_reversed.append(f"{indent}local {','.join(kept_vars)}")
                continue

            assign_match = assign_pattern.match(line_text)
            if assign_match:
                lhs_name = assign_match.group(1)
                rhs_text = assign_match.group(2).strip()
                is_pure_rhs = (
                    pure_rhs_pattern.fullmatch(rhs_text) is not None
                )
                # Treat RHS as impure if it looks like a function call.
                if re.search(r'[A-Za-z_][A-Za-z0-9_]*\s*\(', rhs_text):
                    is_pure_rhs = False

                if lhs_name not in live_vars and is_pure_rhs:
                    continue

                live_vars.discard(lhs_name)
                for token in token_pattern.findall(rhs_text):
                    if token in reserved:
                        continue
                    if token == lhs_name:
                        continue
                    live_vars.add(token)

                kept_reversed.append(line_text)
                continue

            for token in token_pattern.findall(line_text):
                if token in reserved:
                    continue
                live_vars.add(token)
            kept_reversed.append(line_text)

        kept_lines = list(reversed(kept_reversed))
        rewritten_text = '\n'.join(kept_lines)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _simplify_prometheus_env_alias_assignments(self, script_content):
        source_lines = script_content.splitlines()
        rewritten_lines = []
        scope_stack = [{'literal_aliases': {}}]
        assignment_pattern = re.compile(r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*$')
        literal_pattern = re.compile(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'')
        env_lookup_pattern = re.compile(
            r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(env|_G)\s*\[\s*([A-Za-z_][A-Za-z0-9_]*)\s*\]\s*$'
        )
        function_pattern = re.compile(r'\bfunction\s*\(')

        for line_text in source_lines:
            stripped_text = line_text.strip()
            current_scope = scope_stack[-1]
            literal_aliases = current_scope['literal_aliases']
            rewritten_line = line_text
            lookup_match = env_lookup_pattern.match(line_text)
            if lookup_match:
                lhs_name, env_name, key_var = lookup_match.groups()
                key_literal = None
                for scope_data in reversed(scope_stack):
                    key_literal = scope_data['literal_aliases'].get(key_var)
                    if key_literal is not None:
                        break
                if key_literal:
                    try:
                        key_value = self._parse_lua_string_literal(key_literal)
                    except Exception:
                        key_value = None
                    if key_value is not None:
                        if re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', key_value):
                            rewritten_line = f"{lhs_name} = {key_value}"
                        else:
                            rewritten_line = f"{lhs_name} = {env_name}[{self._format_lua_string(key_value)}]"

            rewritten_lines.append(rewritten_line)

            assignment_match = assignment_pattern.match(line_text)
            if not assignment_match:
                if function_pattern.search(stripped_text):
                    scope_stack.append({
                        'literal_aliases': dict(literal_aliases)
                    })
                elif stripped_text == 'end' and len(scope_stack) > 1:
                    scope_stack.pop()
                continue
            lhs_name = assignment_match.group(1)
            rhs_text = assignment_match.group(2).strip()
            if literal_pattern.fullmatch(rhs_text):
                literal_aliases[lhs_name] = rhs_text
            else:
                literal_aliases.pop(lhs_name, None)

            if function_pattern.search(stripped_text):
                scope_stack.append({
                    'literal_aliases': dict(literal_aliases)
                })
            elif stripped_text == 'end' and len(scope_stack) > 1:
                scope_stack.pop()

        rewritten_text = '\n'.join(rewritten_lines)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _simplify_prometheus_dynamic_string_key_accesses(self, script_content):
        source_lines = script_content.splitlines()
        rewritten_lines = []
        literal_aliases = {}
        assignment_pattern = re.compile(r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*$')
        literal_pattern = re.compile(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'')
        index_pattern = re.compile(
            r'([A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*)\[\s*([A-Za-z_][A-Za-z0-9_]*)\s*\]'
        )

        for line_text in source_lines:
            assignment_match = assignment_pattern.match(line_text)

            def replace_index(match_object):
                table_name = match_object.group(1)
                key_alias = match_object.group(2)
                literal_token = literal_aliases.get(key_alias)
                if not literal_token:
                    return match_object.group(0)
                try:
                    key_value = self._parse_lua_string_literal(literal_token)
                except Exception:
                    return match_object.group(0)
                if re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', key_value):
                    return f"{table_name}.{key_value}"
                return f"{table_name}[{self._format_lua_string(key_value)}]"

            rewritten_line = index_pattern.sub(replace_index, line_text)
            rewritten_line = self._simplify_prometheus_string_key_accesses(rewritten_line)
            rewritten_lines.append(rewritten_line)

            if not assignment_match:
                continue
            assigned_name = assignment_match.group(1)
            rhs_text = assignment_match.group(2).strip()
            if literal_pattern.fullmatch(rhs_text):
                literal_aliases[assigned_name] = rhs_text
            else:
                literal_aliases.pop(assigned_name, None)

        rewritten_text = '\n'.join(rewritten_lines)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _simplify_prometheus_method_alias_calls(self, script_content):
        source_lines = script_content.splitlines()
        rewritten_lines = []
        method_aliases = {}
        assign_method_pattern = re.compile(
            r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([A-Za-z_][A-Za-z0-9_\.]*)\.([A-Za-z_][A-Za-z0-9_]*)\s*$'
        )
        assignment_pattern = re.compile(r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*$')
        call_with_assign_pattern = re.compile(
            r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\(\s*([A-Za-z_][A-Za-z0-9_\.]*)\s*(?:,\s*(.*?))?\s*\)\s*$'
        )
        call_no_assign_pattern = re.compile(
            r'^\s*([A-Za-z_][A-Za-z0-9_]*)\(\s*([A-Za-z_][A-Za-z0-9_\.]*)\s*(?:,\s*(.*?))?\s*\)\s*$'
        )

        for line_text in source_lines:
            call_match = call_with_assign_pattern.match(line_text)
            if call_match:
                lhs_name, fn_name, object_name, args_text = call_match.groups()
                alias_data = method_aliases.get(fn_name)
                if alias_data and alias_data['object'] == object_name:
                    if args_text is None or not args_text.strip():
                        rewritten_lines.append(f"{lhs_name} = {object_name}:{alias_data['method']}()")
                    else:
                        rewritten_lines.append(f"{lhs_name} = {object_name}:{alias_data['method']}({args_text.strip()})")
                    method_aliases.pop(lhs_name, None)
                    continue

            call_match = call_no_assign_pattern.match(line_text)
            if call_match:
                fn_name, object_name, args_text = call_match.groups()
                alias_data = method_aliases.get(fn_name)
                if alias_data and alias_data['object'] == object_name:
                    if args_text is None or not args_text.strip():
                        rewritten_lines.append(f"{object_name}:{alias_data['method']}()")
                    else:
                        rewritten_lines.append(f"{object_name}:{alias_data['method']}({args_text.strip()})")
                    continue

            assignment_match = assignment_pattern.match(line_text)
            if assignment_match:
                assigned_name = assignment_match.group(1)
                method_aliases.pop(assigned_name, None)

                method_match = assign_method_pattern.match(line_text)
                if method_match:
                    alias_name, object_name, method_name = method_match.groups()
                    method_aliases[alias_name] = {
                        'object': object_name,
                        'method': method_name
                    }

            rewritten_lines.append(line_text)

        rewritten_text = '\n'.join(rewritten_lines)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _remove_redundant_prometheus_method_loads(self, script_content):
        source_lines = script_content.splitlines()
        rewritten_lines = []
        line_index = 0
        load_pattern = re.compile(
            r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([A-Za-z_][A-Za-z0-9_\.]*)\.([A-Za-z_][A-Za-z0-9_]*)\s*$'
        )
        call_pattern = re.compile(
            r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([A-Za-z_][A-Za-z0-9_\.]*):([A-Za-z_][A-Za-z0-9_]*)\('
        )

        while line_index < len(source_lines):
            current_line = source_lines[line_index]
            load_match = load_pattern.match(current_line)
            if load_match and line_index + 1 < len(source_lines):
                next_line = source_lines[line_index + 1]
                call_match = call_pattern.match(next_line)
                if call_match:
                    lhs_name, object_name, method_name = load_match.groups()
                    call_lhs, call_object, call_method = call_match.groups()
                    if lhs_name == call_lhs and object_name == call_object and method_name == call_method:
                        line_index += 1
                        continue
            rewritten_lines.append(current_line)
            line_index += 1

        rewritten_text = '\n'.join(rewritten_lines)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _looks_like_prometheus_placeholder_identifier(self, identifier_name):
        return (
            len(identifier_name) >= 8
            and re.search(r'[A-Z]', identifier_name)
            and re.search(r'[a-z]', identifier_name)
            and re.search(r'\d', identifier_name)
        )

    def _fix_prometheus_placeholder_returns(self, script_content):
        source_lines = script_content.splitlines()
        rewritten_lines = []

        for line_text in source_lines:
            return_match = re.match(r'^(\s*)return\s+([A-Za-z_][A-Za-z0-9_]*)\s*$', line_text)
            if not return_match:
                rewritten_lines.append(line_text)
                continue

            indent_text, return_name = return_match.groups()
            if not self._looks_like_prometheus_placeholder_identifier(return_name):
                rewritten_lines.append(line_text)
                continue

            while rewritten_lines and re.match(
                rf'^\s*pc\s*=\s*{re.escape(return_name)}\s*$',
                rewritten_lines[-1]
            ):
                rewritten_lines.pop()

            previous_line = rewritten_lines[-1] if rewritten_lines else ''
            unpack_wrap_match = re.match(
                r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*\{\s*unpack_fn\(([^)]*)\)\s*\}\s*$',
                previous_line
            )
            single_wrap_match = re.match(
                r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*\{\s*([A-Za-z_][A-Za-z0-9_]*)\s*\}\s*$',
                previous_line
            )

            if unpack_wrap_match:
                rewritten_lines.append(f"{indent_text}return unpack_fn({unpack_wrap_match.group(1)})")
                continue

            if single_wrap_match:
                rewritten_lines.append(f"{indent_text}return {single_wrap_match.group(2)}")
                continue

            rewritten_lines.append(f"{indent_text}return")

        return '\n'.join(rewritten_lines) + ('\n' if script_content.endswith('\n') else '')

    def _simplify_prometheus_tamper_closures(self, script_content):
        source_lines = script_content.splitlines()
        rewritten_lines = []
        current_index = 0

        while current_index < len(source_lines):
            function_match = re.match(
                r'^(\s*)([A-Za-z_][A-Za-z0-9_]*)\s*=\s*function\(([^)]*)\)\s*$',
                source_lines[current_index]
            )
            if not function_match:
                rewritten_lines.append(source_lines[current_index])
                current_index += 1
                continue

            indent_text, lhs_text, args_text = function_match.groups()
            function_indent = indent_text + '    '
            next_index = current_index + 1

            if next_index + 2 >= len(source_lines):
                rewritten_lines.append(source_lines[current_index])
                current_index += 1
                continue

            error_alias_match = re.match(
                rf'^{re.escape(function_indent)}[A-Za-z_][A-Za-z0-9_]*\s*=\s*error\s*$',
                source_lines[next_index]
            )
            tamper_call_match = re.match(
                rf'^{re.escape(function_indent)}[A-Za-z_][A-Za-z0-9_]*\s*=\s*[A-Za-z_][A-Za-z0-9_]*\("Tamper Detected!"\)\s*$',
                source_lines[next_index + 1]
            )

            if not error_alias_match or not tamper_call_match:
                rewritten_lines.append(source_lines[current_index])
                current_index += 1
                continue

            end_index = next_index + 2
            if re.match(
                rf'^{re.escape(function_indent)}return [A-Za-z_][A-Za-z0-9_]*\s*$',
                source_lines[end_index]
            ):
                end_index += 1

            if end_index >= len(source_lines) or source_lines[end_index].strip() != 'end':
                rewritten_lines.append(source_lines[current_index])
                current_index += 1
                continue

            rewritten_lines.append(f"{indent_text}{lhs_text} = function({args_text})")
            rewritten_lines.append(f"{function_indent}error(\"Tamper Detected!\")")
            rewritten_lines.append(f"{indent_text}end")
            current_index = end_index + 1

        rewritten_text = '\n'.join(rewritten_lines)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _simplify_prometheus_top_level_env_returns(self, script_content):
        lines = script_content.splitlines()
        rewritten_lines = []
        open_depth = 0

        return_env_pattern = re.compile(
            r'^\s*return\s+(?:env|_G)\s*(?:\[\s*(?:"(?:[^"\\]|\\.)*"|\'(?:[^\'\\]|\\.)*\')\s*\]|\.[A-Za-z_][A-Za-z0-9_]*)\s*$'
        )

        for line_text in lines:
            stripped = line_text.strip()
            normalized = stripped[:-1].rstrip() if stripped.endswith(';') else stripped

            looks_top_level = (open_depth == 0) or (line_text and not line_text.startswith((' ', '\t')))
            if looks_top_level and return_env_pattern.match(stripped):
                indent = line_text[:len(line_text) - len(line_text.lstrip(' \t'))]
                rewritten_lines.append(f"{indent}return")
            else:
                rewritten_lines.append(line_text)

            if (
                re.match(r'^(if\b.*then|while\b.*do|for\b.*do|function\b|local\s+function\b)', normalized)
                or re.search(r'=\s*function\b', normalized)
                or normalized == 'repeat'
            ):
                open_depth += 1
            elif normalized == 'end' or normalized.startswith('until '):
                open_depth = max(0, open_depth - 1)

        rewritten_text = '\n'.join(rewritten_lines)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _neutralize_prometheus_antitamper_residuals(self, script_content):
        if (
            'Tamper Detected!' not in script_content
            and 'env[' not in script_content
            and 'env.' not in script_content
        ):
            return script_content

        declared_names = self._collect_declared_lua_names(script_content)
        builtin_names = {
            '_ENV', '_G', 'assert', 'bit32', 'coroutine', 'debug', 'error', 'game',
            'getfenv', 'getgenv', 'io', 'ipairs', 'load', 'math', 'next', 'os',
            'pairs', 'pcall', 'print', 'rawequal', 'rawget', 'rawset', 'require',
            'select', 'setfenv', 'setmetatable', 'string', 'table', 'task',
            'tonumber', 'tostring', 'type', 'unpack', 'utf8', 'warn', 'workspace',
            'xpcall'
        }
        known_names = declared_names | builtin_names
        lines = script_content.splitlines()
        env_is_bound = False
        top_level_depth = 0
        top_local_decl_pattern = re.compile(
            r'^\s*local\s+([A-Za-z_][A-Za-z0-9_]*(?:\s*,\s*[A-Za-z_][A-Za-z0-9_]*)*)\s*(?:=|$)'
        )
        top_assign_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*='
        )
        for scan_line in lines:
            stripped_scan = scan_line.strip()
            normalized_scan = stripped_scan[:-1].rstrip() if stripped_scan.endswith(';') else stripped_scan
            looks_top_level_scan = (top_level_depth == 0) or (scan_line and not scan_line.startswith((' ', '\t')))
            if looks_top_level_scan:
                local_match = top_local_decl_pattern.match(scan_line)
                if local_match:
                    if 'env' in [part.strip() for part in local_match.group(1).split(',')]:
                        env_is_bound = True
                        break
                assign_match = top_assign_pattern.match(scan_line)
                if assign_match and assign_match.group(1) == 'env':
                    env_is_bound = True
                    break

            if (
                re.match(r'^(if\b.*then|while\b.*do|for\b.*do|function\b|local\s+function\b)', normalized_scan)
                or re.search(r'=\s*function\b', normalized_scan)
                or normalized_scan == 'repeat'
            ):
                top_level_depth += 1
            elif normalized_scan == 'end' or normalized_scan.startswith('until '):
                top_level_depth = max(0, top_level_depth - 1)

        rewritten_lines = []
        open_depth = 0
        literal_aliases = {}

        top_level_env_assign_pattern = re.compile(
            r'^(\s*)(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*env\s*(?:\[[^\]]+\]|\.[A-Za-z_][A-Za-z0-9_]*)\s*$'
        )
        top_level_env_return_pattern = re.compile(
            r'^(\s*)return\s+env\s*(?:\[[^\]]+\]|\.[A-Za-z_][A-Za-z0-9_]*)\s*$'
        )
        top_level_env_index_pattern = re.compile(
            r'^(\s*)(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*env\s*\[\s*([A-Za-z_][A-Za-z0-9_]*|"[^"]*"|\'[^\']*\')\s*\]\s*$'
        )
        top_level_env_dot_pattern = re.compile(
            r'^(\s*)(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*env\.([A-Za-z_][A-Za-z0-9_]*)\s*$'
        )
        self_call_pattern = re.compile(
            r'^(\s*)(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*\)\s*$'
        )
        literal_assign_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*("([^"\\]|\\.)*"|\'([^\'\\]|\\.)*\')\s*$'
        )

        for line_text in lines:
            stripped = line_text.strip()
            normalized = stripped[:-1].rstrip() if stripped.endswith(';') else stripped
            rewritten_line = line_text

            literal_match = literal_assign_pattern.match(line_text)
            if literal_match:
                alias_name = literal_match.group(1)
                literal_token = literal_match.group(2)
                try:
                    literal_aliases[alias_name] = self._parse_lua_string_literal(literal_token)
                except Exception:
                    literal_aliases.pop(alias_name, None)

            looks_top_level = (open_depth == 0) or (line_text and not line_text.startswith((' ', '\t')))
            if looks_top_level and stripped:
                if not env_is_bound:
                    env_idx_match = top_level_env_index_pattern.match(line_text)
                    env_dot_match = top_level_env_dot_pattern.match(line_text)
                    if env_idx_match:
                        indent_text, lhs_name, key_expr = env_idx_match.groups()
                        key_name = None
                        if re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', key_expr):
                            key_name = literal_aliases.get(key_expr)
                        else:
                            try:
                                key_name = self._parse_lua_string_literal(key_expr)
                            except Exception:
                                key_name = None
                        if key_name and re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', key_name):
                            rewritten_line = f"{indent_text}{lhs_name} = {key_name}"
                        else:
                            lhs_token_pattern = re.compile(rf'\b{re.escape(lhs_name)}\b')
                            future_use = False
                            for probe in range(len(rewritten_lines) + 1, len(lines)):
                                probe_line = lines[probe]
                                if lhs_token_pattern.search(probe_line):
                                    assign_probe = re.match(
                                        r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=',
                                        probe_line
                                    )
                                    if assign_probe and assign_probe.group(1) == lhs_name:
                                        break
                                    future_use = True
                                    break
                            if not future_use:
                                rewritten_line = f"{indent_text}{lhs_name} = nil"
                    elif env_dot_match:
                        indent_text, lhs_name, key_name = env_dot_match.groups()
                        rewritten_line = f"{indent_text}{lhs_name} = {key_name}"
                    else:
                        env_return_match = top_level_env_return_pattern.match(line_text)
                        if env_return_match:
                            pass

                self_call_match = self_call_pattern.match(line_text)
                if self_call_match:
                    indent_text, lhs_name, fn_name, arg_name = self_call_match.groups()
                    if (
                        lhs_name == arg_name
                        and fn_name not in known_names
                        and len(fn_name) <= 2
                    ):
                        rewritten_line = f"{indent_text}{lhs_name} = {arg_name}"

            rewritten_lines.append(rewritten_line)

            if (
                re.match(r'^(if\b.*then|while\b.*do|for\b.*do|function\b|local\s+function\b)', normalized)
                or re.search(r'=\s*function\b', normalized)
                or normalized == 'repeat'
            ):
                open_depth += 1
            elif normalized == 'end' or normalized.startswith('until '):
                open_depth = max(0, open_depth - 1)

        rewritten_text = '\n'.join(rewritten_lines)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _final_prune_unbound_top_level_env_reads(self, script_content):
        if 'env[' not in script_content and 'env.' not in script_content:
            return script_content

        lines = script_content.splitlines()
        local_decl_pattern = re.compile(
            r'^\s*local\s+([A-Za-z_][A-Za-z0-9_]*(?:\s*,\s*[A-Za-z_][A-Za-z0-9_]*)*)\s*(?:=|$)'
        )
        assign_pattern = re.compile(r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+?)\s*$')
        env_read_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*env\s*(?:\[[^\]]+\]|\.[A-Za-z_][A-Za-z0-9_]*)\s*$'
        )
        env_return_pattern = re.compile(
            r'^\s*return\s+env\s*(?:\[[^\]]+\]|\.[A-Za-z_][A-Za-z0-9_]*)\s*$'
        )

        env_is_bound = False
        for line_text in lines:
            local_match = local_decl_pattern.match(line_text)
            if local_match:
                names = [part.strip() for part in local_match.group(1).split(',')]
                if 'env' in names:
                    env_is_bound = True
                    break
            assign_match = assign_pattern.match(line_text)
            if assign_match and assign_match.group(1) == 'env':
                env_is_bound = True
                break
        if env_is_bound:
            return script_content

        rewritten_lines = list(lines)
        for index, line_text in enumerate(lines):
            if env_return_pattern.match(line_text):
                indent = line_text[:len(line_text) - len(line_text.lstrip(' \t'))]
                rewritten_lines[index] = f"{indent}return"
                continue

            env_read_match = env_read_pattern.match(line_text)
            if not env_read_match:
                continue

            lhs_name = env_read_match.group(1)
            lhs_pattern = re.compile(rf'\b{re.escape(lhs_name)}\b')
            used_later = False
            for probe in range(index + 1, len(lines)):
                probe_line = lines[probe]
                if lhs_pattern.search(probe_line):
                    probe_assign = assign_pattern.match(probe_line)
                    if probe_assign and probe_assign.group(1) == lhs_name:
                        break
                    used_later = True
                    break
            if not used_later:
                indent = line_text[:len(line_text) - len(line_text.lstrip(' \t'))]
                rewritten_lines[index] = f"{indent}{lhs_name} = nil"

        rewritten_text = '\n'.join(rewritten_lines)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _drop_preprint_unbound_env_calls(self, script_content):
        lines = script_content.splitlines()
        env_read_pattern = re.compile(
            r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*env\s*(?:\[[^\]]+\]|\.[A-Za-z_][A-Za-z0-9_]*)\s*$'
        )
        call_assign_pattern = re.compile(
            r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\((.*)\)\s*$'
        )
        any_assign_pattern = re.compile(
            r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*='
        )
        print_call_pattern = re.compile(r'^\s*print\(')

        rewritten_lines = list(lines)
        remove_indices = set()

        for index, line_text in enumerate(lines):
            env_match = env_read_pattern.match(line_text)
            if not env_match:
                continue
            fn_var = env_match.group(1)

            probe_limit = min(len(lines), index + 8)
            call_line_index = -1
            call_lhs_name = None
            print_found = False

            for probe in range(index + 1, probe_limit):
                probe_line = lines[probe]
                call_match = call_assign_pattern.match(probe_line)
                if call_match and call_match.group(2) == fn_var:
                    call_line_index = probe
                    call_lhs_name = call_match.group(1)
                    continue
                if print_call_pattern.match(probe_line):
                    print_found = True
                    break

            if call_line_index == -1 or not print_found or not call_lhs_name:
                continue

            lhs_token_pattern = re.compile(rf'\b{re.escape(call_lhs_name)}\b')
            lhs_used_later = False
            for probe in range(call_line_index + 1, len(lines)):
                probe_line = lines[probe]
                if lhs_token_pattern.search(probe_line):
                    assign_match = any_assign_pattern.match(probe_line)
                    if assign_match and assign_match.group(1) == call_lhs_name:
                        break
                    lhs_used_later = True
                    break
            if lhs_used_later:
                continue

            remove_indices.add(call_line_index)

            fn_used_later = False
            fn_token_pattern = re.compile(rf'\b{re.escape(fn_var)}\b')
            for probe in range(index + 1, len(lines)):
                if probe == call_line_index:
                    continue
                probe_line = lines[probe]
                if fn_token_pattern.search(probe_line):
                    assign_match = any_assign_pattern.match(probe_line)
                    if assign_match and assign_match.group(1) == fn_var:
                        break
                    fn_used_later = True
                    break
            if not fn_used_later:
                remove_indices.add(index)

        if remove_indices:
            rewritten_lines = [
                line for line_index, line in enumerate(rewritten_lines)
                if line_index not in remove_indices
            ]

        rewritten_text = '\n'.join(rewritten_lines)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _score_prometheus_readability_variant(self, script_content):
        if not script_content:
            return -10**9
        score_value = 0.0
        quoted_literals = re.findall(r'"([^"\\]*(?:\\.[^"\\]*)*)"', script_content)
        for literal_text in quoted_literals:
            plain_text = re.sub(r'\\.', 'x', literal_text)
            if len(plain_text) >= 4 and re.search(r'[A-Za-z]', plain_text):
                score_value += 0.7

        for marker_text in (
            'Instance.new', 'game:GetService', ':WaitForChild', 'MouseButton1Click',
            'WalkSpeed', 'JumpPower', 'ScreenGui', 'TextButton', 'TextLabel',
            'Frame', 'PlayerGui', 'LocalPlayer', 'task.spawn', 'print('
        ):
            score_value += script_content.count(marker_text) * 2.0

        penalties = (
            ('_local', 0.22),
            ('env[', 3.2),
            ('while true', 2.4),
            ('nil[', 2.8),
            ('next_prng_byte[', 1.5),
            ('decode_runtime_string(', 2.0),
            ('= nil', 0.3),
        )
        for marker_text, weight in penalties:
            score_value -= script_content.count(marker_text) * weight
        register_hits = len(re.findall(r'\br\d+(?:_local)?\b', script_content))
        score_value -= register_hits * 0.18
        pc_assign_hits = len(re.findall(r'^\s*pc\s*=', script_content, flags=re.MULTILINE))
        score_value -= pc_assign_hits * 0.25
        return score_value

    def _map_placeholder_returns_from_reference(self, script_content, reference_content):
        if not script_content or not reference_content:
            return script_content
        lines = reference_content.splitlines()
        assign_literal_pattern = re.compile(
            r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*("(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\')\s*;?\s*$'
        )
        return_placeholder_pattern = re.compile(
            r'^\s*return\s+([A-Za-z_][A-Za-z0-9_]*)\s*;?\s*$'
        )
        mapping = {}
        for index, line_text in enumerate(lines):
            ret_match = return_placeholder_pattern.match(line_text.strip())
            if not ret_match:
                continue
            placeholder = ret_match.group(1)
            if placeholder in {'pc', 'ret_reg', 'true', 'false', 'nil'}:
                continue
            for back_index in range(index - 1, max(-1, index - 10), -1):
                assign_match = assign_literal_pattern.match(lines[back_index].strip())
                if not assign_match:
                    continue
                literal_text = assign_match.group(2)
                mapping[placeholder] = literal_text
                break
        if not mapping:
            return script_content

        target_lines = script_content.splitlines()
        rewritten = []
        for line_text in target_lines:
            ret_match = return_placeholder_pattern.match(line_text.strip())
            if not ret_match:
                rewritten.append(line_text)
                continue
            placeholder = ret_match.group(1)
            literal_text = mapping.get(placeholder)
            if not literal_text:
                rewritten.append(line_text)
                continue
            indent_text = line_text[:len(line_text) - len(line_text.lstrip(' \t'))]
            rewritten.append(f'{indent_text}return {literal_text}')

        rewritten_text = '\n'.join(rewritten)
        return rewritten_text + ('\n' if script_content.endswith('\n') else '')

    def _inject_prometheus_function_locals(self, function_body, captures, arg_spec, indent_level):
        capture_names = set()
        for capture_text in captures or []:
            stripped_capture = capture_text.strip()
            slotref_match = re.fullmatch(r'__slotref__([A-Za-z_][A-Za-z0-9_]*)', stripped_capture)
            if slotref_match:
                capture_name = slotref_match.group(1)
                capture_names.add(capture_name)
            elif re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', stripped_capture):
                capture_names.add(stripped_capture)

        arg_names = set(arg_spec) if isinstance(arg_spec, list) else set()
        preserved_capture_names = set()
        for capture_name in capture_names:
            first_use_is_assignment = None
            for body_line in function_body.splitlines():
                if re.match(rf'^\s*(?:local\s+)?{re.escape(capture_name)}\s*=', body_line):
                    first_use_is_assignment = True
                    break
                if re.search(rf'\b{re.escape(capture_name)}\b', body_line):
                    first_use_is_assignment = False
                    break
            if first_use_is_assignment is not True:
                preserved_capture_names.add(capture_name)

        excluded_names = preserved_capture_names | arg_names | {
            'env', 'unpack_fn', 'argv', 'runtime_slots'
        }

        candidate_names = []
        for identifier_name in sorted(self._collect_prometheus_identifiers(function_body)):
            if identifier_name in excluded_names:
                continue
            if re.fullmatch(r'(?:ret_reg|pc|r\d+(?:_local)?)', identifier_name):
                candidate_names.append(identifier_name)

        if not candidate_names:
            return function_body

        indent_prefix = '    ' * (indent_level + 1)
        local_line = f"{indent_prefix}local {','.join(candidate_names)}"
        return f"{local_line}\n{function_body}"

    def _render_prometheus_function_literal(self, start_block_id, captures, arg_spec, loop_data, runtime_layout, blocks_by_id, decompile_state, indent_level):
        if start_block_id not in blocks_by_id:
            return f"function(...) -- unresolved block {start_block_id}\n{'    ' * indent_level}end"

        recursion_key = (start_block_id, tuple(captures), str(arg_spec))
        if recursion_key in decompile_state['active_functions']:
            return f"function(...) -- recursive block {start_block_id}\n{'    ' * indent_level}end"

        decompile_state['active_functions'].add(recursion_key)
        try:
            argument_list = '...' if arg_spec == 'vararg' else ', '.join(arg_spec)
            function_body = self._render_prometheus_function_body(
                start_block_id,
                captures,
                loop_data,
                runtime_layout,
                blocks_by_id,
                decompile_state,
                indent_level + 1
            )
            function_body = self._inject_prometheus_function_locals(
                function_body,
                captures,
                arg_spec,
                indent_level
            )
            if isinstance(arg_spec, list):
                for arg_index, arg_name in enumerate(arg_spec, 1):
                    function_body = re.sub(
                        rf'\bargv\s*\[\s*{arg_index}\s*\]',
                        arg_name,
                        function_body
                    )
        finally:
            decompile_state['active_functions'].remove(recursion_key)

        indent_prefix = '    ' * indent_level
        return f"function({argument_list})\n{function_body}\n{indent_prefix}end"

    def _render_prometheus_function_body(self, start_block_id, captures, loop_data, runtime_layout, blocks_by_id, decompile_state, indent_level):
        translated_blocks = self._build_prometheus_translated_blocks(
            start_block_id,
            captures,
            loop_data,
            runtime_layout,
            blocks_by_id,
            decompile_state,
            indent_level
        )
        return self._render_prometheus_structured_flow(
            start_block_id,
            translated_blocks,
            indent_level
        )

    def _decompile_prometheus_vm_to_pseudolua(self, script_content):
        runtime_layout = self._extract_prometheus_runtime_layout(script_content)
        if not runtime_layout:
            return None
        runtime_layout = dict(runtime_layout)
        runtime_layout['env_names'] = self._extract_prometheus_env_names(script_content)

        loop_data = self._extract_main_prometheus_loop(script_content)
        if not loop_data or len(loop_data.get('function_params', [])) < 3:
            return None

        loop_data = {
            'state_var': loop_data['state_var'],
            'capture_var': loop_data['function_params'][2]
        }

        known_block_ids = self._collect_prometheus_entry_ids(
            script_content,
            runtime_layout,
            loop_data['state_var']
        )
        blocks_by_id = {}
        loop_source = self._extract_main_prometheus_loop(script_content)
        preferred_block_ids = self._collect_prometheus_creator_entry_ids(script_content, runtime_layout)

        for _ in range(4):
            blocks_by_id = self._extract_prometheus_block_candidates(
                loop_source,
                known_block_ids,
                preferred_block_ids
            )
            if not blocks_by_id:
                return None

            discovered_targets = set()
            for block_id, block_data in blocks_by_id.items():
                block_data['transition'] = self._resolve_prometheus_transition(
                    block_data,
                    loop_data['state_var'],
                    runtime_layout.get('env_names'),
                    runtime_layout.get('slot_table_name')
                )
                if block_data['transition']['type'] == 'goto':
                    discovered_targets.add(block_data['transition']['target'])
                elif block_data['transition']['type'] == 'branch':
                    discovered_targets.add(block_data['transition']['true_target'])
                    discovered_targets.add(block_data['transition']['false_target'])

            if discovered_targets.issubset(known_block_ids):
                break

            known_block_ids |= discovered_targets
            preferred_block_ids |= discovered_targets

        top_call = self._extract_prometheus_top_call(script_content, runtime_layout)
        if not top_call:
            return None

        decompile_state = {
            'slot_counter': 0,
            'active_functions': set(),
            'enable_alias_fold': False,
            'enable_dead_prune': False
        }

        default_start_block = top_call['start_block_id']
        render_start_block = self._select_prometheus_payload_start(
            blocks_by_id,
            default_start_block
        )
        if render_start_block not in blocks_by_id:
            render_start_block = default_start_block

        # When AntiTamper is present, start from the best payload block and trim
        # residual preamble in the entry block for a cleaner devirtualized body.
        decompile_state['trim_payload_preamble'] = render_start_block != default_start_block

        body_text = self._render_prometheus_function_body(
            render_start_block,
            [],
            loop_data,
            runtime_layout,
            blocks_by_id,
            decompile_state,
            0
        )

        formatted_body = self._format_prometheus_devirtualized_top_level(
            body_text,
            script_content,
            self._extract_main_prometheus_loop(script_content),
            top_call,
            runtime_layout
        )
        sanitized_text = self._sanitize_prometheus_invalid_identifiers(formatted_body)
        sanitized_text = self._simplify_prometheus_tamper_closures(sanitized_text)
        return self._remove_unreferenced_prometheus_labels(sanitized_text)

    def run_stage_pipeline(self, script_content):
        self._pipeline_prng_decoder_constants = None
        self._pipeline_prng_key8_value = None
        stage_results = []
        aggregate_warnings = []
        current_content = self._strip_wearedev_banner(script_content)
        pipeline_metadata = {
            'decoded_strings': [],
            'decoded_string_bytes': [],
            'cipher_mapping_size': 0,
            'lookup_function': None,
            'reversal_ranges': []
        }
        devirtualization_output = ''
        post_output = ''

        def add_stage_result(stage_key, label, filename, content, warnings=None, skipped=False):
            stage_warnings = warnings or []
            aggregate_warnings.extend(stage_warnings)
            stage_results.append({
                'key': stage_key,
                'label': label,
                'filename': filename,
                'content': content,
                'warnings': stage_warnings,
                'skipped': skipped
            })

        step_warnings = []
        try:
            current_content = self._normalize_lua_string_literals(current_content)
            current_content = self._beautify_lua_source(current_content)
        except Exception as formatter_error:
            step_warnings.append(f'Bước 1: Formatter skipped: {formatter_error}')
        add_stage_result('parsed', 'Parse & Format', 'parsed.txt', current_content, step_warnings)

        constant_array_data = self._apply_constant_array_decryption(current_content)
        current_content = constant_array_data['output']
        pipeline_metadata.update({
            'decoded_strings': constant_array_data['decoded_strings'],
            'decoded_string_bytes': constant_array_data['decoded_string_bytes'],
            'cipher_mapping_size': constant_array_data['cipher_mapping_size'],
            'lookup_function': constant_array_data['lookup_function'],
            'reversal_ranges': constant_array_data['reversal_ranges']
        })
        add_stage_result(
            'encryption',
            'Decrypt Constant Array',
            'encryption.txt',
            current_content,
            constant_array_data['warnings'],
            skipped=any(warning.startswith('Bước 2: Không phát hiện constant array') for warning in constant_array_data['warnings'])
        )

        cff_warnings = []
        cff_input = current_content
        try:
            current_content = self._flatten_prometheus_dispatchers(current_content)
            current_content = self._rename_prometheus_runtime_aliases(current_content)
            current_content = self._rename_prometheus_vm_registers(current_content)
            current_content = self._beautify_lua_source(current_content)
        except Exception as cff_error:
            cff_warnings.append(f'Bước 3: CFF flatten skipped: {cff_error}')
        if current_content == cff_input:
            cff_warnings.append('Bước 3: Không phát hiện state-machine dispatcher rõ ràng, bỏ qua')
        add_stage_result(
            'cff',
            'CFF Removal',
            'cff.txt',
            current_content,
            cff_warnings,
            skipped=current_content == cff_input
        )

        devirt_warnings = []
        devirt_input = current_content
        try:
            devirtualized_content = self._decompile_prometheus_vm_to_pseudolua(current_content)
            if devirtualized_content:
                current_content = self._sanitize_invalid_statement_identifiers(devirtualized_content)
                current_content = self._collapse_prometheus_runtime_slot_reads(current_content)
                current_content = self._force_rename_prometheus_decoder_functions(current_content)
                current_content = self._normalize_prometheus_decoder_call_callees(current_content)
                current_content = self._decode_prometheus_runtime_string_calls(current_content)
                current_content = self._recover_prometheus_decoder_cache_return_literals(current_content)
                current_content = self._repair_concat_function_literal_returns(current_content)
                current_content = self._fix_prometheus_placeholder_returns(current_content)
                current_content = self._remove_unreferenced_prometheus_labels(current_content)
            else:
                devirt_warnings.append('Bước 4: Không phát hiện custom Lua VM phù hợp, bỏ qua')
        except Exception as devirt_error:
            devirt_warnings.append(f'Bước 4: Devirtualization skipped: {devirt_error}')
        add_stage_result(
            'devirtualization',
            'Devirtualization',
            'devirtualization.txt',
            current_content,
            devirt_warnings,
            skipped=current_content == devirt_input
        )
        devirtualization_output = current_content

        post_warnings = []
        post_input = current_content
        try:
            current_content = self._simplify_numeric_lines(current_content)
            current_content = self._simplify_obfuscated_conditions(current_content)
            current_content = self._sanitize_invalid_statement_identifiers(current_content)
            current_content = self._remove_invalid_literal_index_assignments(current_content)
            current_content = self._repair_prometheus_uninitialized_loop_seed(current_content)
            current_content = self._repair_prometheus_uninitialized_shuffle_loop_bound(current_content)
            current_content = self._remove_dangerous_nil_reassignments(current_content)
            current_content = self._prune_impossible_nil_index_calls(current_content)
            current_content = self._prune_nil_value_table_writes(current_content)
            current_content = self._repair_roblox_string_constructor_calls(current_content)
            current_content = self._neutralize_unknown_unary_wrapper_calls(current_content)
            current_content = self._neutralize_prometheus_antitamper_residuals(current_content)
            current_content = self._separate_shadowed_function_bindings(current_content)
            current_content = self._collapse_prometheus_runtime_slot_reads(current_content)
            current_content = self._fix_prometheus_decoder_return_values(current_content)
            current_content = self._ensure_prometheus_decoder_cache_returns(current_content)
            current_content = self._force_rename_prometheus_decoder_functions(current_content)
            current_content = self._separate_prometheus_decoder_cache_from_function(current_content)
            current_content = self._normalize_prometheus_decoder_call_callees(current_content)
            current_content = self._decode_prometheus_runtime_string_calls(current_content)
            current_content = self._map_placeholder_returns_from_reference(
                current_content,
                devirtualization_output
            )
            current_content = self._recover_prometheus_decoder_cache_return_literals(current_content)
            current_content = self._repair_concat_function_literal_returns(current_content)
            current_content = self._inline_literal_table_constructor_aliases(current_content)
            current_content = self._simplify_prometheus_env_alias_assignments(current_content)
            current_content = self._simplify_prometheus_dynamic_env_accesses(current_content)
            current_content = self._collapse_prometheus_unresolved_env_dispatch_calls(current_content)
            current_content = self._simplify_prometheus_dynamic_string_key_accesses(current_content)
            current_content = self._simplify_prometheus_method_alias_calls(current_content)
            current_content = self._remove_redundant_prometheus_method_loads(current_content)
            current_content = self._inline_single_use_prometheus_call_aliases(current_content)
            current_content = self._inline_literal_assignments_before_return(current_content)
            current_content = self._prune_overwritten_prometheus_assignments(current_content)
            current_content = self._simplify_prometheus_print_alias_calls(current_content)
            current_content = self._drop_unused_call_assignment_targets(current_content)
            current_content = self._fix_prometheus_placeholder_returns(current_content)
            current_content = self._simplify_prometheus_top_level_env_returns(current_content)
            current_content = self._expand_compound_assignments(current_content)
            current_content = self._remove_unused_literal_assignments(current_content)
            current_content = self._remove_overwritten_literal_assignments(current_content)
            current_content = self._remove_overwritten_string_seed_assignments(current_content)
            current_content = self._remove_redundant_nil_reassignments(current_content)
            current_content = self._remove_redundant_prometheus_pc_assignments(current_content)
            current_content = self._inline_prometheus_pc_temporaries(current_content)
            current_content = self._propagate_prometheus_immediate_literal_aliases(current_content)
            current_content = self._simplify_prometheus_constant_if_conditions(current_content)
            current_content = self._prune_prometheus_literal_if_blocks(current_content)
            current_content = self._simplify_prometheus_adjacent_bool_goto_conditions(current_content)
            current_content = self._simplify_prometheus_adjacent_bool_if_branches(current_content)
            current_content = self._collapse_prometheus_goto_redirect_labels(current_content)
            current_content = self._remove_prometheus_fallthrough_gotos(current_content)
            current_content = self._simplify_prometheus_if_goto_else_chains(current_content)
            current_content = self._inline_prometheus_single_use_then_label_blocks(current_content)
            current_content = self._remove_prometheus_fallthrough_gotos(current_content)
            current_content = self._simplify_prometheus_guard_loops(current_content)
            current_content = self._prune_constant_guarded_prometheus_loops(current_content)
            current_content = self._simplify_prometheus_obfuscated_loop_conditions(current_content)
            current_content = self._collapse_prometheus_lookup_init_while(current_content)
            current_content = self._collapse_prometheus_lookup_shuffle_repeat(current_content)
            current_content = self._canonicalize_prometheus_lookup_bootstrap(current_content)
            current_content = self._prune_prometheus_anti_preamble_noise(current_content)
            current_content = self._remove_overwritten_builtin_alias_seeds(current_content)
            current_content = self._simplify_prometheus_builtin_alias_accesses(current_content)
            current_content = self._flatten_prometheus_decoder_wrapper_returns(current_content)
            current_content = self._normalize_ipairs_iterator_while_loops(current_content)
            current_content = self._prune_dead_prometheus_temporaries(current_content)
            current_content = self._remove_identity_assignments(current_content)
            current_content = self._strip_missing_prometheus_jump_targets(current_content)
            current_content = self._remove_noop_prometheus_conditional_gotos(current_content)
            current_content = self._remove_prometheus_unresolved_jump_comments(current_content)
            current_content = self._rename_prometheus_decoder_symbols(current_content)
            current_content = self._collapse_prometheus_decoder_runtime_scaffold(current_content)
            current_content = self._collapse_prometheus_decoder_callsites(current_content)
            current_content = self._inline_immediate_prometheus_callable_aliases(current_content)
            current_content = self._inline_immediate_prometheus_literal_aliases(current_content)
            current_content = self._inline_short_lived_prometheus_identifier_aliases(current_content)
            current_content = self._inline_single_use_prometheus_callable_aliases(current_content)
            current_content = self._inline_single_use_prometheus_call_literal_args(current_content)
            current_content = self._simplify_numeric_lines(current_content)
            current_content = self._rename_prometheus_register_locals_for_readability(current_content)
            current_content = self._rename_common_prometheus_library_aliases(current_content)
            current_content = self._rename_prometheus_bootstrap_semantic_roles(current_content)
            current_content = self._canonicalize_prometheus_anti_preamble_symbols(current_content)
            current_content = self._canonicalize_prometheus_lookup_bootstrap(current_content)
            current_content = self._inline_prometheus_decoder_function_aliases(current_content)
            current_content = self._semantic_collapse_prometheus_decoder_state_machine(current_content)
            current_content = self._collapse_prometheus_decoder_counted_loops(current_content)
            current_content = self._repair_invalid_for_counter_expressions(current_content)
            current_content = self._remove_redundant_for_counter_seeds(current_content)
            current_content = self._separate_prometheus_decoder_cache_from_function(current_content)
            current_content = self._inline_prometheus_anti_temporaries(current_content)
            current_content = self._repair_invalid_for_counter_expressions(current_content)
            current_content = self._prune_prometheus_decoder_local_decls(current_content)
            current_content = self._rename_prometheus_ui_construction_symbols(current_content)
            current_content = self._simplify_prometheus_simple_numeric_aliases(current_content)
            current_content = self._collapse_prometheus_ui_temp_aliases(current_content)
            current_content = self._prune_unused_local_declaration_names(current_content)
            current_content = self._normalize_prometheus_semantic_suffixes(current_content)
            current_content = self._semantic_rename_prometheus_domain_symbols(current_content)
            current_content = self._rename_prometheus_registers_to_generic_locals(current_content)
            current_content = self._semantic_rename_prometheus_domain_symbols(current_content)
            current_content = self._rename_prometheus_obfuscated_alias_name_patterns(current_content)
            current_content = self._semantic_rename_prometheus_member_usage_symbols(current_content)
            current_content = self._simplify_prometheus_obfuscated_loop_conditions(current_content)
            current_content = self._compact_simple_multiline_table_literals(current_content)
            current_content = self._neutralize_prometheus_antitamper_residuals(current_content)
            current_content = self._simplify_prometheus_top_level_env_returns(current_content)
            current_content = self._normalize_split_comparison_operators(current_content)
            current_content = self._collapse_prometheus_count_zero_guards(current_content)
            current_content = self._prune_prometheus_anti_preamble_noise(current_content)
            current_content = self._prune_unused_local_declaration_names(current_content)
            current_content = self._remove_unreferenced_prometheus_labels(current_content)
            current_content = self._strip_missing_prometheus_jump_targets(current_content)
            current_content = self._remove_unreferenced_prometheus_labels(current_content)
            current_content = self._remove_redundant_prometheus_method_loads(current_content)
            current_content = self._simplify_prometheus_dynamic_env_accesses(current_content)
            current_content = self._collapse_prometheus_unresolved_env_dispatch_calls(current_content)
            current_content = self._simplify_prometheus_dynamic_string_key_accesses(current_content)
            current_content = self._final_prune_unbound_top_level_env_reads(current_content)
            current_content = self._drop_preprint_unbound_env_calls(current_content)
            current_content = self._prune_impossible_nil_index_calls(current_content)
            current_content = self._prune_nil_value_table_writes(current_content)
        except Exception as post_error:
            post_warnings.append(f'Bước 5: Post-encryption cleanup skipped: {post_error}')
        if current_content == post_input:
            post_warnings.append('Bước 5: Không phát hiện post-encryption pattern rõ ràng, chỉ giữ nguyên output devirtualization')
        current_content = self._simplify_prometheus_obfuscated_loop_conditions(current_content)
        current_content = self._collapse_prometheus_lookup_init_while(current_content)
        current_content = self._collapse_prometheus_lookup_shuffle_repeat(current_content)
        current_content = self._normalize_split_comparison_operators(current_content)
        self._pipeline_prng_decoder_constants = self._extract_prometheus_runtime_decoder_constants(current_content)
        decoder_name_match = re.search(r'\bdecode_runtime_string(?:_\d+)?\b', current_content)
        if decoder_name_match:
            self._pipeline_prng_key8_value = self._extract_prometheus_runtime_key8_constant(
                current_content,
                decoder_name_match.group(0)
            )
        if self._pipeline_prng_key8_value is None:
            post_lines_for_key = current_content.splitlines()
            fn_pattern_for_key = re.compile(
                r'^\s*(?:local\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*function\([^)]*\)\s*$'
            )
            for key_index, key_line in enumerate(post_lines_for_key):
                key_match = fn_pattern_for_key.match(key_line.strip())
                if not key_match:
                    continue
                key_end = self._find_matching_block_end_line(post_lines_for_key, key_index)
                if key_end == -1:
                    continue
                key_block = '\n'.join(post_lines_for_key[key_index:key_end + 1])
                if self._classify_prometheus_decoder_function_text(key_block) != 'decode':
                    continue
                self._pipeline_prng_key8_value = self._extract_prometheus_runtime_key8_constant(
                    current_content,
                    key_match.group(1),
                    key_index
                )
                break
        add_stage_result(
            'post_encryption',
            'Post-encryption Cleanup',
            'post+encryption.txt',
            current_content,
            post_warnings,
            skipped=current_content == post_input
        )
        post_output = current_content

        cleanup_warnings = []
        try:
            current_content = self._sanitize_invalid_statement_identifiers(current_content)
            current_content = self._remove_invalid_literal_index_assignments(current_content)
            current_content = self._repair_prometheus_uninitialized_loop_seed(current_content)
            current_content = self._repair_prometheus_uninitialized_shuffle_loop_bound(current_content)
            current_content = self._remove_dangerous_nil_reassignments(current_content)
            current_content = self._prune_impossible_nil_index_calls(current_content)
            current_content = self._prune_nil_value_table_writes(current_content)
            current_content = self._repair_roblox_string_constructor_calls(current_content)
            current_content = self._neutralize_unknown_unary_wrapper_calls(current_content)
            current_content = self._neutralize_prometheus_antitamper_residuals(current_content)
            current_content = self._separate_shadowed_function_bindings(current_content)
            current_content = self._collapse_prometheus_runtime_slot_reads(current_content)
            current_content = self._fix_prometheus_decoder_return_values(current_content)
            current_content = self._ensure_prometheus_decoder_cache_returns(current_content)
            current_content = self._force_rename_prometheus_decoder_functions(current_content)
            current_content = self._separate_prometheus_decoder_cache_from_function(current_content)
            current_content = self._normalize_prometheus_decoder_call_callees(current_content)
            current_content = self._decode_prometheus_runtime_string_calls(current_content)
            current_content = self._map_placeholder_returns_from_reference(
                current_content,
                devirtualization_output
            )
            current_content = self._recover_prometheus_decoder_cache_return_literals(current_content)
            current_content = self._repair_concat_function_literal_returns(current_content)
            current_content = self._inline_literal_table_constructor_aliases(current_content)
            current_content = self._simplify_prometheus_env_alias_assignments(current_content)
            current_content = self._simplify_prometheus_dynamic_env_accesses(current_content)
            current_content = self._collapse_prometheus_unresolved_env_dispatch_calls(current_content)
            current_content = self._simplify_prometheus_dynamic_string_key_accesses(current_content)
            current_content = self._simplify_prometheus_method_alias_calls(current_content)
            current_content = self._remove_redundant_prometheus_method_loads(current_content)
            current_content = self._inline_single_use_prometheus_call_aliases(current_content)
            current_content = self._inline_literal_assignments_before_return(current_content)
            current_content = self._prune_overwritten_prometheus_assignments(current_content)
            current_content = self._simplify_prometheus_print_alias_calls(current_content)
            current_content = self._drop_unused_call_assignment_targets(current_content)
            current_content = self._fix_prometheus_placeholder_returns(current_content)
            current_content = self._simplify_prometheus_top_level_env_returns(current_content)
            current_content = self._expand_compound_assignments(current_content)
            current_content = self._strip_empty_blocks(current_content)
            current_content = self._remove_unused_literal_assignments(current_content)
            current_content = self._remove_overwritten_literal_assignments(current_content)
            current_content = self._remove_overwritten_string_seed_assignments(current_content)
            current_content = self._remove_redundant_nil_reassignments(current_content)
            current_content = self._remove_redundant_prometheus_pc_assignments(current_content)
            current_content = self._inline_prometheus_pc_temporaries(current_content)
            current_content = self._propagate_prometheus_immediate_literal_aliases(current_content)
            current_content = self._simplify_prometheus_constant_if_conditions(current_content)
            current_content = self._prune_prometheus_literal_if_blocks(current_content)
            current_content = self._simplify_prometheus_adjacent_bool_goto_conditions(current_content)
            current_content = self._simplify_prometheus_adjacent_bool_if_branches(current_content)
            current_content = self._collapse_prometheus_goto_redirect_labels(current_content)
            current_content = self._remove_prometheus_fallthrough_gotos(current_content)
            current_content = self._simplify_prometheus_if_goto_else_chains(current_content)
            current_content = self._inline_prometheus_single_use_then_label_blocks(current_content)
            current_content = self._remove_prometheus_fallthrough_gotos(current_content)
            current_content = self._simplify_prometheus_guard_loops(current_content)
            current_content = self._prune_constant_guarded_prometheus_loops(current_content)
            current_content = self._simplify_prometheus_obfuscated_loop_conditions(current_content)
            current_content = self._collapse_prometheus_lookup_init_while(current_content)
            current_content = self._collapse_prometheus_lookup_shuffle_repeat(current_content)
            current_content = self._canonicalize_prometheus_lookup_bootstrap(current_content)
            current_content = self._prune_prometheus_anti_preamble_noise(current_content)
            current_content = self._remove_overwritten_builtin_alias_seeds(current_content)
            current_content = self._simplify_prometheus_builtin_alias_accesses(current_content)
            current_content = self._flatten_prometheus_decoder_wrapper_returns(current_content)
            current_content = self._normalize_ipairs_iterator_while_loops(current_content)
            current_content = self._prune_dead_prometheus_temporaries(current_content)
            current_content = self._remove_identity_assignments(current_content)
            current_content = self._strip_missing_prometheus_jump_targets(current_content)
            current_content = self._rename_prometheus_decoder_symbols(current_content)
            current_content = self._collapse_prometheus_decoder_runtime_scaffold(current_content)
            current_content = self._collapse_prometheus_decoder_callsites(current_content)
            current_content = self._inline_immediate_prometheus_callable_aliases(current_content)
            current_content = self._inline_immediate_prometheus_literal_aliases(current_content)
            current_content = self._inline_short_lived_prometheus_identifier_aliases(current_content)
            current_content = self._inline_single_use_prometheus_callable_aliases(current_content)
            current_content = self._inline_single_use_prometheus_call_literal_args(current_content)
            current_content = self._simplify_numeric_lines(current_content)
            current_content = self._rename_prometheus_register_locals_for_readability(current_content)
            current_content = self._rename_common_prometheus_library_aliases(current_content)
            current_content = self._rename_prometheus_bootstrap_semantic_roles(current_content)
            current_content = self._canonicalize_prometheus_anti_preamble_symbols(current_content)
            current_content = self._canonicalize_prometheus_lookup_bootstrap(current_content)
            current_content = self._inline_prometheus_decoder_function_aliases(current_content)
            current_content = self._semantic_collapse_prometheus_decoder_state_machine(current_content)
            current_content = self._collapse_prometheus_decoder_counted_loops(current_content)
            current_content = self._repair_invalid_for_counter_expressions(current_content)
            current_content = self._remove_redundant_for_counter_seeds(current_content)
            current_content = self._separate_prometheus_decoder_cache_from_function(current_content)
            current_content = self._inline_prometheus_anti_temporaries(current_content)
            current_content = self._repair_invalid_for_counter_expressions(current_content)
            current_content = self._prune_prometheus_decoder_local_decls(current_content)
            current_content = self._rename_prometheus_ui_construction_symbols(current_content)
            current_content = self._simplify_prometheus_simple_numeric_aliases(current_content)
            current_content = self._collapse_prometheus_ui_temp_aliases(current_content)
            current_content = self._prune_unused_local_declaration_names(current_content)
            current_content = self._normalize_prometheus_semantic_suffixes(current_content)
            current_content = self._semantic_rename_prometheus_domain_symbols(current_content)
            current_content = self._rename_prometheus_registers_to_generic_locals(current_content)
            current_content = self._semantic_rename_prometheus_domain_symbols(current_content)
            current_content = self._rename_prometheus_obfuscated_alias_name_patterns(current_content)
            current_content = self._semantic_rename_prometheus_member_usage_symbols(current_content)
            current_content = self._compress_prometheus_anti_decoder_preamble(current_content)
            current_content = self._inline_and_prune_prng_decoder_residuals(current_content)
            current_content = self._inline_literal_table_constructor_aliases(current_content)
            current_content = self._normalize_ipairs_iterator_while_loops(current_content)
            current_content = self._repair_roblox_string_constructor_calls(current_content)
            current_content = self._prune_impossible_nil_index_calls(current_content)
            current_content = self._prune_nil_value_table_writes(current_content)
            current_content = self._simplify_prometheus_obfuscated_loop_conditions(current_content)
            current_content = self._compact_simple_multiline_table_literals(current_content)
            current_content = self._neutralize_prometheus_antitamper_residuals(current_content)
            current_content = self._simplify_prometheus_top_level_env_returns(current_content)
            current_content = self._normalize_split_comparison_operators(current_content)
            current_content = self._collapse_prometheus_count_zero_guards(current_content)
            current_content = self._prune_prometheus_anti_preamble_noise(current_content)
            current_content = self._prune_unused_local_declaration_names(current_content)
            current_content = self._add_missing_local_declarations(current_content)
            current_content = self._normalize_blank_lines(current_content)
            current_content = self._prune_dead_terminal_assignments(current_content)
            current_content = self._prune_dead_prometheus_pc_assignments_by_liveness(current_content)
            # Keep unresolved/garbage returns to stay closer to Prometheus-style
            # deobf outputs used as reference.
            current_content = self._neutralize_garbage_byte_string_assignments(current_content)
            current_content = self._inline_literal_assignments_before_return(current_content)
            current_content = self._strip_missing_prometheus_jump_targets(current_content)
            current_content = self._remove_noop_prometheus_conditional_gotos(current_content)
            current_content = self._remove_prometheus_unresolved_jump_comments(current_content)
            current_content = self._remove_unreferenced_prometheus_labels(current_content)
            current_content = self._remove_redundant_prometheus_method_loads(current_content)
            current_content = self._simplify_prometheus_dynamic_env_accesses(current_content)
            current_content = self._collapse_prometheus_unresolved_env_dispatch_calls(current_content)
            current_content = self._simplify_prometheus_dynamic_string_key_accesses(current_content)
            current_content = self._final_prune_unbound_top_level_env_reads(current_content)
            current_content = self._recover_single_print_literal_via_runtime(
                current_content,
                script_content
            )
            current_content = self._final_prune_unbound_top_level_env_reads(current_content)
            current_content = self._drop_preprint_unbound_env_calls(current_content)
            current_content = self._prune_impossible_nil_index_calls(current_content)
            current_content = self._prune_nil_value_table_writes(current_content)
        except Exception as cleanup_error:
            cleanup_warnings.append(f'Bước 6: Final cleanup skipped: {cleanup_error}')
        current_content = self._simplify_prometheus_obfuscated_loop_conditions(current_content)
        current_content = self._collapse_prometheus_lookup_init_while(current_content)
        current_content = self._collapse_prometheus_lookup_shuffle_repeat(current_content)
        current_content = self._normalize_split_comparison_operators(current_content)
        cleanup_score = self._score_prometheus_readability_variant(current_content)
        post_score = self._score_prometheus_readability_variant(post_output)
        devirt_score = self._score_prometheus_readability_variant(devirtualization_output)
        best_score = cleanup_score
        best_content = current_content
        if post_score > best_score:
            best_score = post_score
            best_content = post_output
        if devirt_score > best_score:
            best_score = devirt_score
            best_content = devirtualization_output
        cleanup_corruption_score = (
            current_content.count('next_prng_byte[')
            + current_content.count('nil[')
            + current_content.count('env[')
            + current_content.count('_local') * 0.05
        )
        has_unresolved_decoder = (
            'decode_runtime_string(' in current_content
            or bool(re.search(r'\benv\[[A-Za-z_][A-Za-z0-9_]*\]', current_content))
        )
        devirt_is_clean = (
            devirtualization_output.count('env[') <= 4
            and devirtualization_output.count('while true') <= 2
            and 'decode_runtime_string(' not in devirtualization_output
        )
        if (
            devirt_is_clean
            and
            best_score > cleanup_score + 8.0
            and (cleanup_corruption_score >= 10.0 or has_unresolved_decoder)
        ):
            current_content = best_content
        add_stage_result(
            'cleanup',
            'Final Cleanup',
            'cleanup1-2.txt',
            current_content,
            cleanup_warnings
        )

        return {
            'stages': stage_results,
            'warnings': aggregate_warnings,
            **pipeline_metadata
        }

    def deobfuscate_script_content(self, script_content):
        pipeline_data = self.run_stage_pipeline(script_content)
        final_stage = pipeline_data['stages'][-1]
        return {
            'deobfuscated_source': final_stage['content'],
            'decrypted_strings': pipeline_data['decoded_strings'],
            'decoded_string_bytes': pipeline_data['decoded_string_bytes'],
            'cipher_mapping_size': pipeline_data['cipher_mapping_size'],
            'lookup_function': pipeline_data['lookup_function'],
            'reversal_ranges': pipeline_data['reversal_ranges'],
            'pipeline_stages': pipeline_data['stages'],
            'warnings': pipeline_data['warnings']
        }

    def analyze_script(self, file_path):
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as file_handle:
            script_data = file_handle.read()

        data_tables = self.locate_data_tables(script_data)
        encryption_functions = self.find_encryption_functions(script_data)
        deobfuscation_data = self.deobfuscate_script_content(script_data)
        lookup_function = deobfuscation_data.get('lookup_function') or {}

        return {
            'script_file': file_path,
            'data_tables_found': len(data_tables),
            'cipher_mapping_size': deobfuscation_data.get('cipher_mapping_size', 0),
            'encryption_functions': len(encryption_functions),
            'decrypted_strings': deobfuscation_data.get('decrypted_strings', []),
            'lookup_function_name': lookup_function.get('name'),
            'lookup_offset': lookup_function.get('offset_value'),
            'reversal_range_count': len(deobfuscation_data.get('reversal_ranges', [])),
            'warnings': deobfuscation_data.get('warnings', [])
        }

    def write_deobfuscated_output(self, input_path, output_path=None):
        with open(input_path, 'r', encoding='utf-8', errors='ignore') as file_handle:
            script_data = file_handle.read()

        deobfuscation_data = self.deobfuscate_script_content(script_data)

        if output_path is None:
            base_name, _ = os.path.splitext(input_path)
            output_path = f"{base_name}.deobf.lua"

        with open(output_path, 'w', encoding='utf-8') as file_handle:
            file_handle.write(deobfuscation_data['deobfuscated_source'])

        deobfuscation_data['output_file'] = output_path
        return deobfuscation_data

    def write_pipeline_outputs(self, input_path, output_dir=None):
        with open(input_path, 'r', encoding='utf-8', errors='ignore') as file_handle:
            script_data = file_handle.read()

        pipeline_data = self.run_stage_pipeline(script_data)

        if output_dir is None:
            base_name, _ = os.path.splitext(os.path.basename(input_path))
            output_dir = os.path.join(os.path.dirname(input_path), f'{base_name}.pipeline')

        os.makedirs(output_dir, exist_ok=True)
        written_files = {}

        for stage_data in pipeline_data['stages']:
            stage_path = os.path.join(output_dir, stage_data['filename'])
            with open(stage_path, 'w', encoding='utf-8') as file_handle:
                file_handle.write(stage_data['content'])
            written_files[stage_data['key']] = stage_path

        pipeline_data['output_dir'] = output_dir
        pipeline_data['written_files'] = written_files
        return pipeline_data

    def generate_output(self, analysis_data):
        output_lines = []

        output_lines.append(f"Script: {analysis_data['script_file']}")
        output_lines.append(f"Data Tables: {analysis_data['data_tables_found']}")
        output_lines.append(f"Cipher Mapping Entries: {analysis_data['cipher_mapping_size']}")
        output_lines.append(f"Encryption Functions: {analysis_data['encryption_functions']}")
        output_lines.append(f"Lookup Function: {analysis_data.get('lookup_function_name')}")
        output_lines.append(f"Lookup Offset: {analysis_data.get('lookup_offset')}")
        output_lines.append(f"Reversal Ranges: {analysis_data.get('reversal_range_count', 0)}")

        warnings = analysis_data.get('warnings') or []
        if warnings:
            output_lines.append("\nWarnings:")
            for warning_message in warnings:
                output_lines.append(f"  - {warning_message}")

        output_lines.append("\nDecrypted Strings:")
        for index, string_value in enumerate(analysis_data['decrypted_strings']):
            if string_value and len(string_value.strip()) > 0:
                preview = string_value[:100] + "..." if len(string_value) > 100 else string_value
                output_lines.append(f"  [{index}] {preview}")

        return '\n'.join(output_lines)


if __name__ == "__main__":
    import sys

    if len(sys.argv) < 2:
        print("Usage: python deobfuscator_core.py <lua_file> [output_file]")
        sys.exit(1)

    deobfuscator = Deobfuscator()
    analysis_results = deobfuscator.analyze_script(sys.argv[1])
    print(deobfuscator.generate_output(analysis_results))

    if len(sys.argv) > 2:
        output_results = deobfuscator.write_deobfuscated_output(sys.argv[1], sys.argv[2])
        print(f"\nDeobfuscated source written to: {output_results['output_file']}")
