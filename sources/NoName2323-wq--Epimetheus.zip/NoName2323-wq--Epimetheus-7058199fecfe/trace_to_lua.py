from __future__ import annotations

import os
import sys
import re
import functools
from collections import OrderedDict
from typing import Optional, Dict, List, Tuple, Any, Union

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from engine.trace_filter import TraceFilter, filter_trace_stream
from engine.ast_optimizer import AstOptimizer, optimize_lua_code

CONSTRUCTOR_PREFIXES = (
    "UDim2.new", "UDim.new", "Color3.fromRGB", "Color3.new",
    "Vector3.new", "Vector2.new", "CFrame.new",
    "BrickColor.new", "NumberRange.new", "NumberSequence.new",
    "ColorSequence.new",
)

_RE_FUNCTION_ADDR = re.compile(r'function:\s*(?:0x)?[0-9a-fA-F]+')
_RE_LOCAL_BINDING = re.compile(r'^local\s+(\S+)\s*=\s*(.+)$')
_RE_CALL_PARTS = re.compile(r'^([a-zA-Z0-9_.]+)\((.*)\)$', re.DOTALL)
_RE_SET_GLOBAL = re.compile(r'^(\S+)\s*=\s*(.+)$')
_RE_NORMALIZED_VAR = re.compile(r'\b[a-zA-Z0-9_]+_v(\d+)\b')
_RE_PATTERN_HEX = re.compile(r'_\d{3,}')
_RE_PATTERN_SERVICE = re.compile(r'Service_\w+')
_RE_TRAILING_HEX = re.compile(r'_\d{3,}$')


@functools.lru_cache(maxsize=1024)
def _get_var_map_pattern(keys_tuple: tuple) -> Optional[re.Pattern]:
    if not keys_tuple:
        return None
    return re.compile(r'\b(' + '|'.join(re.escape(k) for k in keys_tuple) + r')\b')



def clean_dummy_name(name):
    return name


def parse_access_chain(name):
    return name.split(".")


def make_colon_call(obj_chain, method, args_str):
    return f"{obj_chain}:{method}({args_str})"


def simplify_call_result(line):
    m = _RE_LOCAL_BINDING.match(line)
    if not m:
        return line, None, False

    var_name = m.group(1)
    rhs = m.group(2).strip()

    call_match = _RE_CALL_PARTS.match(rhs)
    if not call_match:
        return line, var_name, True

    func_chain = call_match.group(1)
    args_raw = call_match.group(2) or ""

    parts = func_chain.split(".")
    args_list = smart_split_args(args_raw)

    is_method_call = False
    clean_args = args_list

    if len(parts) >= 2 and len(args_list) >= 1:
        obj = ".".join(parts[:-1])
        method = parts[-1]
        first_arg = args_list[0].strip()

        if first_arg == obj:
            is_method_call = True
            clean_args = args_list[1:]

    if is_method_call:
        obj = ".".join(parts[:-1])
        method = parts[-1]
        obj = simplify_obj_name(obj)
        args_str = ", ".join(a.strip() for a in clean_args)
        if "function:" in args_str:
            args_str = _RE_FUNCTION_ADDR.sub('function(...) end', args_str)
        call_expr = f"{obj}:{method}({args_str})"
        nice_var = generate_var_name(obj, method, clean_args)
        return call_expr, nice_var, True
    else:
        func_name = simplify_obj_name(func_chain)
        args_str = ", ".join(a.strip() for a in args_list)
        if "function:" in args_str:
            args_str = _RE_FUNCTION_ADDR.sub('function(...) end', args_str)
        call_expr = f"{func_name}({args_str})"
        nice_var = generate_var_name_from_func(func_name, args_list)
        return call_expr, nice_var, True


def smart_split_args(args_str):
    result = []
    depth = 0
    current = []
    in_string = False
    string_char = None
    escaped = False

    for ch in args_str:
        if in_string:
            current.append(ch)
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == string_char:
                in_string = False
            continue

        if ch in ('"', "'"):
            in_string = True
            string_char = ch
            escaped = False
            current.append(ch)
        elif ch in ('(', '[', '{'):
            depth += 1
            current.append(ch)
        elif ch in (')', ']', '}'):
            depth = max(0, depth - 1)
            current.append(ch)
        elif ch == ',' and depth == 0:
            result.append("".join(current))
            current = []
        else:
            current.append(ch)

    tail = "".join(current)
    if tail.strip():
        result.append(tail)

    return result


def simplify_obj_name(name):
    return _RE_TRAILING_HEX.sub('', name)


def generate_var_name(obj, method, args):
    if method == "GetService" and len(args) >= 1:
        return args[0].strip().strip('"').strip("'")

    if method == "FindFirstChild" and len(args) >= 1:
        return args[0].strip().strip('"').strip("'")

    if method == "FindFirstChildOfClass" and len(args) >= 1:
        return args[0].strip().strip('"').strip("'").lower()

    if method == "WaitForChild" and len(args) >= 1:
        return args[0].strip().strip('"').strip("'")

    if method == "Connect":
        return None

    if method == "GetMouse":
        return "mouse"

    if method == "GetPlayers":
        return "playerList"

    if method == "GetChildren":
        return "children"

    if method == "GetDescendants":
        return "descendants"

    return method[0].lower() + method[1:] if method else None


def generate_var_name_from_func(func_name, args):
    if "Instance.new" in func_name and len(args) >= 1:
        class_name = args[0].strip().strip('"').strip("'")
        return class_name[0].lower() + class_name[1:]

    if "Vector3.new" in func_name:
        return None

    if "Vector2.new" in func_name:
        return None

    if "UDim2.new" in func_name:
        return None

    if "Color3" in func_name:
        return None

    if "CFrame" in func_name:
        return None

    if "task.wait" in func_name:
        return None

    base = func_name.split(".")[-1]
    return base[0].lower() + base[1:] if base else None


def detect_loops(lines):
    n = len(lines)
    if n < 6:
        return None

    normalized = [normalize_for_pattern(l) for l in lines]

    for pattern_len in range(2, min(20, n // 2 + 1)):
        pattern_tuple = tuple(normalized[:pattern_len])
        pattern_hash = hash(pattern_tuple)

        count = 1
        pos = pattern_len
        while pos + pattern_len <= n:
            block = tuple(normalized[pos : pos + pattern_len])
            if hash(block) == pattern_hash and block == pattern_tuple:
                count += 1
                pos += pattern_len
            else:
                break

        if count >= 3 and count * pattern_len >= n * 0.8:
            return pattern_len, count, lines[:pattern_len]

    return None


def normalize_for_pattern(line):
    line = _RE_PATTERN_HEX.sub('_XXX', line)
    return _RE_PATTERN_SERVICE.sub('Service_XXX', line)


def parse_trace_lines(
    trace_lines,
    constants_str="",
    out_file_path=None,
    const_file_path=None,
):
    operations = []
    closure_stack = []

    for line in trace_lines:
        if line.startswith("CALL_RESULT -->"):
            code = line.split("CALL_RESULT -->")[1].strip()
            operations.append({"type": "call", "raw": code, "depth": len(closure_stack)})

        elif line.startswith("SET GLOBAL -->"):
            code = line.split("SET GLOBAL -->")[1].strip()
            operations.append({"type": "set_global", "raw": code, "depth": len(closure_stack)})

        elif line.startswith("TRACE_PRINT -->"):
            msg = line.split("TRACE_PRINT -->")[1].strip()
            operations.append({"type": "print", "raw": msg, "depth": len(closure_stack)})

        elif line.startswith("URL DETECTED -->"):
            url = line.split("URL DETECTED -->")[1].strip()
            operations.append({"type": "url", "raw": url, "depth": len(closure_stack)})

        elif line.startswith("--- ENTERING CLOSURE FOR"):
            func_name = line.replace("--- ENTERING CLOSURE FOR ", "").replace(" ---", "").strip()
            operations.append({"type": "closure_start", "name": func_name, "depth": len(closure_stack)})
            closure_stack.append(func_name)

        elif line.startswith("--- EXITING CLOSURE FOR"):
            operations.append({"type": "closure_end", "depth": len(closure_stack) - 1})
            if closure_stack:
                closure_stack.pop()

        elif line.startswith("PROP_SET -->"):
            code = line.split("PROP_SET -->")[1].strip()
            operations.append({"type": "prop_set", "raw": code, "depth": len(closure_stack)})

        elif line.startswith("LOADSTRING DETECTED"):
            operations.append({"type": "loadstring", "raw": line, "depth": len(closure_stack)})

    lua_lines = []
    var_counter = {}
    var_map = {}
    used_vars = set()

    top_level_calls = [op for op in operations if op["type"] == "call" and op["depth"] == 0]
    loop_info = detect_loops([op["raw"] for op in top_level_calls])

    if loop_info:
        pattern_len, repeat_count, pattern_lines = loop_info
        lua_lines.append(f"-- Loop detected: {repeat_count} iterations")
        lua_lines.append("while true do")

        for raw_line in pattern_lines:
            clean_line = process_call_line(raw_line, var_map, var_counter, used_vars)
            if clean_line:
                lua_lines.append(f"    {clean_line}")

        lua_lines.append("end")
        lua_lines.append("")

        last_loop_call = top_level_calls[pattern_len * repeat_count - 1]
        last_loop_idx = -1
        for idx, op in enumerate(operations):
            if op is last_loop_call:
                last_loop_idx = idx
                break

        remaining_ops = operations[last_loop_idx + 1:] if last_loop_idx != -1 else []
        if remaining_ops:
            lua_lines.extend(render_trace_operations(remaining_ops, var_map, var_counter, used_vars))
    else:
        lua_lines.extend(render_trace_operations(operations, var_map, var_counter, used_vars))

    output_lines = ["-- Deobfuscated via Trace Emulation", ""]

    if constants_str and constants_str.strip():
        const_file = const_file_path
        if not const_file and out_file_path:
            const_file = out_file_path.replace(".deobf.lua", ".constants.lua")

        if const_file and constants_str.count("\n") > 50:
            with open(const_file, 'w', encoding='utf-8') as f:
                f.write(constants_str.strip() + "\n")
            output_lines.append(f"-- String constants ({constants_str.count(chr(10))} entries) saved to: {os.path.basename(const_file)}")
            output_lines.append("")
        else:
            output_lines.append("-- === String Constants ===")
            output_lines.append(constants_str.strip())
            output_lines.append("")

    output_lines.extend(lua_lines)

    final_output = "\n".join(output_lines)
    final_output = postprocess_output(final_output)

    if out_file_path:
        with open(out_file_path, 'w', encoding='utf-8') as f:
            f.write(final_output)
        print(f"Saved {out_file_path}")

    return final_output


def parse_trace(report_file):
    with open(report_file, 'r', encoding='utf-8') as f:
        lines = f.readlines()

    constants_str = ""
    trace_lines = []
    in_constants = False
    in_trace = False

    for line in lines:
        line = line.strip()
        if not line:
            continue

        if line == "--- CONSTANTS START ---" or line == "--- CONSTANTS ---":
            in_constants = True
            continue
        if line == "--- CONSTANTS END ---":
            in_constants = False
            continue
        if line == "--- TRACE ---":
            in_trace = True
            continue
        if line == "--- TRACE END ---":
            in_trace = False
            continue

        if in_constants:
            constants_str += line + "\n"
        elif any(line.startswith(prefix) for prefix in [
            "CALL_RESULT -->", "SET GLOBAL -->", "TRACE_PRINT -->",
            "URL DETECTED -->", "URL DETECTED IN CONCAT -->", "--- ENTERING CLOSURE", "--- EXITING CLOSURE",
            "ACCESSED -->", "LOADSTRING DETECTED", "LOADSTRING CONTENT",
            "PROP_SET -->"
        ]):
            trace_lines.append(line)

    out_file = report_file.replace(".report.txt", ".deobf.lua")
    const_file = report_file.replace(".report.txt", ".constants.lua")
    return parse_trace_lines(trace_lines, constants_str, out_file_path=out_file, const_file_path=const_file)


def process_call_line(raw, var_map, var_counter, used_vars):
    m = _RE_LOCAL_BINDING.match(raw)
    if not m:
        return raw

    orig_var = m.group(1)
    rhs = m.group(2).strip()

    resolved_rhs = resolve_vars(rhs, var_map)

    call_match = _RE_CALL_PARTS.match(resolved_rhs)
    if not call_match:
        clean_name = get_clean_var(orig_var, var_counter, used_vars)
        var_map[orig_var] = clean_name
        return f"local {clean_name} = {resolved_rhs}"

    func_chain = call_match.group(1)
    args_raw = call_match.group(2) or ""

    parts = func_chain.split(".")
    args_list = smart_split_args(args_raw)

    is_method = False
    obj_str = ""
    method_str = ""
    clean_args = args_list

    if len(parts) >= 2 and len(args_list) >= 1:
        obj_str = ".".join(parts[:-1])
        method_str = parts[-1]
        first_arg = args_list[0].strip()

        if first_arg == obj_str:
            is_method = True
            clean_args = args_list[1:]

    clean_arg_strs = []
    for a in clean_args:
        a = a.strip()
        if "function:" in a:
            a = _RE_FUNCTION_ADDR.sub('function(...) end', a)
        clean_arg_strs.append(a)
    args_str = ", ".join(clean_arg_strs)

    if is_method:
        call_expr = f"{obj_str}:{method_str}({args_str})"
    else:
        call_expr = f"{func_chain}({args_str})"

    needs_var = True
    nice_name = None

    if is_method:
        nice_name = generate_var_name(obj_str, method_str, clean_arg_strs)

        if method_str in ("Connect", "FireServer", "Disconnect", "Destroy",
                          "CaptureController", "ClickButton2", "ChangeState",
                          "MoveTo", "SetPrimaryPartCFrame", "ClearAllChildren",
                          "Clone", "Remove", "remove", "insert", "sort"):
            needs_var = False

        if method_str == "wait":
            needs_var = False
    else:
        nice_name = generate_var_name_from_func(func_chain, clean_arg_strs)
        if "task.wait" in func_chain or "wait" in func_chain.lower():
            needs_var = False

    if nice_name and needs_var:
        if nice_name in used_vars:
            count = var_counter.get(nice_name, 1) + 1
            var_counter[nice_name] = count
            final_name = f"{nice_name}{count}"
        else:
            final_name = nice_name
            var_counter[nice_name] = 1

        used_vars.add(final_name)
        var_map[orig_var] = final_name
        return f"local {final_name} = {call_expr}"
    else:
        if nice_name:
            var_map[orig_var] = nice_name
        else:
            var_map[orig_var] = call_expr
        return call_expr


def resolve_vars(text, var_map):
    if var_map:
        keys = tuple(sorted((k for k in var_map.keys() if k and var_map[k]), key=len, reverse=True))
        if keys:
            pattern = _get_var_map_pattern(keys)
            if pattern:
                text = pattern.sub(lambda m: var_map[m.group(1)], text)

    return _RE_NORMALIZED_VAR.sub(r'v\1', text)


def get_clean_var(orig_var, var_counter, used_vars):
    parts = orig_var.split("_")

    while parts and parts[-1].isdigit():
        parts.pop()

    if not parts:
        name = "var"
    else:
        name = parts[-1]
        if name[0].isupper():
            name = name[0].lower() + name[1:]

    if name in used_vars:
        count = var_counter.get(name, 1) + 1
        var_counter[name] = count
        name = f"{name}{count}"

    used_vars.add(name)
    return name


def process_set_global(raw, var_map):
    m = _RE_SET_GLOBAL.match(raw)
    if not m:
        return raw

    var_name = m.group(1)
    value = resolve_vars(m.group(2).strip(), var_map)

    if var_name == value:
        return None

    return f"{var_name} = {value}"


def process_prop_set(raw, var_map):
    resolved = resolve_vars(raw, var_map)
    return resolved


def render_trace_operations(operations, var_map, var_counter, used_vars):
    lua_lines = []
    closure_info_stack = []
    i = 0
    while i < len(operations):
        op = operations[i]
        in_closure = len(closure_info_stack)
        indent = "    " * in_closure

        if op["type"] == "call":
            clean_line = process_call_line(op["raw"], var_map, var_counter, used_vars)
            if clean_line:
                skip = False
                if any(clean_line.startswith(p) for p in CONSTRUCTOR_PREFIXES) and not clean_line.startswith("local "):
                    skip = True
                elif any(clean_line.startswith(p) for p in CONSTRUCTOR_PREFIXES):
                    if i + 1 < len(operations) and operations[i + 1]["type"] == "prop_set":
                        next_raw = operations[i + 1]["raw"]
                        if clean_line in next_raw or clean_line.split("(")[0] in next_raw:
                            skip = True

                if not skip:
                    if i + 1 < len(operations) and operations[i + 1]["type"] == "closure_start":
                        if clean_line.endswith("function(...) end)"):
                            clean_line = clean_line[:-len("function(...) end)")] + "function(...)"
                            operations[i + 1]["inline_close"] = "end)"
                        elif clean_line.endswith("function(...) end"):
                            clean_line = clean_line[:-len("function(...) end")] + "function(...)"
                            operations[i + 1]["inline_close"] = "end"
                    lua_lines.append(f"{indent}{clean_line}")

        elif op["type"] == "set_global":
            clean_line = process_set_global(op["raw"], var_map)
            if clean_line:
                if i + 1 < len(operations) and operations[i + 1]["type"] == "closure_start":
                    if clean_line.endswith("function(...) end"):
                        clean_line = clean_line[:-len("function(...) end")] + "function(...)"
                        operations[i + 1]["inline_close"] = "end"
                lua_lines.append(f"{indent}{clean_line}")

        elif op["type"] == "print":
            msg = op["raw"].replace("\\", "\\\\").replace('"', '\\"')
            lua_lines.append(f'{indent}print("{msg}")')

        elif op["type"] == "url":
            lua_lines.append(f'{indent}-- URL: {op["raw"]}')

        elif op["type"] == "prop_set":
            clean_line = process_prop_set(op["raw"], var_map)
            if clean_line:
                lua_lines.append(f"{indent}{clean_line}")

        elif op["type"] == "closure_start":
            inline_close = op.get("inline_close")
            if inline_close is not None:
                closure_info_stack.append(inline_close)
            else:
                closure_name = op["name"]
                lua_lines.append(f"{indent}-- Closure for {closure_name}")
                lua_lines.append(f"{indent}local function callback(...)")
                closure_info_stack.append("end")

        elif op["type"] == "closure_end":
            if closure_info_stack:
                close_str = closure_info_stack.pop()
            else:
                close_str = "end"
            indent_inner = "    " * len(closure_info_stack)
            lua_lines.append(f"{indent_inner}{close_str}")

        elif op["type"] == "loadstring":
            lua_lines.append(f"{indent}-- {op['raw']}")

        i += 1

    return lua_lines


def postprocess_output(output):
    lines = output.split("\n")
    cleaned = []
    prev_line = ""

    for line in lines:
        stripped = line.strip()

        if stripped == "" and prev_line.strip() == "":
            continue

        if "function:" in line:
            line = _RE_FUNCTION_ADDR.sub('function(...) end', line)

        cleaned.append(line)
        prev_line = line

    merged = "\n".join(cleaned)
    # Apply engine AST optimizer (constant folding, dead code elimination, alias cleanup)
    try:
        merged = optimize_lua_code(merged)
    except Exception:
        pass

    return merged


if __name__ == "__main__":
    if len(sys.argv) > 1:
        parse_trace(sys.argv[1])
    else:
        for file in os.listdir("obfuscated_scripts"):
            if file.endswith(".report.txt"):
                parse_trace(os.path.join("obfuscated_scripts", file))
