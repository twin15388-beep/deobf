import unittest
from engine.trace_filter import TraceFilter, filter_trace_lines
from engine.ast_optimizer import AstOptimizer, optimize_lua_code, safe_eval_math_expr
from engine.static_decoder import StaticConstantDecoder, decode_prometheus_constants


class EngineTraceFilterTests(unittest.TestCase):
    def test_filter_removes_unpack_and_chunk_spam(self):
        lines = [
            "--- TRACE ---",
            "UNPACK CALLED WITH TABLE (size 10)",
            "CAPTURED CHUNK STRING dummy_chunk_data",
            "ACCESSED --> game",
            "CALL_RESULT --> local p = game:GetService(\"Players\")",
            "UNPACK CALLED WITH TABLE (size 5)",
            "SET GLOBAL --> MyGlobal = 123",
            "URL DETECTED --> https://example.com/api",
        ]

        filtered = filter_trace_lines(lines)

        self.assertIn("--- TRACE ---", filtered)
        self.assertIn("ACCESSED --> game", filtered)
        self.assertIn("CALL_RESULT --> local p = game:GetService(\"Players\")", filtered)
        self.assertIn("SET GLOBAL --> MyGlobal = 123", filtered)
        self.assertIn("URL DETECTED --> https://example.com/api", filtered)

        for line in filtered:
            self.assertNotIn("UNPACK CALLED", line)
            self.assertNotIn("CAPTURED CHUNK", line)

    def test_filter_compresses_consecutive_duplicates(self):
        lines = ["ACCESSED --> game"] * 20 + ["CALL_RESULT --> local x = 1"]
        flt = TraceFilter(max_consecutive_duplicates=3)
        filtered = flt.filter_lines(lines)

        # 3 duplicates + 1 call result = 4 lines
        self.assertEqual(len(filtered), 4)
        self.assertEqual(filtered.count("ACCESSED --> game"), 3)
        self.assertEqual(filtered[-1], "CALL_RESULT --> local x = 1")
        self.assertEqual(flt.duplicates_compressed, 17)


class EngineAstOptimizerTests(unittest.TestCase):
    def test_safe_eval_math_expr(self):
        self.assertEqual(safe_eval_math_expr("-80732 + 80796"), 64)
        self.assertEqual(safe_eval_math_expr("0x10 + 5"), 21)
        self.assertEqual(safe_eval_math_expr("100 - 40 * 2"), 20)
        self.assertIsNone(safe_eval_math_expr("os.execute('ls')"))
        self.assertIsNone(safe_eval_math_expr("1 / 0"))

    def test_constant_folding_in_code_preserves_literals(self):
        code = (
            'local a = (-80732 + 80796)\n'
            'local s = "do not fold (-80732 + 80796) here"\n'
            '-- comment (-80732 + 80796) here\n'
            'local b = (0x10 + 4)\n'
        )
        optimized = optimize_lua_code(code)

        self.assertIn("local a = 64", optimized)
        self.assertIn('local s = "do not fold (-80732 + 80796) here"', optimized)
        self.assertIn("-- comment (-80732 + 80796) here", optimized)
        self.assertIn("local b = 20", optimized)

    def test_alias_propagation_and_dead_self_assignment(self):
        code = (
            'local player_service = game:GetService("Players")\n'
            'local alias_service = player_service\n'
            'alias_service:Connect()\n'
            'alias_service = alias_service\n'
        )
        optimized = optimize_lua_code(code)

        self.assertNotIn("local alias_service = player_service", optimized)
        self.assertNotIn("alias_service = alias_service", optimized)
        self.assertIn('player_service:Connect()', optimized)


    def test_string_concatenation_folding(self):
        code = 'local s = "Hello, " .. "world" .. "!"\nlocal s2 = "foo" .. "bar"\n'
        optimized = optimize_lua_code(code)
        self.assertIn('local s = "Hello, world!"', optimized)
        self.assertIn('local s2 = "foobar"', optimized)

    def test_table_concat_folding(self):
        code = 'local res = table.concat({"partA", "partB", "partC"}, "_")\n'
        optimized = optimize_lua_code(code)
        self.assertIn('local res = "partA_partB_partC"', optimized)

    def test_scientific_and_power_math_folding(self):
        code = "local x = (1e2 + 50)\nlocal y = (2 ^ 4)\nlocal z = (10 % 3)\n"
        optimized = optimize_lua_code(code)
        self.assertIn("local x = 150", optimized)
        self.assertIn("local y = 16", optimized)
        self.assertIn("local z = 1", optimized)

    def test_watermark_removal(self):
        code = 'if _var ~= "This Script is Part of the Prometheus Obfuscator by levno-710" then return end\nlocal a = 1\n'
        optimized = optimize_lua_code(code)
        self.assertNotIn('then return end', optimized)
        self.assertIn('local a = 1', optimized)

    def test_ast_optimizer_preserves_literals_in_table_concat_and_watermarks(self):
        code = (
            'local s = "table.concat({\\"a\\", \\"b\\"})"\n'
            '-- table.concat({"a", "b"})\n'
            'local msg = "This Script is Part of the Prometheus Obfuscator by levno-710"\n'
        )
        optimized = optimize_lua_code(code)
        self.assertIn('local s = "table.concat({\\"a\\", \\"b\\"})"', optimized)
        self.assertIn('-- table.concat({"a", "b"})', optimized)
        self.assertIn('local msg = "This Script is Part of the Prometheus Obfuscator by levno-710"', optimized)

    def test_alias_propagation_preserves_object_fields_and_strings(self):
        code = (
            "local service = getService()\n"
            "local alias = service\n"
            'local text = "alias"\n'
            "-- alias should stay\n"
            "obj.alias = 123\n"
            "obj:alias()\n"
            "doSomething(alias)\n"
        )
        optimized = optimize_lua_code(code)
        self.assertIn('local text = "alias"', optimized)
        self.assertIn("-- alias should stay", optimized)
        self.assertIn("obj.alias = 123", optimized)
        self.assertIn("obj:alias()", optimized)
        self.assertIn("doSomething(service)", optimized)

    def test_alias_propagation_chaining_and_mutability(self):
        # Case 1: Chained immutable aliases: local b = a, local c = b -> print(c) resolves to print(a)
        chain_code = (
            "local a = getSomething()\n"
            "local b = a\n"
            "local c = b\n"
            "print(c)\n"
        )
        opt_chain = optimize_lua_code(chain_code)
        self.assertNotIn("local b = a", opt_chain)
        self.assertNotIn("local c = b", opt_chain)
        self.assertIn("print(a)", opt_chain)

        # Case 2: Mutated/reassigned source: a is reassigned, so local b = a must NOT be eliminated
        mut_code = (
            "local a = 1\n"
            "local b = a\n"
            "a = 2\n"
            "print(b)\n"
        )
        opt_mut = optimize_lua_code(mut_code)
        self.assertIn("local b = a", opt_mut)
        self.assertIn("a = 2", opt_mut)
        self.assertIn("print(b)", opt_mut)

    def test_alias_propagation_scope_awareness(self):
        # Case 1: Function parameter shadowing
        fn_code = (
            "local a = getSomething()\n"
            "local b = a\n"
            "function test(a)\n"
            "    return b + a\n"
            "end\n"
        )
        opt_fn = optimize_lua_code(fn_code)
        # b inside function test(a) must NOT be replaced by a because parameter a shadows outer a
        self.assertIn("return b + a", opt_fn)

        # Case 2: Inner block local shadowing
        block_code = (
            "local a = getSomething()\n"
            "local b = a\n"
            "do\n"
            "    local a = 2\n"
            "    print(b)\n"
            "end\n"
        )
        opt_block = optimize_lua_code(block_code)
        self.assertIn("local b = a", opt_block)
        self.assertIn("print(b)", opt_block)

    def test_safe_eval_math_expr_prevents_power_dos(self):
        # Extreme exponent must return None without hanging or throwing memory errors
        self.assertIsNone(safe_eval_math_expr("9 ^ 999999999999"))
        self.assertIsNone(safe_eval_math_expr("9 ^ -10"))
        # Valid bit shift powers must evaluate properly
        self.assertEqual(safe_eval_math_expr("2 ^ 16"), 65536)
        self.assertEqual(safe_eval_math_expr("2 ^ 8"), 256)


class EngineStaticDecoderTests(unittest.TestCase):
    def test_unescape_and_escape_roundtrip(self):
        raw = r"\072\101\108\108\111"  # :ello -> 72='H', 101='e', 108='l', 108='l', 111='o'
        unescaped = StaticConstantDecoder.unescape_lua_string(raw)
        self.assertEqual(unescaped, "Hello")

        escaped = StaticConstantDecoder.escape_for_lua("Hello\nWorld")
        self.assertEqual(escaped, r'"Hello\nWorld"')

    def test_base64_decode_custom_lookup(self):
        decoder = StaticConstantDecoder()
        # Build standard 64 charset
        chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
        lookup = {ch: i for i, ch in enumerate(chars)}

        # Base64 "SGVsbG8=" -> "Hello"
        decoded = decoder.decode_base64("SGVsbG8=", lookup)
        self.assertEqual(decoded, b"Hello")

    def test_base85_decode_custom_lookup(self):
        decoder = StaticConstantDecoder()
        # In Prometheus: 85 printable characters
        chars = (
            "!\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ"
            "[\\]^_`abcdefghijklmnopqrstu"
        )
        lookup = {ch: i for i, ch in enumerate(chars)}

        # Prometheus Base85 encodes 4 bytes into 5 chars:
        # For 'test': bytes: 116, 101, 115, 116 -> value = 1952805748
        # 1952805748 in base 85: codes [37, 34, 69, 45, 23] -> chars:
        encoded = "".join(chars[c] for c in [37, 34, 69, 45, 23])
        decoded = decoder.decode_base85(encoded, lookup)
        self.assertEqual(decoded, b"test")

    def test_unrotate_array(self):
        decoder = StaticConstantDecoder()
        orig = [1, 2, 3, 4, 5]
        rotated = [4, 5, 1, 2, 3]
        unrotated = decoder.unrotate_array(rotated, shift=2, length=5)
        self.assertEqual(unrotated, orig)

    def test_detect_rotate_with_math_and_hex(self):
        decoder = StaticConstantDecoder()
        snippet = "for i, v in ipairs({{1, 0x100}, {1, (0x10 + 4)}, {20 + 1, 0x100}}) do"
        rotate_info = decoder.detect_rotate(snippet)
        self.assertIsNotNone(rotate_info)
        shift, length = rotate_info
        self.assertEqual(shift, 20)
        self.assertEqual(length, 256)

    def test_prometheus_stream_decryption(self):
        decoder = StaticConstantDecoder()
        # Test PRNG stream cipher round-trip with arbitrary keys
        param_mul_45 = 125
        param_add_45 = 654321
        param_mul_8 = 45
        secret_key_8 = 123
        seed = 9876543210
        expected = b"Epimetheus Prometheus Decryption Test"

        # Encrypt with Prometheus cipher formula
        state_45 = seed % 35184372088832
        state_8 = seed % 255 + 2
        prev_values = []

        def get_rnd():
            nonlocal state_45, state_8, prev_values
            if not prev_values:
                state_45 = (state_45 * param_mul_45 + param_add_45) % 35184372088832
                while True:
                    state_8 = (state_8 * param_mul_8) % 257
                    if state_8 != 1:
                        break
                r = state_8 % 32
                shift = 13 - (state_8 - r) // 32
                n_base = (state_45 // (1 << shift)) % 4294967296 if shift >= 0 else (state_45 * (1 << (-shift))) % 4294967296
                n = n_base / (1 << r)
                rnd = int((n % 1.0) * 4294967296) + int(n)
                low_16 = rnd % 65536
                high_16 = (rnd - low_16) // 65536
                prev_values = [low_16 % 256, (low_16 - low_16 % 256) // 256, high_16 % 256, (high_16 - high_16 % 256) // 256]
            return prev_values.pop()

        encrypted = bytearray()
        prev = secret_key_8
        for b in expected:
            rnd = get_rnd()
            encrypted.append((b - (rnd + prev)) % 256)
            prev = b

        decrypted = decoder.decrypt_prometheus_stream(
            bytes(encrypted),
            seed=seed,
            param_mul_45=param_mul_45,
            param_add_45=param_add_45,
            param_mul_8=param_mul_8,
            secret_key_8=secret_key_8,
        )
        self.assertEqual(decrypted, expected)


class EngineSyntaxNormalizerTests(unittest.TestCase):
    def test_rewrite_compound_assignments(self):
        from engine.syntax_normalizer import normalize_luau_syntax

        code = "local a = 1\na += 5\nb -= 2\nc *= 10\nd /= 2\ne %= 3\nf ^= 2\ng ..= 'test'\n"
        normalized = normalize_luau_syntax(code)
        self.assertIn("a = a + 5", normalized)
        self.assertIn("b = b - 2", normalized)
        self.assertIn("c = c * 10", normalized)
        self.assertIn("d = d / 2", normalized)
        self.assertIn("e = e % 3", normalized)
        self.assertIn("f = f ^ 2", normalized)
        self.assertIn("g = g .. 'test'", normalized)

    def test_preserve_string_literals_in_syntax_normalizer(self):
        from engine.syntax_normalizer import normalize_luau_syntax

        code = 'local s = "do += not -= touch *= this"\n'
        normalized = normalize_luau_syntax(code)
        self.assertEqual(normalized, code)

    def test_strip_type_annotations(self):
        from engine.syntax_normalizer import normalize_luau_syntax

        code = (
            "type Point = { x: number, y: number }\n"
            "export type UserID = string\n"
            "type MultilineConfig = {\n"
            "    host: string,\n"
            "    port: number,\n"
            "}\n"
            "local x: number = 100\n"
            "local y: string? = 'abc'\n"
            "local z: Vector3\n"
            "function calculate(a: any, b: number): boolean return true end\n"
            "local function get_pair(k: string): (number, string) return 1, k end\n"
            "function complex_param(p: {x: number, y: string}, count: number): boolean return true end\n"
        )
        normalized = normalize_luau_syntax(code)
        self.assertNotIn("type Point", normalized)
        self.assertNotIn("export type UserID", normalized)
        self.assertNotIn("type MultilineConfig", normalized)
        self.assertNotIn("host: string", normalized)
        self.assertIn("local x = 100", normalized)
        self.assertIn("local y = 'abc'", normalized)
        self.assertIn("local z\n", normalized)
        self.assertIn("function calculate(a, b) return true end", normalized)
        self.assertIn("local function get_pair(k) return 1, k end", normalized)
        self.assertIn("function complex_param(p, count) return true end", normalized)

    def test_type_stripping_preserves_literals_and_comments(self):
        from engine.syntax_normalizer import normalize_luau_syntax

        code = (
            'local s1 = "local x: number = 5"\n'
            'local s2 = "function f(a: number): boolean"\n'
            '-- local x: number = 5\n'
            '--[[ function f(a: number): boolean ]]--\n'
            'local x: number = 10\n'
        )
        normalized = normalize_luau_syntax(code)
        self.assertIn('local s1 = "local x: number = 5"', normalized)
        self.assertIn('local s2 = "function f(a: number): boolean"', normalized)
        self.assertIn('-- local x: number = 5', normalized)
        self.assertIn('--[[ function f(a: number): boolean ]]--', normalized)
        self.assertIn('local x = 10', normalized)

    def test_long_bracket_strings_and_comments(self):
        from engine.syntax_normalizer import normalize_luau_syntax

        code = (
            'local s1 = [=[function f(a: number): boolean]=]\n'
            'local s2 = [==[raw [[nested]] code]==]\n'
            '--[=[ comment with ]] inside ]=]\n'
            '--[==[ deep [[nested]] comment ]==]\n'
            'local x: number = 20\n'
        )
        normalized = normalize_luau_syntax(code)
        self.assertIn('local s1 = [=[function f(a: number): boolean]=]', normalized)
        self.assertIn('local s2 = [==[raw [[nested]] code]==]', normalized)
        self.assertIn('--[=[ comment with ]] inside ]=]', normalized)
        self.assertIn('--[==[ deep [[nested]] comment ]==]', normalized)
        self.assertIn('local x = 20', normalized)

    def test_multiline_function_parameters(self):
        from engine.syntax_normalizer import normalize_luau_syntax

        code = (
            "function foo(\n"
            "    a: number,\n"
            "    b: string\n"
            "): boolean\n"
            "    return true\n"
            "end\n"
        )
        normalized = normalize_luau_syntax(code)
        self.assertIn("function foo(a, b)", normalized)
        self.assertNotIn("a: number", normalized)
        self.assertNotIn("b: string", normalized)

    def test_generic_functions(self):
        from engine.syntax_normalizer import normalize_luau_syntax

        code = (
            "function identity<T>(val: T): T\n"
            "    return val\n"
            "end\n"
        )
        normalized = normalize_luau_syntax(code)
        self.assertIn("function identity(val)", normalized)
        self.assertNotIn("<T>", normalized)

    def test_nested_return_types(self):
        from engine.syntax_normalizer import normalize_luau_syntax

        code = (
            "function create_obj(n: number): {x: {y: string}}\n"
            "    return {x = {y = 'hello'}}\n"
            "end\n"
        )
        normalized = normalize_luau_syntax(code)
        self.assertIn("function create_obj(n)", normalized)
        self.assertNotIn(": {x: {y: string}}", normalized)
        self.assertIn("return {x = {y = 'hello'}}", normalized)

    def test_multiline_union_type_aliases(self):
        from engine.syntax_normalizer import normalize_luau_syntax

        code = (
            "type Composite = \n"
            "    { x: number }\n"
            "    & { y: string }\n"
            "    | { z: boolean }\n"
            "local a = 1\n"
        )
        normalized = normalize_luau_syntax(code)
        self.assertNotIn("Composite", normalized)
        self.assertNotIn("& { y: string }", normalized)
        self.assertNotIn("| { z: boolean }", normalized)
        self.assertIn("local a = 1", normalized)

    def test_collision_safe_placeholders(self):
        from engine.syntax_normalizer import normalize_luau_syntax

        code = (
            "local __EPIMETHEUS_STR_0__ = 123\n"
            'local s = "hello"\n'
        )
        normalized = normalize_luau_syntax(code)
        self.assertIn("local __EPIMETHEUS_STR_0__ = 123", normalized)
        self.assertIn('local s = "hello"', normalized)

    def test_function_type_variable_annotations(self):
        from engine.syntax_normalizer import normalize_luau_syntax

        code = (
            "local cb: (amount: number) -> number\n"
            "local cb2: (amount: number) -> number = function(x) return x end\n"
            "local x: (number, string) -> boolean\n"
            "local f: <T>(T) -> T = id\n"
        )
        normalized = normalize_luau_syntax(code)
        self.assertIn("local cb\n", normalized)
        self.assertIn("local cb2 = function(x) return x end", normalized)
        self.assertIn("local x\n", normalized)
        self.assertIn("local f = id", normalized)
        self.assertNotIn("-> number", normalized)
        self.assertNotIn("<T>(T)", normalized)

    def test_type_cast_operator(self):
        from engine.syntax_normalizer import normalize_luau_syntax

        code = (
            "local x = something :: number\n"
            "local y = (val :: any):Method()\n"
            "local a = value :: (number) -> string\n"
            "local b = value :: (string, number) -> boolean\n"
            "local c = (fn :: (number) -> string):Call()\n"
            "return result :: boolean\n"
        )
        normalized = normalize_luau_syntax(code)
        self.assertIn("local x = something\n", normalized)
        self.assertIn("local y = (val):Method()\n", normalized)
        self.assertIn("local a = value\n", normalized)
        self.assertIn("local b = value\n", normalized)
        self.assertIn("local c = (fn):Call()\n", normalized)
        self.assertIn("return result\n", normalized)
        self.assertNotIn("::", normalized)
        self.assertNotIn("-> string", normalized)
        self.assertNotIn("-> boolean", normalized)

    def test_compound_assignment_with_complex_rhs(self):
        from engine.syntax_normalizer import normalize_luau_syntax

        code = "x += a + b\ny += foo(bar) + qux\nz *= a * b\n"
        normalized = normalize_luau_syntax(code)
        self.assertIn("x = x + (a + b)", normalized)
        self.assertIn("y = y + (foo(bar) + qux)", normalized)
        self.assertIn("z = z * (a * b)", normalized)

    def test_typed_multi_local_declarations(self):
        from engine.syntax_normalizer import normalize_luau_syntax

        code = (
            "local x: number, y: string = 1, 2\n"
            "local a: number, b: string\n"
            "local p: (number) -> string, q: boolean = f, true\n"
        )
        normalized = normalize_luau_syntax(code)
        self.assertIn("local x, y = 1, 2", normalized)
        self.assertIn("local a, b\n", normalized)
        self.assertIn("local p, q = f, true", normalized)

    def test_function_return_type_with_arrow(self):
        from engine.syntax_normalizer import normalize_luau_syntax

        code = (
            "function f(): (number) -> string\n"
            "    return 'val'\n"
            "end\n"
        )
        normalized = normalize_luau_syntax(code)
        self.assertIn("function f()", normalized)
        self.assertNotIn("-> string", normalized)


class EngineConstantInlinerTests(unittest.TestCase):
    def test_detect_wrapper_and_inline_constants(self):
        from engine.constant_inliner import inline_constants_in_code

        code = """
local ARR = { "Players", "Workspace", "Lighting" }
local function get_c(arg)
    return ARR[arg + 10]
end

local s1 = get_c(-9)
local s2 = get_c(-8)
local s3 = get_c(-7)
"""
        inlined = inline_constants_in_code(code, constants=["Players", "Workspace", "Lighting"])
        self.assertIn('local s1 = "Players"', inlined)
        self.assertIn('local s2 = "Workspace"', inlined)
        self.assertIn('local s3 = "Lighting"', inlined)

    def test_unwrap_proxified_locals(self):
        from engine.constant_inliner import ConstantInliner

        inliner = ConstantInliner()
        code = 'local p = setmetatable({ ["abc"] = 123 }, { __index = function() end })'
        unwrapped = inliner.unwrap_proxified_locals(code)
        self.assertEqual(unwrapped, "local p = 123")

    def test_inline_constants_in_code_unwraps_proxified_locals(self):
        from engine.constant_inliner import inline_constants_in_code

        code = 'local val = setmetatable({ ["key"] = "my_value" }, { __index = function() end })\n'
        res = inline_constants_in_code(code)
        self.assertIn('local val = "my_value"', res)
        self.assertNotIn("setmetatable", res)


if __name__ == "__main__":
    unittest.main()
